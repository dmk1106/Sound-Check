# Project state

Read this first at the start of every iteration; update it at the end.
Keep it short.

## Where we are

| Phase | Status |
|---|---|
| 1. Physics prototype | **Done** (it. 1), toy art pass (it. 2) |
| 2. Moving day | **Playable** (it. 3), flow changed in it. 4: load at home -> studio -> gig, no unloading at the studio |
| 3. Apartment | **Basic** (it. 4): gig board menu, catalogue (8 items) that delivers physical furniture / wall pieces |
| 4. First performance | **Playable**: Cat Alley + Moon Diner (both 0 fans), the bandshell, Skyline Tower balcony (150 fans), busking at Hachi Plaza (it. 7) |
| 5. Rhythm game | **Basic** (it. 4): 5 lanes (D F J K L), 5 original songs x 3 charts, difficulty menu |
| 6. Career loop | **Basic**: money, fans, 7 gigs that need specific instruments, 3 fan-gated areas |
| 7. Stores / upgrades | **Basic**: one store, 7 instruments on physical stands |
| 8. City | **Rebuilt** (it. 7): organic street plan with districts, railway viaduct and trains, landmarks, round minimap with a route along the streets. It. 8: Kenney building bays and Quaternius trees, Central Park behind the house (replaces the creek and shrine), fenced home yard with a back gate, a white route line on the ground, knockable street lamps. Still alive as in it. 5: walkers, rag dolls, cats, traffic, soundscape |
| 9. Polish | No saving (settings and park songs are saved). The Harbour is an empty street behind its gate. No cleaning robot yet. |

## What works now

- **Player** (`player/player.gd`): RigidBody3D capsule on a ray "ride spring".
  Faces where it walks; camera only sets what "forward" means for the keys.
  `enter_vehicle()` / `exit_vehicle()` take the body out of the world while driving.
- **Character** (`player/character_model.tscn`, posed by `player/player_visual.gd`):
  George's rigged model `player/model/main_character.glb` (Mixamo-style bone
  names, `Walking` and `Running` clips), drawn with `art/toy_textured.gdshader`.
  No AnimationPlayer: the script samples both clips itself at a phase driven by
  distance walked (feet don't slide), blends rest / walk / run by speed, then
  adds lean, waddle, head wobble and glance, squash, sitting and airborne legs,
  and two-bone IK arms (idle springs, reach, hold; stretch up to 1.35x).
  Blinks / squints with two eyelid ellipsoids on a head BoneAttachment3D.
  Physics-tick state, blended per frame (bone poses aren't interpolated by the engine).
- **Hands** (`player/grab_controller.gd`): hold grab = spring pulling the item's
  grab point to a spot in front of the character (its facing, never the camera).
  Light (< `two_hand_mass`): carried in front. Heavy: the character faces the
  item and it trails behind. Force caps decide carry vs drag (lift 200 N, pull 700 N).
- **Interact** (`world/interactable.gd`, `player/interactor.gd`): E uses the
  nearest Interactable in range. Not while holding (E then raises the item).
- **Truck** (`vehicles/truck.gd`): RigidBody3D locked to the ground plane
  (no Y movement, no tipping), arcade steering in `_integrate_forces`. Frozen
  static whenever nobody drives, so it stays put and loads like a building.
  Roll-up door = a collider that shrinks; ramp only solid when fully out and
  only out while parked with the door open. Cargo = whatever is in `CargoZone`.
  `_settle_cargo()`: back open + pulling away / cornering pushes things lighter
  than `loose_mass` toward the opening (they fall out and stay on the road);
  back shut damps sliding so nothing is rammed through a wall. Headlights on while driving.
- **Places** (`levels/`): studio (interior with cutaway; gig board, catalogue
  laptop, `Delivery` marker, hidden wall pieces under `Mesh/Extras`), music
  store (7 stands), two venues - `alley.tscn` (`venue_id` alley) and
  `venue.tscn` (bandshell). A venue = `StageZone` + `Mic` + `Crowd` + `Parking`.
- **Career** (`game/career.gd`, autoload): money, fans, `GIGS` (venue, song,
  `needs` / `bonus` gear kinds, `needs_fans`), `AREAS` (fan thresholds).
- **Flow** (`game/game_flow.gd`): LOAD_HOME -> DRIVE_TO_STUDIO -> GET_GIG ->
  LOAD_GIG (skipped when the needed kinds are already in the truck) ->
  DRIVE_TO_VENUE -> SET_UP -> PLAY -> PACK_UP -> DRIVE_BACK -> FREE. It only
  *reads* where things physically are. The one real gate: the mic needs the
  booked gig's `needs` on stage.
- **Menus** (`ui/menu.gd`, `GameMenu.open(...)`): one keyboard list menu for the
  gig board, difficulty, catalogue and pause. `game/settings.gd` (autoload):
  Esc pauses; music volume slider drives the "Music" audio bus; saved to `user://`.
- **Show** (`venue/venue.gd`, `ui/rhythm_game.gd`, `audio/songs.gd`): difficulty
  menu -> note highway (right side of the screen) -> `Career.finish_job(accuracy,
  gear quality, bonus gear, difficulty pay)`. Crowd Npcs follow `game.mood`.
- **Route line** (`world/route_line.gd` under GameFlow): a soft white ribbon
  with drifting chevrons on the ground along `RoadNetwork.route()` to
  `GameFlow.route_target`, the same route as the minimap; from the truck while
  driving (wider), from the player on foot. Short links off the road are only
  drawn when a ray says they don't pass through walls or fences.
- **Street lamps** (`world/knock_lamp.gd`): the truck bends one at 3 m/s and
  topples it at 7.5 m/s; its collision switches off at the hit (never blocks
  the truck) and it stands back up 30 s later when nobody is near.
  `tests/lamp_test.tscn`.
- **People** (`npc/npc.gd`): one scene, modes WALK / STAND / SIT, looks and
  timing from `look_seed`. Walkers are layer 5 only (ghosts to the truck and to
  gear, solid to the player) and jump aside for the truck; standers / sitters are solid.
- **Traffic** (`vehicles/traffic_car.gd`, `world/traffic.gd`): kinematic cars on
  two loops (one each way round the block). A box swept in front stops them
  for anything dynamic; stop at corners; back off 1.5 m when stuck nose to nose.
- **Fan gates** (`world/fan_gate.gd`): roadblock that vanishes at its area's fan count.
- **Shop**: `Equipment.for_sale` = frozen, not grabbable, has a price-tag
  Interactable. Buying just unfreezes it. No stock list, no inventory.
- **Catalogue** (`game/studio_catalogue.gd`): buys spawn a real grabbable at
  `Delivery`, or switch on a wall piece. Nothing is placed for you.
- **HUD** (`ui/hud.gd`): objective, money/fans, context prompts, toasts; truck
  contents only while driving. Hidden during a show.
- **Look** (`art/`): `toy.gdshader` (with `light` = emission for neon) on rounded
  `@tool` PrimitiveMesh scripts. Night: dim moon + ~80 unshadowed OmniLights,
  glow, SSR, fog (`art/toy_environment.tres`); `building.gdshader` draws lit
  windows; `ground.gdshader` has `wetness` / puddles; rain is one GPUParticles3D
  that follows the camera and hides indoors.
- **City** (`levels/city.tscn`) is **generated**: edit the plan
  (`tools/city/plan.gd`: junctions, roads with kind / width / district,
  fan-gated areas, where each place sits, reserved ground, railway, traffic
  loops) and rerun `godot --headless --path . res://tools/city_builder.tscn`
  (then `--import`). Never hand-edit city.tscn: the next build replaces it.
  The builder keeps the nodes with scripts / state (House, Studio, MusicStore,
  venues, People, Cats, Traffic, gates, Debug, CentralPark/Seat...) and moves them;
  everything else (ground paint, ~290 buildings, street props, railway, the
  park, the home yard, skyline, walls) is rebuilt. Pieces: `tools/city/layout.gd` (smoothing,
  occupancy grid, building lots), `ground.gd` (road strips, junctions, zebra
  crossings), `buildings.gd` (+ landmarks: Hachi Vision screen, Grand theatre,
  karaoke pagoda, Club Orbit), `streets.gd` (lamps, poles and wires, lanterns,
  street-name signs, traffic lights, vending machines, clutter), `rail.gd`
  (viaduct, Cat Alley arches, `world/train.gd`), `people.gd` (pavement network,
  traffic loops), `park.gd` (Central Park), `plan_image.gd` (the minimap picture).
  `kit.place()` drops in a pack model (glTF / GLB) and caches its mesh as a
  .res in `art/meshes/imported/`. 84 lots use Kenney City Builder bays
  (`art/kenney`, recoloured by `art/kenney_building.gdshader`); trees, bushes,
  flowers and rocks are Quaternius (`art/nature`). Asset record:
  `/mnt/project-files/notes/asset-usage-2026-10-10.md`. `creek.gd` is no longer used.
- **Road network** (`world/road_network.gd`, group `road_network`): every
  road's centre line, width, kind, name and fan area, baked by the builder.
  `route(from, to)` = A* along drivable roads, skipping shut fan gates;
  `street_name_at()`, `road_at()`, `distance_to_roads()`. The minimap, the
  ambience and the tests' drives all use it, so they match the paint.
- **Minimap** (`ui/minimap/minimap.gd`, in the HUD, bottom left): round, turns
  with the camera, follows you on foot and the truck while driving (zooms out
  with speed). Draws `ui/minimap/city_map.png` cut to a circle, a route line to
  `GameFlow.route_target` (the destination, or the studio / venue parking
  when there is none; re-routed when that changes or you wander off), the
  goal (an arrow on the rim when off the map, green "You're here" when within
  arrive distance), the truck, studio / shop / venue icons, N, the street name
  and distance to go.
- **Route line** (`world/route_line.gd` under GameFlow): a soft white ribbon
  with drifting chevrons on the ground along `RoadNetwork.route()` to
  `GameFlow.route_target`, the same route as the minimap; from the truck while
  driving (wider), from the player on foot. Short links off the road are only
  drawn when a ray says they don't pass through walls or fences.
- **Street lamps** (`world/knock_lamp.gd`): the truck bends one at 3 m/s and
  topples it at 7.5 m/s; its collision switches off at the hit (never blocks
  the truck) and it stands back up 30 s later when nobody is near.
  `tests/lamp_test.tscn`.
- **People** (`npc/npc.gd`, `world/sidewalks.gd`): walkers route with AStar3D
  over a hand-laid pavement network (pavement / crossing / door / spot nodes),
  keep right, steer round each other, the player and the truck, wait at
  crossings, vanish into shops for a bit. All NPCs are on layer 5 only: the
  truck does not collide with them. `_hit_by_truck()` (leading end of a truck
  doing 2 m/s or more) -> `knock_down()`: a temporary RigidBody3D "tumbler"
  takes the body, `Career.fine(5)`, floating "-$5"; then get up, dizzy, 2 s of
  grace, walk back (standers / sitters) or carry on (walkers).
- **Sound** (all synthesised): buses Master <- Music; Master <- Sound <-
  Ambience (low-pass) <- Rain / City / Vehicle / Crowd / Nature, and Sound <-
  SFX (reverb), made in `Settings` (`Settings.CATEGORIES`). `game/ambience.gd`
  mixes rain / city / room beds by zone (street, alley, park, indoors, driving) and
  plays footsteps; everything with a place is an AudioStreamPlayer3D in the
  scene (creek, air-con, club bass, crowd murmur, tyres, engine, radio, lift).
- **Settings** (`game/settings.gd`, `ui/menu.gd`): menus take the mouse; slider
  rows drag continuously; toggle rows. Sliders: Music, Sound (all), then one
  per category bus; 0 mutes that bus only. Saved in `user://settings.cfg`. Truck radio: R while driving.
- **Diner** (`levels/diner.tscn`) and **tower** (`levels/tower.tscn`) are
  Venues like the others. The tower's `Lift` (`world/lift.gd`) is an
  AnimatableBody3D platform; gear rides on it as ordinary rigid bodies.
  `Venue.camera_behind` puts the show camera behind the performer.
- **Home yard** (`_home_yard()` in the builder): picket fence all round the
  house with a drive gap for the truck on Creek Lane and the wonky back gate
  (`world/garden_gate.gd`: E opens / shuts; the AnimatableBody3D leaf turns
  itself, so it really blocks and shoves).
- **Central Park** (`tools/city/park.gd`, node `CentralPark`): paths from the
  back gate, Mill Road and a gap off Creek Lane; a stone fountain plaza; a pond
  with a deck; an octagonal music pavilion on its shore (roof lifts away via
  InteriorCutaway when you're inside); the old maple on a knoll; the Ramble
  woods east of the viaduct; lamps, benches, fireflies, Nature-bus sounds.
  Song-writing seats: the pavilion bench (`Seat`, "sit in the pavilion") and
  the bench under the maple (`PoolSeat`). `world/seat.gd` (sit, E = `ui/song_maker.gd`, Space =
  up); `game/song_book.gd` saves sketches to `user://songs.json`.
- **Debug button** (`world/debug_button.gd`) behind the old house: max money
  and fans. Keep until asked to remove.
- **Cats** (`npc/cat.gd`): plain Node3D, no physics; walk / sit / watch / run.
- **Camera**: pitch up to 68 deg; past 8 deg the arm stops orbiting and the camera tilts.
- **Tests** (`tests/`): `playtest` (the loop, 136 checks), `playtest_city` (everything
  from it, 141 checks), `drive_test` (drives to every place along the streets, 12 checks),
  chaos soak with joyride, `character_test` (the model, 17 checks).
  Run with stdbuf -oL to see progress; a full playtest takes about 10-15 minutes.

## Conventions

- Units: metres, kilograms, newtons, seconds. -Z is forward (the truck's nose too).
- Physics layers: 1 `world`, 2 `player`, 3 `props`, 4 `camera_blocker`, 5 `npc`.
  The truck and traffic cars are on `world`. Gear: layer 3, mask 1+2+3 (not walkers).
- Groups: `player`, `truck`, `grabbable`, `equipment`, `interactable`, `venue`,
  `studio`, `studio_parking`, `venue_parking`, `store_parking`, `game_flow`,
  `traffic_car`, `decor`, `npc`, `cat`, `sidewalks`, `ambience`.
- The city is flat: roads, pads and sidewalks are paint on one ground collider.
- The city is made from `tools/city/plan.gd` by the builder; change the plan, not the scene.
- Places (venues, studio, store) are positioned by the plan; spots inside them
  are in their own frame. Tests use `at(node, x, z)` and drive with
  `drive_to()` / `pull_out()` (RoadNetwork routes), not world coordinates.
- Scenes are the source of truth; tunables are exported properties.
- Visual-only motion runs in `_physics_process` (physics interpolation smooths it).
- Cutaway materials don't cast shadows; add a `shadows only` mesh instead.
- Wall decorations are flat single-sided panels with the cutaway shader; Label3D
  signs are single-sided.

## Decisions and why

- **Truck on a plane, velocity set directly**: can't flip, sink or get stuck on
  a kerb; still a real body that bumps things and carries loose cargo.
- **Cargo colliders thicker than they look, and overlapping at every corner**:
  thin things got squeezed through a 6 cm door, and a guitar head wedged itself
  into the seam where wall and floor only just met.
- **No continuous collision detection on gear while it rides in a moving truck**
  (`Truck._update_cargo`): the CCD sweep hits the truck itself, holds the item
  back for a step, and the door drives through it. This was the real cause of
  "gear escapes a shut truck at speed".
- **Thin discs are convex hulls, not CylinderShape3D** (builder `col_disc`).
- **People don't collide with gear or the truck**: a pedestrian brushing a
  moving truck would otherwise knock the cargo about from outside. Being hit is
  a footprint test instead, and only the end moving into them counts, so
  nobody is "run over" by walking into the side of a truck pulling away.
- **Rag doll = one tumbling capsule with floppy limbs**, not a jointed skeleton:
  cheap, can't explode, reads as slapstick.
- **Interact is off while holding something**, so the guitar goes on the lift
  floor before you press the panel (the panel reaches the whole platform).
- **Diner sits back from the street on a forecourt** so the parked truck and
  its ramp don't block the pavement or the door.
- **Alley walls are solid but not camera blockers**, with a see-through shader:
  the camera can sit "inside" a building and still see you.
- **Lamp posts stand at the back of the pavement**: at the kerb they caught the truck.
- **Heavy things trail behind instead of being steered by the camera**: arms
  must follow the character, so "walk and it follows" is the whole control.
- **Shop = physical stands; one tiny list menu for every choice**: bought gear
  still has to be carried to the truck, bought furniture dragged into place.
- **Rhythm clock = frame time, nudged toward the audio clock**: tests can run
  faster than real time with `sync_to_audio = false`.
- **Plain Lambert shading, no wrap / backlight**: wrap fights the shadow map.
- **Character clips sampled by hand, not an AnimationTree**: the phase follows
  distance travelled so walk and run stay in step with the body at any speed,
  and the procedural layers (IK arms, lean, head) need the pose in script anyway.
  The clips' arms are used only while walking free-handed.
- **Eyelids are meshes, not a texture trick**: the eyes are painted into an
  auto-unwrapped atlas, so a shader can't find them; two skin-coloured
  ellipsoids with a lash line, scaled from the top of the eye, read as a blink.

## Known issues / rough edges

- Nothing is saved (except the music volume); Backspace or quitting starts a new career.
- The night look was only checked with a software renderer. Light count
  (~80 small unshadowed lights), SSR and glow are untested on a real GPU;
  the Compatibility renderer shows at most 32 lights per object and no SSR.
- Wet-road reflections are mostly light glints: SSR only mirrors what is on screen.
- Cat Alley is a through route (Canal Street to Grand Street) only just wider
  than the truck: the turn in off Canal Street wants care, and you leave by
  the far end.
- The minimap picture is baked at 0.5 m per pixel; rebuild the city to refresh it.
- Traffic is simple: cars never overtake or go round. Park in a lane and they
  queue behind you. They are immovable: ram one and the truck stops dead.
- Pedestrians have no collision with scenery: they stay on the pavement
  network and steer round people and the truck, but will walk through a bench,
  a dropped amp or a post that sits on their line. "Entering a building" is
  vanishing at the door. Money can go negative from fines.
- Park songs can be written, played back and saved, but not yet performed at a gig.
- The diner front reads dark at night. The character's black outfit is lifted
  a little by `light` on its material; check it on a real GPU.
- Character clips: Walking / Running from the GLB; Sitting, Guitar, Piano and
  Drums Playing are George's Mixamo FBX clips, extracted by
  `tools/extract_clips.gd` to `player/anims/*.res` and retargeted at load by
  `player/mocap_clip.gd` (world-space turn per bone, then limbs swung to point
  like the source). Seats use Sitting; shows use the instrument on stage
  (`Player.performing`, set by the venue; piano / drums upper body only).
  Idle (breathing), jump, land, carry and drag are still procedural: the packs
  had no such clips. Shallow-water wading has no water to wade in any more.
- Seen from a steep side angle, a sliver of painted eye can show past a closed eyelid.
- All audio is synthesised and untested on real speakers: levels will want tuning by ear.
- The balcony show camera sits inside the tower wall (see-through shader).
- With the back open, a heavy amp loaded last can block the guitar from sliding
  out; at a corner both may go. Only things under 8 kg are actively shaken loose.
- The Harbour has a gate and a short street, nothing to do yet.
- Catalogue: one of each, no selling, no rotating furniture except by shoving it.
- Keyboard / drums / bass only matter as gig requirements and bonuses; every
  instrument plays the same note highway.
- The truck has no suspension, body roll or damage.
- Rhythm timing was only tested by a bot with the audio clock off; real audio
  latency is untested.
- Hauling a heavy thing round a tight corner can snag it and break the grip.
- Gamepad bindings exist but were only tested with simulated input.

## Next things to improve

Play it on a real GPU and with real speakers; tune light and sound levels.
Let a park song be played at a gig (`SongBook.to_chart`). Save/load. The
Harbour venue (the bay, cranes and containers are there). Guitar case on the
player's back as a cosmetic. The little cleaning robot. Instrument-specific
charts or sounds. A full-screen map on a key. Let a park song be played at
the pavilion for passers-by. Air guitar on stage could hold the real guitar.
