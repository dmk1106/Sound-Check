extends Node3D
## Entry scene. The city, the truck, the gear, the player and the HUD are
## separate scenes placed here; this script only starts a fresh career and
## handles the restart key.


func _enter_tree() -> void:
	Career.reset()


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed(&"restart"):
		get_tree().reload_current_scene()
