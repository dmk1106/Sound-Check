extends CanvasLayer
## The HUD: what to do next, money and fans, context prompts, and - only while
## driving - what is in the truck. It only listens to signals.

@onready var _objective_panel: Control = %ObjectivePanel
@onready var _objective: Label = %Objective
@onready var _money: Label = %Money
@onready var _fans: Label = %Fans
@onready var _cargo_panel: Control = %CargoPanel
@onready var _cargo: Label = %Cargo
@onready var _door_warning: Label = %DoorWarning
@onready var _prompt_panel: Control = %PromptPanel
@onready var _keys: Array[Control] = [%KeyA, %KeyB]
@onready var _key_labels: Array[Label] = [%KeyALabel, %KeyBLabel]
@onready var _texts: Array[Label] = [%TextA, %TextB]
@onready var _toast_panel: Control = %ToastPanel
@onready var _toast: Label = %Toast

var _hands: GrabController
var _interactor: Interactor
var _truck: Truck
var _player: Player
var _toast_time := 0.0


func _ready() -> void:
	var player := get_tree().get_first_node_in_group(&"player") as Player
	if player:
		_hands = player.hands
		_hands.focus_changed.connect(_refresh_prompt.unbind(1))
		_hands.grab_started.connect(_refresh_prompt.unbind(1))
		_hands.grab_ended.connect(_refresh_prompt.unbind(1))
		_interactor = player.get_node_or_null(^"Interactor")
		if _interactor:
			_interactor.focus_changed.connect(_refresh_prompt.unbind(1))
	_truck = get_tree().get_first_node_in_group(&"truck")
	if _truck:
		_truck.cargo_changed.connect(_refresh_truck.unbind(1))
		_truck.door_changed.connect(_refresh_truck.unbind(1))
		_truck.driver_changed.connect(_on_driver_changed.unbind(1))
	var flow := get_tree().get_first_node_in_group(&"game_flow") as GameFlow
	if flow:
		flow.objective_changed.connect(_on_objective_changed)
		_on_objective_changed(flow.objective)
	else:
		_objective_panel.visible = false
	for node in get_tree().get_nodes_in_group(&"venue"):
		var venue := node as Venue
		venue.show_started.connect(func() -> void: visible = false)
		venue.game_closed.connect(func() -> void: visible = true)
	Career.changed.connect(_refresh_stats)
	Career.message.connect(show_toast)
	Career.fined.connect(_on_fined.unbind(1))
	Settings.radio_changed.connect(_refresh_prompt.unbind(1))
	if player:
		_player = player
		player.seated_changed.connect(_refresh_prompt.unbind(1))
	_toast_panel.visible = false
	_refresh_stats()
	_refresh_truck()
	_refresh_prompt()


func _process(delta: float) -> void:
	if _toast_time > 0.0:
		_toast_time -= delta
		_toast_panel.modulate.a = clampf(_toast_time / 0.4, 0.0, 1.0)
		if _toast_time <= 0.0:
			_toast_panel.visible = false


func show_toast(text: String) -> void:
	_toast.text = text
	_toast_panel.visible = true
	_toast_time = 3.0
	_pop(_toast_panel)


func _on_objective_changed(text: String) -> void:
	_objective.text = text
	_objective_panel.visible = text != ""
	if text != "":
		_pop.call_deferred(_objective_panel)


func _refresh_stats() -> void:
	_money.text = "$%d" % Career.money if Career.money >= 0 else "-$%d" % -Career.money
	_fans.text = "%d fans" % Career.fans


func _on_driver_changed() -> void:
	_refresh_truck()
	_refresh_prompt()


# What's in the truck is only shown from the driver's seat.
func _refresh_truck() -> void:
	var driving := _truck != null and _truck.driver != null
	_cargo_panel.visible = driving
	if not driving:
		return
	var names := PackedStringArray()
	for item in _truck.get_loaded():
		names.append(item.display_name)
	_cargo.text = "empty" if names.is_empty() else ", ".join(names)
	_door_warning.visible = _truck.door_open


func _refresh_prompt() -> void:
	# Up to two prompts side by side: something to use, something to grab.
	var prompts: Array[PackedStringArray] = []
	if _truck and _truck.driver:
		prompts.append(PackedStringArray(["E", "get out"]))
		prompts.append(PackedStringArray(["R", "radio: %s" % ("on" if Settings.truck_radio else "off")]))
	elif _player and _player.seated:
		prompts.append(PackedStringArray(["E", "write a song"]))
		prompts.append(PackedStringArray(["Space", "get up"]))
	elif _hands and not _hands.is_holding():
		if _interactor and _interactor.focus:
			prompts.append(PackedStringArray(["E", _interactor.focus.prompt]))
		if _hands.focus:
			prompts.append(PackedStringArray(["Hold Left Mouse", "grab %s" % _hands.focus.display_name]))
	for i in 2:
		var used := i < prompts.size()
		_keys[i].visible = used
		_texts[i].visible = used
		if used:
			_key_labels[i].text = prompts[i][0]
			_texts[i].text = prompts[i][1]
	_prompt_panel.visible = not prompts.is_empty()


# Money just went: the counter flashes red.
func _on_fined() -> void:
	_pop(_money)
	_money.modulate = Color("ff5566")
	create_tween().tween_property(_money, "modulate", Color.WHITE, 0.9)


## A quick squash-and-settle, so changes get noticed.
func _pop(control: Control) -> void:
	control.pivot_offset = control.size * 0.5
	var tween := create_tween()
	tween.tween_property(control, "scale", Vector2(1.12, 1.12), 0.07)
	tween.tween_property(control, "scale", Vector2.ONE, 0.25).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
