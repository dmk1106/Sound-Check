class_name GameMenu
extends CanvasLayer
## A small keyboard-driven list menu, used for everything that needs a choice:
## the job board, difficulty, the studio catalogue, the pause menu.
##
##   var menu := GameMenu.open(self, "Title", [{"text": "...", "detail": "...", "disabled": false}, ...])
##   menu.chosen.connect(...)     # index of the picked row
##   menu.closed.connect(...)     # closed without / after picking
##
## A row with "slider": 0..1 is dragged with the mouse (or nudged with left /
## right); a row with "toggle": bool flips when picked. Everything can be
## clicked: the mouse pointer is shown while a menu is up.
## W/S or arrows move, E / Enter / Space pick, Esc / Q close.

signal chosen(index: int)
signal slider_changed(index: int, value: float)
signal toggled(index: int, on: bool)
signal closed

const FONT_BOLD := preload("res://art/fonts/fredoka_semibold.tres")
const FONT := preload("res://art/fonts/fredoka_medium.tres")
const INK := Color(0.09, 0.08, 0.16, 0.94)
const ACCENT := Color("ffd166")

static var _open_count := 0

var items: Array = []
var selected := 0

var _title := ""
var _hint := ""
var _board: Control
var _armed_frame := 0
var _player: Player
var _took_controls := false
var _is_closed := false
var _row_rects: Array[Rect2] = []
var _slider_rects := {}          # row index -> the bar's Rect2
var _dragging := -1
var _mouse_before := Input.MOUSE_MODE_CAPTURED


## Builds, shows and returns a menu. `host` only decides where it sits in the tree.
static func open(host: Node, title: String, rows: Array, hint := "W / S to move   ·   E to pick   ·   Esc to close") -> GameMenu:
	var menu := GameMenu.new()
	menu._title = title
	menu._hint = hint
	menu.items = rows
	host.add_child(menu)
	return menu


static func is_any_open() -> bool:
	return _open_count > 0


func _ready() -> void:
	layer = 20
	process_mode = Node.PROCESS_MODE_ALWAYS
	_open_count += 1
	_mouse_before = Input.mouse_mode
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	_armed_frame = Engine.get_process_frames() + 1
	# The player stands still while a menu is up.
	_player = get_tree().get_first_node_in_group(&"player") as Player
	if _player and _player.controls_enabled:
		_player.controls_enabled = false
		_took_controls = true
	_board = Control.new()
	_board.set_anchors_preset(Control.PRESET_FULL_RECT)
	_board.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_board.draw.connect(_draw_board)
	add_child(_board)
	selected = _next_enabled(-1, 1)


func _exit_tree() -> void:
	if not _is_closed:
		_release()


func close() -> void:
	if _is_closed:
		return
	_release()
	closed.emit()
	queue_free()


func _release() -> void:
	_is_closed = true
	_open_count = maxi(_open_count - 1, 0)
	if _open_count == 0:
		Input.mouse_mode = _mouse_before
	if _took_controls and is_instance_valid(_player):
		_player.controls_enabled = true


func _input(event: InputEvent) -> void:
	if _is_closed or Engine.get_process_frames() < _armed_frame:
		return
	if event is InputEventMouse:
		_mouse(event)
		return
	if not (event is InputEventKey or event is InputEventJoypadButton or event is InputEventAction):
		return
	var used := true
	if event.is_action_pressed(&"ui_cancel") or event.is_action_pressed(&"hold_lower"):
		close()
	elif event.is_action_pressed(&"ui_up", true) or event.is_action_pressed(&"move_forward"):
		selected = _next_enabled(selected, -1)
	elif event.is_action_pressed(&"ui_down", true) or event.is_action_pressed(&"move_back"):
		selected = _next_enabled(selected, 1)
	elif event.is_action_pressed(&"ui_left", true) or event.is_action_pressed(&"move_left"):
		_slide(-0.1)
	elif event.is_action_pressed(&"ui_right", true) or event.is_action_pressed(&"move_right"):
		_slide(0.1)
	elif event.is_action_pressed(&"interact") or event.is_action_pressed(&"ui_accept"):
		_pick(selected)
	else:
		used = event.is_pressed()   # swallow other key presses so nothing behind the menu reacts
	if used:
		get_viewport().set_input_as_handled()
	_board.queue_redraw()


func _pick(index: int) -> void:
	if index < 0 or items[index].has("slider") or items[index].get("disabled", false):
		return
	if items[index].has("toggle"):
		items[index].toggle = not items[index].toggle
		toggled.emit(index, items[index].toggle)
	else:
		chosen.emit(index)


## Where a slider's bar is on screen (empty until the menu has been drawn once).
func get_slider_rect(index: int) -> Rect2:
	return _slider_rects.get(index, Rect2())


## Where a row is on screen (empty until the menu has been drawn once).
func get_row_rect(index: int) -> Rect2:
	return _row_rects[index] if index >= 0 and index < _row_rects.size() else Rect2()


func _mouse(event: InputEventMouse) -> void:
	get_viewport().set_input_as_handled()
	var at := event.position
	var button := event as InputEventMouseButton
	if button and button.button_index == MOUSE_BUTTON_LEFT:
		if not button.pressed:
			_dragging = -1
			return
		for index: int in _slider_rects:
			if (_slider_rects[index] as Rect2).grow(12.0).has_point(at):
				selected = index
				_dragging = index
				_drag_to(at.x)
				return
		for index in _row_rects.size():
			if _row_rects[index].has_point(at) and not items[index].get("disabled", false):
				selected = index
				_pick(index)
				break
	elif event is InputEventMouseMotion:
		if _dragging >= 0:
			_drag_to(at.x)
		else:
			for index in _row_rects.size():
				if _row_rects[index].has_point(at) and not items[index].get("disabled", false):
					selected = index
	if _board:
		_board.queue_redraw()


# The slider follows the pointer exactly: no steps.
func _drag_to(x: float) -> void:
	var bar: Rect2 = _slider_rects[_dragging]
	var value := clampf((x - bar.position.x) / bar.size.x, 0.0, 1.0)
	items[_dragging].slider = value
	slider_changed.emit(_dragging, value)


func _slide(amount: float) -> void:
	if selected < 0 or not items[selected].has("slider"):
		return
	var value := clampf(snappedf(float(items[selected].slider) + amount, 0.1), 0.0, 1.0)
	items[selected].slider = value
	slider_changed.emit(selected, value)


func _next_enabled(from: int, step: int) -> int:
	var index := from
	for i in items.size():
		index = posmod(index + step, items.size())
		if not items[index].get("disabled", false):
			return index
	return from


func _draw_board() -> void:
	var view := _board.size
	var width := 620.0
	# Long menus (the settings) squeeze their rows to fit the screen.
	var row_h := clampf((view.y - 160.0) / maxf(items.size(), 1.0), 44.0, 62.0)
	var height := 96.0 + items.size() * row_h + 44.0
	var left := (view.x - width) * 0.5
	var top := (view.y - height) * 0.5
	_board.draw_rect(Rect2(Vector2.ZERO, view), Color(0.03, 0.02, 0.08, 0.55))
	_board.draw_style_box(_box(INK, 28), Rect2(left, top, width, height))
	_board.draw_string(FONT_BOLD, Vector2(left + 32.0, top + 54.0), _title, HORIZONTAL_ALIGNMENT_LEFT, -1, 32, ACCENT)
	_row_rects.clear()
	for i in items.size():
		var item: Dictionary = items[i]
		var y := top + 80.0 + i * row_h
		_row_rects.append(Rect2(left + 16.0, y, width - 32.0, row_h - 6.0))
		var disabled: bool = item.get("disabled", false)
		if i == selected:
			_board.draw_style_box(_box(Color(1, 1, 1, 0.12), 16), Rect2(left + 16.0, y, width - 32.0, row_h - 6.0))
			_board.draw_style_box(_box(ACCENT, 4), Rect2(left + 16.0, y + 10.0, 6.0, row_h - 26.0))
		var color := Color(1, 1, 1, 0.35) if disabled else Color.WHITE
		var has_detail: bool = item.get("detail", "") != ""
		_board.draw_string(FONT_BOLD, Vector2(left + 36.0, y + (25.0 if has_detail else row_h * 0.58)), item.text, HORIZONTAL_ALIGNMENT_LEFT, -1, 22, color)
		if has_detail:
			_board.draw_string(FONT, Vector2(left + 36.0, y + 46.0), item.detail, HORIZONTAL_ALIGNMENT_LEFT, width - 80.0, 15, Color(color, color.a * 0.7))
		if item.has("slider"):
			var bar := Rect2(left + width - 310.0, y + row_h * 0.355, 220.0, 12.0)
			_slider_rects[i] = bar
			_board.draw_style_box(_box(Color(1, 1, 1, 0.18), 6), bar)
			var value := float(item.slider)
			if value > 0.0:
				_board.draw_style_box(_box(ACCENT, 6), Rect2(bar.position, Vector2(bar.size.x * value, bar.size.y)))
			# The knob to grab.
			var knob := Vector2(bar.position.x + bar.size.x * value, bar.position.y + bar.size.y * 0.5)
			_board.draw_circle(knob, 13.0 if _dragging == i else 11.0, Color.WHITE)
			_board.draw_circle(knob, 6.0, ACCENT)
			_board.draw_string(FONT_BOLD, Vector2(bar.end.x + 14.0, y + row_h * 0.58), "%d%%" % roundi(value * 100.0), HORIZONTAL_ALIGNMENT_LEFT, -1, 20, Color.WHITE)
		elif item.has("toggle") or item.get("tag", "") != "":
			var tag: String = ("ON" if item.toggle else "OFF") if item.has("toggle") else item.tag
			var tag_width := FONT_BOLD.get_string_size(tag, HORIZONTAL_ALIGNMENT_LEFT, -1, 20).x
			_board.draw_string(FONT_BOLD, Vector2(left + width - 36.0 - tag_width, y + row_h * 0.58), tag, HORIZONTAL_ALIGNMENT_LEFT, -1, 20, Color(ACCENT, color.a))
	_board.draw_string(FONT, Vector2(left + 32.0, top + height - 20.0), _hint, HORIZONTAL_ALIGNMENT_LEFT, -1, 15, Color(1, 1, 1, 0.55))


func _box(color: Color, corner: int) -> StyleBoxFlat:
	var box := StyleBoxFlat.new()
	box.bg_color = color
	box.set_corner_radius_all(corner)
	box.anti_aliasing_size = 1.2
	return box
