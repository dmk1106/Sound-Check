class_name SongMaker
extends CanvasLayer
## A tiny step sequencer for sketching a tune: sixteen steps, five notes.
## Click a square (or move with the arrows and press E) to put a note there,
## Space plays the loop, and Save keeps it in the SongBook.
##
##   var maker := SongMaker.open(self)
##   maker.closed.connect(...)

signal closed
signal saved(song: Dictionary)

const FONT_BOLD := preload("res://art/fonts/fredoka_semibold.tres")
const FONT := preload("res://art/fonts/fredoka_medium.tres")
const INK := Color(0.09, 0.08, 0.16, 0.95)
const ACCENT := Color("ffd166")
const LANE_COLORS: Array[Color] = [Color("ff5d8f"), Color("ffd166"), Color("3ddbd9"), Color("7f8cff"), Color("c77dff")]
const NOTES: Array[AudioStream] = [preload("res://audio/sfx/note1.ogg"), preload("res://audio/sfx/note2.ogg"),
		preload("res://audio/sfx/note3.ogg"), preload("res://audio/sfx/note4.ogg"), preload("res://audio/sfx/note5.ogg")]
const TICK := preload("res://audio/sfx/tick.ogg")
const BUTTONS: Array[String] = ["Play", "Tempo", "Clear", "New", "Save", "Close"]

static var is_open := false

var song := {}
var playing := false
var cursor := Vector2i(0, 2)     # step, lane

var _board: Control
var _clock := 0.0
var _step := -1
var _cells: Array[Rect2] = []     # step * LANES + lane
var _button_rects: Array[Rect2] = []
var _song_rects: Array[Rect2] = []
var _songs: Array = []
var _mouse_before := Input.MOUSE_MODE_CAPTURED
var _armed_frame := 0
var _note := ""


static func open(host: Node) -> SongMaker:
	var maker := SongMaker.new()
	host.add_child(maker)
	return maker


func _ready() -> void:
	layer = 20
	is_open = true
	song = SongBook.blank(SongBook.next_title())
	_songs = SongBook.load_all()
	_mouse_before = Input.mouse_mode
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	_armed_frame = Engine.get_process_frames() + 1
	_board = Control.new()
	_board.set_anchors_preset(Control.PRESET_FULL_RECT)
	_board.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_board.draw.connect(_draw_board)
	add_child(_board)


func _exit_tree() -> void:
	is_open = false


func close() -> void:
	Input.mouse_mode = _mouse_before
	is_open = false
	closed.emit()
	queue_free()


## Put a note on (or take it off) a step.
func toggle(step: int, lane: int) -> void:
	var notes: Array = song.steps[step]
	# JSON hands numbers back as floats: compare as ints.
	var found := -1
	for i in notes.size():
		if int(notes[i]) == lane:
			found = i
	if found >= 0:
		notes.remove_at(found)
	else:
		notes.append(lane)
		Sfx.play(self, NOTES[lane], -4.0)
	_board.queue_redraw()


func has_note(step: int, lane: int) -> bool:
	for note: Variant in song.steps[step]:
		if int(note) == lane:
			return true
	return false


## Where a square or a button is on screen (after the first frame is drawn).
func cell_rect(step: int, lane: int) -> Rect2:
	return _cells[step * SongBook.LANES + lane] if not _cells.is_empty() else Rect2()


func button_rect(which: String) -> Rect2:
	var index := BUTTONS.find(which)
	return _button_rects[index] if index >= 0 and index < _button_rects.size() else Rect2()


func play(on: bool) -> void:
	playing = on
	_clock = 0.0
	_step = -1
	_board.queue_redraw()


func save() -> void:
	SongBook.save_song(song)
	_songs = SongBook.load_all()
	_note = "Saved \"%s\"" % song.title
	saved.emit(song)
	_board.queue_redraw()


func load_song(index: int) -> void:
	song = (_songs[index] as Dictionary).duplicate(true)
	play(false)


func _process(delta: float) -> void:
	if not playing:
		return
	_clock += delta
	var step_length := 30.0 / float(song.bpm)     # eighth notes
	var step := int(_clock / step_length) % SongBook.STEPS
	if step != _step:
		_step = step
		for lane: Variant in song.steps[step]:
			Sfx.play(self, NOTES[int(lane)], -4.0)
		if step % 4 == 0:
			Sfx.play(self, TICK, -8.0)
		_board.queue_redraw()


func _input(event: InputEvent) -> void:
	if Engine.get_process_frames() < _armed_frame:
		return
	if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		_click(event.position)
	elif event is InputEventMouse:
		pass
	elif event.is_action_pressed(&"ui_cancel"):
		close()
	elif event.is_action_pressed(&"ui_left", true) or event.is_action_pressed(&"move_left"):
		cursor.x = posmod(cursor.x - 1, SongBook.STEPS)
	elif event.is_action_pressed(&"ui_right", true) or event.is_action_pressed(&"move_right"):
		cursor.x = posmod(cursor.x + 1, SongBook.STEPS)
	elif event.is_action_pressed(&"ui_up", true) or event.is_action_pressed(&"move_forward"):
		cursor.y = mini(cursor.y + 1, SongBook.LANES - 1)
	elif event.is_action_pressed(&"ui_down", true) or event.is_action_pressed(&"move_back"):
		cursor.y = maxi(cursor.y - 1, 0)
	elif event.is_action_pressed(&"interact"):
		toggle(cursor.x, cursor.y)
	elif event.is_action_pressed(&"jump"):
		play(not playing)
	elif not (event is InputEventKey or event is InputEventJoypadButton or event is InputEventAction):
		return
	get_viewport().set_input_as_handled()
	if _board:
		_board.queue_redraw()


func _click(at: Vector2) -> void:
	for step in SongBook.STEPS:
		for lane in SongBook.LANES:
			if _cells[step * SongBook.LANES + lane].has_point(at):
				cursor = Vector2i(step, lane)
				toggle(step, lane)
				return
	for i in _button_rects.size():
		if _button_rects[i].has_point(at):
			press_button(BUTTONS[i])
			return
	for i in _song_rects.size():
		if _song_rects[i].has_point(at):
			load_song(i)
			return


func press_button(which: String) -> void:
	match which:
		"Play":
			play(not playing)
		"Tempo":
			var at := SongBook.TEMPOS.find(int(song.bpm))
			song.bpm = SongBook.TEMPOS[(at + 1) % SongBook.TEMPOS.size()]
		"Clear":
			for notes: Array in song.steps:
				notes.clear()
		"New":
			song = SongBook.blank(SongBook.next_title())
			play(false)
		"Save":
			save()
		"Close":
			close()
	if _board:
		_board.queue_redraw()


func _draw_board() -> void:
	var view := _board.size
	var cell := 44.0
	var grid := Vector2(cell * SongBook.STEPS, cell * SongBook.LANES)
	var list_width := 230.0
	var size := Vector2(grid.x + list_width + 96.0, grid.y + 230.0)
	var origin := (view - size) * 0.5
	_board.draw_rect(Rect2(Vector2.ZERO, view), Color(0.03, 0.02, 0.08, 0.5))
	_board.draw_style_box(_box(INK, 28), Rect2(origin, size))
	_board.draw_string(FONT_BOLD, origin + Vector2(32, 52), "Write a song", HORIZONTAL_ALIGNMENT_LEFT, -1, 32, ACCENT)
	_board.draw_string(FONT, origin + Vector2(232, 50), "%s   ·   %d bpm" % [song.title, int(song.bpm)], HORIZONTAL_ALIGNMENT_LEFT, -1, 18, Color(1, 1, 1, 0.75))

	var top_left := origin + Vector2(32, 84)
	_cells.resize(SongBook.STEPS * SongBook.LANES)
	for step in SongBook.STEPS:
		for lane in SongBook.LANES:
			# High notes at the top.
			var rect := Rect2(top_left + Vector2(step * cell, (SongBook.LANES - 1 - lane) * cell), Vector2(cell - 5.0, cell - 5.0))
			_cells[step * SongBook.LANES + lane] = rect
			var color := Color(1, 1, 1, 0.13 if step % 4 == 0 else 0.07)
			if has_note(step, lane):
				color = LANE_COLORS[lane]
			if playing and step == _step:
				color = color.lightened(0.3)
			_board.draw_style_box(_box(color, 8), rect)
			if cursor == Vector2i(step, lane):
				_board.draw_rect(rect.grow(2.0), Color.WHITE, false, 2.0)

	_button_rects.clear()
	var x := top_left.x
	var y := top_left.y + grid.y + 18.0
	for label in BUTTONS:
		var text := label
		if label == "Play" and playing:
			text = "Stop"
		var width := FONT_BOLD.get_string_size(text, HORIZONTAL_ALIGNMENT_LEFT, -1, 20).x + 36.0
		var rect := Rect2(x, y, width, 44.0)
		_button_rects.append(rect)
		_board.draw_style_box(_box(ACCENT if label == "Save" else Color(1, 1, 1, 0.16), 14), rect)
		_board.draw_string(FONT_BOLD, Vector2(x + 18.0, y + 30.0), text, HORIZONTAL_ALIGNMENT_LEFT, -1, 20, INK if label == "Save" else Color.WHITE)
		x += width + 10.0
	_board.draw_string(FONT, Vector2(top_left.x, y + 78.0), "Click squares to place notes   ·   arrows + E also work   ·   Space plays   ·   Esc closes",
			HORIZONTAL_ALIGNMENT_LEFT, -1, 15, Color(1, 1, 1, 0.55))
	if _note != "":
		_board.draw_string(FONT_BOLD, Vector2(x + 12.0, y + 30.0), _note, HORIZONTAL_ALIGNMENT_LEFT, -1, 18, ACCENT)

	# Saved songs down the right-hand side.
	var list := Vector2(top_left.x + grid.x + 28.0, top_left.y)
	_board.draw_string(FONT_BOLD, list + Vector2(0, 16), "Your songs", HORIZONTAL_ALIGNMENT_LEFT, -1, 18, Color(1, 1, 1, 0.8))
	_song_rects.clear()
	for i in mini(_songs.size(), 7):
		var rect := Rect2(list + Vector2(0, 30.0 + i * 38.0), Vector2(list_width, 32.0))
		_song_rects.append(rect)
		_board.draw_style_box(_box(Color(1, 1, 1, 0.2 if _songs[i].title == song.title else 0.09), 10), rect)
		_board.draw_string(FONT, rect.position + Vector2(12, 22), String(_songs[i].title), HORIZONTAL_ALIGNMENT_LEFT, list_width - 20.0, 16, Color.WHITE)
	if _songs.is_empty():
		_board.draw_string(FONT, list + Vector2(0, 52), "Nothing saved yet.", HORIZONTAL_ALIGNMENT_LEFT, -1, 15, Color(1, 1, 1, 0.5))


func _box(color: Color, corner: int) -> StyleBoxFlat:
	var box := StyleBoxFlat.new()
	box.bg_color = color
	box.set_corner_radius_all(corner)
	box.anti_aliasing_size = 1.2
	return box
