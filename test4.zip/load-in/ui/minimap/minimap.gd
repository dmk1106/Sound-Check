class_name Minimap
extends Control
## The round map in the corner. It turns with the camera so "up" is always
## the way you're looking, follows you on foot and the truck when you drive,
## and draws the way to wherever the game wants you to go along the actual
## streets (RoadNetwork.route), so it never cuts through buildings.
##
## The street picture is ui/minimap/city_map.png, baked by the city builder
## from the same road data as the city itself; RoadNetwork.map_rect says
## which bit of the world it covers.

const MAP_TEXTURE := preload("res://ui/minimap/city_map.png")
const FONT := preload("res://art/fonts/fredoka_semibold.tres")

## Pixels per metre on foot and at driving speed (it zooms out as you speed up).
@export var walk_scale := 1.9
@export var drive_scale := 1.05
## Below this many metres to go there's no route line, just the marker.
@export var route_min_distance := 22.0

const RING := Color(0.13, 0.12, 0.2, 0.92)
const RING_EDGE := Color(1, 1, 1, 0.16)
const ROUTE := Color(1.0, 0.78, 0.3)
const ROUTE_SHADOW := Color(0.25, 0.13, 0.0, 0.55)
const PLAYER := Color(1, 1, 1)
const TRUCK := Color(0.42, 0.78, 1.0)
const GOAL := Color(1.0, 0.82, 0.3)
const HERE := Color(0.56, 0.94, 0.78)

var _net: RoadNetwork
var _flow: GameFlow
var _player: Player
var _truck: Truck
var _scale := 1.9
var _centre := Vector3.ZERO
var _right := Vector3.RIGHT
var _forward := Vector3.FORWARD
var _route := PackedVector3Array()
var _route_from := Vector3(INF, 0, INF)
var _route_to := Vector3(INF, 0, INF)
var _route_timer := 0.0
var _pulse := 0.0
## Studio, shop and venues: {node, letter, colour}.
var _places: Array[Dictionary] = []

@onready var _info: Label = $Info
@onready var _street: Label = $Street


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	# Let the level finish setting up (game flow, road network) first.
	await get_tree().process_frame
	_net = get_tree().get_first_node_in_group(&"road_network")
	_flow = get_tree().get_first_node_in_group(&"game_flow")
	_player = get_tree().get_first_node_in_group(&"player")
	_truck = get_tree().get_first_node_in_group(&"truck")
	if _net == null:
		visible = false
		return
	if _flow:
		_flow.route_target_changed.connect(func(_d: Node3D) -> void: _route_timer = 0.0)
	var studio := get_tree().get_first_node_in_group(&"studio") as Node3D
	if studio:
		_places.append({"node": studio, "letter": "S", "colour": Color(0.56, 0.94, 0.78)})
	var store := get_tree().current_scene.find_child("MusicStore", true, false) as Node3D if get_tree().current_scene else null
	if store:
		_places.append({"node": store, "letter": "$", "colour": Color(0.55, 0.85, 1.0)})
	for node in get_tree().get_nodes_in_group(&"venue"):
		var venue := node as Venue
		if venue:
			_places.append({"node": venue, "letter": "", "colour": Color(1.0, 0.6, 0.75)})


func _process(delta: float) -> void:
	if _net == null or not is_visible_in_tree():
		return
	_pulse += delta
	var driving := _truck != null and _truck.driver != null
	var who: Node3D = _truck if driving else _player
	if who == null:
		return
	_centre = who.global_position
	var target_scale := walk_scale
	if driving:
		var speed := _truck.linear_velocity.length() if _truck is RigidBody3D else 10.0
		target_scale = lerpf(walk_scale * 0.8, drive_scale, clampf(speed / 14.0, 0.0, 1.0))
	_scale = lerpf(_scale, target_scale, 1.0 - exp(-2.0 * delta))
	var cam := get_viewport().get_camera_3d()
	if cam:
		var f := -cam.global_basis.z
		f.y = 0.0
		if f.length() > 0.01:
			_forward = f.normalized()
			_right = Vector3(-_forward.z, 0.0, _forward.x)
	_route_timer -= delta
	if _route_timer <= 0.0:
		_route_timer = 0.5
		_update_route()
	_update_labels(driving)
	queue_redraw()


## Where world point `at` lands on the map, relative to the map's centre.
func to_map(at: Vector3) -> Vector2:
	var d := at - _centre
	return Vector2(d.dot(_right), -d.dot(_forward)) * _scale


func radius() -> float:
	return size.x * 0.5 - 6.0


func _destination() -> Vector3:
	if _flow == null or _flow.route_target == null or not is_instance_valid(_flow.route_target):
		return Vector3(INF, 0, INF)
	return _flow.route_target.global_position


func _update_route() -> void:
	var goal := _destination()
	if goal.x == INF:
		_route = PackedVector3Array()
		_route_to = goal
		return
	var flat := Vector2(goal.x - _centre.x, goal.z - _centre.z).length()
	if flat < route_min_distance:
		_route = PackedVector3Array()
		return
	# Re-route when the goal moves or you wander off the line.
	var moved := Vector2(_centre.x - _route_from.x, _centre.z - _route_from.z).length()
	if goal.distance_to(_route_to) < 0.5 and moved < 6.0 and not _route.is_empty():
		return
	_route_from = _centre
	_route_to = goal
	_route = _net.route(_centre, goal)


func _update_labels(driving: bool) -> void:
	var street := _net.street_name_at(_centre)
	_street.text = street
	_street.visible = street != ""
	var goal := _destination()
	if goal.x == INF:
		_info.visible = false
		return
	_info.visible = true
	var arrive := _flow.arrive_distance if driving or _flow.route_target.name == "Parking" else 3.0
	var gap := Vector2(goal.x - _centre.x, goal.z - _centre.z).length()
	if gap <= arrive:
		_info.text = "You're here"
		_info.modulate = HERE
	else:
		var to_go := gap
		if not _route.is_empty():
			to_go = RoadNetwork.length_of(_route) + _centre.distance_to(_route[0]) + _route[_route.size() - 1].distance_to(goal)
		_info.text = "%d m" % int(round(to_go / 10.0) * 10.0) if to_go >= 100.0 else "%d m" % int(to_go)
		_info.modulate = GOAL


func _draw() -> void:
	if _net == null:
		return
	var c := Vector2(size.x * 0.5, size.x * 0.5)
	var r := radius()
	draw_circle(c, r + 6.0, RING)
	_draw_streets(c, r)
	_draw_route(c, r)
	_draw_places(c, r)
	_draw_truck(c, r)
	_draw_goal(c, r)
	_draw_player(c)
	draw_arc(c, r + 0.5, 0, TAU, 96, RING_EDGE, 2.0, true)
	_draw_north(c, r)


# The street picture, cut to a circle and turned with the camera.
func _draw_streets(c: Vector2, r: float) -> void:
	var rect := _net.map_rect
	var pts := PackedVector2Array()
	var uvs := PackedVector2Array()
	for i in 72:
		var a := TAU * i / 72.0
		var p := Vector2(cos(a), sin(a)) * r
		pts.append(c + p)
		var world := _centre + _right * (p.x / _scale) - _forward * (p.y / _scale)
		uvs.append(Vector2((world.x - rect.position.x) / rect.size.x, (world.z - rect.position.y) / rect.size.y))
	draw_polygon(pts, PackedColorArray([Color.WHITE]), uvs, MAP_TEXTURE)


func _draw_route(c: Vector2, r: float) -> void:
	if _route.is_empty():
		return
	var line := PackedVector2Array([Vector2.ZERO])
	for p in _route:
		line.append(to_map(p))
	line.append(to_map(_destination()))
	for pass_ in 2:
		var colour := ROUTE_SHADOW if pass_ == 0 else ROUTE
		var width := 7.0 if pass_ == 0 else 4.0
		for i in range(1, line.size()):
			var seg := _clip(line[i - 1], line[i], r - 2.0)
			if not seg.is_empty():
				draw_line(c + seg[0], c + seg[1], colour, width, true)
				draw_circle(c + seg[1], width * 0.5, colour)


func _draw_places(c: Vector2, r: float) -> void:
	for place in _places:
		var node: Node3D = place.node
		if not is_instance_valid(node) or not node.is_inside_tree():
			continue
		var p := to_map(node.global_position)
		if p.length() > r - 9.0:
			continue
		var colour: Color = place.colour
		draw_circle(c + p, 8.0, Color(0.1, 0.09, 0.16, 0.9))
		draw_arc(c + p, 8.0, 0, TAU, 20, colour, 1.6, true)
		if place.letter == "":
			# A little music note for venues.
			draw_circle(c + p + Vector2(-1.5, 2.5), 2.4, colour)
			draw_line(c + p + Vector2(0.6, 2.5), c + p + Vector2(0.6, -4.5), colour, 1.6)
			draw_line(c + p + Vector2(0.6, -4.5), c + p + Vector2(3.6, -2.5), colour, 1.6)
		else:
			draw_string(FONT, c + p + Vector2(-5, 4.5), place.letter, HORIZONTAL_ALIGNMENT_CENTER, 10, 12, colour)


func _draw_truck(c: Vector2, r: float) -> void:
	if _truck == null or _truck.driver != null:
		return
	var p := to_map(_truck.global_position)
	var edge := p.length() > r - 8.0
	if edge:
		p = p.normalized() * (r - 8.0)
	var dir := -_truck.global_basis.z
	var a := atan2(dir.dot(_right), dir.dot(_forward))
	draw_set_transform(c + p, a, Vector2.ONE)
	draw_rect(Rect2(-4.5, -7, 9, 14), Color(0.08, 0.1, 0.18), true)
	draw_rect(Rect2(-3.5, -6, 7, 12), TRUCK, true)
	draw_rect(Rect2(-3.5, -6, 7, 3.5), TRUCK.darkened(0.4), true)
	draw_set_transform(Vector2.ZERO)


func _draw_goal(c: Vector2, r: float) -> void:
	var goal := _destination()
	if goal.x == INF:
		return
	var p := to_map(goal)
	if p.length() > r - 10.0:
		# Off the map: an arrow on the rim pointing at it.
		var dir := p.normalized()
		var tip := c + dir * (r - 2.0)
		var side := Vector2(-dir.y, dir.x)
		draw_colored_polygon(PackedVector2Array([tip, tip - dir * 13.0 + side * 8.0, tip - dir * 13.0 - side * 8.0]), GOAL)
		return
	var beat := 1.0 + 0.15 * sin(_pulse * 5.0)
	var here := _info.visible and _info.text == "You're here"
	var colour := HERE if here else GOAL
	draw_circle(c + p, 11.0 * beat, Color(colour, 0.25))
	draw_circle(c + p, 7.0, Color(0.1, 0.09, 0.16))
	draw_circle(c + p, 5.0, colour)


func _draw_player(c: Vector2) -> void:
	var facing := _forward
	if _truck and _truck.driver != null:
		facing = -_truck.global_basis.z
	elif _player:
		facing = _player.get_facing_forward()
	facing.y = 0.0
	var a := atan2(facing.dot(_right), facing.dot(_forward))
	draw_set_transform(c, a, Vector2.ONE)
	var arrow := PackedVector2Array([Vector2(0, -10), Vector2(7, 7), Vector2(0, 3.5), Vector2(-7, 7)])
	var outline := PackedVector2Array([Vector2(0, -13), Vector2(9.5, 9.5), Vector2(0, 5.5), Vector2(-9.5, 9.5)])
	draw_colored_polygon(outline, Color(0.08, 0.07, 0.14))
	draw_colored_polygon(arrow, PLAYER)
	draw_set_transform(Vector2.ZERO)


func _draw_north(c: Vector2, r: float) -> void:
	var north := Vector2(-_right.z, _forward.z).normalized() * (r + 1.0)
	draw_circle(c + north, 9.0, Color(0.1, 0.09, 0.16))
	draw_string(FONT, c + north + Vector2(-5, 5), "N", HORIZONTAL_ALIGNMENT_CENTER, 10, 13, Color(1, 0.82, 0.4))


# The part of segment a-b inside the circle of radius r round the origin.
static func _clip(a: Vector2, b: Vector2, r: float) -> PackedVector2Array:
	var a_in := a.length() <= r
	var b_in := b.length() <= r
	if a_in and b_in:
		return PackedVector2Array([a, b])
	var d := b - a
	var qa := d.dot(d)
	if qa < 0.0001:
		return PackedVector2Array()
	var qb := 2.0 * a.dot(d)
	var qc := a.dot(a) - r * r
	var disc := qb * qb - 4.0 * qa * qc
	if disc < 0.0:
		return PackedVector2Array()
	var s := sqrt(disc)
	var t0 := clampf((-qb - s) / (2.0 * qa), 0.0, 1.0)
	var t1 := clampf((-qb + s) / (2.0 * qa), 0.0, 1.0)
	if t1 <= t0:
		return PackedVector2Array()
	return PackedVector2Array([a + d * t0, a + d * t1])
