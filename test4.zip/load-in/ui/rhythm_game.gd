class_name RhythmGame
extends CanvasLayer
## The show: notes fall down five lanes, hit each one as it crosses the line.
## Small on purpose - it only has to turn "played well / badly" into a number.
##
##   start(...)            begin a song
##   finished(accuracy)    the song is over (0..1)
##   show_results(result)  display the payout, then `closed` after the key press

signal finished(accuracy: float)
signal closed

const LANES := 5
const LANE_ACTIONS: Array[StringName] = [&"lane_1", &"lane_2", &"lane_3", &"lane_4", &"lane_5"]
const LANE_KEYS: Array[String] = ["D", "F", "J", "K", "L"]
const LANE_COLORS: Array[Color] = [Color("ff5d8f"), Color("ffd166"), Color("3ddbd9"), Color("7f8cff"), Color("c77dff")]
const FONT := preload("res://art/fonts/fredoka_semibold.tres")

## Seconds a note takes to fall to the line.
@export var fall_time := 1.5
## How far off (seconds) still counts as a hit / as perfect.
@export var hit_window := 0.15
@export var perfect_window := 0.065
## Silence before the song starts.
@export var lead_in := 2.0
## Follow the audio clock (turn off for automated tests running faster than real time).
var sync_to_audio := true

var song_time := 0.0
## Each note: {time, lane, state} with state 0 = coming, 1 = hit, 2 = missed.
var notes: Array[Dictionary] = []
var perfects := 0
var goods := 0
var misses := 0
var combo := 0
var best_combo := 0
## 0..1: how well the last few notes went. The crowd watches this.
var mood := 0.5

var _title := ""
var _running := false
var _result := {}
var _lane_flash: Array[float] = [0.0, 0.0, 0.0, 0.0, 0.0]
var _judgement := ""
var _judgement_age := 9.0
var _end_time := 0.0
var _audio: AudioStreamPlayer
var _board: Control


func _ready() -> void:
	layer = 5
	_audio = AudioStreamPlayer.new()
	_audio.bus = Settings.MUSIC_BUS
	add_child(_audio)
	_board = Control.new()
	_board.set_anchors_preset(Control.PRESET_FULL_RECT)
	_board.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_board.draw.connect(_draw_board)
	add_child(_board)


## `chart` is a list of [beat, lane] pairs; `window` how far off (seconds) still counts.
func start(title: String, bpm: float, chart: Array, stream: AudioStream, window := 0.15) -> void:
	_title = title
	hit_window = window
	perfect_window = window * 0.45
	notes.clear()
	for entry: Array in chart:
		notes.append({"time": float(entry[0]) * 60.0 / bpm, "lane": int(entry[1]), "state": 0})
	_end_time = (notes[-1].time as float) + 2.0 if not notes.is_empty() else 1.0
	_audio.stream = stream
	song_time = -lead_in
	_running = true


func get_accuracy() -> float:
	if notes.is_empty():
		return 0.0
	return (perfects + goods * 0.7) / notes.size()


func show_results(result: Dictionary) -> void:
	_result = result


func _process(delta: float) -> void:
	_judgement_age += delta
	for lane in LANES:
		_lane_flash[lane] = maxf(_lane_flash[lane] - delta * 5.0, 0.0)
	if _running:
		song_time += delta
		if song_time >= 0.0 and not _audio.playing and song_time < 1.0:
			_audio.play(song_time)
		if sync_to_audio and _audio.playing:
			# Stay glued to what is actually coming out of the speakers.
			var heard := _audio.get_playback_position() + AudioServer.get_time_since_last_mix() \
					- AudioServer.get_output_latency()
			if absf(heard - song_time) > 0.05 and heard > 0.0:
				song_time = lerpf(song_time, heard, 0.2)
		for note in notes:
			if note.state == 0 and song_time > (note.time as float) + hit_window:
				note.state = 2
				misses += 1
				combo = 0
				mood = lerpf(mood, 0.0, 0.3)
				_judge("miss")
		if song_time >= _end_time:
			_running = false
			_audio.stop()
			finished.emit(get_accuracy())
	_board.queue_redraw()


func _unhandled_input(event: InputEvent) -> void:
	if not _result.is_empty():
		if event.is_action_pressed(&"interact"):
			get_viewport().set_input_as_handled()
			closed.emit()
		return
	if not _running:
		return
	for lane in LANES:
		if event.is_action_pressed(LANE_ACTIONS[lane]):
			_strike(lane)


func _strike(lane: int) -> void:
	_lane_flash[lane] = 1.0
	# The nearest waiting note in this lane, if it is close enough.
	var best := {}
	var best_error := hit_window
	for note in notes:
		if note.state != 0 or note.lane != lane:
			continue
		var error := absf((note.time as float) - song_time)
		if error <= best_error:
			best_error = error
			best = note
	if best.is_empty():
		return
	best.state = 1
	mood = lerpf(mood, 1.0, 0.25)
	combo += 1
	best_combo = maxi(best_combo, combo)
	if best_error <= perfect_window:
		perfects += 1
		_judge("perfect")
	else:
		goods += 1
		_judge("good")


func _judge(text: String) -> void:
	_judgement = text
	_judgement_age = 0.0


# --- drawing ---

func _draw_board() -> void:
	var view := _board.size
	var lane_width := 80.0
	var width := lane_width * LANES
	# Off to the right, so the player can still watch the character on stage.
	var left := view.x * 0.77 - width * 0.5
	var top := 70.0
	var line_y := view.y - 120.0
	var ink := Color(0.13, 0.12, 0.2, 0.82)

	_board.draw_style_box(_box(ink, 26), Rect2(left - 18.0, top - 18.0, width + 36.0, view.y - top - 30.0))
	for lane in LANES:
		var x := left + lane * lane_width
		var color := LANE_COLORS[lane]
		_board.draw_style_box(_box(Color(color, 0.10 + 0.25 * _lane_flash[lane]), 14),
				Rect2(x + 4.0, top, lane_width - 8.0, line_y - top + 34.0))
		# The target on the line, with its key.
		_board.draw_style_box(_box(Color(color, 0.35 + 0.65 * _lane_flash[lane]), 16),
				Rect2(x + 8.0, line_y - 17.0, lane_width - 16.0, 34.0))
		_text(LANE_KEYS[lane], Vector2(x + lane_width * 0.5, line_y + 62.0), 26, Color.WHITE)

	for note in notes:
		if note.state == 1:
			continue
		var until := (note.time as float) - song_time
		if until > fall_time or until < -0.3:
			continue
		var y := lerpf(line_y, top, until / fall_time)
		var x := left + (note.lane as int) * lane_width
		var color := LANE_COLORS[note.lane as int]
		if note.state == 2:
			color = Color(color, 0.25)
		_board.draw_style_box(_box(color, 15), Rect2(x + 10.0, y - 15.0, lane_width - 20.0, 30.0))

	_text(_title, Vector2(left + width * 0.5, 44.0), 24, Color("ffd166"))
	if combo > 1:
		_text("%d in a row" % combo, Vector2(left - 140.0, line_y + 8.0), 30, Color.WHITE)
	if _judgement_age < 0.5 and _running:
		var fade := 1.0 - _judgement_age / 0.5
		var colors := {"perfect": Color("ffd166"), "good": Color("2ec4b6"), "miss": Color("ff6f59")}
		_text(_judgement.to_upper(), Vector2(left - 140.0, line_y - 44.0 - _judgement_age * 40.0), 32,
				Color(colors[_judgement] as Color, fade))
	if song_time < 0.0 and _running:
		_text("Get ready...", Vector2(view.x * 0.4, view.y * 0.3), 44, Color.WHITE)

	if not _result.is_empty():
		var panel := Rect2(view.x * 0.5 - 250.0, view.y * 0.5 - 150.0, 500.0, 300.0)
		_board.draw_style_box(_box(Color(0.13, 0.12, 0.2, 0.96), 30), panel)
		var accuracy := float(_result.accuracy)
		var headline := "GREAT SHOW!" if accuracy > 0.75 else ("NOT BAD!" if accuracy > 0.4 else "ROUGH NIGHT...")
		var centre := view.x * 0.5
		_text(headline, Vector2(centre, panel.position.y + 66.0), 46, Color("ffd166"))
		_text("%d%% of the notes" % roundi(accuracy * 100.0), Vector2(centre, panel.position.y + 116.0), 24, Color.WHITE)
		_text("+ $%d" % int(_result.pay), Vector2(centre, panel.position.y + 166.0), 36, Color("2ec4b6"))
		_text("+ %d fans" % int(_result.fans), Vector2(centre, panel.position.y + 210.0), 30, Color("ff8fab"))
		_text("press E to pack up", Vector2(centre, panel.position.y + 264.0), 20, Color(1, 1, 1, 0.7))


func _box(color: Color, corner: int) -> StyleBoxFlat:
	var box := StyleBoxFlat.new()
	box.bg_color = color
	box.set_corner_radius_all(corner)
	box.anti_aliasing_size = 1.2
	return box


func _text(text: String, centre: Vector2, size: int, color: Color) -> void:
	var width := FONT.get_string_size(text, HORIZONTAL_ALIGNMENT_LEFT, -1, size).x
	_board.draw_string(FONT, Vector2(centre.x - width * 0.5, centre.y), text, HORIZONTAL_ALIGNMENT_LEFT, -1, size, color)
