class_name StudioCatalogue
extends Interactable
## Order things for the studio from inside the studio. Furniture is delivered
## as real objects you can carry or drag to where you want them; wall pieces
## go up on their spot on the wall.

## Where delivered furniture appears.
@export var delivery_path: NodePath = ^"../Delivery"

## scene = a physical object to deliver; wall = name of a node under
## ../Mesh/Extras to switch on. needs_fans = only for the famous.
const ITEMS: Array[Dictionary] = [
	{"name": "Floor lamp", "detail": "Warm light. Carry it where you like.", "price": 25, "scene": "res://decor/floor_lamp.tscn"},
	{"name": "Plant", "detail": "Something alive in here.", "price": 15, "scene": "res://decor/plant.tscn"},
	{"name": "Neon sign", "detail": "Goes up on the back wall.", "price": 40, "wall": "NeonSign"},
	{"name": "Poster set", "detail": "Three more posters for the walls.", "price": 20, "wall": "Posters"},
	{"name": "Sofa", "detail": "Heavy. Drag it into place.", "price": 70, "scene": "res://decor/sofa.tscn"},
	{"name": "Record shelf", "detail": "Shelves full of vinyl. Heavy.", "price": 60, "scene": "res://decor/shelf.tscn"},
	{"name": "String lights", "detail": "Along the ceiling.", "price": 30, "wall": "StringLights"},
	{"name": "Gold record", "detail": "For the wall. Earned, not bought.", "price": 0, "wall": "GoldRecord", "needs_fans": 100},
]

var _owned := {}
var _menu: GameMenu


func _ready() -> void:
	super()
	prompt = "decorate the studio"
	interacted.connect(_open_menu)


func owns(item_name: String) -> bool:
	return _owned.has(item_name)


func _open_menu(_player: Player) -> void:
	var rows := []
	for item in ITEMS:
		var needs := int(item.get("needs_fans", 0))
		var row := {"text": item.name, "detail": item.detail, "tag": "$%d" % item.price}
		if _owned.has(item.name):
			row.tag = "owned"
			row.disabled = true
		elif Career.fans < needs:
			row.detail = "Needs %d fans." % needs
			row.tag = ""
			row.disabled = true
		elif item.price == 0:
			row.tag = "free"
		rows.append(row)
	_menu = GameMenu.open(self, "Studio catalogue   ($%d)" % Career.money, rows)
	_menu.chosen.connect(_buy)


func _buy(index: int) -> void:
	var item := ITEMS[index]
	if not Career.spend(item.price):
		return
	_owned[item.name] = true
	if item.has("scene"):
		var thing: Node3D = (load(item.scene) as PackedScene).instantiate()
		get_tree().current_scene.add_child(thing)
		thing.global_position = (get_node(delivery_path) as Node3D).global_position + Vector3(0, 0.4, 0)
		Career.say("%s delivered: it's by the door" % item.name)
	else:
		var piece := get_node_or_null("../Mesh/Extras/" + String(item.wall)) as Node3D
		if piece:
			piece.visible = true
		Career.say("%s is up" % item.name)
	_menu.close()
