extends Node
## Player settings (autoloaded as "Settings"): music and sound volume, the
## truck radio, and the pause menu that changes them. Saved to user://settings.cfg.
##
## Audio buses (made here, so there is no bus layout file to keep in step):
##   Master <- Music                        the songs
##   Master <- Sound <- Ambience            (muffled indoors)
##                         <- Rain          the rain bed
##                         <- City          traffic hum, chatter, club bass
##                         <- Vehicle       the truck's engine, cars, the train
##                         <- Crowd         the audience at venues
##                         <- Nature        the park: fountain, pond, birds
##                   <- SFX                 footsteps, bonks, the radio (echoes in the alley)
## Every bus has its own slider in the pause menu; 0 mutes just that one.

signal radio_changed(on: bool)

const FILE := "user://settings.cfg"
const MUSIC_BUS := &"Music"
const SOUND_BUS := &"Sound"
const AMBIENCE_BUS := &"Ambience"
const SFX_BUS := &"SFX"
const RAIN_BUS := &"Rain"
const CITY_BUS := &"City"
const VEHICLE_BUS := &"Vehicle"
const CROWD_BUS := &"Crowd"
const NATURE_BUS := &"Nature"
## The category sliders after Music and Sound: [bus, menu label].
const CATEGORIES := [[RAIN_BUS, "Rain"], [CITY_BUS, "City ambience"], [VEHICLE_BUS, "Vehicles"],
		[SFX_BUS, "Sound effects"], [CROWD_BUS, "Crowd"], [NATURE_BUS, "Nature / park"]]

## 0..1. Applied to the Music audio bus straight away.
var music_volume := 0.8: set = set_music_volume
## 0..1. Everything that isn't music.
var sound_volume := 0.8: set = set_sound_volume
## 0..1 per category bus (see CATEGORIES).
var volumes := {}
## The truck's jingle (only ever heard while driving).
var truck_radio := true: set = set_truck_radio

var _menu: GameMenu = null


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_make_bus(MUSIC_BUS, &"Master")
	_make_bus(SOUND_BUS, &"Master")
	if _make_bus(AMBIENCE_BUS, SOUND_BUS):
		var muffle := AudioEffectLowPassFilter.new()
		muffle.cutoff_hz = 20000.0
		AudioServer.add_bus_effect(AudioServer.get_bus_index(AMBIENCE_BUS), muffle)
	if _make_bus(SFX_BUS, SOUND_BUS):
		var echo := AudioEffectReverb.new()
		echo.room_size = 0.55
		echo.damping = 0.4
		echo.wet = 0.0
		echo.dry = 1.0
		AudioServer.add_bus_effect(AudioServer.get_bus_index(SFX_BUS), echo)
	for category: Array in CATEGORIES:
		_make_bus(category[0], AMBIENCE_BUS)
		volumes[category[0]] = 1.0
	var file := ConfigFile.new()
	if file.load(FILE) == OK:
		music_volume = clampf(float(file.get_value("audio", "music_volume", music_volume)), 0.0, 1.0)
		sound_volume = clampf(float(file.get_value("audio", "sound_volume", sound_volume)), 0.0, 1.0)
		truck_radio = bool(file.get_value("audio", "truck_radio", truck_radio))
		for category: Array in CATEGORIES:
			set_volume(category[0], float(file.get_value("audio", String(category[0]).to_lower() + "_volume", 1.0)))
	else:
		set_music_volume(music_volume)
		set_sound_volume(sound_volume)


# Returns true if the bus was created just now.
func _make_bus(bus_name: StringName, send: StringName) -> bool:
	if AudioServer.get_bus_index(bus_name) >= 0:
		return false
	AudioServer.add_bus()
	var index := AudioServer.bus_count - 1
	AudioServer.set_bus_name(index, bus_name)
	AudioServer.set_bus_send(index, send)
	return true


func set_music_volume(value: float) -> void:
	music_volume = clampf(value, 0.0, 1.0)
	_apply(MUSIC_BUS, music_volume)


func set_sound_volume(value: float) -> void:
	sound_volume = clampf(value, 0.0, 1.0)
	_apply(SOUND_BUS, sound_volume)


## Volume (0..1) of one category bus, applied at once.
func set_volume(bus_name: StringName, value: float) -> void:
	volumes[bus_name] = clampf(value, 0.0, 1.0)
	_apply(bus_name, volumes[bus_name])


func set_truck_radio(on: bool) -> void:
	if on == truck_radio:
		return
	truck_radio = on
	radio_changed.emit(on)


func _apply(bus_name: StringName, volume: float) -> void:
	var bus := AudioServer.get_bus_index(bus_name)
	if bus >= 0:
		AudioServer.set_bus_mute(bus, volume <= 0.001)
		AudioServer.set_bus_volume_db(bus, linear_to_db(maxf(volume, 0.001)))


func save() -> void:
	var file := ConfigFile.new()
	file.set_value("audio", "music_volume", music_volume)
	file.set_value("audio", "sound_volume", sound_volume)
	file.set_value("audio", "truck_radio", truck_radio)
	for bus_name: StringName in volumes:
		file.set_value("audio", String(bus_name).to_lower() + "_volume", volumes[bus_name])
	file.save(FILE)


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed(&"ui_cancel") and _menu == null and not GameMenu.is_any_open():
		get_viewport().set_input_as_handled()
		open_pause_menu()


## The pause / settings menu. The whole game stops while it is up.
func open_pause_menu() -> void:
	get_tree().paused = true
	var rows := [
		{"text": "Music volume", "slider": music_volume},
		{"text": "Sound volume", "slider": sound_volume},
	]
	for category: Array in CATEGORIES:
		rows.append({"text": category[1], "slider": volumes[category[0]]})
	rows.append({"text": "Truck radio", "toggle": truck_radio})
	rows.append({"text": "Resume"})
	_menu = GameMenu.open(self, "Paused", rows, "Drag a slider with the mouse, or A / D   ·   E to pick   ·   Esc to close")
	_menu.slider_changed.connect(func(index: int, value: float) -> void:
		if index == 0:
			set_music_volume(value)
		elif index == 1:
			set_sound_volume(value)
		else:
			set_volume(CATEGORIES[index - 2][0], value))
	_menu.toggled.connect(func(_index: int, on: bool) -> void: set_truck_radio(on))
	_menu.closed.connect(_on_menu_closed)
	_menu.chosen.connect(func(_index: int) -> void: _menu.close())


func _on_menu_closed() -> void:
	_menu = null
	save()
	get_tree().paused = false
