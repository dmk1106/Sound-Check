class_name Ambience
extends Node
## The sound of where you are. Three beds that are always running - rain, the
## hum of the city, the hush of a room - are mixed by where the listener is:
##
##   street    rain, and the busier the road the louder the city
##   alley     the city falls away, footsteps echo
##   indoors   rain and traffic turn to a muffled patter, the room hums
##   driving   everything a little duller, from inside the cab
##
## Things with a place of their own (cars, crowds, the creek, air-con units,
## a club's bass) are sounds in the world and take care of themselves.
## Footsteps and the "ching" of money live here too.

const RAIN := preload("res://audio/ambience/rain.ogg")
const CITY := preload("res://audio/ambience/city.ogg")
const ROOM := preload("res://audio/ambience/room.ogg")
const CASH := preload("res://audio/sfx/cash.ogg")
const STEPS: Array[AudioStream] = [preload("res://audio/sfx/step1.ogg"), preload("res://audio/sfx/step2.ogg"),
		preload("res://audio/sfx/step3.ogg"), preload("res://audio/sfx/step4.ogg")]

## Extra spot that counts as an alley (x min, z min, size); the narrow
## streets of the RoadNetwork (alleys and footpaths) count anyway.
@export var alley := Rect2()
## The park (x min, z min, size): the city fades back, it's calmer under the trees.
@export var park := Rect2(-62, -58, 108, 44)
## Road centre lines as pairs of end points, only used when the level has no
## RoadNetwork.
@export var roads := PackedVector3Array()
## Metres walked per footstep.
@export var stride := 1.2

## Where the listener is: "street", "alley", "park", "indoors" or "driving" (for tests and debugging).
var zone := "street"
## 0..1: how close the listener is to a road.
var busy := 0.0
var footsteps := 0

var _rain: AudioStreamPlayer
var _city: AudioStreamPlayer
var _room: AudioStreamPlayer
var _walked := 0.0
var _last_money := 0
var _muffle: AudioEffectLowPassFilter
var _echo: AudioEffectReverb
var _net: RoadNetwork
var _look_timer := 0.0
var _to_road := INF
var _narrow := false

@onready var _player: Player = get_tree().get_first_node_in_group(&"player")
@onready var _truck: Truck = get_tree().get_first_node_in_group(&"truck")


func _ready() -> void:
	add_to_group(&"ambience")
	_rain = _bed(RAIN, Settings.RAIN_BUS)
	_city = _bed(CITY, Settings.CITY_BUS)
	_room = _bed(ROOM, Settings.AMBIENCE_BUS)
	var ambience_bus := AudioServer.get_bus_index(Settings.AMBIENCE_BUS)
	var sfx_bus := AudioServer.get_bus_index(Settings.SFX_BUS)
	if ambience_bus >= 0 and AudioServer.get_bus_effect_count(ambience_bus) > 0:
		_muffle = AudioServer.get_bus_effect(ambience_bus, 0) as AudioEffectLowPassFilter
	if sfx_bus >= 0 and AudioServer.get_bus_effect_count(sfx_bus) > 0:
		_echo = AudioServer.get_bus_effect(sfx_bus, 0) as AudioEffectReverb
	_last_money = Career.money
	Career.changed.connect(_on_career_changed)


func _bed(stream: AudioStreamOggVorbis, bus: StringName) -> AudioStreamPlayer:
	stream.loop = true
	var speaker := AudioStreamPlayer.new()
	speaker.stream = stream
	speaker.bus = bus
	speaker.volume_db = -60.0
	add_child(speaker)
	speaker.play(randf() * stream.get_length())
	return speaker


func _process(delta: float) -> void:
	if _player == null:
		return
	var driving := _truck != null and _truck.driver != null
	var here := _truck.global_position if driving else _player.global_position
	var indoors := InteriorCutaway.indoors > 0 and not driving
	_look_timer -= delta
	if _look_timer <= 0.0:
		_look_timer = 0.2
		_look_around(here)
	var in_alley := (_narrow or alley.has_point(Vector2(here.x, here.z))) and not indoors
	busy = clampf(1.0 - (_to_road - 4.0) / 24.0, 0.0, 1.0)
	var in_park := park.has_point(Vector2(here.x, here.z)) and not indoors and not in_alley
	zone = "driving" if driving else ("indoors" if indoors else ("alley" if in_alley else ("park" if in_park else "street")))

	var rain := -9.0
	var city := lerpf(-27.0, -11.0, busy)
	var room := -60.0
	var cutoff := 20000.0
	var wet := 0.03
	match zone:
		"indoors":
			rain = -17.0
			city -= 9.0
			room = -15.0
			cutoff = 1000.0
			wet = 0.12
		"park":
			rain = -11.0
			city -= 8.0
		"alley":
			rain = -12.0
			city -= 7.0
			wet = 0.42
		"driving":
			rain = -13.0
			city -= 4.0
			cutoff = 4500.0
	var blend := 1.0 - exp(-3.0 * delta)
	_rain.volume_db = lerpf(_rain.volume_db, rain, blend)
	_city.volume_db = lerpf(_city.volume_db, city, blend)
	_room.volume_db = lerpf(_room.volume_db, room, blend)
	if _muffle:
		_muffle.cutoff_hz = lerpf(_muffle.cutoff_hz, cutoff, blend)
	if _echo:
		_echo.wet = lerpf(_echo.wet, wet, blend)

	# Footsteps: one for every stride actually walked on the ground.
	if not driving and _player.grounded and not _player.seated:
		var velocity := _player.linear_velocity
		_walked += Vector2(velocity.x, velocity.z).length() * delta
		if _walked >= stride:
			_walked = 0.0
			footsteps += 1
			Sfx.play_at(self, STEPS[randi() % STEPS.size()], _player.global_position + Vector3.DOWN * 0.85,
					-13.0 if indoors else -9.0, randf_range(0.85, 1.15), 14.0)


# How far the nearest proper road is, and whether we're in a narrow alley.
func _look_around(here: Vector3) -> void:
	if _net == null:
		_net = get_tree().get_first_node_in_group(&"road_network")
	var flat := Vector3(here.x, 0, here.z)
	_to_road = INF
	_narrow = false
	if _net:
		var road := _net.road_at(flat, 0.6)
		_narrow = road >= 0 and _net.road_kind[road] in [RoadNetwork.Kind.ALLEY, RoadNetwork.Kind.PATH]
		for i in _net.road_count():
			if _net.road_kind[i] in [RoadNetwork.Kind.AVENUE, RoadNetwork.Kind.STREET, RoadNetwork.Kind.LANE]:
				_to_road = minf(_to_road, _net.distance_to_road(i, flat))
		return
	for i in range(0, roads.size(), 2):
		var closest := Geometry3D.get_closest_point_to_segment(flat, roads[i], roads[i + 1])
		_to_road = minf(_to_road, closest.distance_to(flat))


## What the mix is doing right now (for tests and debugging): bed volumes in
## dB, the low-pass cutoff on the Ambience bus, the echo on the SFX bus.
func levels() -> Dictionary:
	return {"rain": _rain.volume_db, "city": _city.volume_db, "room": _room.volume_db,
			"cutoff": _muffle.cutoff_hz if _muffle else 20000.0, "echo": _echo.wet if _echo else 0.0}


func _on_career_changed() -> void:
	if Career.money > _last_money:
		Sfx.play(self, CASH, -6.0)
	_last_money = Career.money
