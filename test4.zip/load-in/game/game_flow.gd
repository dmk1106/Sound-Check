class_name GameFlow
extends Node
## Walks the player through the loop: move out -> studio -> pick a gig ->
## drive to it -> set up -> play -> home. It only watches where things
## physically are and says what to do next; it never moves or stores gear.

signal objective_changed(text: String)
## Where the current step wants you to go changed (null = nowhere in particular).
signal destination_changed(destination: Node3D)
## Where the route (minimap and the white line on the ground) leads changed.
signal route_target_changed(target: Node3D)

enum Step { LOAD_HOME, DRIVE_TO_STUDIO, GET_GIG, LOAD_GIG, DRIVE_TO_VENUE, SET_UP, PLAY, PACK_UP, DRIVE_BACK, FREE }

## How close (metres) the parked truck has to be to count as "there".
@export var arrive_distance := 12.0

var step := Step.LOAD_HOME
var objective := ""
## The spot the current step is heading for (studio parking, the venue's
## parking, the mic...), or null. The minimap routes to it.
var destination: Node3D = null
## Where the guide route leads: the destination, or when this step has none,
## the next place the loop takes you (the studio at the very start, the
## venue while you fetch gear for a gig). null = no route.
var route_target: Node3D = null

var _timer := 0.0
var _venue: Venue
var _show_venue: Venue

@onready var _beacon: Node3D = $Beacon
@onready var _truck: Truck = get_tree().get_first_node_in_group(&"truck")
@onready var _studio: Node3D = get_tree().get_first_node_in_group(&"studio")
@onready var _studio_parking: Node3D = get_tree().get_first_node_in_group(&"studio_parking")


func _ready() -> void:
	add_to_group(&"game_flow")
	for node in get_tree().get_nodes_in_group(&"venue"):
		var venue := node as Venue
		venue.show_started.connect(func() -> void:
			_show_venue = venue
			_go(Step.PLAY))
		venue.show_finished.connect(func(_result: Dictionary) -> void: _go(Step.PACK_UP))
	_truck.cargo_changed.connect(_on_cargo_changed)
	_update()


func _physics_process(delta: float) -> void:
	_timer -= delta
	if _timer <= 0.0:
		_timer = 0.25
		_update()


## The venue of the booked gig (null without a gig).
func get_venue() -> Venue:
	if not Career.has_job():
		return null
	for node in get_tree().get_nodes_in_group(&"venue"):
		if (node as Venue).venue_id == Career.job.venue:
			return node
	return null


func _update() -> void:
	_venue = get_venue()
	# Booking a gig while pottering about jumps straight to getting ready for it.
	if Career.has_job() and step in [Step.GET_GIG, Step.FREE]:
		step = Step.LOAD_GIG
	var text := ""
	var target: Node3D = null
	match step:
		Step.LOAD_HOME:
			text = "Moving day! Load your guitar and amp into the truck"
			if _truck_has_all(_owned_gear()):
				step = Step.DRIVE_TO_STUDIO
		Step.DRIVE_TO_STUDIO:
			text = "Close the back, get in the cab and drive to your new studio"
			target = _studio_parking
			if _parked_at(_studio_parking):
				step = Step.GET_GIG
		Step.GET_GIG:
			text = "Pop into the studio and pick a gig from the board. Leave the gear in the truck."
			target = _studio
		Step.LOAD_GIG:
			# Usually everything is still in the truck from moving day, so this passes at once.
			text = "The gig needs the %s. Get it into the truck." % Career.describe_kinds(_kinds_not_in_truck())
			if _kinds_not_in_truck().is_empty():
				step = Step.DRIVE_TO_VENUE
		Step.DRIVE_TO_VENUE:
			text = "Drive to %s" % Career.job.venue_name
			target = _venue.get_node(^"Parking")
			if _parked_at(target):
				step = Step.SET_UP
			elif not _kinds_not_in_truck().is_empty() and not _near(target, 30.0):
				step = Step.LOAD_GIG
		Step.SET_UP:
			text = "Set up: carry the %s over to the mic" % Career.describe_kinds(_venue.missing_kinds())
			target = _venue.get_node(^"Mic")
			if _venue.is_set_up():
				step = Step.PLAY
		Step.PLAY:
			if _venue == null or _venue.playing:
				text = ""
			else:
				text = "Step up to the mic and start the show"
				target = _venue.get_node(^"Mic")
				if not _venue.is_set_up():
					step = Step.SET_UP
		Step.PACK_UP:
			text = "Pack your gear back into the truck"
			# Packed = nothing of yours left on the stage.
			if _show_venue == null or _show_venue.stage.get_gear().is_empty():
				step = Step.DRIVE_BACK
		Step.DRIVE_BACK:
			text = "Drive back to the studio"
			target = _studio_parking
			if _parked_at(_studio_parking):
				step = Step.FREE
		Step.FREE:
			text = "Pick another gig from the board, do up the studio from the catalogue, or go shopping at Wobble Music"
	_beacon.visible = target != null
	if target:
		_beacon.global_position = Vector3(target.global_position.x, 0.0, target.global_position.z)
	if text != objective:
		objective = text
		objective_changed.emit(objective)
	if target != destination:
		destination = target
		destination_changed.emit(destination)
	var route := target
	if route == null:
		match step:
			Step.LOAD_HOME:
				route = _studio_parking
			Step.LOAD_GIG:
				route = _venue.get_node(^"Parking") if _venue else null
			Step.FREE:
				route = _studio
	if route != route_target:
		route_target = route
		route_target_changed.emit(route_target)


func _go(new_step: Step) -> void:
	step = new_step
	_update()


# Something dropping out of a moving truck is worth a shout.
var _last_cargo := 0
func _on_cargo_changed(loaded: Array[Grabbable]) -> void:
	if loaded.size() < _last_cargo and _truck.driver != null:
		Career.say("Something fell out of the truck! Stop and grab it.")
	_last_cargo = loaded.size()


func _owned_gear() -> Array[Equipment]:
	var gear: Array[Equipment] = []
	for node in get_tree().get_nodes_in_group(&"equipment"):
		var item := node as Equipment
		if item and item.is_owned():
			gear.append(item)
	return gear


func _truck_has_all(gear: Array[Equipment]) -> bool:
	if gear.is_empty():
		return false
	for item in gear:
		if not _truck.is_loaded(item):
			return false
	return true


# Kinds the booked gig needs that are not in the truck.
func _kinds_not_in_truck() -> Array[StringName]:
	var kinds := {}
	for item in _truck.get_loaded():
		if item is Equipment:
			kinds[(item as Equipment).kind] = true
	var missing: Array[StringName] = []
	if Career.has_job():
		for kind: StringName in Career.job.needs:
			if not kinds.has(kind):
				missing.append(kind)
	return missing


func _near(place: Node3D, distance: float) -> bool:
	var offset := _truck.global_position - place.global_position
	return Vector2(offset.x, offset.z).length() < distance


func _parked_at(place: Node3D) -> bool:
	return _truck.driver == null and _near(place, arrive_distance)
