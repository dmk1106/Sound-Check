class_name Sfx
extends RefCounted
## One-shot sounds. Each makes its own little player that removes itself.

## A sound somewhere in the world. `context` is any node in the scene tree.
static func play_at(context: Node, stream: AudioStream, position: Vector3, volume_db := 0.0, pitch := 1.0, reach := 30.0) -> void:
	var speaker := AudioStreamPlayer3D.new()
	speaker.stream = stream
	speaker.bus = Settings.SFX_BUS
	speaker.volume_db = volume_db
	speaker.pitch_scale = pitch
	speaker.unit_size = 5.0
	speaker.max_distance = reach
	context.get_tree().current_scene.add_child(speaker)
	speaker.global_position = position
	speaker.finished.connect(speaker.queue_free)
	speaker.play()


## A sound that isn't anywhere in particular (the HUD going "ching").
static func play(context: Node, stream: AudioStream, volume_db := 0.0, pitch := 1.0) -> void:
	var speaker := AudioStreamPlayer.new()
	speaker.stream = stream
	speaker.bus = Settings.SFX_BUS
	speaker.volume_db = volume_db
	speaker.pitch_scale = pitch
	context.get_tree().current_scene.add_child(speaker)
	speaker.finished.connect(speaker.queue_free)
	speaker.play()
