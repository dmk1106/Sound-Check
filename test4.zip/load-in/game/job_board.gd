class_name JobBoard
extends Interactable
## The gig board in the studio: lists the gigs, what each one needs you to
## bring, and books the one you pick.

@onready var _offer: Label3D = $Offer

var _menu: GameMenu


func _ready() -> void:
	super()
	prompt = "look at the gig board"
	Career.changed.connect(_refresh)
	interacted.connect(_open_menu)
	_refresh()


func _open_menu(_player: Player) -> void:
	var rows := []
	for gig in Career.GIGS:
		var offered := Career.is_offered(gig)
		var detail := "Bring: %s.  Bonus: %s.  At %s." % [Career.describe_kinds(gig.needs), Career.describe_kinds(gig.bonus), gig.venue_name]
		if not offered:
			detail = "Needs %d fans." % gig.needs_fans
		rows.append({"text": gig.title, "detail": detail, "tag": "$%d" % gig.pay, "disabled": not offered})
	_menu = GameMenu.open(self, "Gigs", rows)
	_menu.chosen.connect(func(index: int) -> void:
		Career.accept(Career.GIGS[index])
		_menu.close())


func _refresh() -> void:
	if Career.has_job():
		_offer.text = "BOOKED\n%s\nbring: %s" % [Career.job.title, Career.describe_kinds(Career.job.needs)]
	else:
		_offer.text = "GIGS\npick one\nhere"
