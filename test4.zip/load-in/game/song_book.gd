class_name SongBook
extends RefCounted
## The player's own songs, sketched at the creek. A song is plain data:
##   {"title": String, "bpm": int, "steps": [[lane, ...], ...]}
## one entry per eighth note, each a list of the lanes (0-4, low to high) that
## sound on it. Saved as JSON in user://songs.json.
##
## This is the foundation only. Nothing else in the game reads the book yet;
## to_chart() is there so a sketch can become a playable gig song later.

const FILE := "user://songs.json"
const STEPS := 16
const LANES := 5
const TEMPOS: Array[int] = [80, 100, 120, 140]


static func blank(title: String) -> Dictionary:
	var steps := []
	for i in STEPS:
		steps.append([])
	return {"title": title, "bpm": 100, "steps": steps}


static func load_all() -> Array:
	if not FileAccess.file_exists(FILE):
		return []
	var parsed: Variant = JSON.parse_string(FileAccess.get_file_as_string(FILE))
	if parsed is Dictionary and (parsed as Dictionary).get("songs") is Array:
		return (parsed as Dictionary).songs
	return []


## Adds the song, or replaces the one with the same title.
static func save_song(song: Dictionary) -> void:
	var songs := load_all()
	var replaced := false
	for i in songs.size():
		if songs[i].title == song.title:
			songs[i] = song.duplicate(true)
			replaced = true
	if not replaced:
		songs.append(song.duplicate(true))
	var file := FileAccess.open(FILE, FileAccess.WRITE)
	if file:
		file.store_string(JSON.stringify({"songs": songs}, "\t"))


static func delete_song(title: String) -> void:
	var kept := []
	for song: Dictionary in load_all():
		if song.title != title:
			kept.append(song)
	var file := FileAccess.open(FILE, FileAccess.WRITE)
	if file:
		file.store_string(JSON.stringify({"songs": kept}, "\t"))


## A name nobody has used yet.
static func next_title() -> String:
	var taken := {}
	for song: Dictionary in load_all():
		taken[song.title] = true
	var number := 1
	while taken.has("Creek song %d" % number):
		number += 1
	return "Creek song %d" % number


## The song as a rhythm-game chart: [beat, lane] for every note (two steps to the beat).
static func to_chart(song: Dictionary) -> Array:
	var chart := []
	for i in (song.steps as Array).size():
		for lane: Variant in song.steps[i]:
			chart.append([i * 0.5, int(lane)])
	return chart
