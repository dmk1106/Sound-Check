extends Node
## The player's career: money, fans, the gigs on offer and the one that is
## booked. Autoloaded as "Career". Nothing in here stores gear: equipment only
## ever exists as physical objects in the world.

signal changed
## Short messages for the HUD ("Gig booked", "Not enough money"...).
signal message(text: String)
## A new part of town opened up.
signal area_unlocked(area: Dictionary)
## Money taken away (knocking someone over with the truck...).
signal fined(amount: int)

## Every gig. `needs` = kinds of gear (Equipment.kind) that must be on stage,
## `bonus` = kinds that pay extra if they are there too, `needs_fans` = how
## well known you have to be before the gig is offered.
const GIGS: Array[Dictionary] = [
	{"id": &"alley", "title": "Back alley session", "venue": &"alley", "venue_name": "Cat Alley, under the tracks off Canal Street",
			"song": &"alley_cat_shuffle", "pay": 60, "fans": 20, "needs_fans": 0, "needs": [&"guitar"], "bonus": [&"mic", &"amp"]},
	{"id": &"diner", "title": "Dinner set at the diner", "venue": &"diner", "venue_name": "the Moon Diner on Kanda Avenue",
			"song": &"late_night_diner", "pay": 45, "fans": 14, "needs_fans": 0, "needs": [&"guitar"], "bonus": [&"mic"]},
	{"id": &"rock", "title": "Rock night", "venue": &"bandshell", "venue_name": "The Bandshell in the park",
			"song": &"garage_sunrise", "pay": 130, "fans": 35, "needs_fans": 40, "needs": [&"guitar", &"amp"], "bonus": [&"mic", &"bass"]},
	{"id": &"keys", "title": "Keyboard lounge set", "venue": &"alley", "venue_name": "Cat Alley, under the tracks off Canal Street",
			"song": &"alley_cat_shuffle", "pay": 150, "fans": 30, "needs_fans": 40, "needs": [&"keyboard"], "bonus": [&"mic"]},
	{"id": &"drums", "title": "Drum showcase", "venue": &"bandshell", "venue_name": "The Bandshell in the park",
			"song": &"neon_rush", "pay": 210, "fans": 50, "needs_fans": 90, "needs": [&"drums"], "bonus": [&"bass", &"amp"]},
	{"id": &"headline", "title": "Headline set", "venue": &"bandshell", "venue_name": "The Bandshell in the park",
			"song": &"neon_rush", "pay": 340, "fans": 90, "needs_fans": 150, "needs": [&"guitar", &"amp", &"mic"], "bonus": [&"drums", &"keyboard", &"bass"]},
	{"id": &"balcony", "title": "Balcony show, Skyline Tower", "venue": &"tower", "venue_name": "Skyline Tower in Uptown (take the lift)",
			"song": &"top_of_the_town", "pay": 480, "fans": 130, "needs_fans": 150, "needs": [&"guitar", &"amp"], "bonus": [&"mic", &"keyboard", &"bass"]},
	{"id": &"busk", "title": "Busking at Hachi Plaza", "venue": &"plaza", "venue_name": "Hachi Plaza on Neon Row",
			"song": &"alley_cat_shuffle", "pay": 30, "fans": 12, "needs_fans": 0, "needs": [&"guitar"], "bonus": [&"amp"]},
]

## Parts of town that open up as the fans add up (see world/fan_gate.gd).
const AREAS: Array[Dictionary] = [
	{"id": &"park_side", "name": "Park Side", "fans": 40},
	{"id": &"uptown", "name": "Uptown", "fans": 150},
	{"id": &"harbour", "name": "The Harbour", "fans": 500},
]

const KIND_NAMES := {&"guitar": "guitar", &"amp": "amp", &"mic": "microphone", &"bass": "bass",
		&"keyboard": "keyboard", &"drums": "drum kit"}

var money := 0
var fans := 0
var gigs_played := 0
## The booked gig (empty when none).
var job := {}

var _unlocked := {}


func reset() -> void:
	money = 0
	fans = 0
	gigs_played = 0
	job = {}
	_unlocked = {}
	changed.emit()


func has_job() -> bool:
	return not job.is_empty()


func is_offered(gig: Dictionary) -> bool:
	return fans >= int(gig.needs_fans)


func accept(gig: Dictionary) -> void:
	job = gig.duplicate()
	changed.emit()
	message.emit("Gig booked: %s" % job.title)


func is_area_open(id: StringName) -> bool:
	for area in AREAS:
		if area.id == id:
			return fans >= int(area.fans)
	return true


## "a guitar and an amp"
static func describe_kinds(kinds: Array) -> String:
	var names := PackedStringArray()
	for kind: StringName in kinds:
		names.append(KIND_NAMES.get(kind, String(kind)))
	if names.is_empty():
		return "nothing"
	if names.size() == 1:
		return names[0]
	var last := names[names.size() - 1]
	names.remove_at(names.size() - 1)
	return ", ".join(names) + " and " + last


## Pays out the booked gig.
##   accuracy 0..1 from the rhythm game, gear_quality = summed quality of the
##   required gear on stage, bonus_gear = how many optional pieces were there,
##   difficulty_pay = multiplier of the chosen difficulty.
func finish_job(accuracy: float, gear_quality: int, bonus_gear := 0, difficulty_pay := 1.0) -> Dictionary:
	var gear_bonus := 1.0 + 0.25 * gear_quality + 0.15 * bonus_gear
	var pay := roundi(float(job.pay) * (0.4 + 0.6 * accuracy) * gear_bonus * difficulty_pay)
	var new_fans := roundi(float(job.fans) * (0.3 + 0.7 * accuracy) * gear_bonus)
	var result := {"title": job.title, "pay": pay, "fans": new_fans, "accuracy": accuracy}
	money += pay
	gigs_played += 1
	job = {}
	add_fans(new_fans)
	return result


func add_fans(amount: int) -> void:
	fans += amount
	changed.emit()
	for area in AREAS:
		if fans >= int(area.fans) and not _unlocked.has(area.id):
			_unlocked[area.id] = true
			area_unlocked.emit(area)
			message.emit("New part of town open: %s!" % area.name)


func can_afford(price: int) -> bool:
	return money >= price


func spend(price: int) -> bool:
	if money < price:
		message.emit("Not enough money")
		return false
	money -= price
	changed.emit()
	return true


## Takes money away, whether or not there is any (you can end up owing).
func fine(amount: int, reason: String) -> void:
	money -= amount
	changed.emit()
	fined.emit(amount)
	message.emit("-$%d  %s" % [amount, reason])


func say(text: String) -> void:
	message.emit(text)
