class_name Venue
extends Node3D
## A place to play: a stage area that knows what gear is physically on it, a
## mic to start the show from, and a crowd. Gear has to be carried here for real.

signal show_started
signal show_finished(result: Dictionary)
## The results screen was dismissed: back to walking around.
signal game_closed

const RHYTHM_GAME := preload("res://ui/rhythm_game.tscn")

## Matches "venue" in Career.GIGS.
@export var venue_id: StringName = &"bandshell"
@export var venue_name := "The Bandshell"
## If false the crowd is always hanging around; if true they only turn up for a booked gig.
@export var crowd_arrives_for_gig := true
## During a show the camera normally looks at the stage from out front. With
## this on it sits behind the performer instead and looks out over the crowd
## (for a balcony, where the view is the point).
@export var camera_behind := false

## True while a show is on.
var playing := false
## The running rhythm game (null between shows).
var game: RhythmGame = null

var _player: Player
var _difficulty := {}
var _menu: GameMenu
var _crowd: Array[Npc] = []

@onready var stage: GearZone = $StageZone
@onready var _mic: Interactable = $Mic


func _ready() -> void:
	add_to_group(&"venue")
	for node in $Crowd.get_children():
		if node is Npc:
			_crowd.append(node)
	_mic.interacted.connect(_on_mic_used)
	stage.changed.connect(_refresh)
	Career.changed.connect(_refresh)
	_refresh()


func _process(_delta: float) -> void:
	if playing and game:
		for fan in _crowd:
			fan.excitement = game.mood


func has_gig() -> bool:
	return Career.has_job() and Career.job.venue == venue_id


## Kinds of gear the booked gig still needs on stage.
func missing_kinds() -> Array[StringName]:
	var missing: Array[StringName] = []
	if not has_gig():
		return missing
	var here := stage.best_by_kind()
	for kind: StringName in Career.job.needs:
		if not here.has(kind):
			missing.append(kind)
	return missing


## True once everything the booked gig needs is on stage.
func is_set_up() -> bool:
	return has_gig() and missing_kinds().is_empty()


func start_show(player: Player, difficulty: Dictionary) -> void:
	if playing:
		return
	playing = true
	_player = player
	_difficulty = difficulty
	_mic.enabled = false
	for fan in _crowd:
		fan.watch(player)
	player.hands.drop()
	player.controls_enabled = false
	player.performing = _instrument()
	# Face the crowd; camera out front, looking at the stage.
	player.face_toward(global_rotation.y)
	player.camera_rig.yaw = global_rotation.y + (0.0 if camera_behind else PI)
	player.camera_rig.pitch = deg_to_rad(-20.0 if camera_behind else -12.0)
	var song: StringName = Career.job.song
	game = RHYTHM_GAME.instantiate()
	add_child(game)
	game.finished.connect(_on_song_finished)
	game.closed.connect(_on_results_closed)
	game.start(Songs.title(song), Songs.bpm(song), Songs.chart(song, difficulty.id), Songs.stream(song), difficulty.window)
	show_started.emit()


## Which clip the player performs with: whatever lead instrument is on stage.
func _instrument() -> StringName:
	var gear := stage.best_by_kind()
	if gear.has(&"guitar") or gear.has(&"bass"):
		return &"guitar"
	if gear.has(&"keyboard"):
		return &"piano"
	if gear.has(&"drums"):
		return &"drums"
	return &"guitar"


func _on_mic_used(player: Player) -> void:
	if not Career.has_job():
		Career.say("No gig booked. Pick one from the board at your studio.")
	elif not has_gig():
		Career.say("Tonight's gig is at %s, not here." % Career.job.venue_name)
	elif not missing_kinds().is_empty():
		Career.say("Set up first: you still need the %s here." % Career.describe_kinds(missing_kinds()))
	else:
		var rows := []
		for difficulty in Songs.DIFFICULTIES:
			rows.append({"text": difficulty.name, "detail": difficulty.detail})
		_menu = GameMenu.open(self, Songs.title(Career.job.song), rows)
		_menu.chosen.connect(func(index: int) -> void:
			_menu.close()
			start_show(player, Songs.DIFFICULTIES[index]))


func _on_song_finished(accuracy: float) -> void:
	var gear := stage.best_by_kind()
	var quality := 0
	for kind: StringName in Career.job.needs:
		if gear.has(kind):
			quality += (gear[kind] as Equipment).quality
	var extras := 0
	for kind: StringName in Career.job.bonus:
		if gear.has(kind):
			extras += 1
	var result := Career.finish_job(accuracy, quality, extras, float(_difficulty.pay))
	for fan in _crowd:
		fan.cheer(accuracy)
	game.show_results(result)
	show_finished.emit(result)


func _on_results_closed() -> void:
	game.queue_free()
	game = null
	playing = false
	_mic.enabled = true
	_player.controls_enabled = true
	_player.performing = &""
	for fan in _crowd:
		fan.relax()
	game_closed.emit()
	_refresh()


func _refresh() -> void:
	if not has_gig():
		_mic.prompt = "play a show (no gig booked here)"
	elif not missing_kinds().is_empty():
		_mic.prompt = "play the show (bring the %s first)" % Career.describe_kinds(missing_kinds())
	else:
		_mic.prompt = "start the show"
	if crowd_arrives_for_gig and not playing:
		for fan in _crowd:
			fan.set_present(has_gig())
	# No crowd, no murmur.
	var murmur := get_node_or_null(^"Crowd/Murmur") as AudioStreamPlayer3D
	if murmur:
		murmur.stream_paused = crowd_arrives_for_gig and not has_gig()
	var interactor := get_tree().get_first_node_in_group(&"interactor") as Interactor
	if interactor:
		interactor.refresh()
