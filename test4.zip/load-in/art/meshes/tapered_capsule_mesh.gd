@tool
class_name TaperedCapsuleMesh
extends PrimitiveMesh
## A capsule whose two ends can have different radii: bellies, limbs, pear and
## egg shapes. Its axis is local Y; `height` is the full length including both ends.

@export_range(0.0, 10.0, 0.001, "or_greater", "suffix:m") var bottom_radius := 0.3:
	set(value):
		bottom_radius = value
		request_update()

@export_range(0.0, 10.0, 0.001, "or_greater", "suffix:m") var top_radius := 0.2:
	set(value):
		top_radius = value
		request_update()

@export_range(0.0, 10.0, 0.001, "or_greater", "suffix:m") var height := 1.0:
	set(value):
		height = value
		request_update()

@export_range(3, 64) var radial_segments := 24:
	set(value):
		radial_segments = value
		request_update()

## Rings on each rounded end.
@export_range(2, 24) var rings := 8:
	set(value):
		rings = value
		request_update()


func _create_mesh_array() -> Array:
	var low := -height * 0.5 + bottom_radius    # centre of the bottom ball
	var high := maxf(height * 0.5 - top_radius, low)
	# Where the straight flank touches both balls.
	var between := maxf(high - low, 0.0001)
	var flank := asin(clampf((bottom_radius - top_radius) / between, -1.0, 1.0))

	var points := PackedVector2Array()
	var normals := PackedVector2Array()
	Lathe.arc(points, normals, Vector2(0.0, low), bottom_radius, -PI * 0.5, flank, rings)
	Lathe.arc(points, normals, Vector2(0.0, high), top_radius, flank, PI * 0.5, rings)
	return Lathe.build(points, normals, radial_segments)
