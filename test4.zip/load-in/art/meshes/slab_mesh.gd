@tool
class_name SlabMesh
extends PrimitiveMesh
## A shape cut out of a slab, with softly rounded edges: guitar bodies, signs,
## anything with a recognisable silhouette. Draw the outline in the XY plane,
## anticlockwise as seen from +Z; the slab's thickness runs along Z.

@export var outline := PackedVector2Array([Vector2(-0.5, -0.5), Vector2(0.5, -0.5), Vector2(0.5, 0.5), Vector2(-0.5, 0.5)]):
	set(value):
		outline = value
		request_update()
@export_range(0.001, 10.0, 0.001, "or_greater", "suffix:m") var thickness := 0.1:
	set(value):
		thickness = value
		request_update()
## Radius of the rounded edge (never more than half the thickness).
@export_range(0.0, 1.0, 0.001, "or_greater", "suffix:m") var bevel := 0.02:
	set(value):
		bevel = value
		request_update()
@export_range(1, 8) var bevel_segments := 3:
	set(value):
		bevel_segments = value
		request_update()


func _create_mesh_array() -> Array:
	var points := outline
	if points.size() < 3:
		points = PackedVector2Array([Vector2(-0.5, -0.5), Vector2(0.5, -0.5), Vector2(0.0, 0.5)])
	var count := points.size()
	var half := thickness * 0.5
	var b := clampf(bevel, 0.0, half)

	# Which way is "out" at every point of the outline, and how far the edge
	# can be pulled in there before a tight corner would fold over itself.
	var outward := PackedVector2Array()
	var pull := PackedFloat32Array()
	for i in count:
		var before := points[(i - 1 + count) % count]
		var after := points[(i + 1) % count]
		var tangent := (after - before).normalized()
		outward.append(Vector2(tangent.y, -tangent.x))
		# Radius of the circle through this point and its neighbours two steps away.
		var p0 := points[(i - 2 + count) % count]
		var p1 := points[i]
		var p2 := points[(i + 2) % count]
		var turn := (p1 - p0).cross(p2 - p1)
		var limit := 1.0
		if turn > 0.000001 and b > 0.0:   # convex corner
			var corner_radius := (p1 - p0).length() * (p2 - p1).length() * (p2 - p0).length() / (2.0 * turn)
			limit = clampf(corner_radius * 0.75 / b, 0.0, 1.0)
		pull.append(limit)
	# Smooth the limits so the rim doesn't ripple, without ever exceeding them.
	for pass_index in 3:
		var smoothed := pull.duplicate()
		for i in count:
			var average := (pull[(i - 1 + count) % count] + pull[i] + pull[(i + 1) % count]) / 3.0
			smoothed[i] = minf(pull[i], average)
		pull = smoothed

	var vertices := PackedVector3Array()
	var normals := PackedVector3Array()
	var uvs := PackedVector2Array()
	var indices := PackedInt32Array()

	# Rings from the edge of the front face, around the rounded rim, to the edge of the back face.
	var rings := 0
	for face in 2:
		var side := 1.0 if face == 0 else -1.0
		for step in bevel_segments + 1:
			var k := step if face == 0 else bevel_segments - step
			var a := PI * 0.5 * float(k) / bevel_segments
			var inset := b * (1.0 - sin(a))
			var z := (half - b * (1.0 - cos(a))) * side
			for i in count:
				var p := points[i] - outward[i] * inset * pull[i]
				vertices.append(Vector3(p.x, p.y, z))
				normals.append(Vector3(outward[i].x * sin(a), outward[i].y * sin(a), cos(a) * side).normalized())
				uvs.append(Vector2(float(i) / count, float(rings) / (bevel_segments * 2 + 1)))
			rings += 1
	for ring in rings - 1:
		for i in count:
			var a := ring * count + i
			var b2 := ring * count + (i + 1) % count
			var c := a + count
			var d := b2 + count
			indices.append_array(PackedInt32Array([a, b2, d, a, d, c]))

	# Flat faces. Godot's front faces are clockwise. The triangles are worked
	# out on the outline itself (always a clean polygon), then drawn with the
	# pulled-in edge of each face.
	var front := PackedVector2Array()
	for i in count:
		front.append(Vector2(vertices[i].x, vertices[i].y))
	var triangles := Geometry2D.triangulate_polygon(points)
	var back_start := (rings - 1) * count
	for t in range(0, triangles.size(), 3):
		var i0 := triangles[t]
		var i1 := triangles[t + 1]
		var i2 := triangles[t + 2]
		if (front[i1] - front[i0]).cross(front[i2] - front[i0]) > 0.0:
			var swap := i1
			i1 = i2
			i2 = swap
		indices.append_array(PackedInt32Array([i0, i1, i2]))
		indices.append_array(PackedInt32Array([back_start + i0, back_start + i2, back_start + i1]))

	var arrays := []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = vertices
	arrays[Mesh.ARRAY_NORMAL] = normals
	arrays[Mesh.ARRAY_TEX_UV] = uvs
	arrays[Mesh.ARRAY_INDEX] = indices
	return arrays
