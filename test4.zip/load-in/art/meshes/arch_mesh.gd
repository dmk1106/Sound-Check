@tool
class_name ArchMesh
extends PrimitiveMesh
## A tube bent into an arc (a slice of a torus) standing in the XY plane,
## centred on the origin with the middle of the arc pointing up (+Y).
## Handles, headbands, wheel arches, smiles.

## Radius of the arc, measured to the middle of the tube.
@export_range(0.01, 10.0, 0.001, "or_greater", "suffix:m") var radius := 0.5:
	set(value):
		radius = value
		request_update()
@export_range(0.001, 5.0, 0.001, "or_greater", "suffix:m") var tube_radius := 0.05:
	set(value):
		tube_radius = value
		request_update()
## How much of the circle the arc covers.
@export_range(1.0, 360.0, 0.1, "degrees") var angle := 180.0:
	set(value):
		angle = value
		request_update()
## Stretches the tube along Z: 1 = round, 3 = a wide strap.
@export_range(0.1, 10.0, 0.01, "or_greater") var width_scale := 1.0:
	set(value):
		width_scale = value
		request_update()
@export_range(2, 64) var arc_segments := 16:
	set(value):
		arc_segments = value
		request_update()
@export_range(3, 32) var tube_segments := 10:
	set(value):
		tube_segments = value
		request_update()


func _create_mesh_array() -> Array:
	var vertices := PackedVector3Array()
	var normals := PackedVector3Array()
	var uvs := PackedVector2Array()
	var indices := PackedInt32Array()

	var sweep := deg_to_rad(angle)
	var start := PI * 0.5 + sweep * 0.5   # left end first, so the arc runs clockwise seen from +Z
	var row := tube_segments + 1
	for i in arc_segments + 1:
		var a := start - sweep * float(i) / arc_segments
		var out := Vector3(cos(a), sin(a), 0.0)
		for j in row:
			var b := TAU * float(j) / tube_segments
			var offset := out * cos(b) * tube_radius + Vector3.BACK * sin(b) * tube_radius * width_scale
			vertices.append(out * radius + offset)
			normals.append((out * cos(b) * width_scale + Vector3.BACK * sin(b)).normalized())
			uvs.append(Vector2(float(i) / arc_segments, float(j) / tube_segments))
	for i in arc_segments:
		for j in tube_segments:
			var a := i * row + j
			var b := a + 1
			var c := a + row
			var d := c + 1
			indices.append_array(PackedInt32Array([a, c, d, a, d, b]))

	# Flat caps on both ends.
	for end in 2:
		var a := start - sweep * float(end)
		var out := Vector3(cos(a), sin(a), 0.0)
		var along := Vector3(sin(a), -cos(a), 0.0)   # direction the arc travels
		var normal := along if end == 1 else -along
		var centre := vertices.size()
		vertices.append(out * radius)
		normals.append(normal)
		uvs.append(Vector2(0.5, 0.5))
		for j in row:
			var b := TAU * float(j) / tube_segments
			vertices.append(out * radius + out * cos(b) * tube_radius + Vector3.BACK * sin(b) * tube_radius * width_scale)
			normals.append(normal)
			uvs.append(Vector2(0.5 + cos(b) * 0.5, 0.5 + sin(b) * 0.5))
		for j in tube_segments:
			var p := centre + 1 + j
			if end == 0:
				indices.append_array(PackedInt32Array([centre, p, p + 1]))
			else:
				indices.append_array(PackedInt32Array([centre, p + 1, p]))

	var arrays := []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = vertices
	arrays[Mesh.ARRAY_NORMAL] = normals
	arrays[Mesh.ARRAY_TEX_UV] = uvs
	arrays[Mesh.ARRAY_INDEX] = indices
	return arrays
