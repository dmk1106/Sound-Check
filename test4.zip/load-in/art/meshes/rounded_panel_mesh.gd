@tool
class_name RoundedPanelMesh
extends PrimitiveMesh
## A flat, single-sided panel with rounded corners, facing +Z (like QuadMesh).
## A radius of half the shorter side gives a pill; on a square, a disc.

@export var size := Vector2(1.0, 1.0):
	set(value):
		size = value
		request_update()
@export var radius := 0.1:
	set(value):
		radius = value
		request_update()
## Segments per corner.
@export_range(1, 24) var segments := 6:
	set(value):
		segments = value
		request_update()


func _create_mesh_array() -> Array:
	var half := size * 0.5
	var r := clampf(radius, 0.0, minf(half.x, half.y))
	var steps := segments if r > 0.0 else 0
	var inner := half - Vector2(r, r)
	var corners: Array[Vector2] = [
		Vector2(inner.x, inner.y), Vector2(-inner.x, inner.y),
		Vector2(-inner.x, -inner.y), Vector2(inner.x, -inner.y)]

	# Centre, then the outline anticlockwise as seen from +Z.
	var outline := PackedVector2Array()
	for corner in 4:
		for step in steps + 1:
			var angle := (corner + (float(step) / steps if steps > 0 else 0.0)) * PI * 0.5
			outline.append(corners[corner] + Vector2(cos(angle), sin(angle)) * r)

	var vertices := PackedVector3Array([Vector3.ZERO])
	var normals := PackedVector3Array([Vector3.BACK])
	var uvs := PackedVector2Array([Vector2(0.5, 0.5)])
	for point in outline:
		vertices.append(Vector3(point.x, point.y, 0.0))
		normals.append(Vector3.BACK)
		uvs.append(Vector2(point.x / size.x + 0.5, 0.5 - point.y / size.y))

	var indices := PackedInt32Array()
	var count := outline.size()
	for i in count:
		# Godot's front faces are clockwise.
		indices.append_array(PackedInt32Array([0, 1 + (i + 1) % count, 1 + i]))

	var arrays := []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = vertices
	arrays[Mesh.ARRAY_NORMAL] = normals
	arrays[Mesh.ARRAY_TEX_UV] = uvs
	arrays[Mesh.ARRAY_INDEX] = indices
	return arrays
