@tool
class_name Lathe
## Helper for the round toy meshes: spins a 2D outline around the Y axis.


## `points` are (radius, height) pairs from the bottom up; `normals` are the
## matching outward directions as (radial, vertical). Returns mesh arrays.
static func build(points: PackedVector2Array, normals: PackedVector2Array, radial_segments: int) -> Array:
	var vertices := PackedVector3Array()
	var vertex_normals := PackedVector3Array()
	var uvs := PackedVector2Array()
	var indices := PackedInt32Array()
	var columns := radial_segments + 1

	for k in points.size():
		for s in columns:
			var angle := TAU * s / radial_segments
			var around := Vector3(cos(angle), 0.0, sin(angle))
			vertices.append(around * points[k].x + Vector3.UP * points[k].y)
			vertex_normals.append((around * normals[k].x + Vector3.UP * normals[k].y).normalized())
			uvs.append(Vector2(float(s) / radial_segments, 1.0 - float(k) / (points.size() - 1)))

	for k in points.size() - 1:
		for s in radial_segments:
			var a := k * columns + s
			var b := a + columns
			var c := b + 1
			var d := a + 1
			indices.append_array(PackedInt32Array([a, d, c, a, c, b]))

	var arrays := []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = vertices
	arrays[Mesh.ARRAY_NORMAL] = vertex_normals
	arrays[Mesh.ARRAY_TEX_UV] = uvs
	arrays[Mesh.ARRAY_INDEX] = indices
	return arrays


## Appends a circular arc to an outline: centre, radius, start/end angle of the
## normal above the horizon (radians), number of steps.
static func arc(points: PackedVector2Array, normals: PackedVector2Array, center: Vector2, radius: float, from: float, to: float, steps: int) -> void:
	for i in steps + 1:
		var angle := lerpf(from, to, float(i) / steps)
		var direction := Vector2(cos(angle), sin(angle))
		points.append(center + direction * radius)
		normals.append(direction)
