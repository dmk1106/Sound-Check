@tool
class_name RoundedCylinderMesh
extends PrimitiveMesh
## A cylinder (or cone slice) with rounded rims: wheels, knobs, discs, posts, trunks.
## Its axis is local Y.

@export_range(0.0, 10.0, 0.001, "or_greater", "suffix:m") var bottom_radius := 0.5:
	set(value):
		bottom_radius = value
		request_update()

@export_range(0.0, 10.0, 0.001, "or_greater", "suffix:m") var top_radius := 0.5:
	set(value):
		top_radius = value
		request_update()

@export_range(0.0, 10.0, 0.001, "or_greater", "suffix:m") var height := 1.0:
	set(value):
		height = value
		request_update()

## Radius of the rounded rims (never more than half the height or the smaller radius).
@export_range(0.0, 1.0, 0.001, "or_greater", "suffix:m") var bevel := 0.05:
	set(value):
		bevel = value
		request_update()

@export_range(3, 64) var radial_segments := 24:
	set(value):
		radial_segments = value
		request_update()

## Smoothness of the rounded rims.
@export_range(1, 12) var bevel_segments := 4:
	set(value):
		bevel_segments = value
		request_update()


func _create_mesh_array() -> Array:
	var b := clampf(bevel, 0.0, minf(height * 0.5, minf(bottom_radius, top_radius)))
	var half := height * 0.5
	var side := atan2(bottom_radius - top_radius, maxf(height - 2.0 * b, 0.0001))

	var points := PackedVector2Array()
	var normals := PackedVector2Array()
	points.append(Vector2(0.0, -half))
	normals.append(Vector2.UP)   # Vector2.UP is (0, -1): pointing down the mesh's Y axis
	Lathe.arc(points, normals, Vector2(bottom_radius - b, -half + b), b, -PI * 0.5, side, bevel_segments)
	Lathe.arc(points, normals, Vector2(top_radius - b, half - b), b, side, PI * 0.5, bevel_segments)
	points.append(Vector2(0.0, half))
	normals.append(Vector2.DOWN)
	return Lathe.build(points, normals, radial_segments)
