@tool
class_name RoundedBoxMesh
extends PrimitiveMesh
## A box with rounded edges and corners: the basic building block of the toy look.
## Use it wherever you would use a BoxMesh.

@export var size := Vector3.ONE:
	set(value):
		size = value
		request_update()

## Radius of the rounded edges (never more than half the smallest side).
@export_range(0.0, 1.0, 0.001, "or_greater", "suffix:m") var radius := 0.05:
	set(value):
		radius = value
		request_update()

## Smoothness of the rounding.
@export_range(1, 12) var segments := 4:
	set(value):
		segments = value
		request_update()

## Leave the flat middle of one face out, for boxes you can look into.
@export_enum("Closed:-1", "+X:0", "-X:1", "+Y:2", "-Y:3", "+Z:4", "-Z:5") var open_face := -1:
	set(value):
		open_face = value
		request_update()

# For each face: outward normal, then two edge directions with u x v = normal.
const FACES := [
	[Vector3.RIGHT, Vector3.UP, Vector3.BACK],
	[Vector3.LEFT, Vector3.BACK, Vector3.UP],
	[Vector3.UP, Vector3.BACK, Vector3.RIGHT],
	[Vector3.DOWN, Vector3.RIGHT, Vector3.BACK],
	[Vector3.BACK, Vector3.RIGHT, Vector3.UP],
	[Vector3.FORWARD, Vector3.UP, Vector3.RIGHT],
]


func _create_mesh_array() -> Array:
	var half := size * 0.5
	var r := clampf(radius, 0.0, minf(half.x, minf(half.y, half.z)))
	var inner := half - Vector3(r, r, r)
	var steps := segments if r > 0.0 else 0

	var vertices := PackedVector3Array()
	var normals := PackedVector3Array()
	var uvs := PackedVector2Array()
	var indices := PackedInt32Array()

	for face in FACES.size():
		var n: Vector3 = FACES[face][0]
		var u: Vector3 = FACES[face][1]
		var v: Vector3 = FACES[face][2]
		var along_u := _stops(absf(half.dot(u)), r, steps)
		var along_v := _stops(absf(half.dot(v)), r, steps)
		var base := vertices.size()
		var columns := along_v.size()
		for i in along_u.size():
			for j in columns:
				var on_cube := n * absf(half.dot(n)) + u * along_u[i] + v * along_v[j]
				var core := on_cube.clamp(-inner, inner)
				var normal := (on_cube - core).normalized() if r > 0.0 else n
				vertices.append(core + normal * r)
				normals.append(normal)
				uvs.append(Vector2(float(i) / (along_u.size() - 1), float(j) / (columns - 1)))
		for i in along_u.size() - 1:
			for j in columns - 1:
				if face == open_face and i == steps and j == steps:
					continue
				var a := base + i * columns + j
				var b := a + columns
				var c := b + 1
				var d := a + 1
				indices.append_array(PackedInt32Array([a, d, c, a, c, b]))

	var arrays := []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = vertices
	arrays[Mesh.ARRAY_NORMAL] = normals
	arrays[Mesh.ARRAY_TEX_UV] = uvs
	arrays[Mesh.ARRAY_INDEX] = indices
	return arrays


## Positions across one face: bunched up over the rounded edges, one big gap for the flat middle.
func _stops(half_extent: float, r: float, steps: int) -> PackedFloat32Array:
	var flat := half_extent - r
	var stops := PackedFloat32Array()
	for k in range(steps, -1, -1):
		stops.append(-flat - r * tan(PI * 0.25 * k / maxi(steps, 1)))
	for k in steps + 1:
		stops.append(flat + r * tan(PI * 0.25 * k / maxi(steps, 1)))
	return stops
