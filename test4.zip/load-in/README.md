# Load-In (working title)

Goofy physics-driven music career game.

**Current state: the whole loop is playable, in a rainy neon city at night
that carries on around you: people with places to go, traffic, cats, a
soundscape that changes with where you stand, two starter gigs, and a tower
balcony to work up to.**
Load up at the old house, drive through traffic to your studio, pick a gig
from the board, squeeze the truck down a back alley, set up, pick a
difficulty, play the show, get paid, do up the studio, buy more instruments,
repeat. Nothing is an inventory item: every piece of gear is a rigid body
that stays wherever you leave it (including on the road, if you drive off
with the back open).

## Run it

1. Godot **4.4 or newer**, standard build (tested on 4.4, 4.5, 4.6 and 4.7).
2. Import `project.godot`, press **F5**.

Physics engine: Jolt (built into Godot 4.4+). Renderer: Forward+.

Slow on an older laptop? In `art/toy_environment.tres` turn off SSR, SSAO and
glow, and in `art/toy_lens.tres` turn off the far blur. Or switch the project
to the Compatibility renderer: it skips most of those by itself (the night
look is built for Forward+ and is flatter there).

## Controls

| Action | Keyboard / mouse | Gamepad |
|---|---|---|
| Move / drive | WASD or arrows | Left stick |
| Look | Mouse | Right stick |
| Grab (hold) and drop (release) | Left mouse button | RT or RB |
| Use: truck doors, driver's seat, gig board, catalogue, price tags, mic | E | X |
| Menus: move / pick / close | W S (A D for sliders) / E / Esc | D-pad / X / Start |
| Pause + settings (music / sound volume, truck radio) | Esc, then drag the sliders with the mouse | Start |
| Truck radio on / off (while driving) | R | Y |
| Sit (creek log), then write a song / get up | E, then E / Space | X, then X / A |
| Raise / lower what you hold | Mouse wheel, or E / Q while holding | D-pad up / down |
| Jump (on foot), brake (driving) | Space | A |
| Hit notes in a show (five lanes) | D F J K L | D-pad left / up, X, Y, B |
| Restart | Backspace | Back |

The character faces the way it walks and its arms always reach out in front of
it; the mouse only turns the camera. Light things (guitar) are carried in
front of you. Heavy things (amps) can't be lifted: grab one and walk, and it
drags along behind you.

## The loop

1. Old house: carry the guitar and drag the amp into the truck.
2. Close the back (E at the back of the truck), get in (E at a cab door), drive.
   The yellow beam shows where to go. Leave the back open and light gear
   slides out onto the road when you pull away or corner: stop, get out, pick
   it up, put it back.
3. Studio (Back Street, cyan STUDIO sign): park and walk in. The gear stays in the truck.
4. Gig board on the wall: E opens the list. Each gig says what to bring.
   The first one is a back-alley session that only needs a guitar.
5. Drive to the alley off East Avenue (pink "LIVE >>" sign). It is barely
   wider than the truck: come up the east side of the avenue and take it slowly.
   You have to back out again afterwards.
6. Carry the guitar to the rug by the mic (the amp too if you like: it pays extra).
7. E at the mic, pick Easy / Medium / Hard, play. Better playing, better gear,
   extras and a harder chart = more pay and fans. The crowd reacts to how it is going.
8. Pack up, drive home. In the studio the laptop is the catalogue: lamps,
   plants, a sofa, shelves, posters, neon. Furniture arrives as real objects
   you carry or drag into place.
9. Wobble Music (Main Street, giant guitar on the roof) sells guitars, a bass,
   a microphone, a keyboard, a drum kit and a stack amp from stands out front.
10. Fans open things up: 40 = Park Side (the Bandshell and its gigs),
    150 = Uptown (Skyline Tower), 500 = the Harbour. Roadblocks show what is still shut.

Also from day one, no fans needed: a dinner set at the **Moon Diner** (west
end of Main Street, set back on its own forecourt: carry the guitar in
through the door). Later, **Skyline Tower** in Uptown: drag the amp onto the
yellow goods lift, put the guitar down beside it, press the panel, and set up
on the balcony twelve metres over the street.

## Around town

- **People** find their way along the pavements, keep right, step round each
  other and the parked truck, wait at crossings, pop into shops, stand about
  chatting and sit at the bus stop. Drive into one and they go flying as a rag
  doll, it costs you $5, and they get up, shake it off and carry on.
- **Cats** potter about their patch, sit, watch you go by, and clear off when the truck comes.
- **Sound**: rain, city hum, passing tyres, chatter, air-con units, club bass
  through the walls, your own footsteps. Indoors it is muffled, the alley
  echoes, the creek is water and not much else.
- **The creek** is behind the old house (follow the stepping stones round the
  east side). Sit on the log and press E to sketch a tune: sixteen steps, five
  notes, click squares, Space plays, Save keeps it (`user://songs.json`).
- **DEBUG button**: the striped post with the red button behind the old house
  maxes money and fans. For testing only.

## Where things are

```
scenes/      main.tscn      entry scene: city + truck + gear + player + flow + HUD
levels/      city.tscn      the night city: roads, buildings, lights, people, traffic, rain
             alley.tscn, diner.tscn, venue.tscn, tower.tscn   the four places to play
             studio.tscn, music_store.tscn
world/       shared pieces  cutaway walls, Interactable, GearZone, FanGate (roadblocks),
                            traffic.gd, rain.gd, ground / building / water shaders,
                            sidewalks.gd (pavement network), lift.gd, seat.gd,
                            loop_sound.gd, debug_button.gd
npc/         npc.tscn       one body for everyone: walkers, standers, sitters, crowds (npc.gd)
             cat.tscn       cats (cat.gd)
player/      player.tscn    movement, hands (grab_controller.gd), interactor, camera
             character_model.tscn  the character: model/main_character.glb (rigged, walk + run
                            clips), textured toy shader, eyelids; posed by player_visual.gd
equipment/   gear           grabbable.gd -> equipment.gd; 2 electric guitars, acoustic, bass,
                            microphone, keyboard, drum kit, amp, stack amp
decor/       studio furniture (plain grabbables): floor lamp, plant, sofa, record shelf
vehicles/    truck.tscn (truck.gd), car_compact.tscn, car_van.tscn (traffic_car.gd)
game/        career.gd      autoload "Career": money, fans, gigs, areas
             settings.gd    autoload "Settings": volumes, truck radio, pause menu, audio buses
             ambience.gd    the mix of rain / city / room by where you are; footsteps
             sfx.gd         one-shot sounds; song_book.gd  songs written at the creek
             game_flow.gd   the "what next" objective and the beam
             job_board.gd, studio_catalogue.gd
venue/       venue.gd       stage + mic + crowd: checks the gear, starts the show, pays out
ui/          hud.tscn, rhythm_game.tscn, menu.gd (the one list menu everything uses),
             song_maker.gd (the creek sketchpad)
audio/       songs.gd + songs/<name>.ogg and <name>.gd (title, BPM, three charts),
             ambience/ and sfx/ (loops and one-shots)
art/         the look       toy.gdshader (+ toy_textured for the character), meshes/, night environment, fonts (SIL OFL)
tests/       two automated playthroughs, a chaos soak test and a character test
```

`PROJECT_STATE.md` is the running log of what exists, why, and what's next.

## Tuning cheat sheet

Everything below is an exported property - select the node, change it in the Inspector.

| I want to... | Change |
|---|---|
| Make the truck faster / slower | `Truck` > Driving > `top_speed`, `engine_acceleration`, `brake_deceleration` |
| Make it turn tighter or drift more | `Truck` > Driving > `steer_angle_slow`, `steer_angle_fast`, `grip` (lower = driftier) |
| Move the driving camera | `Truck` > Camera > `camera_distance`, `camera_height` |
| Change door speed | `Truck` > Back door > `door_time` |
| Make an item heavier / lighter | `mass` on the item's root (`equipment/*.tscn`) |
| Change what can be lifted | `Player/Hands` > Strength > `max_lift_force` (about 10 N per kg) |
| Change dragging strength | `Player/Hands` > Strength > `max_pull_force` |
| Change where things are carried | `Player/Hands` > Reach > `hold_distance`, `hold_height_default` |
| Change what counts as "heavy" (dragged, not carried) | `Player/Hands` > Strength > `two_hand_mass` |
| Change walk speed / snappiness | `Player` > Movement > `walk_speed`, `acceleration`, `braking`, `turn_speed` |
| Change how much heavy things slow you | `Player` > Loads > `free_mass`, `heavy_mass`, `min_speed_factor` |
| Make the body wobblier / arms floppier | `Player/Visual` > Wobble, Arms |
| Walk / run timing, when the walk turns into a run | `Player/Visual` > Locomotion |
| Make the character brighter at night | `light` on the skin material in `player/character_model.tscn` |
| Change gig pay, fans, what a gig needs, unlocks | `GIGS` and `AREAS` at the top of `game/career.gd` |
| Change what falls out of an open truck, and how easily | `Truck` > Loose cargo > `loose_mass`, `loose_pull` |
| Change amp dragging | `Player/Hands` > `max_pull_force`, `swing_speed`; `Player` > Loads > `heavy_mass`, `min_speed_factor` |
| More / fewer cars or their speed | `City/Traffic` > `cars_per_route`, `routes`; `cruise_speed` in `vehicles/traffic_car.gd` |
| Change the fine for hitting someone | `fine` on `npc/npc.tscn` |
| Make people walk faster / more of them | `walk_speed` on the NPC; walkers are placed in the city builder |
| Change how far up the camera looks | `Player/CameraRig` > `pitch_max_degrees`, `orbit_max_degrees` |
| Rebalance the soundscape | the `match zone` block in `game/ambience.gd`; each placed sound's `volume_db` / `max_distance` |
| Lift speed | `Tower/Lift` > `speed` |
| Change the studio catalogue | `ITEMS` at the top of `game/studio_catalogue.gd` |
| Change difficulty timing / pay | `DIFFICULTIES` in `audio/songs.gd` |
| Change the mood of the night | `art/toy_environment.tres` (fog, glow, ambient), `Sun` (the moon) in `levels/city.tscn` |
| Change a shop price or how good gear is | `price`, `quality` on the item (`equipment/*.tscn`) |
| Make notes fall slower | `fall_time` in `ui/rhythm_game.gd` |
| Recolour something | its mesh's material: `albedo`, `softness`, `roughness` |

## Adding a piece of gear

1. Duplicate `equipment/guitar.tscn` (or make a RigidBody3D with `equipment/equipment.gd`).
   Collision layer 3 (`props`), mask 1, 2, 3. Avoid thin CylinderShape3D colliders
   (use a convex shape): they can sink into walls.
2. Give it collision shapes, meshes, a `mass` and a physics material.
   For the toy look build it from the meshes in `art/meshes/` with a
   ShaderMaterial using `art/toy.gdshader`.
3. Add `Marker3D` nodes under a child called `GrabPoints` wherever hands can hold it.
4. Set `display_name`, `kind` ("guitar", "amp", "mic", "bass", "keyboard", "drums"), `quality` and `price`.
   Gigs ask for kinds, so a new kind also needs a name in `KIND_NAMES` (`game/career.gd`).
5. To sell it: put it on a stand in `levels/music_store.tscn` with `for_sale` ticked.
   It gets its price tag by itself.

## Adding a song

1. Put `<name>.ogg` and `<name>.gd` in `audio/songs/`. The script holds `TITLE`,
   `BPM` and `CHARTS` = `{"easy": [[beat, lane], ...], "medium": ..., "hard": ...}` (lanes 0-4).
2. Add one line to `LIST` in `audio/songs.gd`, and use the name as a gig's `song`.

The five songs, and every ambient loop and sound effect, are original
(synthesised for this project by scripts that are not included), so they are
free to ship.

## Tests

```
godot --headless --fixed-fps 60 --path . res://tests/playtest.tscn
godot --headless --fixed-fps 60 --path . res://tests/playtest_city.tscn
godot --headless --fixed-fps 60 --path . res://tests/chaos_test.tscn -- seed=3 seconds=120
godot --headless --fixed-fps 60 --path . res://tests/character_test.tscn
```

`playtest` plays the whole loop with fake input (loading, losing the guitar
out of the open back, traffic, the gig board, the alley, difficulty, the
show, the catalogue, the volume setting, fan unlocks, shopping) and checks
every step. `playtest_city` does the rest: looks up, presses the debug
button, writes and saves a song at the creek, drags the sliders with the
mouse, toggles the radio, runs two people over and pays for it, plays the
diner, and takes the gear up the lift to play the tower balcony.
`chaos_test` mashes the controls on
foot, then joyrides the truck, and fails if anything explodes, leaves the
world or passes through a wall. `character_test` checks the character model:
feet on the ground, walk and run clips, arms up in a jump, both hands on a
held guitar, blinking. Exit code 0 means pass. (A one-off "Jolt job
system" warning can show up in these flat-out headless runs; it is harmless.)
