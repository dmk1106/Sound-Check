class_name Equipment
extends Grabbable
## A piece of music gear. Always a physical object: it is where it is.

## Emitted when the player buys it (see for_sale).
signal bought

## What it is ("guitar", "amp"...). Gigs ask for kinds, not for particular items.
@export var kind: StringName
## How good it is. Better gear on stage means better pay and more fans.
@export var quality := 0
## Shop price. Only matters while for_sale.
@export var price := 0
## Sitting in a shop: bolted down until someone pays for it.
@export var for_sale := false


var _price_tag: Interactable


func _ready() -> void:
	super()
	add_to_group(&"equipment")
	if for_sale:
		can_grab = false
		freeze = true
		# The price tag: walk up and press interact to pay.
		_price_tag = Interactable.new()
		_price_tag.prompt = "buy the %s for $%d" % [display_name, price]
		_price_tag.radius = 1.7
		add_child(_price_tag)
		_price_tag.interacted.connect(_on_price_tag_used)
		var label := Label3D.new()
		label.text = "$%d" % price
		label.font = preload("res://art/fonts/fredoka_semibold.tres")
		label.font_size = 96
		label.pixel_size = 0.004
		label.outline_size = 24
		label.modulate = Color("ffd166")
		label.outline_modulate = Color("2b2740")
		label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		label.position = Vector3(0, 1.25, 0)
		label.top_level = true
		_price_tag.add_child(label)
		label.global_position = global_position + Vector3(0, 1.3, 0)


## True for gear the player owns (as opposed to shop stock).
func is_owned() -> bool:
	return not for_sale


## Hand it over: from now on it is ordinary, grabbable gear.
func buy() -> void:
	for_sale = false
	can_grab = true
	freeze = false
	sleeping = false
	if _price_tag:
		_price_tag.queue_free()
		_price_tag = null
	bought.emit()


func _on_price_tag_used(_player: Player) -> void:
	if Career.spend(price):
		Career.say("Bought the %s" % display_name)
		buy()
