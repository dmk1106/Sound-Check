class_name Grabbable
extends RigidBody3D
## Any physical object the player can grab, carry, drag and drop.
##
## A Grabbable is always a real rigid body in the world: it is never put in an
## inventory. Whoever grabs it only applies forces to it (see GrabController).
##
## Grab points: add Marker3D nodes under a child called "GrabPoints". Hands take
## the marker closest to them. With no markers the body's origin is used.

signal grabbed(by: Node3D)
signal released(by: Node3D)

## Name shown in prompts and lists.
@export var display_name := "Thing"
## Extra angular damping while held, so a carried item swings but doesn't spin forever.
@export var held_angular_damp := 2.5

## False for things that can't be picked up yet (gear still for sale in a shop).
var can_grab := true
## Who is holding this right now (null when free).
var holder: Node3D = null

var _grab_points: Array[Marker3D] = []
var _meshes: Array[MeshInstance3D] = []
var _free_angular_damp := 0.0

static var _highlight_material: ShaderMaterial


func _ready() -> void:
	add_to_group(&"grabbable")
	var points := get_node_or_null(^"GrabPoints")
	if points:
		for child in points.get_children():
			if child is Marker3D:
				_grab_points.append(child)
	for node in find_children("*", "MeshInstance3D"):
		_meshes.append(node)


func is_held() -> bool:
	return holder != null


## World positions of every grab point (the body origin if none are defined).
func get_grab_positions() -> PackedVector3Array:
	var result := PackedVector3Array()
	for point in _grab_points:
		result.append(point.global_position)
	if result.is_empty():
		result.append(global_position)
	return result


func grab(by: Node3D) -> void:
	holder = by
	_free_angular_damp = angular_damp
	angular_damp = held_angular_damp
	sleeping = false
	grabbed.emit(by)


func release() -> void:
	var by := holder
	holder = null
	angular_damp = _free_angular_damp
	sleeping = false
	released.emit(by)


## Makes the object glow while it is the thing the player would grab.
func set_highlighted(on: bool) -> void:
	if on and _highlight_material == null:
		_highlight_material = ShaderMaterial.new()
		_highlight_material.shader = preload("res://art/highlight.gdshader")
	for mesh in _meshes:
		mesh.material_overlay = _highlight_material if on else null
