class_name Songs
extends RefCounted
## Every song a gig can play. To add one: drop <name>.ogg and <name>.gd (the
## charts: TITLE, BPM, CHARTS) into audio/songs/ and add a line here.

const LIST := {
	&"alley_cat_shuffle": {"chart": preload("res://audio/songs/alley_cat_shuffle.gd"), "stream": preload("res://audio/songs/alley_cat_shuffle.ogg")},
	&"garage_sunrise": {"chart": preload("res://audio/songs/garage_sunrise.gd"), "stream": preload("res://audio/songs/garage_sunrise.ogg")},
	&"neon_rush": {"chart": preload("res://audio/songs/neon_rush.gd"), "stream": preload("res://audio/songs/neon_rush.ogg")},
	&"late_night_diner": {"chart": preload("res://audio/songs/late_night_diner.gd"), "stream": preload("res://audio/songs/late_night_diner.ogg")},
	&"top_of_the_town": {"chart": preload("res://audio/songs/top_of_the_town.gd"), "stream": preload("res://audio/songs/top_of_the_town.ogg")},
}

## How each difficulty plays: which chart, how forgiving the timing is, and
## how much it multiplies the pay.
const DIFFICULTIES: Array[Dictionary] = [
	{"id": "easy", "name": "Easy", "detail": "Fewer notes, forgiving timing. Pays 80%.", "window": 0.19, "pay": 0.8},
	{"id": "medium", "name": "Medium", "detail": "The full melody. Pays 100%.", "window": 0.15, "pay": 1.0},
	{"id": "hard", "name": "Hard", "detail": "Dense, fast, tight timing. Pays 130%.", "window": 0.12, "pay": 1.3},
]


static func title(id: StringName) -> String:
	return LIST[id].chart.TITLE


static func bpm(id: StringName) -> float:
	return LIST[id].chart.BPM


static func chart(id: StringName, difficulty: String) -> Array:
	return LIST[id].chart.CHARTS[difficulty]


static func stream(id: StringName) -> AudioStream:
	return LIST[id].stream
