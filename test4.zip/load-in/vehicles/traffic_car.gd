class_name TrafficCar
extends AnimatableBody3D
## A car that drives round a loop of road. Kinematic: it follows its route,
## slows for corners, stops at junctions, and waits for anything in its way
## (you, your truck, a guitar lying in the road, the car in front).

## Corner points of the loop (world space), in driving order. Empty = a
## parked car: it just sits there, solid, engine off.
@export var route := PackedVector3Array()
## One flag per route point: 1 = a junction (stop, look, go). Empty = every
## point is a junction (the old square loops).
@export var stops := PackedByteArray()
@export var cruise_speed := 8.0
@export var corner_speed := 3.5
## Seconds to wait at each corner (junction) before pulling away.
@export var junction_stop := 0.9
## How far (metres) to reverse out of the way when stuck behind something.
@export var back_off := 1.5
@export var body_color := Color("e63946")

var speed := 0.0
## What we are waiting behind (null when the road is clear).
var blocked_by: Object = null

var _target := 0
const HORN := preload("res://audio/sfx/horn.ogg")

var _horn_wait := 0.0
var _stop_timer := 0.0
var _blocked_time := 0.0
var _backed_up := 0.0
var _squeeze_time := 0.0
var _stopped_here := false
var _feeler := PhysicsShapeQueryParameters3D.new()
var _width := 1.8
var _length := 3.8


@onready var _tyres: AudioStreamPlayer3D = get_node_or_null(^"Tyres")


func _ready() -> void:
	add_to_group(&"traffic_car")
	if route.size() < 2:
		# Parked: no tyre noise, no driving.
		set_physics_process(false)
		if _tyres:
			_tyres.stop()
			_tyres.autoplay = false
	elif _tyres and _tyres.stream is AudioStreamOggVorbis:
		(_tyres.stream as AudioStreamOggVorbis).loop = true
		_tyres.play(randf() * _tyres.stream.get_length())
	_feeler.shape = BoxShape3D.new()
	_feeler.collision_mask = 0b10111
	_feeler.exclude = [get_rid()]
	var body := get_node_or_null(^"BodyShape") as CollisionShape3D
	if body and body.shape is BoxShape3D:
		_width = (body.shape as BoxShape3D).size.x
		_length = (body.shape as BoxShape3D).size.z
	for node in find_children("Paint*", "MeshInstance3D"):
		var mesh := node as MeshInstance3D
		var material: ShaderMaterial = mesh.mesh.surface_get_material(0).duplicate()
		material.set_shader_parameter(&"albedo", body_color)
		mesh.material_override = material


## Start on the route: nearest to `along` metres round the loop.
func place_on_route(along: float) -> void:
	var count := route.size()
	for i in count:
		var from := route[i]
		var to := route[(i + 1) % count]
		var length := from.distance_to(to)
		if along <= length:
			global_position = from.lerp(to, along / length)
			_target = (i + 1) % count
			var heading := to - from
			global_rotation.y = atan2(-heading.x, -heading.z)
			return
		along -= length


func _physics_process(delta: float) -> void:
	if route.size() < 2:
		return
	var here := global_position
	var to := route[_target] - here
	to.y = 0.0
	var distance := to.length()
	var forward := -global_basis.z
	var off_by := angle_difference(global_rotation.y, atan2(-to.x, -to.z))

	blocked_by = _look_ahead(here, forward)
	# Gridlock: two cars each waiting for the other would sit there all night.
	# After a while one of them (always the same one of a pair) just goes.
	_squeeze_time = maxf(_squeeze_time - delta, 0.0)
	if blocked_by is TrafficCar:
		if _squeeze_time > 0.0:
			blocked_by = null
		elif _blocked_time > 9.0 and _first_in_gridlock():
			_squeeze_time = 4.0
			_blocked_time = 0.0
			blocked_by = null
	var wanted := cruise_speed
	var junction := stops.is_empty() or stops[_target] == 1
	if absf(off_by) > 0.25 or (distance < 12.0 and (junction or _turn_at(_target) > 0.35)):
		wanted = corner_speed
	# Junction: come to a stop just before the corner, wait, then go.
	if junction and distance < 7.0 and not _stopped_here:
		wanted = 0.0
		if speed < 0.2:
			_stop_timer += delta
			if _stop_timer >= junction_stop:
				_stopped_here = true
	if blocked_by:
		wanted = 0.0
		# Stuck nose to nose with something that isn't moving on? Back up a
		# little, once, to give it room to get round.
		_blocked_time += delta
		# Held up by the player or their truck for a while: a polite toot.
		_horn_wait -= delta
		if _blocked_time > 3.5 and _horn_wait <= 0.0 and (blocked_by is Truck or blocked_by is Player):
			_horn_wait = randf_range(7.0, 14.0)
			Sfx.play_at(self, HORN, global_position, -3.0, randf_range(0.9, 1.15), 45.0)
		if _blocked_time > 2.5 and _backed_up < back_off:
			wanted = -1.2
			_backed_up += absf(speed) * delta
	else:
		# (Runs down rather than snapping to zero, so two cars that keep backing
		# off and meeting again still count as stuck.)
		_blocked_time = maxf(_blocked_time - delta * 0.5, 0.0)
		if _blocked_time <= 0.0:
			_backed_up = 0.0
	speed = move_toward(speed, wanted, (14.0 if wanted < speed else 4.0) * delta)

	if distance < 4.5:
		_target = (_target + 1) % route.size()
		_stopped_here = false
		_stop_timer = 0.0
	# Wet tyres: louder and higher the faster it goes.
	if _tyres:
		var rolling := clampf(absf(speed) / 8.0, 0.0, 1.0)
		_tyres.volume_db = lerpf(-40.0, -4.0, sqrt(rolling))
		_tyres.pitch_scale = 0.75 + rolling * 0.5
	# Steering only works while rolling.
	var turn := clampf(off_by, -1.0, 1.0) * 1.6 * clampf(speed / corner_speed, 0.0, 1.0)
	global_rotation.y += turn * delta
	global_position = here + forward * speed * delta


# How sharply the route turns at point i (radians).
func _turn_at(i: int) -> float:
	var n := route.size()
	var a := route[i] - route[(i - 1 + n) % n]
	var b := route[(i + 1) % n] - route[i]
	return absf(Vector2(a.x, a.z).angle_to(Vector2(b.x, b.z)))


# True if the cars waiting on each other form a ring that includes this one,
# and this is the one that should break it.
func _first_in_gridlock() -> bool:
	var lowest := get_instance_id()
	var car: TrafficCar = self
	for i in 8:
		car = car.blocked_by as TrafficCar
		if car == null:
			return false
		if car == self:
			return lowest == get_instance_id()
		lowest = mini(lowest, car.get_instance_id())
	return false


# The first person, vehicle or loose object in our lane, if any: a box the
# width of the car swept out in front of it.
func _look_ahead(here: Vector3, forward: Vector3) -> Object:
	var reach := 2.2 + speed * 0.75
	# From just above the road up: a guitar lying flat in the lane counts too.
	(_feeler.shape as BoxShape3D).size = Vector3(_width + 0.3, 1.2, reach)
	_feeler.transform = Transform3D(global_basis, here + Vector3.UP * 0.64 + forward * (_length * 0.5 + reach * 0.5))
	var found: Object = null
	for hit in get_world_3d().direct_space_state.intersect_shape(_feeler, 12):
		if hit.collider is RigidBody3D or hit.collider is AnimatableBody3D:
			# A vehicle rather than whatever is riding in the back of it.
			if found == null or hit.collider is Truck or hit.collider is TrafficCar:
				found = hit.collider
	return found
