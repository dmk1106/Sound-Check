class_name Truck
extends RigidBody3D
## The moving truck: a real cargo bay you load by hand, a roll-up back door
## with a ramp, and a driver's seat.
##
## Cargo: there is no cargo list. Whatever is physically sitting inside the
## CargoZone area counts as loaded, and stops counting the moment it leaves.
## Closing the door doesn't store anything; it is just a wall that keeps the
## gear from sliding out.
##
## Driving: deliberately simple. The truck slides on a flat plane (it can't
## tip, jump or sink), speeds up, brakes and steers like an arcade car, and
## bumps into anything solid. Parked, it is frozen in place like a building.

signal cargo_changed(loaded: Array[Grabbable])
signal door_changed(open: bool)
signal driver_changed(driver: Player)

@export_group("Driving")
## Top speed forwards and backwards, m/s.
@export var top_speed := 15.0
@export var reverse_speed := 5.0
## m/s² on the throttle, on the brake, and when coasting.
@export var engine_acceleration := 6.5
@export var brake_deceleration := 11.0
@export var coast_deceleration := 2.5
## How quickly sideways sliding is scrubbed off (1/s). Lower = driftier.
@export var grip := 7.0
## Steering lock at walking pace and at top speed.
@export_range(5.0, 45.0, 1.0, "degrees") var steer_angle_slow := 34.0
@export_range(2.0, 45.0, 1.0, "degrees") var steer_angle_fast := 10.0
## How fast the steering wheel turns (full locks per second).
@export var steer_speed := 3.0
## Distance between the axles: longer = wider turns.
@export var wheelbase := 3.85

@export_group("Camera")
@export var camera_distance := 11.0
@export var camera_height := 2.2

@export_group("Loose cargo")
## Things lighter than this slide about when the back is left open.
@export var loose_mass := 8.0
## How hard (m/s²) pulling away or cornering tugs loose things toward an open back.
@export var loose_pull := 7.0
## With the back shut: how strongly (1/s) sliding cargo is slowed down.
@export var cargo_grip := 4.0

@export_group("Back door")
## Seconds to roll the door fully up or down.
@export var door_time := 0.6
@export var starts_open := true

## Who is driving (null when parked).
var driver: Player = null
var door_open := true
## Signed speed along the truck's nose, m/s.
var speed := 0.0

var _inside: Array[Grabbable] = []
var _held_inside := 0
var _cargo_timer := 0.0
var _steer := 0.0
var _door := 1.0           # 0 = shut, 1 = rolled up
var _ramp := 1.0           # 0 = stowed under the bed, 1 = on the ground
var _entered_at := 0
var _door_height := 1.0
var _door_top := 0.0
var _wheel_spin := 0.0
var _on_foot_distance := 6.0
var _on_foot_height := 0.55
var _last_speed := 0.0

@onready var _cargo_shape: CollisionShape3D = $CargoZone/ZoneShape
@onready var _door_shape: CollisionShape3D = $DoorShape
@onready var _ramp_shape: CollisionShape3D = $RampShape
@onready var _door_mesh: Node3D = $Mesh/CargoBox/Door
@onready var _ramp_mesh: Node3D = $Mesh/Ramp
@onready var _back: Interactable = $Back
@onready var _seats: Array[Interactable] = [$SeatLeft, $SeatRight]
@onready var _front_wheels: Array[Node3D] = [$Mesh/WheelFrontL, $Mesh/WheelFrontR]
@onready var _wheels: Array[Node3D] = [$Mesh/WheelFrontL/Spin, $Mesh/WheelFrontR/Spin, $Mesh/WheelRearL/Spin, $Mesh/WheelRearR/Spin]
@onready var _exits: Array[Marker3D] = [$ExitLeft, $ExitRight, $ExitBack]
@onready var _ramp_rest_z: float = _ramp_mesh.position.z
@onready var _headlights: Node3D = $Headlights
@onready var _engine: AudioStreamPlayer3D = $Engine
@onready var _radio: AudioStreamPlayer3D = $Radio


func _ready() -> void:
	add_to_group(&"truck")
	_back.interacted.connect(func(_player: Player) -> void: set_door_open(not door_open))
	for seat in _seats:
		seat.interacted.connect(enter)
	var box := _door_shape.shape as BoxShape3D
	_door_height = box.size.y
	_door_top = _door_shape.position.y + _door_height * 0.5
	door_open = starts_open
	_door = 1.0 if door_open else 0.0
	_ramp = _door
	freeze = true
	_headlights.visible = false
	for speaker: AudioStreamPlayer3D in [_engine, _radio]:
		if speaker.stream is AudioStreamOggVorbis:
			(speaker.stream as AudioStreamOggVorbis).loop = true
	Settings.radio_changed.connect(func(_on: bool) -> void: _apply_radio())
	_apply_door()
	_refresh_prompts()


func _unhandled_input(event: InputEvent) -> void:
	if driver and event.is_action_pressed(&"interact") \
			and Engine.get_physics_frames() - _entered_at > 15:
		get_viewport().set_input_as_handled()
		leave()
	elif driver and event.is_action_pressed(&"radio"):
		get_viewport().set_input_as_handled()
		Settings.truck_radio = not Settings.truck_radio
		Settings.save()
		Career.say("Radio on" if Settings.truck_radio else "Radio off")


## True while the jingle is coming out of the truck.
func is_radio_playing() -> bool:
	return _radio.playing


# The jingle only ever plays while someone is at the wheel and the radio is switched on.
func _apply_radio() -> void:
	var on := driver != null and Settings.truck_radio
	if on and not _radio.playing:
		_radio.play()
	elif not on and _radio.playing:
		_radio.stop()


func _physics_process(delta: float) -> void:
	# Door and ramp glide to where they should be. The ramp is only ever down
	# while the truck is parked with the back open.
	var door_goal := 1.0 if door_open else 0.0
	var ramp_goal := 1.0 if door_open and driver == null else 0.0
	if _door != door_goal or _ramp != ramp_goal:
		_door = move_toward(_door, door_goal, delta / door_time)
		_ramp = move_toward(_ramp, ramp_goal, delta / door_time)
		_apply_door()

	_cargo_timer -= delta
	if _cargo_timer <= 0.0:
		_cargo_timer = 0.15
		_update_cargo()

	if driver:
		# The driver rides along (hidden) so the rest of the game knows where they are.
		driver.global_position = to_global(Vector3(0.0, 1.2, -1.6))
		# The engine note climbs with the speed.
		var revs := clampf(absf(speed) / top_speed, 0.0, 1.0)
		_engine.pitch_scale = lerpf(_engine.pitch_scale, 0.75 + revs * 1.1 + absf(Input.get_axis(&"move_back", &"move_forward")) * 0.12, 1.0 - exp(-6.0 * delta))
		_engine.volume_db = lerpf(-12.0, -5.0, revs)
		_settle_cargo(delta)
		_wheel_spin += speed / 0.4 * delta
		for wheel in _wheels:
			wheel.rotation.x = -_wheel_spin
		for wheel in _front_wheels:
			wheel.rotation.y = _steer * deg_to_rad(steer_angle_slow) * 0.8


func _integrate_forces(state: PhysicsDirectBodyState3D) -> void:
	if driver == null:
		return
	var delta := state.step
	var forward := -state.transform.basis.z
	forward.y = 0.0
	forward = forward.normalized()
	var right := forward.cross(Vector3.UP)
	var velocity := state.linear_velocity
	speed = velocity.dot(forward)
	var slide := velocity.dot(right)

	var throttle := Input.get_axis(&"move_back", &"move_forward")
	var braking := Input.is_action_pressed(&"jump")
	if braking:
		speed = move_toward(speed, 0.0, brake_deceleration * delta)
	elif throttle > 0.0:
		# Pressing forward while rolling backwards brakes first.
		var rate := brake_deceleration if speed < -0.3 else engine_acceleration
		speed = move_toward(speed, top_speed * throttle, rate * delta)
	elif throttle < 0.0:
		var rate := brake_deceleration if speed > 0.3 else engine_acceleration
		speed = move_toward(speed, reverse_speed * throttle, rate * delta)
	else:
		speed = move_toward(speed, 0.0, coast_deceleration * delta)
	slide *= exp(-grip * delta)

	# Steering: a bicycle model, with less lock the faster you go.
	_steer = move_toward(_steer, Input.get_axis(&"move_right", &"move_left"), steer_speed * delta)
	var lock := deg_to_rad(lerpf(steer_angle_slow, steer_angle_fast, clampf(absf(speed) / top_speed, 0.0, 1.0)))
	var turn_rate := speed * tan(_steer * lock) / wheelbase

	state.linear_velocity = forward * speed + right * slide
	state.angular_velocity = Vector3(0.0, turn_rate, 0.0)


# What the cargo does while the truck is moving.
#  - Back shut: the load is boxed in. It still slides and tumbles, but is kept
#    from building up enough speed to be rammed through a wall when the driver
#    stamps on the brakes.
#  - Back open: nothing holds it. Pulling away or swinging round a corner
#    shakes light, loose things toward the opening - and out onto the road,
#    where they stay until someone stops and picks them up.
func _settle_cargo(delta: float) -> void:
	var pulling_away := maxf((speed - _last_speed) / delta, 0.0) / engine_acceleration
	_last_speed = speed
	if _door < 0.5:
		for item in _inside:
			if is_instance_valid(item) and not item.is_held():
				var carried := linear_velocity + angular_velocity.cross(item.global_position - global_position)
				var drift := item.linear_velocity - carried
				drift.y = 0.0
				item.apply_central_force(-drift * item.mass * cargo_grip)
		return
	var cornering := absf(angular_velocity.y * speed) / 1.5
	var shake := clampf(pulling_away + cornering, 0.0, 1.0)
	if shake < 0.05:
		return
	for item in _inside:
		if is_instance_valid(item) and item.mass < loose_mass and not item.is_held():
			item.sleeping = false
			item.apply_central_force(global_basis.z * item.mass * loose_pull * shake)


# --- driving ---

## Put `player` behind the wheel.
func enter(player: Player) -> void:
	if driver:
		return
	driver = player
	_entered_at = Engine.get_physics_frames()
	_on_foot_distance = player.camera_rig.distance
	_on_foot_height = player.camera_rig.pivot_height
	player.enter_vehicle(self)
	player.camera_rig.follow(self, camera_distance, camera_height, true)
	speed = 0.0
	_last_speed = 0.0
	_steer = 0.0
	freeze = false
	_headlights.visible = true
	_engine.play()
	_apply_radio()
	_update_cargo()
	_refresh_prompts()
	driver_changed.emit(driver)


## Stop, park and step out. The truck stays exactly where it is.
func leave() -> void:
	if driver == null:
		return
	var player := driver
	driver = null
	linear_velocity = Vector3.ZERO
	angular_velocity = Vector3.ZERO
	speed = 0.0
	freeze = true
	_headlights.visible = false
	_engine.stop()
	_radio.stop()
	player.exit_vehicle(_find_exit(player), global_rotation.y)
	player.camera_rig.follow(player, _on_foot_distance, _on_foot_height)
	_update_cargo()
	_refresh_prompts()
	driver_changed.emit(null)


# First exit spot that isn't blocked: driver's side, other side, behind.
func _find_exit(player: Player) -> Vector3:
	var space := get_world_3d().direct_space_state
	var query := PhysicsShapeQueryParameters3D.new()
	var body := SphereShape3D.new()
	body.radius = 0.4
	query.shape = body
	query.collision_mask = 0b101
	query.exclude = [get_rid()]
	for spot in _exits:
		var at := spot.global_position
		at.y = global_position.y + player.ride_height
		query.transform = Transform3D(Basis.IDENTITY, at)
		if space.intersect_shape(query, 1).is_empty():
			return at
	var fallback := _exits[0].global_position
	fallback.y = global_position.y + player.ride_height
	return fallback


# --- back door ---

func set_door_open(open: bool) -> void:
	if open == door_open:
		return
	door_open = open
	_refresh_prompts()
	door_changed.emit(door_open)


func _apply_door() -> void:
	# The door rolls up into the roof: it gets shorter from the bottom.
	var shut := 1.0 - _door
	_door_mesh.scale.y = maxf(shut, 0.02)
	_door_mesh.visible = shut > 0.02
	var box := _door_shape.shape as BoxShape3D
	box.size.y = maxf(_door_height * shut, 0.05)
	_door_shape.position.y = _door_top - box.size.y * 0.5
	_door_shape.disabled = shut < 0.05
	# The ramp slides out from under the bed and is only solid once it is fully out.
	_ramp_mesh.position.z = _ramp_rest_z - (1.0 - _ramp) * 2.35
	_ramp_mesh.visible = _ramp > 0.02
	_ramp_shape.disabled = _ramp < 0.98


func _refresh_prompts() -> void:
	_back.prompt = "close the back" if door_open else "open the back"
	_back.enabled = driver == null
	for seat in _seats:
		seat.enabled = driver == null


# --- cargo ---
# Worked out from where things actually are, a few times a second. (Overlap
# events from an area riding on a body that keeps freezing, thawing and
# driving off are not something to bet a gig on.)

## Everything resting in the cargo bay (things still in someone's hands don't count).
func get_loaded() -> Array[Grabbable]:
	var loaded: Array[Grabbable] = []
	for item in _inside:
		if is_instance_valid(item) and not item.is_held():
			loaded.append(item)
	return loaded


func is_loaded(item: Grabbable) -> bool:
	return _in_cargo_bay(item) and not item.is_held()


func _in_cargo_bay(item: Grabbable) -> bool:
	var local := _cargo_shape.global_transform.affine_inverse() * item.global_position
	var half: Vector3 = (_cargo_shape.shape as BoxShape3D).size * 0.5
	return absf(local.x) <= half.x and absf(local.y) <= half.y and absf(local.z) <= half.z


# Safety net. A hard stop can ram one piece of gear into another so hard that
# it is squeezed into the truck's solid floor or cab. If something's centre is
# inside those solids, pop it back up into the cargo bay it came from.
func _rescue_if_embedded(item: Grabbable) -> void:
	var half: Vector3 = (_cargo_shape.shape as BoxShape3D).size * 0.5
	var local := _cargo_shape.global_transform.affine_inverse() * item.global_position
	# Under the cargo floor, or forward of the front wall inside the cab block.
	var below_floor := local.y < -half.y - 0.05 and local.y > -half.y - 0.6 and absf(local.z) < half.z
	var in_cab := local.z < -half.z - 0.12 and local.z > -half.z - 1.9 and absf(local.y) < half.y + 0.6
	if absf(local.x) > half.x or not (below_floor or in_cab):
		return
	local.x = clampf(local.x, -half.x + 0.35, half.x - 0.35)
	local.z = clampf(local.z, -half.z + 0.45, half.z - 0.45)
	local.y = -half.y + 0.45
	item.global_position = _cargo_shape.global_transform * local
	item.linear_velocity = linear_velocity
	item.angular_velocity = Vector3.ZERO
	item.reset_physics_interpolation()


func _update_cargo() -> void:
	var now: Array[Grabbable] = []
	var held := 0
	for node in get_tree().get_nodes_in_group(&"grabbable"):
		var item := node as Grabbable
		if item and not item.is_held():
			_rescue_if_embedded(item)
		# Continuous collision detection sweeps a body along its own motion as if
		# everything else stood still. Riding in a truck doing 15 m/s that sweep
		# hits the truck itself, the item is held back for a step, and the back
		# door drives straight through it. So: off while riding, back on outside.
		if item:
			var riding := driver != null and _in_cargo_bay(item)
			if item.continuous_cd == riding:
				item.continuous_cd = not riding
		if item and _in_cargo_bay(item):
			now.append(item)
			if item.is_held():
				held += 1
	if now != _inside or held != _held_inside:
		_inside = now
		_held_inside = held
		cargo_changed.emit(get_loaded())
