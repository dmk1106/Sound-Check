class_name Player
extends RigidBody3D
## Physics-driven character.
##
## The body is a capsule that floats on a spring above the ground (so ramps,
## small steps and standing on gear all just work) and is pushed around by
## forces instead of being moved directly. That is what lets it shove
## equipment, get tugged by whatever it is dragging, and bump into things.
##
## Rotation is locked: the capsule never turns. `facing_yaw` is where the
## character looks: it follows the direction of travel, and the arms always
## reach out along it. The camera only decides which way "forward" is for the
## movement keys.

signal jumped
signal landed(impact_speed: float)
signal seated_changed(seated: bool)

@export_group("Movement")
## Top speed in m/s when not carrying anything heavy.
@export var walk_speed := 4.0
## How quickly the wanted velocity changes, in m/s². Higher = snappier.
@export var acceleration := 28.0
## Stopping and turning back is this many times harder/quicker than speeding up.
@export var braking := 1.7
## How hard the body chases the wanted velocity (1/s).
@export var move_response := 14.0
## Leg strength in newtons: the hardest the legs can push the body along.
@export var max_move_force := 1300.0
## Share of control kept while airborne.
@export_range(0.0, 1.0) var air_control := 0.4
## How fast the body turns to face where it is going.
@export var turn_speed := 11.0

@export_group("Loads")
## Loads up to this mass (kg) don't slow you down.
@export var free_mass := 5.0
## At this mass (kg) you are slowed to min_speed_factor. Counts for what the
## hands are hauling and for what the body is shoving along.
@export var heavy_mass := 40.0
@export_range(0.1, 1.0) var min_speed_factor := 0.55

@export_group("Ride spring")
## Height of the body origin above the ground when standing.
@export var ride_height := 0.9
## How far below standing height the legs still find the ground (keeps you glued to ramps).
@export var ride_reach := 0.35
## Stiffness of the legs, as a frequency in Hz.
@export var ride_frequency := 3.2
@export var ride_damping_ratio := 0.9
## What counts as ground.
@export_flags_3d_physics var ground_mask := 0b101

@export_group("Jump")
@export var jump_height := 0.85
@export var coyote_time := 0.12
@export var jump_buffer_time := 0.12

## False while a menu / cutscene / rhythm game owns the input.
var controls_enabled := true
## Mass (kg) of whatever the hands are hauling. Set by GrabController.
var carried_mass := 0.0
## 0..1 speed multiplier from the heaviest thing being hauled or shoved.
var speed_factor := 1.0
## Direction the body visually faces (radians, 0 = -Z).
var facing_yaw := 0.0
## When not zero, the body faces along this instead of its movement (set by
## the hands while hauling something heavy: you face what you drag).
var face_direction := Vector3.ZERO
## The vehicle being driven (null on foot).
var vehicle: Node3D = null
var grounded := false
## True while sitting on a seat (see sit_at).
var seated := false
## What the player is playing on stage (&"guitar", &"piano", &"drums"), or
## empty. Set by the venue during a show; PlayerVisual plays the matching clip.
var performing: StringName = &""
## Bodies the legs ignore (the thing being carried).
var ride_exclude: Array[RID] = []

var _goal_velocity := Vector3.ZERO
var _ground_velocity := Vector3.ZERO
var _pushed_mass := 0.0
var _push_memory := 0.0
var _ride_pause := 0.0
var _air_time := 0.0
var _jump_buffer := 0.0
var _fall_speed := 0.0
var _spawn_position := Vector3.ZERO
var _face_goal := 0.0
var _on_foot_layer := 0
var _on_foot_mask := 0

@onready var camera_rig: CameraRig = $CameraRig
@onready var hands: GrabController = $Hands
@onready var _gravity: float = ProjectSettings.get_setting("physics/3d/default_gravity")


func _ready() -> void:
	add_to_group(&"player")
	# The capsule itself never rotates; remember which way the scene had us facing.
	facing_yaw = global_rotation.y
	_face_goal = facing_yaw
	global_rotation = Vector3.ZERO
	$Visual.rotation.y = facing_yaw
	camera_rig.yaw = facing_yaw
	_spawn_position = global_position
	reset_physics_interpolation()


func _physics_process(delta: float) -> void:
	if vehicle or seated:
		return
	_update_load(delta)
	_update_ride_spring(delta)
	_update_jump(delta)
	_update_movement(delta)
	_update_facing(delta)
	if global_position.y < -20.0:
		respawn()


## Sit down: `seat` is the top of the seat, `yaw` the way to face. The body is
## parked there until stand_up().
func sit_at(seat: Vector3, yaw: float) -> void:
	hands.drop()
	seated = true
	controls_enabled = false
	freeze = true
	linear_velocity = Vector3.ZERO
	# Hips on the seat (they are 0.48 m below the body's origin).
	global_position = seat + Vector3.UP * 0.56
	facing_yaw = yaw
	_face_goal = yaw
	reset_physics_interpolation()
	seated_changed.emit(true)


func stand_up() -> void:
	if not seated:
		return
	seated = false
	freeze = false
	controls_enabled = true
	global_position += Vector3.UP * 0.3
	seated_changed.emit(false)


## Direction the player is aiming, as a rotation around Y (0 = -Z). Follows the camera.
func get_aim_yaw() -> float:
	return camera_rig.yaw


## Horizontal unit vector the player is aiming along (camera forward).
func get_aim_forward() -> Vector3:
	return camera_rig.get_forward()


## Unit vector the character is facing along.
func get_facing_forward() -> Vector3:
	return Vector3.FORWARD.rotated(Vector3.UP, facing_yaw)


## Turn to look this way (radians, 0 = -Z) until movement says otherwise.
func face_toward(yaw: float) -> void:
	_face_goal = yaw


## Sit in a vehicle: the body leaves the world until exit_vehicle().
func enter_vehicle(new_vehicle: Node3D) -> void:
	hands.drop()
	vehicle = new_vehicle
	controls_enabled = false
	_on_foot_layer = collision_layer
	_on_foot_mask = collision_mask
	collision_layer = 0
	collision_mask = 0
	freeze = true
	visible = false
	_goal_velocity = Vector3.ZERO


## Step out at a world position, facing `yaw`.
func exit_vehicle(at: Vector3, yaw: float) -> void:
	vehicle = null
	# Move first, then come back to life: a body that is unfrozen and moved in
	# the same breath can wake up at its old position.
	global_position = at
	PhysicsServer3D.body_set_state(get_rid(), PhysicsServer3D.BODY_STATE_TRANSFORM, Transform3D(Basis.IDENTITY, at))
	collision_layer = _on_foot_layer
	collision_mask = _on_foot_mask
	freeze = false
	linear_velocity = Vector3.ZERO
	facing_yaw = yaw
	_face_goal = yaw
	visible = true
	controls_enabled = true
	reset_physics_interpolation()


## Point on the ground under the body.
func get_feet_position() -> Vector3:
	return global_position + Vector3.DOWN * ride_height


func get_horizontal_velocity() -> Vector3:
	return Vector3(linear_velocity.x, 0.0, linear_velocity.z)


## Put the player back where the level started them (safety net for falling out of the world).
func respawn() -> void:
	global_position = _spawn_position
	linear_velocity = Vector3.ZERO
	_goal_velocity = Vector3.ZERO
	reset_physics_interpolation()
	camera_rig.snap_to_target()


# --- Loads: hauling or shoving heavy things slows you down ---
func _integrate_forces(state: PhysicsDirectBodyState3D) -> void:
	# Find the heaviest loose body we are walking into.
	var pushed := 0.0
	if _goal_velocity.length_squared() > 0.01:
		var direction := _goal_velocity.normalized()
		for i in state.get_contact_count():
			var other := state.get_contact_collider_object(i) as RigidBody3D
			if other == null or other.freeze:
				continue
			# The contact normal points from the other body toward us.
			if state.get_contact_local_normal(i).dot(direction) < -0.3:
				pushed = maxf(pushed, other.mass)
	if pushed > 0.0:
		_pushed_mass = pushed
		_push_memory = 0.2


func _update_load(delta: float) -> void:
	_push_memory -= delta
	if _push_memory <= 0.0:
		_pushed_mass = 0.0
	var load_ratio := inverse_lerp(free_mass, heavy_mass, maxf(carried_mass, _pushed_mass))
	speed_factor = lerpf(1.0, min_speed_factor, clampf(load_ratio, 0.0, 1.0))


# --- Legs: a spring that holds the capsule at ride_height above whatever is below ---
func _update_ride_spring(delta: float) -> void:
	_ride_pause = maxf(_ride_pause - delta, 0.0)
	var was_grounded := grounded
	grounded = false
	_ground_velocity = Vector3.ZERO

	var from := global_position
	var query := PhysicsRayQueryParameters3D.create(
			from, from + Vector3.DOWN * (ride_height + ride_reach), ground_mask)
	var exclude: Array[RID] = [get_rid()]
	exclude.append_array(ride_exclude)
	query.exclude = exclude
	var hit := get_world_3d().direct_space_state.intersect_ray(query)

	if hit.is_empty() or _ride_pause > 0.0:
		_air_time += delta
		_fall_speed = maxf(-linear_velocity.y, 0.0)
		return

	grounded = true
	_air_time = 0.0
	if not was_grounded:
		landed.emit(_fall_speed)

	var ground := hit.collider as RigidBody3D
	if ground and ground.freeze:
		ground = null   # a parked vehicle is just ground
	if ground:
		_ground_velocity = ground.linear_velocity

	# Implicit spring-damper: stays stable whatever the stiffness or tick rate.
	var compression: float = ride_height - (from.y - hit.position.y)
	var speed := linear_velocity.y - _ground_velocity.y
	var k := mass * pow(TAU * ride_frequency, 2.0)
	var c := 2.0 * ride_damping_ratio * sqrt(k * mass)
	var spring := (k * compression - (c + delta * k) * speed) \
			/ (1.0 + (delta * c + delta * delta * k) / mass)
	var weight := mass * _gravity
	# Never pull down harder than one extra g, never shove up harder than a hard landing.
	var force := clampf(spring + weight, -weight, weight * 8.0)
	apply_central_force(Vector3.UP * force)

	# Standing on a loose object presses down on it (capped so light gear isn't crushed into orbit).
	if ground and force > 0.0:
		var press := minf(force, ground.mass * _gravity * 3.0)
		ground.apply_force(Vector3.DOWN * press, hit.position - ground.global_position)


func _update_jump(delta: float) -> void:
	_jump_buffer = maxf(_jump_buffer - delta, 0.0)
	if controls_enabled and Input.is_action_just_pressed(&"jump"):
		_jump_buffer = jump_buffer_time
	var can_jump := (grounded or _air_time < coyote_time) and _ride_pause <= 0.0
	if _jump_buffer > 0.0 and can_jump:
		_jump_buffer = 0.0
		_ride_pause = 0.25
		grounded = false
		linear_velocity.y = sqrt(2.0 * _gravity * jump_height) * lerpf(0.6, 1.0, speed_factor)
		jumped.emit()


func _update_movement(delta: float) -> void:
	var input := Vector2.ZERO
	if controls_enabled:
		input = Input.get_vector(&"move_left", &"move_right", &"move_forward", &"move_back")
	var wanted := Vector3(input.x, 0.0, input.y).rotated(Vector3.UP, camera_rig.yaw)
	wanted *= walk_speed * speed_factor
	var effort := braking if wanted.dot(_goal_velocity) <= 0.0 else 1.0
	_goal_velocity = _goal_velocity.move_toward(wanted, acceleration * effort * delta)

	var ground_velocity := Vector3(_ground_velocity.x, 0.0, _ground_velocity.z)
	var error := _goal_velocity + ground_velocity - get_horizontal_velocity()
	var force := error * mass * minf(move_response, 1.0 / delta)
	if not grounded:
		effort = air_control
	apply_central_force(force.limit_length(max_move_force * effort))


func _update_facing(delta: float) -> void:
	if face_direction.length_squared() > 0.0001:
		_face_goal = atan2(-face_direction.x, -face_direction.z)
	elif _goal_velocity.length_squared() > 0.09:
		_face_goal = atan2(-_goal_velocity.x, -_goal_velocity.z)
	facing_yaw = lerp_angle(facing_yaw, _face_goal, 1.0 - exp(-turn_speed * delta))
