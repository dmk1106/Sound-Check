class_name Interactor
extends Node3D
## Lets the player use the nearest Interactable with the interact key.
## Hands full = no interacting (the same key then raises what is held).

signal focus_changed(target: Interactable)

## The Interactable that would be used right now (null if none in range).
var focus: Interactable = null

@onready var player: Player = get_parent()


func _ready() -> void:
	add_to_group(&"interactor")


func _physics_process(_delta: float) -> void:
	var best: Interactable = null
	if player.controls_enabled and not player.hands.is_holding():
		var here := player.global_position
		var best_distance := INF
		for node in get_tree().get_nodes_in_group(&"interactable"):
			var target := node as Interactable
			if target == null or not target.enabled or not target.is_visible_in_tree():
				continue
			var offset := target.global_position - here
			if absf(offset.y) > 2.0:
				continue
			var distance := Vector2(offset.x, offset.z).length()
			# Compare how deep inside each one's circle we are, so a small
			# target isn't drowned out by a big one next to it.
			if distance <= target.radius and distance / target.radius < best_distance:
				best_distance = distance / target.radius
				best = target
	if best != focus:
		focus = best
		focus_changed.emit(focus)


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed(&"interact") and focus and player.controls_enabled \
			and not player.hands.is_holding():
		get_viewport().set_input_as_handled()
		focus.interact(player)


## Ask the HUD to re-read the prompt (after the focused thing changed its text).
func refresh() -> void:
	focus_changed.emit(focus)
