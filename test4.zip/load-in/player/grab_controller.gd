class_name GrabController
extends Node3D
## The player's hands.
##
## Finds the Grabbable in reach, and while the grab button is held pulls its grab
## point toward a spot in front of the character with a spring force. The same
## force pushes back on the player, so heavy things tug you around.
##
## The arms always reach out the way the character is facing - never toward
## the camera or the mouse. Light things are carried in front; with heavy
## things the character turns to face what it is hauling and drags it along.
##
## There is no "carry mode" and "drag mode": the force is simply limited.
##   * lighter than max_lift_force  -> it leaves the ground and dangles from the hands
##   * heavier                      -> it stays on the ground and gets dragged
## Mass, friction and shape of each object do the rest.

signal focus_changed(item: Grabbable)
signal grab_started(item: Grabbable)
signal grab_ended(item: Grabbable)

@export_group("Reach")
## How far away (horizontally) a grab point can be and still be grabbed.
@export var reach := 1.3
## How far in front of the body the hands hold things.
@export var hold_distance := 0.7
## How far to the right of the body (0 = straight ahead).
@export var hold_side := 0.0
## Hand height above the feet when carrying.
@export var hold_height_default := 1.15
@export var hold_height_min := 0.3
@export var hold_height_max := 1.9
## Height change per mouse-wheel notch.
@export var hold_height_step := 0.15
## Height change per second while a raise/lower key is held.
@export var hold_height_speed := 1.2
## How fast the hands themselves move up and down, in m/s (pick-up speed).
@export var lift_speed := 2.5
## How fast the arms can swing a held item around the body, in radians/s.
## Turning faster than this makes the item trail behind.
@export var swing_speed := 9.0
## Physics layers that hold grabbable things.
@export_flags_3d_physics var grab_mask := 0b100
## Physics layers that block reaching (walls).
@export_flags_3d_physics var blocker_mask := 0b001

@export_group("Strength")
## Spring pulling the held item to the hands, in N/m. Heavier items sag and lag more.
@export var stiffness := 900.0
@export var damping_ratio := 0.8
## Most upward force the arms can give, in N. Roughly: can lift (this / 10) kg.
@export var max_lift_force := 200.0
## Most sideways force the arms can give, in N.
@export var max_pull_force := 700.0
## Light things are never accelerated harder than this (m/s²), so a guitar
## isn't whipped around or squashed into walls with the strength meant for amps.
@export var max_acceleration := 40.0
## The grip is lost if the item ends up this far from the hands...
@export var break_distance := 1.5
## ...for this long.
@export var break_time := 0.25
## Items at least this heavy (kg) are hauled, not carried: the character
## faces them and they follow behind.
@export var two_hand_mass := 8.0

## What is being held right now (null if nothing).
var held: Grabbable = null
## What would be grabbed if the button were pressed now (null if nothing in reach).
var focus: Grabbable = null
## Force applied to the held item last tick (for visuals / feedback).
var last_force := Vector3.ZERO

var _want_grab := false
var _grab_local := Vector3.ZERO
var _focus_point := Vector3.ZERO
var _hold_yaw := 0.0            # direction the arms point (follows the character's facing, rate-limited)
var _hold_height := 1.15        # where the hands are now
var _hold_height_goal := 1.15   # where the player wants them
var _break_timer := 0.0
var _shape_query := PhysicsShapeQueryParameters3D.new()

@onready var player: Player = get_parent()
@onready var _gravity: float = ProjectSettings.get_setting("physics/3d/default_gravity")
@onready var _focus_marker: Node3D = get_node_or_null(^"FocusMarker")


func _ready() -> void:
	var sphere := SphereShape3D.new()
	sphere.radius = reach + 1.0
	_shape_query.shape = sphere
	_shape_query.collision_mask = grab_mask
	if _focus_marker:
		_focus_marker.top_level = true
		_focus_marker.visible = false


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed(&"grab"):
		# A click that only re-captures the mouse must not grab.
		if event is InputEventMouseButton and Input.mouse_mode != Input.MOUSE_MODE_CAPTURED:
			return
		_want_grab = true
	elif event.is_action_released(&"grab"):
		_want_grab = false
	elif is_holding() and event is InputEventMouseButton and event.pressed:
		if event.is_action(&"hold_raise"):
			_set_hold_height_goal(_hold_height_goal + hold_height_step)
		elif event.is_action(&"hold_lower"):
			_set_hold_height_goal(_hold_height_goal - hold_height_step)


func _notification(what: int) -> void:
	# Alt-tabbing away while holding the button must not leave the hands stuck shut.
	if what == NOTIFICATION_APPLICATION_FOCUS_OUT:
		_want_grab = false


func _physics_process(delta: float) -> void:
	var want := _want_grab and player.controls_enabled
	if held != null:
		# Also lets go if the item was deleted while in our hands.
		if not want or not is_instance_valid(held):
			drop()
		else:
			_set_hold_height_goal(_hold_height_goal
					+ Input.get_axis(&"hold_lower", &"hold_raise") * hold_height_speed * delta)
			_hold_height = move_toward(_hold_height, _hold_height_goal, lift_speed * delta)
			_apply_hold(delta)
	else:
		_hold_yaw = player.facing_yaw
		_hold_height = hold_height_default
		_set_focus(_find_focus())
		if want and focus:
			_grab(focus, _focus_point)
	_update_focus_marker()


## True while something is in the hands.
func is_holding() -> bool:
	return is_instance_valid(held)


## True while the button is held but the hands are empty.
func is_reaching() -> bool:
	return _want_grab and not is_holding()


## True when the held item is heavy enough to be hauled rather than carried.
func uses_both_hands() -> bool:
	return is_holding() and held.mass >= two_hand_mass


## Where the hands want the held item's grab point to be (world space).
func get_hold_point() -> Vector3:
	var forward := Vector3.FORWARD.rotated(Vector3.UP, _hold_yaw)
	var right := forward.cross(Vector3.UP)
	return player.get_feet_position() \
			+ forward * hold_distance \
			+ right * hold_side \
			+ Vector3.UP * _hold_height


## Where the hands actually are on the held item (world space).
func get_grip_position() -> Vector3:
	if is_holding():
		return held.to_global(_grab_local)
	return get_hold_point()


## Let go of whatever is held. It keeps its momentum and stays where it lands.
func drop() -> void:
	if held == null:
		return
	var item := held
	held = null
	last_force = Vector3.ZERO
	player.carried_mass = 0.0
	player.face_direction = Vector3.ZERO
	player.ride_exclude.clear()
	if is_instance_valid(item):
		item.release()
		grab_ended.emit(item)


func _grab(item: Grabbable, at: Vector3) -> void:
	_set_focus(null)
	held = item
	_grab_local = item.to_local(at)
	_break_timer = 0.0

	# Start with the hands where the item already is, then bring it round to the
	# carrying position: no yank, whatever side it was picked up from.
	var feet := player.get_feet_position()
	var to_item := at - feet
	if Vector2(to_item.x, to_item.z).length() > 0.05:
		_hold_yaw = atan2(-to_item.x, -to_item.z) + atan2(hold_side, hold_distance)
		# Turn to face what we just took hold of.
		player.face_toward(_hold_yaw)
	_hold_height = clampf(to_item.y, hold_height_min, hold_height_max)
	_hold_height_goal = hold_height_default

	player.ride_exclude = [item.get_rid()]
	player.carried_mass = item.mass
	item.grab(player)
	grab_started.emit(item)


func _set_hold_height_goal(value: float) -> void:
	_hold_height_goal = clampf(value, hold_height_min, hold_height_max)


func _apply_hold(delta: float) -> void:
	var state := PhysicsServer3D.body_get_direct_state(held.get_rid())
	if state == null:
		return
	var grip := held.to_global(_grab_local)

	# Where the arms point. Heavy: at the thing itself, so it trails behind
	# wherever we walk. Light: wherever the character is facing.
	var wanted_yaw := player.facing_yaw
	if uses_both_hands():
		var to_grip := grip - player.get_feet_position()
		if Vector2(to_grip.x, to_grip.z).length() > 0.2:
			wanted_yaw = atan2(-to_grip.x, -to_grip.z)
		player.face_direction = Vector3.FORWARD.rotated(Vector3.UP, wanted_yaw)
	else:
		player.face_direction = Vector3.ZERO
	_hold_yaw = rotate_toward(_hold_yaw, wanted_yaw, swing_speed * delta)

	var from_origin := grip - held.global_position
	var from_center := from_origin - state.center_of_mass
	var error := get_hold_point() - grip
	var velocity := state.get_velocity_at_local_position(from_origin) - player.linear_velocity

	# Spring-damper toward the hands, solved implicitly per axis so it stays
	# stable for any stiffness, mass or grab point (even far from the centre of mass).
	var k := stiffness
	var c := 2.0 * damping_ratio * sqrt(k * held.mass)
	var inverse_inertia := state.inverse_inertia_tensor
	var force := Vector3.ZERO
	for axis in 3:
		var direction := Vector3.ZERO
		direction[axis] = 1.0
		var lever := from_center.cross(direction)
		var inverse_mass := state.inverse_mass + lever.dot(inverse_inertia * lever) + 1.0 / player.mass
		force[axis] = (k * error[axis] - (c + delta * k) * velocity[axis]) \
				/ (1.0 + (delta * c + delta * delta * k) * inverse_mass)

	# Arm strength. This is what makes heavy gear heavy.
	var gentle := held.mass * max_acceleration
	force.y = clampf(force.y, -max_lift_force, minf(max_lift_force, held.mass * _gravity + gentle))
	var sideways := Vector2(force.x, force.z).limit_length(minf(max_pull_force, gentle))
	force.x = sideways.x
	force.z = sideways.y

	held.apply_force(force, from_origin)
	player.apply_central_force(-force)
	last_force = force

	# Lose the grip if the item gets yanked away (stuck behind a wall, fell off a ledge...).
	_break_timer = _break_timer + delta if error.length() > break_distance else 0.0
	if _break_timer > break_time:
		drop()


func _find_focus() -> Grabbable:
	var feet := player.get_feet_position()
	var chest := feet + Vector3.UP * 1.1
	var forward := player.get_facing_forward()
	var space := get_world_3d().direct_space_state
	_shape_query.transform = Transform3D(Basis.IDENTITY, chest)

	var best: Grabbable = null
	var best_score := INF
	for hit in space.intersect_shape(_shape_query, 24):
		var item := hit.collider as Grabbable
		if item == null or item.is_held() or not item.can_grab:
			continue
		for point in item.get_grab_positions():
			var offset := point - feet
			if offset.y < -0.5 or offset.y > 2.3:
				continue
			offset.y = 0.0
			var distance := offset.length()
			if distance > reach:
				continue
			# Closest grab point wins; things in front of the character count as closer
			# than things beside or behind us.
			var facing := forward.dot(offset / distance) if distance > 0.001 else 1.0
			var score := distance * (1.5 - 0.5 * facing)
			if score >= best_score:
				continue
			if _is_blocked(space, chest, point):
				continue
			best_score = score
			best = item
			_focus_point = point
	return best


func _is_blocked(space: PhysicsDirectSpaceState3D, from: Vector3, to: Vector3) -> bool:
	var target := to.move_toward(from, 0.08)
	var ray := PhysicsRayQueryParameters3D.create(from, target, blocker_mask)
	return not space.intersect_ray(ray).is_empty()


func _set_focus(item: Grabbable) -> void:
	if item == focus:
		return
	if is_instance_valid(focus):
		focus.set_highlighted(false)
	focus = item
	if focus:
		focus.set_highlighted(true)
	focus_changed.emit(focus)


func _update_focus_marker() -> void:
	if _focus_marker == null:
		return
	var jumped := not _focus_marker.visible or _focus_marker.global_position.distance_to(_focus_point) > 0.3
	_focus_marker.visible = focus != null
	if focus:
		_focus_marker.global_position = _focus_point
		if jumped:
			# Hopping to another grab point: don't let interpolation smear it across the gap.
			_focus_marker.reset_physics_interpolation()
