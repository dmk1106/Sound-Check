class_name CameraRig
extends Node3D
## Third-person orbit camera. It sits inside the player scene but moves on its
## own (top_level), following the target smoothly at render rate.
##
## `yaw` is also the player's aim direction: movement is relative to it and the
## hands hold things out in that direction.

@export var target_path: NodePath = ^".."
## Height of the orbit pivot above the target's origin.
@export var pivot_height := 0.55
@export var distance := 6.0
## Radians per pixel of mouse movement.
@export var mouse_sensitivity := 0.002
## Radians per second at full stick deflection.
@export var stick_sensitivity := 2.6
@export var invert_y := false
@export_range(-89.0, 0.0, 1.0, "degrees") var pitch_min_degrees := -72.0
## How far up you can look. Past orbit_max_degrees the camera stops swinging
## down toward the ground and tilts its head back instead, so it can take in
## rooftops, balconies and signs without ending up under the pavement.
@export_range(0.0, 85.0, 1.0, "degrees") var pitch_max_degrees := 68.0
@export_range(0.0, 60.0, 1.0, "degrees") var orbit_max_degrees := 8.0
## Higher = the camera sticks to the player more tightly.
@export var follow_speed := 14.0

var yaw := 0.0
var pitch := deg_to_rad(-28.0)

var _chase := false
var _since_look := 10.0

@onready var _target: Node3D = get_node(target_path)
@onready var _arm: SpringArm3D = $Arm
@onready var _camera: Camera3D = $Arm/Camera


func _ready() -> void:
	top_level = true
	# Moved every rendered frame, so it must not be physics-interpolated.
	physics_interpolation_mode = Node.PHYSICS_INTERPOLATION_MODE_OFF
	_arm.spring_length = distance
	if _target is CollisionObject3D:
		_arm.add_excluded_object(_target.get_rid())
	global_position = _target.global_position + Vector3.UP * pivot_height
	_apply_rotation()
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED


func _unhandled_input(event: InputEvent) -> void:
	var captured := Input.mouse_mode == Input.MOUSE_MODE_CAPTURED
	if event is InputEventMouseMotion and captured:
		_since_look = 0.0
		yaw -= event.relative.x * mouse_sensitivity
		pitch -= event.relative.y * mouse_sensitivity * (-1.0 if invert_y else 1.0)
		_clamp_pitch()
	elif event is InputEventMouseButton and event.pressed and not captured:
		# First click only re-captures the mouse; it must not also grab something.
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
		get_viewport().set_input_as_handled()


func _process(delta: float) -> void:
	var look := Input.get_vector(&"look_left", &"look_right", &"look_up", &"look_down")
	_since_look += delta
	if look != Vector2.ZERO:
		_since_look = 0.0
		yaw -= look.x * stick_sensitivity * delta
		pitch -= look.y * stick_sensitivity * delta * (-1.0 if invert_y else 1.0)
		_clamp_pitch()

	var target_transform := _target.get_global_transform_interpolated()
	var target_origin := target_transform.origin
	if _chase and _since_look > 1.2:
		# Driving: drift back behind the vehicle when the player isn't looking around.
		var speed := 0.0
		if _target is RigidBody3D:
			speed = (_target as RigidBody3D).linear_velocity.length()
		var behind := target_transform.basis.get_euler().y
		yaw = lerp_angle(yaw, behind, 1.0 - exp(-clampf(speed * 0.3, 0.0, 2.5) * delta))
	var target_position := target_origin + Vector3.UP * pivot_height
	global_position = global_position.lerp(target_position, 1.0 - exp(-follow_speed * delta))
	_apply_rotation()
	# Lets cutaway walls dissolve wherever they would hide the player.
	# (Not while driving: the vehicle would dissolve itself.)
	RenderingServer.global_shader_parameter_set(&"see_through_focus",
			Vector3(0.0, -10000.0, 0.0) if _chase else target_origin)


## Horizontal unit vector the camera looks along.
func get_forward() -> Vector3:
	return Vector3.FORWARD.rotated(Vector3.UP, yaw)


## Switch to following something else (a vehicle, or back to the player).
## `chase` makes the camera settle behind the target as it moves.
func follow(target: Node3D, new_distance: float, new_pivot_height: float, chase := false) -> void:
	_target = target
	_chase = chase
	distance = new_distance
	pivot_height = new_pivot_height
	_arm.spring_length = distance
	if target is CollisionObject3D:
		_arm.add_excluded_object(target.get_rid())
	if chase:
		yaw = target.global_rotation.y
		_since_look = 10.0
	global_position = target.global_position + Vector3.UP * pivot_height
	_apply_rotation()


## Jump straight to the target (after a respawn / teleport).
func snap_to_target() -> void:
	global_position = _target.global_position + Vector3.UP * pivot_height


func _clamp_pitch() -> void:
	pitch = clampf(pitch, deg_to_rad(pitch_min_degrees), deg_to_rad(pitch_max_degrees))


func _apply_rotation() -> void:
	rotation = Vector3(0.0, yaw, 0.0)
	var orbit := minf(pitch, deg_to_rad(orbit_max_degrees))
	_arm.rotation = Vector3(orbit, 0.0, 0.0)
	_camera.rotation = Vector3(pitch - orbit, 0.0, 0.0)
