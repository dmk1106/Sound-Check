extends Node3D
## Cosmetic only: the character model (player/character_model.tscn).
## Nothing in here affects physics, so movement and grabbing never depend on it.
##
## The pose is built in layers every frame:
##   1. the walk and run clips that came with the model, blended by speed and
##      played by distance travelled, so the feet don't slide;
##   2. on top: lean into speed / bumps / heavy loads, waddle, head that lags
##      and glances at what the hands want, squash on jumps and landings,
##      sitting, arms flung up in the air;
##   3. the arms: springy idle arms, or two-bone IK onto whatever the hands are
##      reaching for or holding (rubbery: they stretch a little to get there);
##   4. blinking eyelids, and a squint while hauling.
##
## The simulation (springs, phase) runs in _physics_process; _process blends
## the last two ticks, like physics interpolation does for nodes.

@export_group("Wobble")
## Lean (radians) per m/s of speed.
@export var lean_from_speed := 0.02
## Lean per m/s² of acceleration; the body lags behind sudden moves and bumps.
@export var lean_from_accel := 0.012
## Lean at full arm strain (hauling something heavy).
@export var lean_from_load := 0.4
@export var lean_stiffness := 70.0
## Lower = wobblier.
@export var lean_damping := 7.0
@export var max_lean := 0.6
## How much the head lags behind the body. 0 = bolted on.
@export var head_wobble := 0.6
## Side-to-side roll (radians) while walking, on top of the clips.
@export var waddle := 0.05

@export_group("Locomotion")
@export var walk_clip := &"Walking"
@export var run_clip := &"Running"
## Ground speed (m/s) each clip was animated for: played at that speed the
## feet stay planted. Faster or slower just plays it faster or slower.
@export var walk_clip_speed := 1.05
@export var run_clip_speed := 3.0
## Between these speeds (m/s) the walk turns into a run.
@export var run_blend_from := 1.4
@export var run_blend_to := 2.6
## Below this speed (m/s) the character stands still.
@export var idle_speed := 0.15
## Legs apart in the air (radians).
@export var leg_swing := 0.5
## How far the body sinks when sitting, so the thighs rest on the seat.
@export var seat_drop := 0.12

@export_group("Mocap")
## Mixamo clips (player/anims, baked onto our skeleton by MocapClip).
@export var sitting_clip: Animation = preload("res://player/anims/sitting.res")
## Played on stage, by what the player is performing on (Player.performing).
@export var perform_clips := {
	&"guitar": preload("res://player/anims/guitar.res"),
	&"piano": preload("res://player/anims/piano.res"),
	&"drums": preload("res://player/anims/drums.res"),
}
## Clips that only move the upper body (the seated ones, used standing up).
@export var upper_body_clips: Array[StringName] = [&"piano", &"drums"]
## Gentle breathing when standing still (radians of spine sway).
@export var breathing := 0.025

@export_group("Arms")
## How far the arms may stretch past their length to reach the hands' target.
@export var max_arm_stretch := 1.35
## Lower = floppier.
@export var arm_stiffness := 220.0
@export var arm_damping := 13.0

@export_group("Face")
## How fast the eyelids move (1/s).
@export var lid_speed := 40.0

const LEFT := 0
const RIGHT := 1
const BONE_PREFIX := "mixamorig_"
## The model faces +Z; the game's forward is -Z.
const FLIP := Basis(Vector3.UP, PI)

var _random := RandomNumberGenerator.new()   # private, so blinking never disturbs gameplay randomness
var _time := 0.0
var _last_velocity := Vector3.ZERO
var _lean := Vector2.ZERO          # x = forward, y = right (in facing space)
var _lean_velocity := Vector2.ZERO
var _head_tilt := Vector2.ZERO     # same axes, relative to the body
var _head_tilt_velocity := Vector2.ZERO
var _head_look := Vector2.ZERO     # x = yaw, y = pitch
var _phase := 0.0                  # walk cycles travelled (not wrapped)
var _move := 0.0                   # 0 = standing, 1 = walking or running
var _run := 0.0                    # 0 = walk clip, 1 = run clip
var _air := 0.0
var _seat := 0.0
var _squash := 0.0
var _squash_velocity := 0.0
var _eye_open := 1.0
var _blink_timer := 2.5
var _arm_weight: Array[float] = [1.0, 1.0]
# Hand positions relative to the player's origin (world axes), and their speed.
var _hand: Array[Vector3] = [Vector3.ZERO, Vector3.ZERO]
var _hand_velocity: Array[Vector3] = [Vector3.ZERO, Vector3.ZERO]
var _posed := false
# The simulation at the last two physics ticks (see _snapshot).
var _previous := {}
var _current := {}

# Skeleton
var _skeleton: Skeleton3D
var _rest_rotation: Array[Quaternion] = []
var _rest_position: Array[Vector3] = []
var _pose_rotation: Array[Quaternion] = []
var _pose_position: Array[Vector3] = []
var _hips := -1
var _spine := -1
var _head := -1
var _arm: Array[int] = [-1, -1]
var _forearm: Array[int] = [-1, -1]
var _wrist: Array[int] = [-1, -1]
var _fingertip: Array[int] = [-1, -1]
var _thigh: Array[int] = [-1, -1]
var _shin: Array[int] = [-1, -1]
var _ankle: Array[int] = [-1, -1]
# Clips: walk, run; per bone the (rotation, position) track or -1.
var _clips: Array[Animation] = []
var _sit_clip: MocapClip = null
var _perform_clips := {}
var _perform := 0.0
var _perform_name := &""
var _mocap_time := 0.0
var _clip_tracks: Array = []

@onready var _player: Player = get_parent()
@onready var _hands: GrabController = _player.get_node(^"Hands")
@onready var _model: Node3D = $Model
@onready var _lids: Array[Node3D] = [
	$Model/target_character/Skeleton3D/HeadAttachment/LidL,
	$Model/target_character/Skeleton3D/HeadAttachment/LidR,
]


func _ready() -> void:
	_player.jumped.connect(func() -> void: _squash_velocity += 2.5)
	_player.landed.connect(_on_landed)
	_model.position.y = -_player.ride_height
	_skeleton = _model.get_node(^"target_character/Skeleton3D")
	_find_bones()
	_find_clips()
	_bake_mocap()
	_current = _snapshot()
	_previous = _current


func _find_bones() -> void:
	for i in _skeleton.get_bone_count():
		var rest := _skeleton.get_bone_rest(i)
		_rest_rotation.append(rest.basis.get_rotation_quaternion())
		_rest_position.append(rest.origin)
	_pose_rotation = _rest_rotation.duplicate()
	_pose_position = _rest_position.duplicate()
	_hips = _bone("Hips")
	_spine = _bone("Spine")
	_head = _bone("Head")
	for side in 2:
		var s := "Left" if side == LEFT else "Right"
		_arm[side] = _bone(s + "Arm")
		_forearm[side] = _bone(s + "ForeArm")
		_wrist[side] = _bone(s + "Hand")
		_fingertip[side] = _first_child(_wrist[side])
		_thigh[side] = _bone(s + "UpLeg")
		_shin[side] = _bone(s + "Leg")
		# The bone at the ankle (the right leg has an extra one there).
		_ankle[side] = _first_child(_shin[side])


func _bone(bone_name: String) -> int:
	var i := _skeleton.find_bone(BONE_PREFIX + bone_name)
	assert(i >= 0, "character model has no bone " + BONE_PREFIX + bone_name)
	return i


func _first_child(bone: int) -> int:
	var children := _skeleton.get_bone_children(bone)
	return children[0] if children.size() > 0 else bone


func _find_clips() -> void:
	var player := _model.get_node_or_null(^"AnimationPlayer") as AnimationPlayer
	for clip_name in [walk_clip, run_clip]:
		var clip := Animation.new()
		if player and player.has_animation(clip_name):
			clip = player.get_animation(clip_name)
		else:
			push_warning("character model has no clip " + clip_name)
		# Per bone: (rotation track, position track), -1 = none.
		var tracks: Array[Vector2i] = []
		tracks.resize(_skeleton.get_bone_count())
		tracks.fill(Vector2i(-1, -1))
		for t in clip.get_track_count():
			var bone := _skeleton.find_bone(str(clip.track_get_path(t).get_concatenated_subnames()))
			if bone < 0:
				continue
			match clip.track_get_type(t):
				Animation.TYPE_ROTATION_3D:
					tracks[bone].x = t
				Animation.TYPE_POSITION_3D:
					tracks[bone].y = t
		_clips.append(clip)
		_clip_tracks.append(tracks)


func _bake_mocap() -> void:
	if sitting_clip:
		_sit_clip = MocapClip.bake(sitting_clip, _skeleton)
	for clip_name: StringName in perform_clips:
		var anim := perform_clips[clip_name] as Animation
		if anim:
			_perform_clips[clip_name] = MocapClip.bake(anim, _skeleton, clip_name in upper_body_clips)


# --- Simulation (physics ticks) ---

func _physics_process(delta: float) -> void:
	rotation.y = _player.facing_yaw
	_time += delta

	var velocity := _player.linear_velocity
	var acceleration := ((velocity - _last_velocity) / delta).limit_length(40.0)
	_last_velocity = velocity
	var speed := Vector2(velocity.x, velocity.z).length()
	var speed_ratio := clampf(speed / _player.walk_speed, 0.0, 1.2)
	var strain := clampf(_hands.last_force.length() / _hands.max_pull_force, 0.0, 1.0)
	var on_ground := _player.grounded and not _player.seated

	# Locomotion: which clips, how much, and how far through the cycle.
	var blend := 1.0 - exp(-10.0 * delta)
	_move = lerpf(_move, smoothstep(idle_speed, idle_speed * 3.0, speed) if on_ground else 0.0, blend)
	_run = lerpf(_run, smoothstep(run_blend_from, run_blend_to, speed), blend)
	_air = lerpf(_air, 0.0 if _player.grounded or _player.seated else 1.0, 1.0 - exp(-14.0 * delta))
	_seat = lerpf(_seat, 1.0 if _player.seated else 0.0, 1.0 - exp(-12.0 * delta))
	_mocap_time += delta
	# On stage: fade into the clip for the instrument (and out again after).
	var performing: StringName = _player.performing
	if performing != &"" and _perform_clips.has(performing):
		if performing != _perform_name and _perform < 0.05:
			_perform_name = performing
		_perform = lerpf(_perform, 1.0 if performing == _perform_name else 0.0, 1.0 - exp(-5.0 * delta))
	else:
		_perform = lerpf(_perform, 0.0, 1.0 - exp(-5.0 * delta))
	if on_ground:
		var cycle_length := lerpf(walk_clip_speed * _clips[0].length, run_clip_speed * _clips[1].length, _run)
		_phase += speed * delta / maxf(cycle_length, 0.1)

	_update_lean(delta, velocity, acceleration, strain)
	_update_squash(delta)
	_update_head(delta)
	_update_face(delta, strain)
	_update_arms(delta, speed_ratio)

	_previous = _current
	_current = _snapshot()
	if not _posed:
		# First tick: don't let anything sweep in from the origin.
		_posed = true
		_previous = _current
		reset_physics_interpolation()


func _snapshot() -> Dictionary:
	var step := sin(_phase * TAU) * _move
	return {
		"phase": _phase, "move": _move, "run": _run, "air": _air, "seat": _seat,
		"lean": _lean, "step": step, "head": Vector2(_head_tilt.x - _head_look.y, _head_tilt.y),
		"look": _head_look.x, "hand_l": _hand[LEFT], "hand_r": _hand[RIGHT],
		"arm_l": _arm_weight[LEFT], "arm_r": _arm_weight[RIGHT], "eyes": _eye_open,
		"perform": _perform, "time": _mocap_time,
	}


func _on_landed(impact: float) -> void:
	_squash_velocity -= clampf(impact * 0.5, 0.0, 4.0)
	_head_tilt_velocity.x += clampf(impact * 0.6, 0.0, 4.0)   # nod


func _update_lean(delta: float, velocity: Vector3, acceleration: Vector3, strain: float) -> void:
	# Work in facing space, where forward is -Z and right is +X.
	var into_facing := global_basis.inverse()
	var v := into_facing * Vector3(velocity.x, 0.0, velocity.z)
	var a := into_facing * Vector3(acceleration.x, 0.0, acceleration.z)
	var pull := into_facing * _hands.last_force

	var target := Vector2(-v.z, v.x) * lean_from_speed
	target -= Vector2(-a.z, a.x) * lean_from_accel
	target += Vector2(-pull.z, pull.x) / _hands.max_pull_force * lean_from_load
	# Reach a little toward whatever is held.
	if _hands.is_holding():
		target.x += 0.12 * (1.0 - strain)
	target = target.limit_length(max_lean)
	if _player.seated:
		target = Vector2.ZERO

	_lean_velocity += ((target - _lean) * lean_stiffness - _lean_velocity * lean_damping) * delta
	_lean = (_lean + _lean_velocity * delta).limit_length(max_lean * 1.3)


func _update_squash(delta: float) -> void:
	_squash_velocity += (-_squash * 180.0 - _squash_velocity * 14.0) * delta
	_squash += _squash_velocity * delta
	# A slow breath on top of the jump / landing squash.
	var stretch := clampf(1.0 + _squash + sin(_time * 2.4) * 0.008, 0.7, 1.25)
	var bulge := 1.0 / sqrt(stretch)
	_model.basis = FLIP.scaled(Vector3(bulge, stretch, bulge))


func _update_head(delta: float) -> void:
	# The head tries to stay upright while the body leans under it, and overshoots.
	var target := -_lean * head_wobble
	_head_tilt_velocity += ((target - _head_tilt) * 110.0 - _head_tilt_velocity * 7.0) * delta
	_head_tilt = (_head_tilt + _head_tilt_velocity * delta).limit_length(0.7)

	# Glance at whatever the hands care about.
	var look := Vector2.ZERO
	var interest := Vector3.ZERO
	var weight := 0.0
	if _hands.is_holding():
		interest = _hands.get_grip_position()
		weight = 0.4
	elif _hands.focus:
		interest = _hands.focus.global_position
		weight = 1.0
	if weight > 0.0:
		var head_position := _skeleton.global_transform * _skeleton.get_bone_global_pose(_head).origin
		var local := global_basis.inverse() * (interest - head_position)
		look.x = clampf(atan2(-local.x, -local.z), -0.8, 0.8) * weight
		look.y = clampf(atan2(local.y, Vector2(local.x, local.z).length()), -0.55, 0.3) * weight
	_head_look = _head_look.lerp(look, 1.0 - exp(-9.0 * delta))


func _update_face(delta: float, strain: float) -> void:
	_blink_timer -= delta
	if _blink_timer < -0.11:
		_blink_timer = _random.randf_range(1.8, 4.5)
	var open := 1.0
	if _blink_timer < 0.0:
		open = 0.0                             # blink
	elif not _player.grounded and not _player.seated:
		open = 1.0                             # whee
	else:
		open = lerpf(1.0, 0.45, strain)        # squint when hauling
	_eye_open = lerpf(_eye_open, open, 1.0 - exp(-lid_speed * delta))


func _update_arms(delta: float, speed_ratio: float) -> void:
	var origin := _player.global_position
	var facing := global_basis
	var right := facing.x
	var shoulders: Array[Vector3] = []
	var reach := 0.0
	for side in 2:
		shoulders.append(_skeleton.global_transform * _skeleton.get_bone_global_pose(_arm[side]).origin)
		reach = _arm_length(side)

	# Idle: arms hang a little away from the body and swing against the legs.
	var swing := sin(_phase * TAU) * 0.3 * speed_ratio
	var targets: Array[Vector3] = [
		shoulders[LEFT] + facing * Vector3(-0.3, -0.85, swing + 0.02) * reach,
		shoulders[RIGHT] + facing * Vector3(0.3, -0.85, -swing + 0.02) * reach,
	]
	# 0 = floppy spring, anything higher = follow the target this tightly.
	var follow: Array[float] = [0.0, 0.0]
	# 1 = the arms are posed here; 0 = they come from the walk / run clip.
	var override := 1.0 - _move
	if (_player.seated and _sit_clip) or _player.performing != &"":
		# The mocap clip moves the arms.
		override = 0.0
	elif _player.seated:
		# Hands in the lap.
		targets[LEFT] = shoulders[LEFT] + facing * Vector3(0.1, -0.75, -0.45) * reach
		targets[RIGHT] = shoulders[RIGHT] + facing * Vector3(-0.1, -0.75, -0.45) * reach
		override = 1.0
	elif not _player.grounded:
		# Airborne: arms fly up.
		targets[LEFT] = shoulders[LEFT] + facing * Vector3(-0.55, 0.6, -0.1) * reach
		targets[RIGHT] = shoulders[RIGHT] + facing * Vector3(0.55, 0.6, -0.1) * reach
		override = 1.0
	if _hands.is_holding():
		# Both arms reach out to whatever is held.
		var grip := _hands.get_grip_position()
		targets[LEFT] = grip - right * 0.08
		targets[RIGHT] = grip + right * 0.08
		follow[LEFT] = 60.0
		follow[RIGHT] = 60.0
		override = 1.0
	elif _hands.is_reaching():
		var reach_point := _hands.get_hold_point()
		targets[LEFT] = reach_point - right * 0.16
		targets[RIGHT] = reach_point + right * 0.16
		follow[LEFT] = 22.0
		follow[RIGHT] = 22.0
		override = 1.0

	for side in 2:
		_arm_weight[side] = lerpf(_arm_weight[side], override, 1.0 - exp(-12.0 * delta))
		# Simulated relative to the body, so the hands never trail behind while running.
		var target := targets[side] - origin
		if follow[side] > 0.0:
			_hand[side] = _hand[side].lerp(target, 1.0 - exp(-follow[side] * delta))
			_hand_velocity[side] = Vector3.ZERO
		elif not _posed:
			_hand[side] = target
		else:
			_hand_velocity[side] += ((target - _hand[side]) * arm_stiffness - _hand_velocity[side] * arm_damping) * delta
			_hand[side] += _hand_velocity[side] * delta


## Shoulder to the middle of the hand, unstretched.
func _arm_length(side: int) -> float:
	return _rest_position[_forearm[side]].length() + _rest_position[_wrist[side]].length() \
			+ _rest_position[_fingertip[side]].length() * 0.5


# --- Posing (every frame) ---

func _process(_delta: float) -> void:
	if not _player.visible:
		return
	var t := Engine.get_physics_interpolation_fraction()
	var s := {}
	for key in _current:
		s[key] = lerp(_previous[key], _current[key], t)
	_build_pose(s)
	for i in _pose_rotation.size():
		_skeleton.set_bone_pose_rotation(i, _pose_rotation[i])
		_skeleton.set_bone_pose_position(i, _pose_position[i])
	for side in 2:
		var closed := clampf(1.0 - (s["eyes"] as float), 0.0, 1.0)
		_lids[side].scale = Vector3(1.0, maxf(closed, 0.001), 1.0)
		_lids[side].visible = closed > 0.02


func _build_pose(s: Dictionary) -> void:
	# 1. Clips (or the rest pose when standing still).
	var move: float = s["move"]
	var run: float = s["run"]
	var phase := fposmod(s["phase"] as float, 1.0)
	for i in _pose_rotation.size():
		_pose_rotation[i] = _rest_rotation[i]
		_pose_position[i] = _rest_position[i]
		if move < 0.001:
			continue
		var walk_rotation := _sample_rotation(0, i, phase)
		var run_rotation := _sample_rotation(1, i, phase)
		_pose_rotation[i] = _rest_rotation[i].slerp(walk_rotation.slerp(run_rotation, run), move)
		var walk_position := _sample_position(0, i, phase)
		var run_position := _sample_position(1, i, phase)
		_pose_position[i] = _rest_position[i].lerp(walk_position.lerp(run_position, run), move)

	# 1b. Mocap: sitting, and playing on stage.
	var seat: float = s["seat"]
	var time: float = s["time"]
	if _sit_clip and seat > 0.001:
		_blend_mocap(_sit_clip, time, seat)
	var perform: float = s["perform"]
	if perform > 0.001 and _perform_clips.has(_perform_name):
		_blend_mocap(_perform_clips[_perform_name], time, perform)

	# 2. Body.
	var air: float = s["air"]
	if seat > 0.001:
		_pose_position[_hips] += Vector3.DOWN * seat_drop * seat
	for side in 2:
		if seat > 0.001 and not _sit_clip:
			# Thighs out in front, shins dangling.
			_aim(_thigh[side], _shin[side], Vector3(0.0, -0.15, 1.0), seat)
			_aim(_shin[side], _ankle[side], Vector3(0.0, -1.0, 0.25), seat)
		if air > 0.001:
			var split := leg_swing * (1.0 if side == LEFT else -1.0)
			_rotate_global(_thigh[side], Quaternion(Vector3.RIGHT, split * air))
	var lean: Vector2 = s["lean"]
	var step: float = s["step"]
	# Breathing when standing about.
	var still := (1.0 - move) * (1.0 - seat) * (1.0 - perform)
	if still > 0.001:
		_rotate_global(_spine, _from_visual(Vector3(sin(time * 1.7) * breathing * still, 0.0, sin(time * 0.6) * breathing * 0.4 * still)))
	_rotate_global(_spine, _from_visual(Vector3(-lean.x, step * waddle * 1.4, -lean.y - step * waddle)))
	var head: Vector2 = s["head"]
	_rotate_global(_head, _from_visual(Vector3(-head.x, s["look"], -head.y)))

	# 3. Arms.
	var to_skeleton := _skeleton.get_global_transform_interpolated().affine_inverse()
	var origin := _player.get_global_transform_interpolated().origin
	var facing := get_global_transform_interpolated().basis
	_pose_arm(LEFT, to_skeleton * (origin + (s["hand_l"] as Vector3)), to_skeleton.basis * (facing * Vector3(-0.7, -0.45, 0.6)), s["arm_l"])
	_pose_arm(RIGHT, to_skeleton * (origin + (s["hand_r"] as Vector3)), to_skeleton.basis * (facing * Vector3(0.7, -0.45, 0.6)), s["arm_r"])


func _blend_mocap(clip: MocapClip, time: float, weight: float) -> void:
	for i in clip.driven:
		_pose_rotation[i] = _pose_rotation[i].slerp(clip.rotation(i, time), weight)
	_pose_position[_hips] += clip.hips_offset(time) * weight


func _sample_rotation(clip: int, bone: int, phase: float) -> Quaternion:
	var track: int = _clip_tracks[clip][bone].x
	if track < 0:
		return _rest_rotation[bone]
	return _clips[clip].rotation_track_interpolate(track, phase * _clips[clip].length)


func _sample_position(clip: int, bone: int, phase: float) -> Vector3:
	var track: int = _clip_tracks[clip][bone].y
	if track < 0:
		return _rest_position[bone]
	return _clips[clip].position_track_interpolate(track, phase * _clips[clip].length)


func _pose_arm(side: int, hand: Vector3, pole: Vector3, weight: float) -> void:
	if weight <= 0.001:
		return
	var arm := _arm[side]
	var forearm := _forearm[side]
	var wrist := _wrist[side]
	var upper_length := _rest_position[forearm].length()
	var lower_length := _rest_position[wrist].length()
	var palm := _rest_position[_fingertip[side]].length() * 0.5

	var shoulder := _global(arm).origin
	var wrist_target := hand - (hand - shoulder).normalized() * palm
	var stretch := clampf(shoulder.distance_to(wrist_target) / (upper_length + lower_length), 1.0, max_arm_stretch)
	var elbow := _solve_elbow(shoulder, wrist_target, pole, upper_length * stretch, lower_length * stretch)

	stretch = lerpf(1.0, stretch, weight)
	_pose_position[forearm] = _rest_position[forearm] * stretch
	_pose_position[wrist] = _rest_position[wrist] * stretch
	_aim_at(arm, forearm, elbow, weight)
	_aim_at(forearm, wrist, wrist_target, weight)
	_aim_at(wrist, _fingertip[side], hand + (hand - _global(wrist).origin), weight)


## Two-bone IK: where the elbow goes for a given shoulder and hand. If the
## hand is out of reach the arm simply goes straight.
func _solve_elbow(shoulder: Vector3, hand: Vector3, pole: Vector3, upper: float, lower: float) -> Vector3:
	var to_hand := hand - shoulder
	var distance := to_hand.length()
	var reach := upper + lower
	if distance < 0.001:
		return shoulder + pole.normalized() * upper
	if distance >= reach:
		return shoulder + to_hand * (upper / reach)
	var direction := to_hand / distance
	# Law of cosines: how far along the shoulder-hand line the elbow sits.
	var along := (distance * distance + upper * upper - lower * lower) / (2.0 * distance)
	var out := sqrt(maxf(upper * upper - along * along, 0.0))
	var bend := pole - direction * pole.dot(direction)
	if bend.length_squared() < 0.0001:
		bend = direction.cross(Vector3.RIGHT)
	return shoulder + direction * along + bend.normalized() * out


# --- Pose helpers (skeleton space) ---

## A rotation given as Euler angles in the character's own axes (-Z forward),
## turned into the model's axes (+Z forward).
func _from_visual(euler: Vector3) -> Quaternion:
	return (FLIP * Basis.from_euler(euler) * FLIP).get_rotation_quaternion()


## Where a bone is right now, from the pose being built.
func _global(bone: int) -> Transform3D:
	var local := Transform3D(Basis(_pose_rotation[bone]), _pose_position[bone])
	var parent := _skeleton.get_bone_parent(bone)
	return _global(parent) * local if parent >= 0 else local


## Turns a bone (and so everything below it) about its own joint by a
## rotation given in skeleton axes.
func _rotate_global(bone: int, rotation_delta: Quaternion) -> void:
	var parent := _skeleton.get_bone_parent(bone)
	var parent_rotation := _global(parent).basis.get_rotation_quaternion() if parent >= 0 else Quaternion.IDENTITY
	_pose_rotation[bone] = parent_rotation.inverse() * rotation_delta * parent_rotation * _pose_rotation[bone]


## Turns a bone so that `child` (a bone below it) lies along `direction`.
func _aim(bone: int, child: int, direction: Vector3, weight: float) -> void:
	var joint := _global(bone)
	_aim_at(bone, child, joint.origin + direction.normalized(), weight)


## Turns a bone so that `child` points at `target` (skeleton space).
func _aim_at(bone: int, child: int, target: Vector3, weight: float) -> void:
	var joint := _global(bone)
	var current := (joint.basis * _pose_position[child]).normalized()
	var wanted := (target - joint.origin).normalized()
	if current.is_zero_approx() or wanted.is_zero_approx() or current.dot(wanted) > 0.99999:
		return
	var turn := Quaternion(current, wanted) if current.dot(wanted) > -0.9999 else Quaternion(current.cross(Vector3.UP).normalized(), PI)
	var before := _pose_rotation[bone]
	_rotate_global(bone, turn)
	_pose_rotation[bone] = before.slerp(_pose_rotation[bone], weight)
