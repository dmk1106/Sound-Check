class_name MocapClip
extends RefCounted
## A Mixamo clip (player/anims/*.res, made by tools/extract_clips.gd) baked
## onto our character's skeleton, ready to be sampled by PlayerVisual.
##
## The source skeleton stands in a T-pose with ordinary proportions; ours is a
## chibi in an A-pose whose head sits in front of the neck. So the clip can't be
## copied bone for bone. Instead, frame by frame:
##   - every bone turns in the world the way its source bone turned away from
##     the source rest pose (keeps twist, works for the torso and head), then
##   - limb bones are swung so they point the same way as the source limb
##     (fixes the T-pose / A-pose difference for arms, legs, hands and feet).
## Hips movement is scaled to our height and centred on the clip's average,
## so a seated clip doesn't push the character through the bench.

const FPS := 30.0
const PREFIX := "mixamorig_"
## Bones that are swung to point like the source, with the source bone that
## marks their far end (its child in the source skeleton).
const AIM := {
	"LeftShoulder": "LeftArm", "RightShoulder": "RightArm",
	"LeftArm": "LeftForeArm", "RightArm": "RightForeArm",
	"LeftForeArm": "LeftHand", "RightForeArm": "RightHand",
	"LeftHand": "LeftHandMiddle1", "RightHand": "RightHandMiddle1",
	"LeftUpLeg": "LeftLeg", "RightUpLeg": "RightLeg",
	"LeftLeg": "LeftFoot", "RightLeg": "RightFoot",
	"LeftFoot": "LeftToeBase", "RightFoot": "RightToeBase",
}
## Bones above the waist (for clips that only drive the upper body).
const UPPER := ["Spine", "Spine1", "Spine2", "Neck", "Head", "LeftShoulder", "RightShoulder",
		"LeftArm", "RightArm", "LeftForeArm", "RightForeArm", "LeftHand", "RightHand"]

var length := 0.0
## frames[f][bone] = local rotation for our skeleton (rest where the clip says nothing).
var frames: Array = []
## Hips offset from the rest position, per frame (skeleton space).
var hips: PackedVector3Array = PackedVector3Array()
## Bone indices this clip drives (all of them, or just the upper body).
var driven: PackedInt32Array = PackedInt32Array()


## Bakes `anim` onto `skeleton`. With `upper_only`, legs and hips are left alone.
static func bake(anim: Animation, skeleton: Skeleton3D, upper_only := false) -> MocapClip:
	var clip := MocapClip.new()
	clip.length = anim.length
	var names: PackedStringArray = anim.get_meta(&"rest_names")
	var parents: PackedStringArray = anim.get_meta(&"rest_parents")
	var rests: Array = anim.get_meta(&"rest_xforms")
	var source_index := {}
	for i in names.size():
		source_index[names[i]] = i
	var source_parent := PackedInt32Array()
	for i in names.size():
		source_parent.append(source_index.get(parents[i], -1))
	# Tracks per source bone: (rotation, position).
	var tracks: Array[Vector2i] = []
	tracks.resize(names.size())
	tracks.fill(Vector2i(-1, -1))
	for t in anim.get_track_count():
		var bone: int = source_index.get(str(anim.track_get_path(t).get_concatenated_subnames()), -1)
		if bone < 0:
			continue
		if anim.track_get_type(t) == Animation.TYPE_ROTATION_3D:
			tracks[bone].x = t
		elif anim.track_get_type(t) == Animation.TYPE_POSITION_3D:
			tracks[bone].y = t

	var source_rest := _globals(rests, source_parent)
	var count := skeleton.get_bone_count()
	var target_rest: Array[Transform3D] = []
	var target_local: Array[Transform3D] = []
	for i in count:
		target_rest.append(skeleton.get_bone_global_rest(i))
		target_local.append(skeleton.get_bone_rest(i))
	# Which source bone each of ours follows (-1 = none, keep the rest pose).
	var follow := PackedInt32Array()
	var aim_end := PackedInt32Array()
	var aim_child := PackedInt32Array()
	for i in count:
		var short := skeleton.get_bone_name(i).trim_prefix(PREFIX)
		var use := not upper_only or short in UPPER
		follow.append(source_index.get(PREFIX + short, -1) if use else -1)
		aim_end.append(source_index.get(PREFIX + str(AIM[short]), -1) if use and AIM.has(short) else -1)
		var children := skeleton.get_bone_children(i)
		aim_child.append(children[0] if children.size() > 0 else -1)
		if follow[i] >= 0:
			clip.driven.append(i)
	var hips_bone := skeleton.find_bone(PREFIX + "Hips")
	var source_hips: int = source_index.get(PREFIX + "Hips", -1)
	var scale: float = target_rest[hips_bone].origin.y / maxf((source_rest[source_hips] as Transform3D).origin.y, 0.01)

	var frame_count := maxi(int(ceil(anim.length * FPS)) + 1, 2)
	var hips_sum := Vector3.ZERO
	for f in frame_count:
		var time := minf(f / FPS, anim.length)
		var local: Array = []
		for i in names.size():
			var rest: Transform3D = rests[i]
			var rotation := anim.rotation_track_interpolate(tracks[i].x, time) if tracks[i].x >= 0 else rest.basis.get_rotation_quaternion()
			var position := anim.position_track_interpolate(tracks[i].y, time) if tracks[i].y >= 0 else rest.origin
			local.append(Transform3D(Basis(rotation), position))
		var source := _globals(local, source_parent)

		var rotations: Array[Quaternion] = []
		var globals: Array[Transform3D] = []
		for i in count:
			var parent := skeleton.get_bone_parent(i)
			var parent_global := globals[parent] if parent >= 0 else Transform3D.IDENTITY
			var rotation := target_local[i].basis.get_rotation_quaternion()
			var s := follow[i]
			if s >= 0:
				# Turn in the world as the source bone did, relative to its rest.
				var delta: Quaternion = (source[s] as Transform3D).basis.get_rotation_quaternion() * (source_rest[s] as Transform3D).basis.get_rotation_quaternion().inverse()
				var world := delta * target_rest[i].basis.get_rotation_quaternion()
				rotation = parent_global.basis.get_rotation_quaternion().inverse() * world
				var e := aim_end[i]
				var c := aim_child[i]
				if e >= 0 and c >= 0:
					# Then swing it to point exactly like the source limb.
					var wanted: Vector3 = ((source[e] as Transform3D).origin - (source[s] as Transform3D).origin).normalized()
					var world_basis := parent_global.basis.get_rotation_quaternion() * rotation
					var current := (world_basis * target_local[c].origin).normalized()
					if not wanted.is_zero_approx() and not current.is_zero_approx() and current.dot(wanted) < 0.99999 and current.dot(wanted) > -0.9999:
						world_basis = Quaternion(current, wanted) * world_basis
						rotation = parent_global.basis.get_rotation_quaternion().inverse() * world_basis
			rotation = rotation.normalized()
			rotations.append(rotation)
			globals.append(parent_global * Transform3D(Basis(rotation), target_local[i].origin))
		clip.frames.append(rotations)
		var offset := Vector3.ZERO
		if not upper_only and source_hips >= 0:
			offset = ((source[source_hips] as Transform3D).origin - (source_rest[source_hips] as Transform3D).origin) * scale
		clip.hips.append(offset)
		hips_sum += offset
	# Centre the hips on the clip's average: the body is placed by the game.
	var mean := hips_sum / frame_count
	for f in frame_count:
		clip.hips[f] -= mean
	return clip


static func _globals(locals: Array, parents: PackedInt32Array) -> Array:
	var out := []
	out.resize(locals.size())
	for i in locals.size():
		var p := parents[i]
		out[i] = (out[p] as Transform3D) * (locals[i] as Transform3D) if p >= 0 else locals[i]
	return out


## Local rotation of `bone` at `time` (looping).
func rotation(bone: int, time: float) -> Quaternion:
	var f := fposmod(time, length) * FPS
	var a := int(f)
	var b := mini(a + 1, frames.size() - 1)
	return (frames[a][bone] as Quaternion).slerp(frames[b][bone] as Quaternion, f - a)


func hips_offset(time: float) -> Vector3:
	var f := fposmod(time, length) * FPS
	var a := int(f)
	var b := mini(a + 1, hips.size() - 1)
	return hips[a].lerp(hips[b], f - a)
