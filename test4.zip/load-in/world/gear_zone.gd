class_name GearZone
extends Area3D
## A place where gear counts as "there" simply by physically being there:
## a studio floor, a stage. No lists to add things to.
##
## Setup: collision shapes covering the space, mask = props layer.

signal changed

var _inside: Array[Equipment] = []


func _ready() -> void:
	body_entered.connect(_on_body_entered)
	body_exited.connect(_on_body_exited)


## Gear resting in the zone (things still in someone's hands don't count).
func get_gear() -> Array[Equipment]:
	var gear: Array[Equipment] = []
	for item in _inside:
		if is_instance_valid(item) and not item.is_held():
			gear.append(item)
	return gear


func has(item: Equipment) -> bool:
	return item in _inside and not item.is_held()


## The best piece of each kind that is in the zone: {kind: Equipment}.
func best_by_kind() -> Dictionary:
	var best := {}
	for item in get_gear():
		if not best.has(item.kind) or item.quality > (best[item.kind] as Equipment).quality:
			best[item.kind] = item
	return best


func _on_body_entered(body: Node3D) -> void:
	var item := body as Equipment
	if item == null or item in _inside:
		return
	_inside.append(item)
	item.grabbed.connect(_on_grip_changed)
	item.released.connect(_on_grip_changed)
	changed.emit()


func _on_body_exited(body: Node3D) -> void:
	var item := body as Equipment
	if item == null or item not in _inside:
		return
	_inside.erase(item)
	item.grabbed.disconnect(_on_grip_changed)
	item.released.disconnect(_on_grip_changed)
	changed.emit()


func _on_grip_changed(_by: Node3D) -> void:
	changed.emit()
