extends DirectionalLight3D
## The level is lit for the Forward+ / Mobile renderers. The Compatibility
## (OpenGL) renderer adds a shadow-casting light on top of the ambient light in
## sRGB space, which comes out far too bright, so the sun is toned down there.

@export var compatibility_energy_scale := 0.4


func _ready() -> void:
	if RenderingServer.get_current_rendering_method() == "gl_compatibility":
		light_energy *= compatibility_energy_scale
