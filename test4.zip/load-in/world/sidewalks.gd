class_name Sidewalks
extends Node3D
## The pavement network pedestrians find their way around on: points joined by
## links, searched with A*. Points can be plain pavement, the middle of a
## zebra crossing (look before stepping out), a shop door (go in for a while)
## or a spot to hang about.

enum Kind { PAVEMENT, ROAD, DOOR, SPOT }

@export var points := PackedVector3Array()
## One Kind per point.
@export var kinds := PackedByteArray()
## Pairs of point indices.
@export var links := PackedInt32Array()

var _astar := AStar3D.new()
var _goals: Array[int] = []


func _ready() -> void:
	add_to_group(&"sidewalks")
	for i in points.size():
		# Crossing the road costs a bit more, so people don't zig-zag across it.
		_astar.add_point(i, points[i], 3.0 if kinds[i] == Kind.ROAD else 1.0)
		if kinds[i] == Kind.DOOR or kinds[i] == Kind.SPOT:
			_goals.append(i)
	for i in range(0, links.size(), 2):
		_astar.connect_points(links[i], links[i + 1])


func nearest(to: Vector3) -> int:
	return _astar.get_closest_point(to)


func kind_of(id: int) -> Kind:
	return kinds[id] as Kind


func position_of(id: int) -> Vector3:
	return points[id]


## Point ids from wherever `from` is to the point `to_id`.
func route(from: Vector3, to_id: int) -> PackedInt64Array:
	return _astar.get_id_path(nearest(from), to_id)


## Somewhere worth going: a door or a hang-out spot a sensible walk away.
func random_goal(random: RandomNumberGenerator, from: Vector3) -> int:
	var best := -1
	for attempt in 6:
		var id: int = _goals[random.randi() % _goals.size()] if not _goals.is_empty() else random.randi() % points.size()
		var distance := points[id].distance_to(from)
		if distance > 12.0 and distance < 90.0:
			return id
		best = id
	return best


## Distance from `at` to the nearest stretch of the network (for tests).
func distance_to_network(at: Vector3) -> float:
	var best := INF
	for i in range(0, links.size(), 2):
		var a := points[links[i]]
		var b := points[links[i + 1]]
		var closest := Geometry3D.get_closest_point_to_segment(Vector3(at.x, 0, at.z), Vector3(a.x, 0, a.z), Vector3(b.x, 0, b.z))
		best = minf(best, closest.distance_to(Vector3(at.x, 0, at.z)))
	return best
