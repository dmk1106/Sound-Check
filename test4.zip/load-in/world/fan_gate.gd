class_name FanGate
extends StaticBody3D
## A roadblock across the way into a part of town that opens once the player
## has enough fans. You can see past it, so you know there is more city.

## One of Career.AREAS.
@export var area_id: StringName

var is_open := false

@onready var _sign: Label3D = get_node_or_null(^"Sign")


func _ready() -> void:
	Career.changed.connect(_refresh)
	for area in Career.AREAS:
		if area.id == area_id and _sign:
			_sign.text = "%s\nopens at %d fans" % [String(area.name).to_upper(), area.fans]
	_refresh()


func _refresh() -> void:
	var open := Career.is_area_open(area_id)
	if open == is_open:
		return
	is_open = open
	visible = not open
	for child in get_children():
		if child is CollisionShape3D:
			(child as CollisionShape3D).set_deferred(&"disabled", open)
