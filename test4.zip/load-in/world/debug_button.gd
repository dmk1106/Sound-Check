extends Interactable
## DEVELOPMENT ONLY. A big button behind the old house that maxes out money
## and fans, so every gig, gate and catalogue item can be tested straight away.
## Not part of normal play. Keep it until the game no longer needs testing.

const MONEY := 999999
const FANS := 99999


func _ready() -> void:
	super()
	prompt = "DEBUG: max money and fans"
	interacted.connect(func(_player: Player) -> void:
		Career.money = MONEY
		Career.add_fans(maxi(FANS - Career.fans, 0))
		Career.say("DEBUG: money and fans maxed"))
