class_name RoadNetwork
extends Node3D
## The city's streets as data: every road is a polyline of centre points with
## a width, a kind and a name. The city builder (tools/city_builder.gd) lays
## the paint, pavements and traffic from the same data and bakes it in here,
## so the minimap and the route finder always match the streets you drive on.
##
## Routing is A* over the centre-line points; roads behind a closed fan gate
## are left out until the gate opens.

enum Kind { AVENUE, STREET, LANE, ALLEY, PATH }

## Centre-line points of every road, one road after another.
@export var points := PackedVector3Array()
## Where each road starts in `points` (one entry per road, plus the end).
@export var road_start := PackedInt32Array()
@export var road_width := PackedFloat32Array()
## One Kind per road.
@export var road_kind := PackedByteArray()
@export var road_name := PackedStringArray()
## Career.AREAS id that has to be open to drive this road ("" = always open).
@export var road_area := PackedStringArray()
## Index pairs of points that are the same junction (roads meeting).
@export var joins := PackedInt32Array()
## The area ui/minimap/city_map.png covers (x, z in metres).
@export var map_rect := Rect2()
## Centre line of the elevated railway, for the map.
@export var railway := PackedVector3Array()

var _astar := AStar3D.new()
var _road_of := PackedInt32Array()
var _open_areas := {}


func _enter_tree() -> void:
	add_to_group(&"road_network")


func _ready() -> void:
	_build()
	Career.changed.connect(_refresh_gates)
	_refresh_gates()


func road_count() -> int:
	return road_width.size()


## The centre line of road `road` (world space).
func road_points(road: int) -> PackedVector3Array:
	return points.slice(road_start[road], road_start[road + 1])


func is_drivable(road: int) -> bool:
	return road_kind[road] != Kind.PATH


func is_road_open(road: int) -> bool:
	return road_area[road] == "" or _open_areas.get(road_area[road], false)


## Road under / nearest to `at`, or -1 if nothing is within `within` metres of
## a road's edge.
func road_at(at: Vector3, within := 0.0) -> int:
	var best := -1
	var best_gap := INF
	for road in road_count():
		var gap := distance_to_road(road, at) - road_width[road] * 0.5
		if gap < best_gap:
			best_gap = gap
			best = road
	return best if best_gap <= within else -1


## The name of the street at `at` ("" if you're not on or right next to one).
func street_name_at(at: Vector3) -> String:
	var road := road_at(at, 3.0)
	return road_name[road] if road >= 0 else ""


## Distance from `at` to the nearest road's centre line.
func distance_to_roads(at: Vector3, drivable_only := true) -> float:
	var best := INF
	for road in road_count():
		if drivable_only and not is_drivable(road):
			continue
		best = minf(best, distance_to_road(road, at))
	return best


## A drivable route along the roads from `from` to `to`: the points to drive
## through, starting where `from` meets the nearest road and ending where the
## road passes closest to `to`. Empty if there is no way (a gate is shut).
func route(from: Vector3, to: Vector3) -> PackedVector3Array:
	var start := _closest_on_roads(from)
	var finish := _closest_on_roads(to)
	if start.is_empty() or finish.is_empty():
		return PackedVector3Array()
	if start.road == finish.road and absi(int(start.segment) - int(finish.segment)) <= 1:
		return PackedVector3Array([start.point, finish.point])
	var best := PackedVector3Array()
	var best_length := INF
	for a in [int(start.segment) - 1, int(start.segment)]:
		for b in [int(finish.segment) - 1, int(finish.segment)]:
			if _astar.is_point_disabled(a) or _astar.is_point_disabled(b):
				continue
			var middle := _astar.get_point_path(a, b)
			if middle.is_empty():
				continue
			var path := PackedVector3Array([start.point])
			path.append_array(middle)
			path.append(finish.point)
			path = _tidy(path)
			var length := length_of(path)
			if length < best_length:
				best_length = length
				best = path
	return best


## Total length of a route.
static func length_of(path: PackedVector3Array) -> float:
	var total := 0.0
	for i in range(1, path.size()):
		total += path[i - 1].distance_to(path[i])
	return total


func _build() -> void:
	_road_of.resize(points.size())
	for road in road_count():
		for i in range(road_start[road], road_start[road + 1]):
			_road_of[i] = road
			_astar.add_point(i, points[i])
			if i > road_start[road]:
				_astar.connect_points(i - 1, i)
	for i in range(0, joins.size(), 2):
		_astar.connect_points(joins[i], joins[i + 1])
	for road in road_count():
		if not is_drivable(road):
			for i in range(road_start[road], road_start[road + 1]):
				_astar.set_point_disabled(i, true)


func _refresh_gates() -> void:
	for area in Career.AREAS:
		_open_areas[area.id] = Career.is_area_open(area.id)
	for road in road_count():
		if not is_drivable(road) or road_area[road] == "":
			continue
		var shut := not is_road_open(road)
		for i in range(road_start[road], road_start[road + 1]):
			_astar.set_point_disabled(i, shut)


## Distance from `at` to the centre line of road `road`.
func distance_to_road(road: int, at: Vector3) -> float:
	var flat := Vector3(at.x, 0.0, at.z)
	var best := INF
	for i in range(road_start[road] + 1, road_start[road + 1]):
		var closest := Geometry3D.get_closest_point_to_segment(flat, points[i - 1], points[i])
		best = minf(best, closest.distance_to(flat))
	return best


# Nearest spot on any open, drivable road: {road, segment (index of the
# segment's second point), point}.
func _closest_on_roads(at: Vector3) -> Dictionary:
	var flat := Vector3(at.x, 0.0, at.z)
	var best := {}
	var best_distance := INF
	for road in road_count():
		if not is_drivable(road) or not is_road_open(road):
			continue
		for i in range(road_start[road] + 1, road_start[road + 1]):
			var closest := Geometry3D.get_closest_point_to_segment(flat, points[i - 1], points[i])
			var distance := closest.distance_to(flat)
			if distance < best_distance:
				best_distance = distance
				best = {"road": road, "segment": i, "point": closest}
	return best


# Drop points that double back on themselves where the route joins the road.
func _tidy(path: PackedVector3Array) -> PackedVector3Array:
	var out := PackedVector3Array()
	for p in path:
		if out.size() >= 1 and out[out.size() - 1].distance_to(p) < 0.5:
			continue
		if out.size() >= 2:
			var a := out[out.size() - 2]
			var b := out[out.size() - 1]
			if (b - a).dot(p - b) < -0.5 * (b - a).length() * (p - b).length():
				out.remove_at(out.size() - 1)
		out.append(p)
	return out
