class_name Train
extends Node3D
## A short commuter train that rattles along the elevated railway every so
## often: lit windows, a coloured stripe, headlights, a low rumble. Purely for
## show (no collision; nobody can get up on the tracks).

## The track's centre line, at rail height (world space).
@export var track := PackedVector3Array()
@export var speed := 13.0
@export var cars := 3
@export var car_length := 12.0
## Seconds between runs.
@export var pause := 22.0
@export var stripe := Color("3ddbd9")

const RUMBLE := preload("res://audio/ambience/tyres.ogg")

var _length := 0.0
var _along := 0.0
var _direction := 1.0
var _wait := 6.0
var _cars: Array[Node3D] = []
var _sound: AudioStreamPlayer3D


func _ready() -> void:
	for i in range(1, track.size()):
		_length += track[i - 1].distance_to(track[i])
	for i in cars:
		_cars.append(_make_car(i == 0, i == cars - 1))
	_sound = AudioStreamPlayer3D.new()
	_sound.stream = RUMBLE.duplicate()
	(_sound.stream as AudioStreamOggVorbis).loop = true
	_sound.pitch_scale = 0.45
	_sound.volume_db = 2.0
	_sound.unit_size = 14.0
	_sound.max_distance = 90.0
	_sound.bus = &"Vehicle"
	_cars[cars / 2].add_child(_sound)
	_along = -car_length * cars
	_place()


func _physics_process(delta: float) -> void:
	if _length <= 0.0:
		return
	if _wait > 0.0:
		_wait -= delta
		visible = false
		if _sound.playing:
			_sound.stop()
		return
	visible = true
	if not _sound.playing:
		_sound.play()
	_along += speed * delta * _direction
	var span := _length + car_length * cars
	if (_direction > 0.0 and _along > span) or (_direction < 0.0 and _along < -car_length * cars):
		_direction = -_direction
		_wait = pause
	_place()


func _place() -> void:
	for i in _cars.size():
		var head := _along - i * (car_length + 0.6) * _direction
		var front := _point_at(head)
		var back := _point_at(head - car_length * _direction)
		var car := _cars[i]
		var mid := (front + back) * 0.5
		var dir := front - back
		if dir.length() < 0.01:
			continue
		car.global_transform = Transform3D(Basis.looking_at(dir.normalized(), Vector3.UP), mid)


func _point_at(along: float) -> Vector3:
	if along <= 0.0:
		var d := (track[1] - track[0]).normalized()
		return track[0] + d * along
	for i in range(1, track.size()):
		var seg := track[i - 1].distance_to(track[i])
		if along <= seg:
			return track[i - 1].lerp(track[i], along / seg)
		along -= seg
	var e := track.size() - 1
	return track[e] + (track[e] - track[e - 1]).normalized() * along


func _make_car(is_front: bool, is_back: bool) -> Node3D:
	var car := Node3D.new()
	add_child(car)
	var body := _toy(Color("c9ccd8"), 0.05, 0.35, 0.2)
	var glass := _toy(Color("fff1cf"), 1.8, 0.2, 0.1)
	var band := _toy(stripe, 1.0, 0.4, 0.2)
	var dark := _toy(Color("2a2a33"), 0.0, 0.6, 0.2)
	_box(car, Vector3(2.8, 2.9, car_length), body, Vector3(0, 1.75, 0))
	_box(car, Vector3(2.86, 0.9, car_length - 1.0), glass, Vector3(0, 2.15, 0))
	_box(car, Vector3(2.88, 0.22, car_length - 0.2), band, Vector3(0, 1.35, 0))
	_box(car, Vector3(2.4, 0.5, car_length - 1.5), dark, Vector3(0, 0.3, 0))
	for end in [-1.0, 1.0]:
		if (end < 0.0 and is_front) or (end > 0.0 and is_back):
			for x in [-0.8, 0.8]:
				_box(car, Vector3(0.3, 0.2, 0.06), _toy(Color("fff6d8"), 4.0, 0.2, 0.1), Vector3(x, 1.0, end * car_length * 0.5 + end * 0.04))
	return car


func _box(parent: Node3D, size: Vector3, material: Material, at: Vector3) -> void:
	var mi := MeshInstance3D.new()
	var mesh := BoxMesh.new()
	mesh.size = size
	mesh.material = material
	mi.mesh = mesh
	mi.position = at
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(mi)


static func _toy(colour: Color, light: float, roughness: float, softness: float) -> ShaderMaterial:
	var m := ShaderMaterial.new()
	m.shader = preload("res://art/toy.gdshader")
	m.set_shader_parameter(&"albedo", colour)
	m.set_shader_parameter(&"light", light)
	m.set_shader_parameter(&"roughness", roughness)
	m.set_shader_parameter(&"softness", softness)
	return m
