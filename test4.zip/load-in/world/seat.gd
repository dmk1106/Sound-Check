extends Interactable
## Somewhere to sit and think. Sitting down here is where songs get written:
## E opens the song sketchpad, Space gets back up.

## Height of the seat above this node.
@export var seat_height := 0.42

var sitter: Player = null

var _maker: SongMaker = null


func _ready() -> void:
	super()
	if prompt == "use":
		prompt = "sit by the creek"
	interacted.connect(_sit)


func _sit(player: Player) -> void:
	sitter = player
	enabled = false
	player.sit_at(global_position + Vector3.UP * seat_height, global_rotation.y)
	Career.say("A good place to write a song")


func stand_up() -> void:
	if sitter == null:
		return
	sitter.stand_up()
	sitter = null
	enabled = true


func open_song_maker() -> SongMaker:
	_maker = SongMaker.open(self)
	_maker.closed.connect(func() -> void: _maker = null)
	return _maker


func _unhandled_input(event: InputEvent) -> void:
	if sitter == null or _maker != null or GameMenu.is_any_open():
		return
	if event.is_action_pressed(&"interact"):
		get_viewport().set_input_as_handled()
		open_song_maker()
	elif event.is_action_pressed(&"jump"):
		get_viewport().set_input_as_handled()
		stand_up()
