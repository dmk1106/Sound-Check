extends Node3D
## A street lamp the truck can knock over. Clip it slowly and it bends; hit it
## at speed and it topples into the road, light flickering out. It never
## blocks anything once hit (its collision switches off at the moment of
## impact, so the truck drives straight through), and it stands itself back
## up a while later when nobody is close.
##
## The city builder puts the lamp's parts under `Pivot` (at the foot of the
## post) and its collision in the `Body` StaticBody3D.

## Truck speed (m/s) needed to bend the post, and to knock it right over.
@export var bend_speed := 3.0
@export var topple_speed := 7.5
## Seconds before it is put back up (only when the truck and player are away).
@export var reset_after := 30.0

const BONK := preload("res://audio/sfx/bonk.ogg")
## The truck's footprint in its own space (x across, z along; forward is -z).
const TRUCK_X := 1.3
const TRUCK_Z := Vector2(-2.6, 3.2)

var knocked := false
var _truck: RigidBody3D
var _timer := 0.0
var _flicker := 0.0
var _energy := 1.0
## The truck's speed lately (a hit slows it before we notice, so remember).
var _recent_speed := 0.0
@onready var _pivot: Node3D = $Pivot
@onready var _body: StaticBody3D = $Body
@onready var _light: OmniLight3D = get_node_or_null(^"Pivot/Light")


func _ready() -> void:
	if _light:
		_energy = _light.light_energy
	_timer = randf() * 0.2


func _physics_process(delta: float) -> void:
	if knocked:
		_update_knocked(delta)
		return
	# Cheap check a few times a second while the truck is far off.
	_timer -= delta
	if _timer > 0.0:
		return
	if _truck == null or not is_instance_valid(_truck):
		_truck = get_tree().get_first_node_in_group(&"truck") as RigidBody3D
		if _truck == null:
			_timer = 1.0
			return
	var to_truck := _truck.global_position - global_position
	var distance := Vector2(to_truck.x, to_truck.z).length()
	if distance > 14.0:
		_timer = clampf((distance - 14.0) / 20.0, 0.1, 0.5)
		return
	var velocity := _truck.linear_velocity
	var speed := Vector2(velocity.x, velocity.z).length()
	_recent_speed = maxf(speed, _recent_speed - 8.0 * delta)
	speed = _recent_speed
	if speed < bend_speed:
		_timer = 0.0
		return
	# Is the post in the truck's path, about to be hit (within the next quarter second)?
	var local := _truck.global_transform.affine_inverse() * global_position
	var ahead := speed * 0.25 + 0.4
	if absf(local.x) < TRUCK_X + 0.2 and local.z > TRUCK_Z.x - ahead and local.z < TRUCK_Z.y + ahead:
		_knock(velocity, speed)


func _knock(velocity: Vector3, speed: float) -> void:
	knocked = true
	_timer = reset_after
	_body.process_mode = Node.PROCESS_MODE_DISABLED
	for shape in _body.get_children():
		if shape is CollisionShape3D:
			shape.disabled = true
	var direction := Vector3(velocity.x, 0.0, velocity.z).normalized()
	var axis := Vector3.UP.cross(direction).normalized()
	var topple := speed >= topple_speed
	# Bent posts lean away from the bumper; toppled ones fall flat (a little short of it, on the kerb).
	var angle := deg_to_rad(84.0 if topple else lerpf(18.0, 40.0, inverse_lerp(bend_speed, topple_speed, speed)))
	var to_local := global_basis.inverse()
	var turn := Basis(to_local * axis, angle)
	var tween := create_tween()
	tween.tween_property(_pivot, ^"basis", turn, 0.55 if topple else 0.25).set_trans(Tween.TRANS_BOUNCE).set_ease(Tween.EASE_OUT)
	Sfx.play_at(self, BONK, global_position + Vector3.UP, 2.0, randf_range(0.55, 0.7), 30.0)
	_flicker = 1.6 if topple else 0.9
	# A comedic bump for the truck.
	if _truck:
		_truck.linear_velocity *= 0.88 if topple else 0.95


func _update_knocked(delta: float) -> void:
	if _light:
		if _flicker > 0.0:
			_flicker -= delta
			_light.light_energy = _energy * (0.15 if randf() < 0.5 else 1.0)
			if _flicker <= 0.0:
				# Toppled: out for good. Bent: back on, a bit dimmer.
				_light.light_energy = 0.0 if _pivot.basis.get_euler().length() > 1.0 else _energy * 0.7
	_timer -= delta
	if _timer > 0.0:
		return
	# Back up when nobody's looking (well, when nobody's near).
	for group in [&"truck", &"player"]:
		var n := get_tree().get_first_node_in_group(group) as Node3D
		if n and n.global_position.distance_to(global_position) < 25.0:
			_timer = 3.0
			return
	knocked = false
	_pivot.basis = Basis()
	if _light:
		_light.light_energy = _energy
	_body.process_mode = Node.PROCESS_MODE_INHERIT
	for shape in _body.get_children():
		if shape is CollisionShape3D:
			shape.disabled = false
