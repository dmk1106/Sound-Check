extends GPUParticles3D
## Rain that only falls where the camera is: the emitter box follows the view.

func _process(_delta: float) -> void:
	# No rain indoors (the drops would fall straight through the ceiling).
	visible = InteriorCutaway.indoors <= 0
	var camera := get_viewport().get_camera_3d()
	if camera:
		var ahead := -camera.global_basis.z
		ahead.y = 0.0
		global_position = camera.global_position + ahead.normalized() * 9.0 + Vector3.UP * 9.0
