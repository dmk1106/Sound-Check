extends Label3D
## A neon sign with a dodgy tube: mostly on, now and then it stutters.

var _lit := Color.WHITE
var _timer := 0.0
var _stutter := 0


func _ready() -> void:
	_lit = modulate
	_timer = randf_range(1.0, 8.0)


func _process(delta: float) -> void:
	_timer -= delta
	if _timer > 0.0:
		return
	if _stutter == 0:
		_stutter = randi_range(3, 9)
	_stutter -= 1
	var on := _stutter % 2 == 0
	modulate = _lit if on else Color(_lit.r * 0.18, _lit.g * 0.18, _lit.b * 0.18)
	_timer = randf_range(0.03, 0.14) if _stutter > 0 else randf_range(2.5, 11.0)
