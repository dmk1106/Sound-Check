class_name RouteLine
extends MeshInstance3D
## A white line on the ground from you to where the current objective wants
## you (GameFlow.route_target), along the same road route the minimap draws
## (RoadNetwork.route), so the two always agree. It never cuts across
## buildings: the bits joining you to the road and the road to the goal are
## only drawn when nothing solid is in the way.

const SHADER := preload("res://world/route_line.gdshader")

## Half width of the line on foot and while driving (metres).
@export var walk_half_width := 0.2
@export var drive_half_width := 0.42
## Hidden when you are this close to the goal (metres, on foot / driving).
@export var walk_hide_distance := 5.0
@export var drive_hide_distance := 9.0
## How much of the route to draw (metres).
@export var max_length := 260.0
## Height above the road paint.
@export var lift := 0.06

var _net: RoadNetwork
var _flow: GameFlow
var _player: Player
var _truck: Truck
var _material: ShaderMaterial
var _timer := 0.0
var _route := PackedVector3Array()
var _route_from := Vector3(INF, 0, INF)
var _route_to := Vector3(INF, 0, INF)
## The points the line was last drawn through (for tests).
var drawn := PackedVector3Array()


func _ready() -> void:
	cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	top_level = true
	_material = ShaderMaterial.new()
	_material.shader = SHADER
	await get_tree().process_frame
	_net = get_tree().get_first_node_in_group(&"road_network")
	_flow = get_tree().get_first_node_in_group(&"game_flow")
	_player = get_tree().get_first_node_in_group(&"player")
	_truck = get_tree().get_first_node_in_group(&"truck")
	if _flow:
		_flow.route_target_changed.connect(func(_t: Node3D) -> void: _timer = 0.0)


func _process(delta: float) -> void:
	_timer -= delta
	if _timer > 0.0:
		return
	_timer = 0.3
	_refresh()


func _refresh() -> void:
	if _net == null or _flow == null or _player == null:
		visible = false
		return
	var target := _flow.route_target
	var driving := _truck != null and _truck.driver != null
	var who: Node3D = _truck if driving else _player
	if target == null or not is_instance_valid(target) or (_player.seated and not driving):
		_clear()
		return
	var goal := target.global_position
	var here := who.global_position
	var flat := Vector2(goal.x - here.x, goal.z - here.z).length()
	if flat < (drive_hide_distance if driving else walk_hide_distance):
		_clear()
		return
	# Re-route when the goal moves or you wander off the line.
	var moved := Vector2(here.x - _route_from.x, here.z - _route_from.z).length()
	if goal.distance_to(_route_to) > 0.5 or moved > 5.0 or _route.is_empty():
		_route_from = here
		_route_to = goal
		_route = _net.route(here, goal)
	if _route.is_empty():
		_clear()
		return
	var line := PackedVector3Array()
	var start := Vector3(here.x, 0, here.z)
	if _clear_between(start, _route[0]):
		line.append(start)
	else:
		# Skip ahead to the first road point we can see from here, if any.
		pass
	line.append_array(_trim_behind(_route, start))
	var end := Vector3(goal.x, 0, goal.z)
	if _clear_between(line[line.size() - 1], end):
		line.append(end)
	_build(line, drive_half_width if driving else walk_half_width)


func _clear() -> void:
	visible = false
	drawn = PackedVector3Array()
	_route = PackedVector3Array()


# Drop route points already passed: everything before the point closest to `at`.
func _trim_behind(route: PackedVector3Array, at: Vector3) -> PackedVector3Array:
	var best := 0
	var best_d := INF
	for i in mini(route.size(), 40):
		var d := Vector2(route[i].x - at.x, route[i].z - at.z).length()
		if d < best_d:
			best_d = d
			best = i
	return route.slice(best)


## Nothing solid (buildings, walls, fences) between two ground points?
func _clear_between(a: Vector3, b: Vector3) -> bool:
	if a.distance_to(b) < 0.5:
		return true
	var space := get_world_3d().direct_space_state
	var query := PhysicsRayQueryParameters3D.create(a + Vector3.UP * 0.7, b + Vector3.UP * 0.7, 1)
	var exclude: Array[RID] = []
	if _truck:
		exclude.append(_truck.get_rid())
	query.exclude = exclude
	return space.intersect_ray(query).is_empty()


func _build(line: PackedVector3Array, half: float) -> void:
	# Resample evenly so the strip bends smoothly round corners.
	var pts := PackedVector3Array()
	var total := 0.0
	pts.append(line[0])
	for i in range(1, line.size()):
		var a := line[i - 1]
		var b := line[i]
		var length := a.distance_to(b)
		var steps := maxi(1, int(ceil(length / 1.0)))
		for k in range(1, steps + 1):
			var p := a.lerp(b, float(k) / steps)
			total += a.distance_to(b) / steps
			pts.append(p)
			if total >= max_length:
				break
		if total >= max_length:
			break
	if pts.size() < 2:
		_clear()
		return
	var verts := PackedVector3Array()
	var uvs := PackedVector2Array()
	var indices := PackedInt32Array()
	var along := 0.0
	for i in pts.size():
		if i > 0:
			along += pts[i - 1].distance_to(pts[i])
		var prev := pts[maxi(i - 1, 0)]
		var next := pts[mini(i + 1, pts.size() - 1)]
		var dir := Vector3(next.x - prev.x, 0, next.z - prev.z).normalized()
		var side := Vector3(-dir.z, 0, dir.x) * half
		var p := Vector3(pts[i].x, lift, pts[i].z)
		verts.append(p + side)
		verts.append(p - side)
		uvs.append(Vector2(along, 1.0))
		uvs.append(Vector2(along, -1.0))
		if i > 0:
			var k := i * 2
			indices.append_array([k - 2, k - 1, k, k - 1, k + 1, k])
	var arrays := []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = verts
	arrays[Mesh.ARRAY_TEX_UV] = uvs
	arrays[Mesh.ARRAY_INDEX] = indices
	var m := ArrayMesh.new()
	m.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	m.surface_set_material(0, _material)
	_material.set_shader_parameter(&"total_length", along)
	mesh = m
	global_transform = Transform3D.IDENTITY
	drawn = pts
	visible = true
