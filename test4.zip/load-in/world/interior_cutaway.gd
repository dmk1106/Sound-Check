class_name InteriorCutaway
extends Area3D
## Marks an indoor space (room, truck cargo bay, venue...).
##
## While the player is inside - or the camera is inside / hovering just above -
## the nodes in `hide_while_inside` (outer walls, roof) are hidden, turning the
## building into a dollhouse you can see into. From outside it looks solid.
##
## Setup: give it BoxShape3D children covering the interior. The area is only
## used as a volume marker (no physics), so its layers don't matter.

## Nodes to hide (paths relative to this node).
@export var hide_while_inside: Array[NodePath] = []
## The player counts as inside this far beyond the box on each axis.
@export var player_margin := Vector3(0.3, 0.5, 0.3)
## Same for the camera. The Y value is what keeps a roof from filling the
## screen when the camera floats over it.
@export var camera_margin := Vector3(0.3, 3.0, 0.3)

## How many indoor spaces the player or camera is in right now (rain stops for them).
static var indoors := 0

var _hidden := false
var _boxes: Array[CollisionShape3D] = []
var _targets: Array[Node3D] = []


func _ready() -> void:
	for child in get_children():
		if child is CollisionShape3D and child.shape is BoxShape3D:
			_boxes.append(child)
	for path in hide_while_inside:
		var node := get_node_or_null(path) as Node3D
		if node:
			_targets.append(node)


func _process(_delta: float) -> void:
	var inside := false
	var camera := get_viewport().get_camera_3d()
	if camera:
		inside = _contains(camera.global_position, camera_margin)
	if not inside:
		var player := get_tree().get_first_node_in_group(&"player") as Node3D
		if player:
			inside = _contains(player.global_position, player_margin)
	if inside == _hidden:
		return
	_hidden = inside
	indoors += 1 if inside else -1
	for node in _targets:
		node.visible = not inside


func _exit_tree() -> void:
	if _hidden:
		indoors -= 1


func _contains(point: Vector3, margin: Vector3) -> bool:
	for box in _boxes:
		var local := box.global_transform.affine_inverse() * point
		var half: Vector3 = (box.shape as BoxShape3D).size * 0.5 + margin
		if absf(local.x) <= half.x and absf(local.y) <= half.y and absf(local.z) <= half.z:
			return true
	return false
