class_name Lift
extends AnimatableBody3D
## A goods lift: a platform that carries whoever and whatever is standing on
## it between the ground and one upper floor. Nothing is teleported: gear put
## on the platform simply rides up with it.
##
## Buttons: the panel on the platform sends it to the other floor; a call
## button on each floor brings it there.

signal arrived(at_top: bool)

## How far up the top floor is, in metres.
@export var travel := 12.0
@export var speed := 1.7
## Interactables that call the lift down / up to their floor.
@export var call_bottom: NodePath
@export var call_top: NodePath

var at_top := false
var moving := false

var _base_y := 0.0
var _goal := 0.0

@onready var _panel: Interactable = $Panel
@onready var _hum: AudioStreamPlayer3D = get_node_or_null(^"Hum")
@onready var _call_bottom: Interactable = get_node_or_null(call_bottom)
@onready var _call_top: Interactable = get_node_or_null(call_top)


func _ready() -> void:
	_base_y = position.y
	_goal = _base_y
	_panel.interacted.connect(func(_player: Player) -> void: go(not at_top))
	if _call_bottom:
		_call_bottom.interacted.connect(func(_player: Player) -> void: go(false))
	if _call_top:
		_call_top.interacted.connect(func(_player: Player) -> void: go(true))
	if _hum and _hum.stream is AudioStreamOggVorbis:
		(_hum.stream as AudioStreamOggVorbis).loop = true
	_refresh()


## Send the lift to the top (true) or the bottom (false).
func go(to_top: bool) -> void:
	if moving or to_top == at_top:
		return
	moving = true
	_goal = _base_y + (travel if to_top else 0.0)
	if _hum:
		_hum.play()
	_refresh()


func _physics_process(delta: float) -> void:
	if not moving:
		return
	# Ease in to the stop so the cargo isn't jolted.
	var left := absf(_goal - position.y)
	position.y = move_toward(position.y, _goal, speed * clampf(left * 1.6 + 0.12, 0.12, 1.0) * delta)
	if is_equal_approx(position.y, _goal):
		moving = false
		at_top = _goal > _base_y + travel * 0.5
		if _hum:
			_hum.stop()
		_refresh()
		arrived.emit(at_top)


func _refresh() -> void:
	_panel.enabled = not moving
	_panel.prompt = "send the lift down" if at_top else "ride the lift up"
	if _call_bottom:
		_call_bottom.enabled = not moving and at_top
		_call_bottom.prompt = "call the lift"
	if _call_top:
		_call_top.enabled = not moving and not at_top
		_call_top.prompt = "call the lift"
