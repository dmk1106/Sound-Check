class_name Interactable
extends Node3D
## A spot the player can walk up to and use with the interact key:
## a door handle, a driver's seat, a job board, a price tag.
##
## Put it where the player should stand near. Connect to `interacted`, or let
## the owner read `prompt` and decide what happens.

signal interacted(player: Player)

## Shown on the HUD after the key, e.g. "open the back".
@export var prompt := "use"
## How close (metres, along the ground) the player has to be.
@export var radius := 1.6
@export var enabled := true


func _ready() -> void:
	add_to_group(&"interactable")


func interact(player: Player) -> void:
	interacted.emit(player)
