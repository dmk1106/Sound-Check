class_name LoopSound
extends AudioStreamPlayer3D
## A sound that sits somewhere in the world and loops: an air-con unit, a
## creek, music leaking out of a club, a crowd.

## Start somewhere random in the loop, so two of the same don't phase.
@export var random_start := true


func _ready() -> void:
	if stream is AudioStreamOggVorbis:
		(stream as AudioStreamOggVorbis).loop = true
	if autoplay or playing:
		play(randf() * stream.get_length() if random_start and stream else 0.0)
