extends Node3D
## Puts cars on the roads. Each route is a loop of corner points; the cars are
## spread evenly round it and then look after themselves (TrafficCar).

@export var car_scenes: Array[PackedScene] = []
## One loop per entry.
@export var routes: Array[PackedVector3Array] = []
## Per route, one flag per point: 1 = a junction to stop at. Empty = stop at every point.
@export var route_stops: Array[PackedByteArray] = []
@export var cars_per_route := 3
## Per route; overrides cars_per_route where given.
@export var route_cars := PackedInt32Array()
@export var colors: Array[Color] = [Color("e63946"), Color("ffd166"), Color("3ddbd9"), Color("f4f1de"), Color("7f8cff"), Color("ff8a5b"), Color("2b2d42")]


func _ready() -> void:
	var index := 0
	for r in routes.size():
		var route := routes[r]
		var length := 0.0
		for i in route.size():
			length += route[i].distance_to(route[(i + 1) % route.size()])
		var count := route_cars[r] if r < route_cars.size() else cars_per_route
		for i in count:
			var car: TrafficCar = car_scenes[index % car_scenes.size()].instantiate()
			car.route = route
			if r < route_stops.size():
				car.stops = route_stops[r]
			car.body_color = colors[index % colors.size()]
			car.cruise_speed = 7.0 + (index % 3) * 1.0
			add_child(car)
			car.place_on_route(length * (i + 0.37) / count)
			car.reset_physics_interpolation()
			index += 1
