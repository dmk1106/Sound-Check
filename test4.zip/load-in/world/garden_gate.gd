extends Interactable
## The wonky garden gate at the back of the house: E swings it open or shut.
## The leaf is an AnimatableBody3D turning on the hinge at this node's -x end, so it
## really blocks the way when shut and shoves things gently as it swings.

## How far it swings open (degrees, away from the yard).
@export var open_angle := 105.0
## Degrees per second.
@export var swing_speed := 160.0
@export var is_open := false

const CREAK := preload("res://audio/sfx/squeak.ogg")

var _angle := 0.0
# The leaf itself turns (an AnimatableBody3D only follows its own transform, not a parent's).
@onready var _leaf: Node3D = $Hinge/Leaf


func _ready() -> void:
	super()
	radius = 1.8
	_angle = open_angle if is_open else 0.0
	_apply()
	_update_prompt()
	interacted.connect(func(_p: Player) -> void: toggle())


func toggle() -> void:
	is_open = not is_open
	_update_prompt()
	Sfx.play_at(self, CREAK, global_position + Vector3.UP, -10.0, randf_range(0.7, 0.85), 12.0)
	var interactor := get_tree().get_first_node_in_group(&"interactor")
	if interactor:
		interactor.call(&"refresh")


func _update_prompt() -> void:
	prompt = "close the gate" if is_open else "open the gate"


func _physics_process(delta: float) -> void:
	var target := open_angle if is_open else 0.0
	if is_equal_approx(_angle, target):
		return
	_angle = move_toward(_angle, target, swing_speed * delta)
	_apply()


func _apply() -> void:
	_leaf.rotation.y = deg_to_rad(_angle)
