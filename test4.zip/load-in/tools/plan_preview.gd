extends SceneTree
## Quick look at the plan without building the 3D city:
##   godot --headless --path . -s res://tools/plan_preview.gd -- out.png
const Layout := preload("res://tools/city/layout.gd")
const PlanImage := preload("res://tools/city/plan_image.gd")
const Plan := preload("res://tools/city/plan.gd")

func _init() -> void:
	var t := Time.get_ticks_msec()
	var layout := Layout.new()
	layout.paint_plan()
	print("painted ", Time.get_ticks_msec() - t)
	layout.place_frontage()
	print("frontage ", layout.lots.size(), " ", Time.get_ticks_msec() - t)
	layout.place_backfill()
	layout.place_backfill(3.0, 0.6)
	print("all lots ", layout.lots.size(), " ", Time.get_ticks_msec() - t)
	var greens := []
	var paved := []
	for spec in Plan.RESERVED:
		if spec.what in ["park", "creek", "home"]:
			greens.append(Layout.rect_polygon(spec))
		else:
			paved.append(Layout.rect_polygon(spec))
	var img := PlanImage.new(layout).draw(float(OS.get_cmdline_user_args()[1]) if OS.get_cmdline_user_args().size() > 1 else 0.5, [], greens, paved)
	img.save_png(OS.get_cmdline_user_args()[0])
	print("drawn ", Time.get_ticks_msec() - t)
	quit()
