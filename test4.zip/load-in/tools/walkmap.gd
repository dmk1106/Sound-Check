extends Node3D
## Prints an ASCII map of what's solid around a spot (for planning test paths):
##   godot --headless --path . res://tools/walkmap.tscn -- cx cz half [step] [x,z=label ...]
## '#' = something solid at waist height, '.' = free, letters = marked points.
## North (-z) is up.

func _ready() -> void:
	var args := OS.get_cmdline_user_args()
	var city: Node = load("res://levels/city.tscn").instantiate()
	add_child(city)
	for i in 3:
		await get_tree().physics_frame
	var cx := float(args[0])
	var cz := float(args[1])
	var half := float(args[2])
	var step := float(args[3]) if args.size() > 3 else 0.5
	var marks := {}
	for a in args.slice(4):
		if a.begins_with("probe="):
			var pp: PackedStringArray = a.trim_prefix("probe=").split(",")
			var probe := SphereShape3D.new()
			probe.radius = 0.6
			var pq := PhysicsShapeQueryParameters3D.new()
			pq.shape = probe
			pq.collision_mask = 1
			pq.transform = Transform3D(Basis(), Vector3(float(pp[0]), 0.8, float(pp[1])))
			for hit in get_world_3d().direct_space_state.intersect_shape(pq, 8):
				var body := hit.collider as CollisionObject3D
				var owner_id: int = body.shape_find_owner(hit.shape)
				print("probe %s: %s / %s" % [a, body.get_path(), body.shape_owner_get_owner(owner_id).name])
			continue
		var kv: PackedStringArray = a.split("=")
		var p: PackedStringArray = kv[0].split(",")
		marks[Vector2i(roundi((float(p[0]) - cx) / step), roundi((float(p[1]) - cz) / step))] = kv[1]
	var space := get_world_3d().direct_space_state
	var shape := SphereShape3D.new()
	shape.radius = step * 0.5
	var q := PhysicsShapeQueryParameters3D.new()
	q.shape = shape
	q.collision_mask = 1
	var n := int(half / step)
	print("x %.1f..%.1f  z %.1f..%.1f  step %.2f" % [cx - half, cx + half, cz - half, cz + half, step])
	for j in range(-n, n + 1):
		var row := ""
		for i in range(-n, n + 1):
			if marks.has(Vector2i(i, j)):
				row += marks[Vector2i(i, j)]
				continue
			var solid := false
			for y in [0.5, 1.2]:
				q.transform = Transform3D(Basis(), Vector3(cx + i * step, y, cz + j * step))
				if not space.intersect_shape(q, 1).is_empty():
					solid = true
			row += "#" if solid else "."
		print("%7.1f %s" % [cz + j * step, row])
	get_tree().quit()
