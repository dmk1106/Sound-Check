extends SceneTree
func _init() -> void:
	var ours: Node = (load("res://player/model/main_character.glb") as PackedScene).instantiate()
	var sk: Skeleton3D = ours.find_children("*", "Skeleton3D", true, false)[0]
	var names := []
	for i in sk.get_bone_count():
		names.append("%s<%s" % [sk.get_bone_name(i), sk.get_bone_name(sk.get_bone_parent(i)) if sk.get_bone_parent(i) >= 0 else "-"])
	print(names)
	for f in ["guitar_playing", "piano_playing", "drums_playing", "sitting"]:
		var n: Node = (load("res://player/anims/source/%s.fbx" % f) as PackedScene).instantiate()
		var ap: AnimationPlayer = n.find_children("*", "AnimationPlayer", true, false)[0]
		for an in ap.get_animation_list():
			var a: Animation = ap.get_animation(an)
			var types := {}
			for t in a.get_track_count():
				types[a.track_get_type(t)] = types.get(a.track_get_type(t), 0) + 1
			print(f, " ", an, " len=", a.length, " tracks=", a.get_track_count(), " types=", types, " keys0=", a.track_get_key_count(0))
		n.free()
	ours.free()
	quit()
