extends SceneTree
## Pulls the Mixamo clips out of George's FBX files (player/anims/source) into
## small Animation resources (player/anims/*.res) that carry the FBX
## skeleton's rest pose as metadata, so player/mocap_clip.gd can retarget them
## onto our character. Run once after changing the FBX files:
##   godot --headless --path . -s tools/extract_clips.gd
const CLIPS := {"guitar_playing": "guitar", "piano_playing": "piano", "drums_playing": "drums", "sitting": "sitting"}

func _init() -> void:
	for f in CLIPS:
		var n: Node = (load("res://player/anims/source/%s.fbx" % f) as PackedScene).instantiate()
		var sk: Skeleton3D = n.find_children("*", "Skeleton3D", true, false)[0]
		var ap: AnimationPlayer = n.find_children("*", "AnimationPlayer", true, false)[0]
		var anim: Animation = ap.get_animation(&"mixamo_com").duplicate(true)
		# Keep only bone tracks of bones we can use (no fingers except the middle base).
		for t in range(anim.get_track_count() - 1, -1, -1):
			var bone := str(anim.track_get_path(t).get_concatenated_subnames())
			if bone.contains("Hand") and not bone.ends_with("Hand") and not bone.ends_with("HandMiddle1"):
				anim.remove_track(t)
		var names := PackedStringArray()
		var parents := PackedStringArray()
		var rests: Array[Transform3D] = []
		for i in sk.get_bone_count():
			var bone_name := sk.get_bone_name(i)
			if bone_name.contains("Hand") and not bone_name.ends_with("Hand") and not bone_name.ends_with("HandMiddle1"):
				continue
			names.append(bone_name)
			var p := sk.get_bone_parent(i)
			parents.append(sk.get_bone_name(p) if p >= 0 else "")
			rests.append(sk.get_bone_rest(i))
		anim.set_meta(&"rest_names", names)
		anim.set_meta(&"rest_parents", parents)
		anim.set_meta(&"rest_xforms", rests)
		anim.resource_name = CLIPS[f]
		var path := "res://player/anims/%s.res" % CLIPS[f]
		print(path, " ", ResourceSaver.save(anim, path, ResourceSaver.FLAG_COMPRESS), " tracks=", anim.get_track_count(), " len=", anim.length)
		n.free()
	quit()
