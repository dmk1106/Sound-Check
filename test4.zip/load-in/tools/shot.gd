extends Node
## Renders still pictures of the game from chosen cameras (needs a display:
##   xvfb-run godot --rendering-driver opengl3 --path . res://tools/shot.tscn -- out_dir name:x,y,z:tx,ty,tz[:fov|ortho=size] ...
## A view with ortho=size looks straight down.

func _ready() -> void:
	var args := OS.get_cmdline_user_args()
	var out := args[0]
	var main: Node = load("res://scenes/main.tscn").instantiate()
	add_child(main)
	var hud := main.get_node_or_null("HUD")
	var cam := Camera3D.new()
	add_child(cam)
	cam.current = true
	cam.far = 900.0
	get_window().size = Vector2i(1280, 720)
	for i in 30:
		await get_tree().process_frame
	for view in args.slice(1):
		# gig=ID books that gig and skips to driving there;
		# player=x,y,z puts the player there.
		if view.begins_with("gig="):
			for gig in Career.GIGS:
				if String(gig.id) == view.trim_prefix("gig="):
					Career.accept(gig)
			var flow := get_tree().get_first_node_in_group(&"game_flow") as GameFlow
			flow.step = GameFlow.Step.DRIVE_TO_VENUE
			for i in 10:
				await get_tree().process_frame
			continue
		# truck=x,y,z,yaw parks the truck there with the gear loaded inside.
		if view.begins_with("truck="):
			var truck := main.find_child("Truck", true, false) as Node3D
			var tp := view.trim_prefix("truck=").split(",")
			truck.global_transform = Transform3D(Basis.from_euler(Vector3(0, float(tp[3]), 0)), Vector3(float(tp[0]), float(tp[1]), float(tp[2])))
			var z := 1.2
			for item_name in ["Guitar", "Amp"]:
				var item := main.find_child(item_name, true, false) as RigidBody3D
				if item:
					item.global_position = truck.to_global(Vector3(0, 1.0, z))
					item.linear_velocity = Vector3.ZERO
					z -= 1.4
			for i in 30:
				await get_tree().physics_frame
			continue
		# game=NAME: a picture from the game's own camera (behind the player or the truck).
		if view.begins_with("game="):
			var game_cam: Camera3D = null
			for c in main.find_children("*", "Camera3D", true, false):
				if c != cam:
					game_cam = c
			if game_cam:
				game_cam.current = true
				if hud:
					hud.visible = true
				for i in 40:
					await get_tree().process_frame
				get_viewport().get_texture().get_image().save_png(out + "/" + view.trim_prefix("game=") + ".png")
				print("shot ", view)
				cam.current = true
			continue
		# yaw=DEG turns the player (and so the camera behind them) to face that way.
		if view.begins_with("yaw="):
			var player := get_tree().get_first_node_in_group(&"player") as Node3D
			var rig := main.find_child("CameraRig", true, false)
			if rig and rig.get("yaw") != null:
				rig.set("yaw", deg_to_rad(float(view.trim_prefix("yaw="))))
			elif player:
				player.rotation.y = deg_to_rad(float(view.trim_prefix("yaw=")))
			continue
		# perform=NAME plays that stage clip; sit=x,y,z,yaw sits the player down; wait=N frames.
		if view.begins_with("perform="):
			var player := get_tree().get_first_node_in_group(&"player")
			player.set("performing", StringName(view.trim_prefix("perform=")))
			continue
		if view.begins_with("sit="):
			var player := get_tree().get_first_node_in_group(&"player") as Player
			var sp := view.trim_prefix("sit=").split(",")
			player.sit_at(Vector3(float(sp[0]), float(sp[1]), float(sp[2])), deg_to_rad(float(sp[3])))
			continue
		# seat=NAME sits the player on that Seat node, the way E would.
		if view.begins_with("seat="):
			var player := get_tree().get_first_node_in_group(&"player") as Player
			var seat := main.find_child(view.trim_prefix("seat="), true, false) as Node3D
			player.sit_at(seat.global_position + Vector3.UP * float(seat.get("seat_height")), seat.global_rotation.y)
			continue
		if view.begins_with("wait="):
			for i in int(view.trim_prefix("wait=")):
				await get_tree().physics_frame
			continue
		if view.begins_with("player="):
			var player := get_tree().get_first_node_in_group(&"player") as Node3D
			player.global_position = _v(view.trim_prefix("player="))
			for i in 10:
				await get_tree().physics_frame
			continue
		var parts: PackedStringArray = view.split(":")
		var at := _v(parts[1])
		var look := _v(parts[2])
		cam.projection = Camera3D.PROJECTION_PERSPECTIVE
		cam.fov = 60.0
		if parts.size() > 3:
			if parts[3].begins_with("ortho="):
				cam.projection = Camera3D.PROJECTION_ORTHOGONAL
				cam.size = float(parts[3].trim_prefix("ortho="))
			elif parts[3] == "hud":
				pass
			else:
				cam.fov = float(parts[3])
		if hud:
			hud.visible = parts.size() > 3 and parts[3] == "hud"
		cam.environment = null
		# Overviews without the depth-of-field blur.
		cam.attributes = CameraAttributesPractical.new() if (parts[0].contains("aerial") or parts[0].begins_with("top") or (parts.size() > 3 and parts[3].begins_with("ortho"))) else null
		if cam.projection == Camera3D.PROJECTION_ORTHOGONAL:
			var we := main.find_children("*", "WorldEnvironment", true, false)
			if not we.is_empty():
				var env: Environment = (we[0] as WorldEnvironment).environment.duplicate()
				env.fog_enabled = false
				env.volumetric_fog_enabled = false
				cam.environment = env
			cam.global_transform = Transform3D(Basis.from_euler(Vector3(-PI / 2, 0, 0)), at)
		else:
			cam.global_transform = Transform3D().looking_at(look - at, Vector3.UP).translated(at)
		for i in (50 if hud and hud.visible else 8):
			await get_tree().process_frame
		var img := get_viewport().get_texture().get_image()
		img.save_png(out + "/" + parts[0] + ".png")
		print("shot ", parts[0])
	get_tree().quit()

func _v(s: String) -> Vector3:
	var p := s.split(",")
	return Vector3(float(p[0]), float(p[1]), float(p[2]))
