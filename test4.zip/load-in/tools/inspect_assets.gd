extends SceneTree
func _init() -> void:
	for dir in ["res://art/kenney/", "res://art/nature/"]:
		for f in DirAccess.get_files_at(dir):
			if not (f.ends_with(".glb") or f.ends_with(".gltf")):
				continue
			var scene: PackedScene = load(dir + f)
			var n: Node = scene.instantiate()
			var aabb := AABB()
			var first := true
			var mats := []
			for mi in n.find_children("*", "MeshInstance3D", true, false):
				var m: MeshInstance3D = mi
				var box: AABB = m.global_transform * m.mesh.get_aabb() if m.is_inside_tree() else (m.transform * m.mesh.get_aabb())
				aabb = box if first else aabb.merge(box)
				first = false
				for s in m.mesh.get_surface_count():
					var mat := m.mesh.surface_get_material(s)
					if mat is StandardMaterial3D:
						mats.append("%s(%s,a%d,tex=%s)" % [mat.resource_name, mat.albedo_color.to_html(false), mat.transparency, mat.albedo_texture != null])
			print("%-28s size=%s pos=%s %s" % [f, aabb.size.snapped(Vector3.ONE*0.01), aabb.position.snapped(Vector3.ONE*0.01), mats])
			n.free()
	quit()
