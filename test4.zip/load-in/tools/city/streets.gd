extends RefCounted
## Everything on the pavements: street lamps, utility poles strung with
## wires, paper lanterns across Neon Row, vending machines, street-name signs
## at the junctions, traffic lights, benches, bins, bikes, rubbish, trees,
## parked cars, the plaza and the building site.

const Plan := preload("res://tools/city/plan.gd")
const Layout := preload("res://tools/city/layout.gd")
const Kit := preload("res://tools/city/kit.gd")
const Ground := preload("res://tools/city/ground.gd")

const CAR_SCENES := [preload("res://vehicles/car_compact.tscn"), preload("res://vehicles/car_van.tscn")]

var kit: Kit
var layout: Layout
var ground: Ground
var root: Node3D
const KNOCK_LAMP := preload("res://world/knock_lamp.gd")

var solid: StaticBody3D
var rng := RandomNumberGenerator.new()
var light_count := 0
## Places people like to hang about (benches, vending machines, the plaza).
var spots: Array[Vector3] = []
## Where the sitters sit: {at, yaw}.
var seats: Array[Dictionary] = []


func _init(the_kit: Kit, the_layout: Layout, the_ground: Ground, parent: Node3D, body: StaticBody3D) -> void:
	kit = the_kit
	layout = the_layout
	ground = the_ground
	root = parent
	solid = body
	rng.seed = 4242


func build() -> void:
	for r in layout.roads.size():
		var road: Dictionary = layout.roads[r]
		match road.kind:
			Plan.AVENUE, Plan.STREET, Plan.LANE:
				_lamps(r, road)
		if road.style[0] in ["home", "market", "back", "canal"] or road.style[1] in ["home", "market", "back", "canal"]:
			_utility_poles(r, road)
	_lantern_strings(layout.roads[_road_index("Neon Row")], 11.0)
	_lantern_strings(layout.roads[_road_index("Lantern Alley")], 5.0)
	_junction_signs()
	_vending_machines()
	_street_clutter()


func _road_index(name: String) -> int:
	for i in layout.roads.size():
		if layout.roads[i].name == name:
			return i
	return -1


## Is `p` on open pavement (not in a road, building, junction or reserved spot)?
func _on_pavement(p: Vector2, road: Dictionary) -> bool:
	if layout.value_at(p) != Layout.ROAD:
		return false
	for other in layout.roads:
		if layout.distance_to_road(p, other) < other.width * 0.5 + 0.4:
			return false
	for name in ground.junctions:
		var j: Dictionary = ground.junctions[name]
		if p.distance_to(j.centre) < j.radius + 2.5:
			return false
	return true


# --- lamps ---------------------------------------------------------------------

func _lamps(r: int, road: Dictionary) -> void:
	var style: String = road.style[0] if road.style[0] != "" else road.style[1]
	var spacing: float = {Plan.AVENUE: 19.0, Plan.STREET: 17.0, Plan.LANE: 21.0}[road.kind]
	if style == "neon":
		spacing = 24.0
	var line: PackedVector2Array = road.points
	var total := Layout.length_of(line)
	var along := 6.0
	var side := 1.0
	while along < total - 4.0:
		var here := Layout.at_distance(line, along)
		var normal: Vector2 = Layout.left_of(here.dir) * side
		var p: Vector2 = here.point + normal * (road.width * 0.5 + 1.9)
		if _on_pavement(p, road):
			_lamp(p, -normal, style, road.area)
		along += spacing * (0.5 if road.kind == Plan.AVENUE else 1.0)
		side = -side


func _lamp(p: Vector2, toward_road: Vector2, style: String, area: String) -> void:
	var yaw := Layout.yaw_facing(toward_road)
	# The truck can knock it over (world/knock_lamp.gd): parts on a pivot at the foot, own collision.
	var lamp := kit.node(root, "Lamp", Kit.yawed(yaw, Kit.v3(p)))
	lamp.set_script(KNOCK_LAMP)
	var pivot := kit.node(lamp, "Pivot")
	var iron := kit.toy(Color("2d2c38"), 0, 0.55, 0.2, 0.2)
	var tall := 5.2 if style in ["avenue", "uptown", "neon", "canal"] else 4.3
	var colour := Color("ffcf8a")
	match style:
		"uptown": colour = Color("e8f0ff")
		"neon": colour = Color("ffe9d0")
		"canal": colour = Color("ffb36b")
		"back": colour = Color("ffb36b")
	kit.add_box(pivot, "Base", Vector3(0, 0.25, 0), Vector3(0.36, 0.5, 0.36), iron)
	kit.mesh(pivot, "Pole", kit.cyl(0.08, 0.06, tall, iron, 8), Transform3D(Basis(), Vector3(0, tall * 0.5, 0)))
	kit.add_box(pivot, "Arm", Vector3(0, tall - 0.05, 0.6), Vector3(0.1, 0.1, 1.3), iron)
	kit.add_box(pivot, "Head", Vector3(0, tall - 0.18, 1.2), Vector3(0.4, 0.2, 0.6), iron)
	kit.mesh(pivot, "Glass", kit.box(Vector3(0.32, 0.06, 0.5), kit.glow(colour, 4.0)), Transform3D(Basis(), Vector3(0, tall - 0.3, 1.2)), false)
	kit.omni(pivot, "Light", Vector3(0, tall - 0.6, 1.3), colour, 1.25, 11.5)
	var body := StaticBody3D.new()
	body.name = "Body"
	lamp.add_child(body)
	body.owner = kit.owner
	kit.cyl_shape(body, "Shape", Vector3(0, tall * 0.5, 0), 0.16, tall)
	light_count += 1


# --- utility poles and wires -----------------------------------------------------

func _utility_poles(r: int, road: Dictionary) -> void:
	var line: PackedVector2Array = road.points
	var total := Layout.length_of(line)
	var side := 1.0 if road.style[0] in ["home", "market", "back", "canal"] else -1.0
	var along := 3.0
	var previous := Vector3.INF
	var wood := kit.toy(Color("5b4636"), 0, 0.9, 0.2)
	var dark := kit.toy(Color("26252e"), 0, 0.7)
	var wire := kit.toy(Color("15141b"), 0, 0.9)
	while along < total - 2.0:
		var here := Layout.at_distance(line, along)
		var normal: Vector2 = Layout.left_of(here.dir) * side
		var p: Vector2 = here.point + normal * (road.width * 0.5 + 1.2)
		if _on_pavement(p, road) and layout.value_at(p) == Layout.ROAD:
			var pole := kit.node(root, "UtilityPole", Kit.yawed(Layout.yaw_facing(here.dir), Kit.v3(p)))
			kit.mesh(pole, "Pole", kit.cyl(0.13, 0.1, 8.0, wood, 8), Transform3D(Basis(), Vector3(0, 4.0, 0)))
			kit.add_box(pole, "Crossbar", Vector3(0, 7.4, 0), Vector3(1.6, 0.12, 0.12), wood)
			kit.add_box(pole, "Crossbar", Vector3(0, 6.7, 0), Vector3(1.2, 0.1, 0.1), wood, 0, true, 90.0)
			if rng.randf() < 0.4:
				kit.mesh(pole, "Transformer", kit.cyl(0.32, 0.32, 0.8, kit.toy(Color("7d8494"), 0, 0.5), 10), Transform3D(Basis(), Vector3(0, 5.7, -0.35)), true, 90.0)
			if rng.randf() < 0.3:
				# A little lamp on the pole: the side-street look.
				kit.mesh(pole, "PoleLamp", kit.sphere(0.14, kit.glow(Color("fff0d0"), 3.5)), Transform3D(Basis(), Vector3(0, 4.6, 0.4)), false)
			kit.cyl_shape(solid, "Pole", Kit.v3(p, 4.0), 0.16, 8.0)
			var top := Kit.v3(p, 7.35)
			if previous != Vector3.INF and previous.distance_to(top) < 40.0:
				for offset in [-0.6, 0.6, 0.0]:
					var lateral := Kit.v3(Layout.left_of(here.dir) * offset, 0.0) if offset != 0.0 else Vector3(0, -0.65, 0)
					_wire(previous + lateral, top + lateral, wire)
			previous = top
		along += 24.0


## A sagging cable between two points: two straight pieces.
func _wire(a: Vector3, b: Vector3, material: Material) -> void:
	var mid := (a + b) * 0.5 + Vector3(0, -0.45, 0)
	for pair in [[a, mid], [mid, b]]:
		var from: Vector3 = pair[0]
		var to: Vector3 = pair[1]
		var length := from.distance_to(to)
		var dir := (to - from) / length
		var basis := Basis.looking_at(dir, Vector3.UP if absf(dir.y) < 0.99 else Vector3.RIGHT)
		kit.mesh(root, "Wire", kit.box(Vector3(0.03, 0.03, length), material, 0.0, 1), Transform3D(basis, (from + to) * 0.5), false, 110.0)


# --- lanterns across the street ---------------------------------------------------

func _lantern_strings(road: Dictionary, spacing: float) -> void:
	var line: PackedVector2Array = road.points
	var total := Layout.length_of(line)
	var along := spacing * 0.5
	var cable := kit.toy(Color("1d1c24"), 0, 0.9)
	var colours := [Color("ff4f5e"), Color("fff1d6"), Color("ff8a5b")]
	while along < total - 2.0:
		var here := Layout.at_distance(line, along)
		var n := Layout.left_of(here.dir)
		var reach: float = road.width * 0.5 + 2.3
		var a := Kit.v3(here.point + n * reach, 5.6)
		var b := Kit.v3(here.point - n * reach, 5.6)
		if _clear_of_junctions(here.point):
			_wire(a, b, cable)
			var count := int(reach * 2.0 / 1.5)
			for i in count:
				var t := (i + 0.5) / count
				var p := a.lerp(b, t) + Vector3(0, -0.45 * sin(PI * t) * 1.8 - 0.35, 0)
				var c: Color = colours[(i + int(along)) % colours.size()]
				kit.mesh(root, "Lantern", kit.capsule(0.2, 0.2, 0.55, kit.glow(c, 2.4)), Transform3D(Basis(), p), false, 120.0)
			if int(along / spacing) % 2 == 0:
				kit.omni(root, "LanternGlow", Kit.v3(here.point, 4.6), Color("ff8a6b"), 0.7, 8.0)
				light_count += 1
		along += spacing


## Not on any road you can drive down (alleys included), with `margin` to spare.
func _off_carriageway(p: Vector2, margin: float) -> bool:
	for road in layout.roads:
		if road.kind != Plan.PATH and layout.distance_to_road(p, road) < road.width * 0.5 + margin:
			return false
	return true


func _clear_of_junctions(p: Vector2) -> bool:
	for name in ground.junctions:
		var j: Dictionary = ground.junctions[name]
		if p.distance_to(j.centre) < j.radius + 1.0:
			return false
	return true


# --- signs at the junctions ---------------------------------------------------------

func _junction_signs() -> void:
	var iron := kit.toy(Color("2d2c38"), 0, 0.55, 0.2, 0.2)
	var blade := kit.toy(Color("1e6b4a"), 0.25, 0.5)
	for name in ground.junctions:
		var j: Dictionary = ground.junctions[name]
		# Which streets meet here (different names only).
		var names := []
		for arm in j.arms:
			var road_name: String = layout.roads[arm.road].name
			if layout.roads[arm.road].kind != Plan.PATH and not (road_name in names):
				names.append(road_name)
		if names.size() < 2:
			continue
		# Stand it on the corner between the first two arms.
		var a: Vector2 = j.arms[0].dir
		var b: Vector2 = j.arms[1].dir
		var corner_dir := (a + b).normalized()
		if corner_dir.length() < 0.1:
			corner_dir = Layout.left_of(a)
		var p: Vector2 = j.centre + corner_dir * (j.radius + 2.2)
		if layout.value_at(p) != Layout.ROAD or not _off_carriageway(p, 0.6):
			continue
		var sign := kit.node(root, "StreetSign", Kit.yawed(0.0, Kit.v3(p)))
		kit.mesh(sign, "Pole", kit.cyl(0.05, 0.05, 3.4, iron, 8), Transform3D(Basis(), Vector3(0, 1.7, 0)))
		kit.cyl_shape(solid, "SignPole", Kit.v3(p, 1.7), 0.1, 3.4)
		for k in mini(names.size(), 2):
			# Each blade runs along its street.
			var road_dir := Vector2.RIGHT
			for arm in j.arms:
				if layout.roads[arm.road].name == names[k]:
					road_dir = arm.dir
					break
			var yaw := Layout.yaw_facing(Layout.left_of(road_dir))
			var y := 3.0 + k * 0.42
			var text: String = names[k].to_upper()
			var length := 0.4 + text.length() * 0.19
			sign_blade(sign, Transform3D(Basis(Vector3.UP, yaw), Vector3(0, y, 0)), length, blade, text)
		# Traffic lights on the big junctions.
		var avenues := 0
		for arm in j.arms:
			if arm.kind == Plan.AVENUE:
				avenues += 1
		var light_at: Vector2 = j.centre + corner_dir * (j.radius + 1.4)
		if avenues >= 2 and _off_carriageway(light_at, 0.4):
			_traffic_light(light_at, -corner_dir)
		if j.arms.size() >= 3:
			spots.append(Kit.v3(p + corner_dir * 0.8))


func sign_blade(parent: Node3D, xform: Transform3D, length: float, material: Material, text: String) -> void:
	kit.mesh(parent, "Blade", kit.box(Vector3(length, 0.32, 0.05), material, 0.03), xform * Transform3D(Basis(), Vector3(length * 0.5 - 0.1, 0, 0)), true, 90.0)
	for face in [1.0, -1.0]:
		var b := Basis(Vector3.UP, 0.0 if face > 0.0 else PI)
		kit.label(parent, "BladeText", text, xform * Transform3D(b, Vector3(length * 0.5 - 0.1, 0, 0.035 * face)), 0.2, Color(1.4, 1.4, 1.35), false, false, 64)


func _traffic_light(p: Vector2, facing: Vector2) -> void:
	var iron := kit.toy(Color("2d2c38"), 0, 0.55, 0.2, 0.2)
	var tl := kit.node(root, "TrafficLight", Kit.yawed(Layout.yaw_facing(facing), Kit.v3(p)))
	kit.mesh(tl, "Pole", kit.cyl(0.08, 0.08, 4.2, iron, 8), Transform3D(Basis(), Vector3(0, 2.1, 0)))
	kit.add_box(tl, "Arm", Vector3(0, 4.1, 1.6), Vector3(0.1, 0.1, 3.2), iron)
	kit.add_box(tl, "Box", Vector3(0, 3.6, 3.0), Vector3(0.4, 1.1, 0.35), kit.toy(Color("1b1b22")))
	var lit := rng.randi() % 3
	var colours := [Color("ff3b3b"), Color("ffb020"), Color("3bff8a")]
	for k in 3:
		var on := k == lit
		kit.mesh(tl, "Lamp", kit.sphere(0.12, kit.glow(colours[k], 3.5) if on else kit.toy(colours[k].darkened(0.75))), Transform3D(Basis(), Vector3(0, 3.95 - k * 0.34, 3.19)), false, 120.0)
	kit.cyl_shape(solid, "TrafficLight", Kit.v3(p, 2.1), 0.12, 4.2)


# --- vending machines and other clutter ----------------------------------------------

func _vending_machines() -> void:
	# In front of the plainer buildings of the busier quarters.
	var count := 0
	for lot in layout.lots:
		if not lot.front or lot.shop or not (lot.style in ["home", "market", "back", "neon", "canal"]):
			continue
		if rng.randf() > 0.45:
			continue
		var base := Transform3D(Basis(Vector3.UP, lot.yaw), Kit.v3(lot.centre))
		var n := rng.randi_range(1, 3)
		var x0: float = lot.size.x * 0.5 - 1.0 - n * 0.95
		for i in n:
			var local := Vector3(x0 + i * 0.95, 0, lot.size.y * 0.5 + 0.45)
			var world := base * local
			if layout.value_at(Vector2(world.x, world.z)) != Layout.ROAD:
				continue
			_vending(base * Transform3D(Basis(), local))
			count += 1
		if n > 0:
			var front := base * Vector3(x0, 0, lot.size.y * 0.5 + 1.4)
			spots.append(front)


func _vending(xform: Transform3D) -> void:
	var colours := ["e63946", "f4f1de", "3d5a80", "2a9d8f", "ffb703"]
	var body := Color(colours[rng.randi() % colours.size()])
	var v := kit.node(root, "Vending", xform)
	kit.add_box(v, "Box", Vector3(0, 0.9, 0), Vector3(0.9, 1.8, 0.7), kit.toy(body, 0.08, 0.5, 0.3))
	kit.mesh(v, "Screen", kit.box(Vector3(0.75, 0.9, 0.04), kit.toy(Color("e8f6ff"), 1.6, 0.2)), Transform3D(Basis(), Vector3(0, 1.25, 0.36)), false)
	for k in 6:
		kit.add_box(v, "Can", Vector3(-0.27 + (k % 3) * 0.27, 1.1 + (k / 3) * 0.32, 0.39), Vector3(0.12, 0.2, 0.03), kit.toy(Color(Plan.NEON_COLORS[(k + rng.randi()) % Plan.NEON_COLORS.size()]), 0.8), 0, false, 35.0)
	kit.shape(solid, "Vending", xform * Transform3D(Basis(), Vector3(0, 0.9, 0)), Vector3(0.9, 1.8, 0.7))


func _street_clutter() -> void:
	# Bins, rubbish bags and bikes in front of some buildings.
	for lot in layout.lots:
		if not lot.front:
			continue
		var base := Transform3D(Basis(Vector3.UP, lot.yaw), Kit.v3(lot.centre))
		var roll := rng.randf()
		var local := Vector3(rng.randf_range(-0.3, 0.3) * lot.size.x, 0, lot.size.y * 0.5 + 0.5)
		var world := base * local
		if layout.value_at(Vector2(world.x, world.z)) != Layout.ROAD:
			continue
		if roll < 0.18:
			_bags(base * Transform3D(Basis(), local))
		elif roll < 0.3 and lot.style in ["home", "market", "neon", "back"]:
			_bike(base * Transform3D(Basis(Vector3.UP, PI * 0.5), local))
		elif roll < 0.38:
			_bin(base * Transform3D(Basis(), local))


func _bags(xform: Transform3D) -> void:
	var g := kit.node(root, "Rubbish", xform)
	var black := kit.toy(Color("1d1d26"), 0, 0.3, 0.6)
	for i in rng.randi_range(2, 4):
		var p := Vector3(rng.randf_range(-0.5, 0.5), 0.25, rng.randf_range(-0.2, 0.2))
		kit.mesh(g, "Bag", kit.sphere(0.32, black, 0.55), Transform3D(Basis(Vector3.UP, rng.randf() * TAU), p), true, 50.0)


func _bike(xform: Transform3D) -> void:
	var b := kit.node(root, "Bike", xform)
	var frame := kit.toy(Color(Plan.NEON_COLORS[rng.randi() % Plan.NEON_COLORS.size()]).darkened(0.2), 0, 0.4, 0.2, 0.3)
	var tyre := kit.toy(Color("15151a"), 0, 0.8)
	for x in [-0.5, 0.5]:
		kit.mesh(b, "Wheel", kit.cyl(0.33, 0.33, 0.05, tyre, 14), Transform3D(Basis(Vector3.FORWARD, PI * 0.5), Vector3(x, 0.33, 0)), true, 40.0)
	kit.mesh(b, "Frame", kit.box(Vector3(1.0, 0.05, 0.05), frame), Transform3D(Basis(Vector3.FORWARD, 0.25), Vector3(0, 0.62, 0)), true, 40.0)
	kit.add_box(b, "Saddle", Vector3(-0.25, 0.85, 0), Vector3(0.25, 0.06, 0.12), tyre, 0, true, 40.0)
	kit.add_box(b, "Bars", Vector3(0.42, 0.9, 0), Vector3(0.06, 0.06, 0.5), frame, 0, true, 40.0)


func _bin(xform: Transform3D) -> void:
	var b := kit.node(root, "Bin", xform)
	kit.mesh(b, "Can", kit.cyl(0.28, 0.3, 0.85, kit.toy(Color("4a5a50"), 0, 0.6, 0.2, 0.2), 12), Transform3D(Basis(), Vector3(0, 0.425, 0)), true, 60.0)
	kit.mesh(b, "Lid", kit.cyl(0.32, 0.26, 0.12, kit.toy(Color("3a463f")), 12), Transform3D(Basis(), Vector3(0, 0.9, 0)), true, 50.0)
	kit.cyl_shape(solid, "Bin", xform * Vector3(0, 0.45, 0), 0.3, 0.9)


# --- bigger set pieces ----------------------------------------------------------

## Quaternius Stylized Nature MegaKit models (art/nature, CC0).
const NATURE := "res://art/nature/%s.gltf"
const TREES := ["CommonTree_1", "CommonTree_2", "CommonTree_3", "CommonTree_4", "CommonTree_5"]
const PINES := ["Pine_1", "Pine_2", "Pine_3"]
const BUSHES := ["Bush_Common", "Bush_Common_Flowers", "Bush_Common"]
const FLOWERS := ["Flower_3_Group", "Flower_4_Group"]
const GRASSES := ["Grass_Common_Short", "Grass_Common_Tall", "Grass_Wispy_Short", "Grass_Wispy_Tall"]
const PLANTS := ["Fern_1", "Plant_1", "Plant_7", "Plant_1_Big", "Plant_7_Big", "Clover_1", "Clover_2"]
const ROCKS := ["Rock_Medium_1", "Rock_Medium_2", "Rock_Medium_3"]
const PEBBLES := ["Pebble_Round_1", "Pebble_Round_2", "Pebble_Round_3", "Pebble_Round_4", "Pebble_Round_5"]


## A tree. `scale` 1 = a street tree about 5 m tall; `kind` 0/1 = broadleaf,
## 2 = pine.
func tree(at: Vector3, scale := 1.0, kind := 0, solid_body: StaticBody3D = null) -> Node3D:
	var t := kit.node(root, "Tree", Transform3D(Basis(Vector3.UP, rng.randf() * TAU), at))
	var model: String = _pick_from(PINES) if kind == 2 else _pick_from(TREES)
	var s := scale * rng.randf_range(0.55, 0.68)
	kit.place(t, "Model", NATURE % model, Transform3D(Basis().scaled(Vector3.ONE * s), Vector3.ZERO), true, 160.0)
	var body := solid_body if solid_body else solid
	kit.cyl_shape(body, "Tree", at + Vector3(0, 1.4 * scale, 0), 0.24 * scale, 2.8 * scale)
	return t


## A bush (about 1.2 m round at scale 1), no collision: you can push through.
func bush(at: Vector3, scale := 1.0, flowers := -1) -> Node3D:
	var model: String = BUSHES[1] if flowers == 1 else (BUSHES[0] if flowers == 0 else _pick_from(BUSHES))
	return _plant(model, at, scale * rng.randf_range(0.6, 0.8), 90.0)


func flower_bed(at: Vector3, scale := 1.0) -> Node3D:
	return _plant(_pick_from(FLOWERS), at, scale * rng.randf_range(0.5, 0.7), 60.0)


func grass_tuft(at: Vector3, scale := 1.0) -> Node3D:
	return _plant(_pick_from(GRASSES), at, scale * rng.randf_range(0.35, 0.55), 45.0, false)


func ground_plant(at: Vector3, scale := 1.0) -> Node3D:
	return _plant(_pick_from(PLANTS), at, scale * rng.randf_range(0.6, 0.9), 50.0, false)


## A boulder (solid). `scale` 1 = about 2.5 m across.
func rock(at: Vector3, scale := 1.0, solid_body: StaticBody3D = null) -> Node3D:
	var model: String = _pick_from(ROCKS)
	var s := scale * rng.randf_range(0.7, 0.9)
	var r := kit.node(root, "Rock", Transform3D(Basis(Vector3.UP, rng.randf() * TAU), at))
	kit.place(r, "Model", NATURE % model, Transform3D(Basis().scaled(Vector3.ONE * s), Vector3(0, -0.15 * s, 0)), true, 140.0)
	var body := solid_body if solid_body else solid
	kit.cyl_shape(body, "Rock", at + Vector3(0, 0.6 * s, 0), 1.2 * s, 1.4 * s)
	return r


func pebble(at: Vector3, scale := 1.0) -> Node3D:
	return _plant(_pick_from(PEBBLES), at, scale * rng.randf_range(0.8, 1.6), 40.0, false)


func _plant(model: String, at: Vector3, s: float, fade: float, shadow := true) -> Node3D:
	var p := kit.node(root, "Plant", Transform3D(Basis(Vector3.UP, rng.randf() * TAU), at))
	kit.place(p, "Model", NATURE % model, Transform3D(Basis().scaled(Vector3.ONE * s), Vector3.ZERO), shadow, fade)
	return p


func _pick_from(list: Array) -> String:
	return list[rng.randi() % list.size()]


func bench(xform: Transform3D, seat := true) -> void:
	var b := kit.node(root, "Bench", xform)
	var wood := kit.toy(Color("8a5a3c"), 0, 0.85, 0.3)
	var iron := kit.toy(Color("2d2c38"), 0, 0.55, 0.2, 0.2)
	kit.add_box(b, "Plank", Vector3(0, 0.45, 0), Vector3(1.8, 0.08, 0.5), wood)
	kit.add_box(b, "Back", Vector3(0, 0.78, -0.22), Vector3(1.8, 0.35, 0.06), wood)
	for x in [-0.75, 0.75]:
		kit.add_box(b, "Leg", Vector3(x, 0.22, 0), Vector3(0.08, 0.44, 0.45), iron)
	kit.shape(solid, "Bench", xform * Transform3D(Basis(), Vector3(0, 0.45, -0.02)), Vector3(1.8, 0.9, 0.55))
	if seat:
		seats.append({"at": xform * Vector3(0.4, 0, 0.18), "yaw": xform.basis.get_euler().y})


func parked_car(xform: Transform3D, colour: Color, van := false) -> void:
	var car: Node3D = CAR_SCENES[1 if van else 0].instantiate()
	car.name = kit.name_for(root, "ParkedCar")
	car.transform = xform
	car.set("body_color", colour)
	root.add_child(car)
	car.owner = kit.owner


func cone(at: Vector3) -> void:
	var c := kit.node(root, "Cone", Kit.yawed(0.0, at))
	kit.mesh(c, "Cone", kit.cyl(0.2, 0.03, 0.6, kit.toy(Color("ff7a1a"), 0.15, 0.6), 10), Transform3D(Basis(), Vector3(0, 0.33, 0)), true, 60.0)
	kit.add_box(c, "Foot", Vector3(0, 0.03, 0), Vector3(0.42, 0.06, 0.42), kit.toy(Color("26252e")), 0, true, 60.0)
	kit.mesh(c, "Stripe", kit.cyl(0.13, 0.1, 0.1, kit.toy(Color("f4f1de"), 0.3), 10), Transform3D(Basis(), Vector3(0, 0.38, 0)), false, 45.0)


func barrier(xform: Transform3D, length := 2.0) -> void:
	var b := kit.node(root, "Barrier", xform)
	kit.add_box(b, "Board", Vector3(0, 0.75, 0), Vector3(length, 0.3, 0.06), kit.toy(Color("f4f1de"), 0.15))
	for k in int(length / 0.5):
		kit.add_box(b, "Stripe", Vector3(-length * 0.5 + 0.25 + k * 0.5, 0.75, 0.035), Vector3(0.22, 0.3, 0.02), kit.toy(Color("e63946"), 0.2), 0.3, false, 50.0)
	for x in [-length * 0.4, length * 0.4]:
		kit.add_box(b, "Leg", Vector3(x, 0.4, 0), Vector3(0.08, 0.8, 0.5), kit.toy(Color("26252e")))
	kit.mesh(b, "Blinker", kit.sphere(0.09, kit.glow(Color("ffb020"), 4.0)), Transform3D(Basis(), Vector3(length * 0.4, 1.0, 0)), false)
	kit.shape(solid, "Barrier", xform * Transform3D(Basis(), Vector3(0, 0.5, 0)), Vector3(length, 1.0, 0.4))
