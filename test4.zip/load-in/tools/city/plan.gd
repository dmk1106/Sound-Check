extends RefCounted
## The city plan: every street, district, landmark and the places the game
## needs, in metres (x east, z south; the starting house is at the origin and
## faces +z, down its drive onto Creek Lane). tools/city_builder.gd turns this
## into levels/city.tscn. Change the plan and re-run the builder, rather than
## editing the generated streets by hand.

const AVENUE := 0
const STREET := 1
const LANE := 2
const ALLEY := 3
const PATH := 4

## Junctions and road ends. Roads that share a junction name meet there.
const NODES := {
	"harbour_jct": Vector2(-70, 24),
	"mill_jct": Vector2(-45, 17.5),
	"market_jct": Vector2(-30, 15.8),
	"canal_jct": Vector2(28, 16.4),
	"grand_north": Vector2(62, 31),
	"kanda_row": Vector2(-68, 60),
	"kanda_back": Vector2(-52, 97),
	"kanda_park": Vector2(-6, 133),
	"kanda_grand": Vector2(54, 128),
	"grand_uptown": Vector2(68, 64),
	"grand_alley": Vector2(68, 82),
	"grand_back": Vector2(63, 106),
	"row_market": Vector2(-30, 58),
	"row_lantern": Vector2(6, 62.5),
	"row_canal": Vector2(30, 60.5),
	"back_market": Vector2(-26, 94.5),
	"back_rook": Vector2(-10, 96),
	"back_lantern": Vector2(10, 98.6),
	"back_canal": Vector2(27, 100),
	"canal_alley": Vector2(30.5, 77),
	"mill_end": Vector2(-53, -4),
	"rook_end": Vector2(-10, 113),
	"park_end": Vector2(2, 156),
	"uptown_end": Vector2(118, 66),
	"kanda_hoshi": Vector2(-61, 79),
	"harbour_end": Vector2(-116, 4),
}

## Roads. `points` run through junction names and plain control points; the
## centre line is a smooth curve through all of them. `style` = the district
## look of the buildings along each side (left, right as you drive from the
## first point), "" for none. `area` = the fan-gated part of town it is in.
const ROADS := [
	{"name": "Creek Lane", "kind": STREET, "width": 8.0, "style": ["home", "home"],
		"points": ["harbour_jct", Vector2(-58, 19.5), "mill_jct", "market_jct", Vector2(-15, 15.5), Vector2(15, 15.5), "canal_jct", Vector2(46, 21.5), "grand_north"]},
	{"name": "Kanda Avenue", "kind": AVENUE, "width": 10.0, "style": ["avenue", "avenue"],
		"points": ["harbour_jct", Vector2(-75, 42), "kanda_row", "kanda_hoshi", "kanda_back", Vector2(-34, 115), "kanda_park", Vector2(24, 138), "kanda_grand"]},
	{"name": "Grand Street", "kind": AVENUE, "width": 10.0, "style": ["avenue", "avenue"],
		"points": ["grand_north", Vector2(66, 47), "grand_uptown", "grand_alley", "grand_back", Vector2(58, 118), "kanda_grand"]},
	{"name": "Neon Row", "kind": STREET, "width": 8.0, "style": ["neon", "neon"],
		"points": ["kanda_row", Vector2(-50, 57), "row_market", Vector2(-12, 61.5), "row_lantern", "row_canal", Vector2(48, 62), "grand_uptown"]},
	{"name": "Market Lane", "kind": LANE, "width": 6.0, "style": ["market", "market"],
		"points": ["market_jct", Vector2(-33, 30), Vector2(-32, 44), "row_market", Vector2(-24, 77), "back_market"]},
	{"name": "Hoshi Lane", "kind": LANE, "width": 6.0, "style": ["market", "back"],
		"points": ["kanda_hoshi", Vector2(-47, 73.5), "row_market"]},
	{"name": "Canal Street", "kind": STREET, "width": 7.0, "style": ["canal", "canal"],
		"points": ["canal_jct", Vector2(31, 31), Vector2(29, 46), "row_canal", "canal_alley", Vector2(28, 90), "back_canal"]},
	{"name": "Back Street", "kind": STREET, "width": 7.0, "style": ["back", "back"],
		"points": ["kanda_back", "back_market", "back_rook", "back_lantern", "back_canal", Vector2(45, 103), "grand_back"]},
	{"name": "Cat Alley", "kind": ALLEY, "width": 4.4, "style": ["", ""],
		"points": ["canal_alley", Vector2(41, 77.5), Vector2(51, 79.5), "grand_alley"]},
	{"name": "Mill Road", "kind": LANE, "width": 6.0, "style": ["home", "home"],
		"points": ["mill_jct", Vector2(-48, 6), "mill_end"], "end_circle": 7.0},
	{"name": "Rook Court", "kind": LANE, "width": 6.0, "style": ["back", "back"],
		"points": ["back_rook", Vector2(-11, 105), "rook_end"], "end_circle": 7.5},
	{"name": "Lantern Alley", "kind": PATH, "width": 3.2, "style": ["", ""],
		"points": ["row_lantern", Vector2(8, 72), Vector2(6, 83), "back_lantern"]},
	{"name": "Uptown Boulevard", "kind": AVENUE, "width": 9.0, "style": ["uptown", "uptown"], "area": "uptown",
		"points": ["grand_uptown", Vector2(86, 61), Vector2(102, 62.5), "uptown_end"]},
	{"name": "Park Road", "kind": LANE, "width": 7.0, "style": ["", ""], "area": "park_side",
		"points": ["kanda_park", Vector2(-4, 145), "park_end"]},
	{"name": "Harbour Road", "kind": STREET, "width": 8.0, "style": ["harbour", "harbour"], "area": "harbour",
		"points": ["harbour_jct", Vector2(-86, 21), Vector2(-102, 13), "harbour_end"]},
]

## The built-up area. Outside it: the dark skyline backdrop and the world edge.
const BOUNDS := Rect2(-128, -52, 270, 248)

## Fan-gated parts of town: a wall runs round each (except along the world
## edge), with the gate where the road goes in.
const GATED := [
	{"area": "uptown", "polygon": [Vector2(88, 26), Vector2(142, 26), Vector2(142, 142), Vector2(88, 142)],
		"gate": Vector2(88, 61.2), "gate_yaw_from": "grand_uptown"},
	{"area": "park_side", "polygon": [Vector2(-30, 143), Vector2(36, 147), Vector2(36, 196), Vector2(-30, 196)],
		"gate": Vector2(-3.8, 144), "gate_yaw_from": "kanda_park"},
	{"area": "harbour", "polygon": [Vector2(-128, -52), Vector2(-80, -52), Vector2(-80, 33), Vector2(-128, 33)],
		"gate": Vector2(-80, 20.6), "gate_yaw_from": "harbour_jct"},
]

## Places the game needs, and where they sit: position and yaw (degrees).
const PLACES := {
	"Studio": {"at": Vector2(-12, 81.4), "yaw": 0.0},
	"MusicStore": {"at": Vector2(-48, 39.1), "yaw": 0.0},
	"Diner": {"at": Vector2(-92.8, 45.0), "yaw": 0.0},
	"Alley": {"at": Vector2(46, 87.4), "yaw": 0.0},
	"Venue": {"at": Vector2(2, 165), "yaw": 0.0},
	"Tower": {"at": Vector2(123.5, 60.4), "yaw": 180.0},
	"Plaza": {"at": Vector2(2, 50.5), "yaw": 180.0},
}

## Ground kept clear of generated buildings: rectangles (centre, size, yaw)
## or polygons, each with what goes there.
const RESERVED := [
	{"what": "home", "polygon": [Vector2(-17, -14), Vector2(13, -14), Vector2(13, 10), Vector2(-17, 10)]},
	{"what": "park_central", "polygon": [Vector2(-80, -52), Vector2(142, -52), Vector2(142, -12), Vector2(60, -12), Vector2(40, -10), Vector2(17, -14),
			Vector2(-17, -14), Vector2(-42, -12), Vector2(-58, -10), Vector2(-80, -10)]},
	{"what": "Studio", "rect": [Vector2(-12, 84.5), Vector2(17, 13)]},
	{"what": "MusicStore", "rect": [Vector2(-48, 44), Vector2(16, 19)]},
	{"what": "Diner", "rect": [Vector2(-88, 45), Vector2(18, 16)]},
	{"what": "Alley", "rect": [Vector2(46, 87), Vector2(14, 13)]},
	{"what": "park", "polygon": [Vector2(-30, 143), Vector2(36, 147), Vector2(36, 196), Vector2(-30, 196)]},
	{"what": "Tower", "rect": [Vector2(123.5, 60.4), Vector2(14, 14)]},
	{"what": "plaza", "polygon": [Vector2(-12, 42), Vector2(14, 41), Vector2(15, 56.5), Vector2(-12, 56)]},
	{"what": "works", "polygon": [Vector2(-46, 21), Vector2(-37, 21), Vector2(-37.5, 33), Vector2(-46, 33)]},
	{"what": "court", "rect": [Vector2(48, 44), Vector2(14, 10)]},
	{"what": "court", "rect": [Vector2(-42, 86), Vector2(9, 8)]},
	{"what": "lot", "rect": [Vector2(-80, 112), Vector2(16, 12)]},
	{"what": "park_path", "rect": [Vector2(38, 0.5), Vector2(5, 23)]},
	{"what": "waterfront", "polygon": [Vector2(-128, -10), Vector2(-108, -10), Vector2(-108, 33), Vector2(-128, 33)]},
]

## The elevated railway: a smooth line of track on pillars, crossing the creek
## north of the house, running down beside Canal Street and along over Cat
## Alley into Uptown.
const RAILWAY := [Vector2(12, -56), Vector2(14, -30), Vector2(17, 0), Vector2(19, 30), Vector2(20, 52), Vector2(23, 68),
		Vector2(33, 77.2), Vector2(51, 79.5), Vector2(68, 82.2), Vector2(100, 87), Vector2(146, 92)]
const RAIL_HEIGHT := 8.4
const RAIL_WIDTH := 6.4

## Traffic loops, as junction names in driving order (they drive on the right).
const TRAFFIC := [
	["harbour_jct", "grand_north", "kanda_grand", "kanda_back", "kanda_row", "harbour_jct"],
	["harbour_jct", "kanda_row", "kanda_back", "kanda_grand", "grand_north", "harbour_jct"],
	["kanda_row", "grand_uptown", "grand_back", "kanda_back", "kanda_row"],
	["back_canal", "canal_jct", "market_jct", "back_market", "back_canal"],
]

## District looks: building sizes (m), colours, and how much neon.
const STYLES := {
	"home": {"height": [5.0, 9.0], "width": [7.0, 11.0], "depth": [7.0, 10.0], "setback": [3.0, 5.5], "gap": 0.35,
		"walls": ["5c4a63", "4b5568", "6b5a4e", "3f4d5c", "5e5470", "4e5f58"], "lit": 0.55, "shop": 0.12, "tall_sign": 0.05,
		"billboard": 0.0, "fire_escape": 0.1, "water_tower": 0.0, "roof": "pitched", "awning": 0.3, "tier": 0.0, "fence": 0.7},
	"neon": {"height": [9.0, 22.0], "width": [5.5, 9.5], "depth": [7.0, 10.0], "setback": [2.4, 3.2], "gap": 0.04,
		"walls": ["2d2a40", "3a2f4a", "26304a", "41304a", "2e3a48", "3b3550"], "lit": 0.5, "shop": 1.0, "tall_sign": 0.75,
		"billboard": 0.35, "fire_escape": 0.1, "water_tower": 0.0, "roof": "flat", "awning": 0.5, "tier": 0.25, "fence": 0.0},
	"avenue": {"height": [12.0, 30.0], "width": [9.0, 16.0], "depth": [9.0, 14.0], "setback": [3.0, 3.8], "gap": 0.08,
		"walls": ["4a3f52", "3d4660", "533e3e", "3f3a4f", "4f4a45", "36404f"], "lit": 0.45, "shop": 0.75, "tall_sign": 0.35,
		"billboard": 0.3, "fire_escape": 0.45, "water_tower": 0.3, "roof": "flat", "awning": 0.4, "tier": 0.35, "fence": 0.0},
	"market": {"height": [6.0, 12.0], "width": [5.0, 8.0], "depth": [6.0, 9.0], "setback": [2.0, 2.6], "gap": 0.05,
		"walls": ["5a4636", "4f3f3a", "604a3c", "463d4f", "54433a"], "lit": 0.5, "shop": 0.95, "tall_sign": 0.45,
		"billboard": 0.05, "fire_escape": 0.2, "water_tower": 0.05, "roof": "flat", "awning": 0.85, "tier": 0.1, "fence": 0.0},
	"canal": {"height": [6.0, 14.0], "width": [10.0, 18.0], "depth": [8.0, 13.0], "setback": [2.2, 3.5], "gap": 0.2,
		"walls": ["5b3a32", "4d3530", "62443a", "3e3a3a", "553f35"], "lit": 0.3, "shop": 0.35, "tall_sign": 0.15,
		"billboard": 0.1, "fire_escape": 0.5, "water_tower": 0.35, "roof": "flat", "awning": 0.2, "tier": 0.0, "fence": 0.0, "roller": 0.5},
	"back": {"height": [8.0, 15.0], "width": [7.0, 11.0], "depth": [7.0, 11.0], "setback": [2.2, 3.0], "gap": 0.12,
		"walls": ["5e3b36", "4c3534", "583f3a", "423a48", "513a3f"], "lit": 0.4, "shop": 0.45, "tall_sign": 0.2,
		"billboard": 0.05, "fire_escape": 0.75, "water_tower": 0.25, "roof": "flat", "awning": 0.35, "tier": 0.05, "fence": 0.0},
	"uptown": {"height": [24.0, 48.0], "width": [12.0, 20.0], "depth": [12.0, 16.0], "setback": [3.5, 5.0], "gap": 0.15,
		"walls": ["283048", "2b3a52", "1f2a40", "343a58", "2a2f45"], "lit": 0.6, "shop": 0.6, "tall_sign": 0.1,
		"billboard": 0.2, "fire_escape": 0.0, "water_tower": 0.0, "roof": "flat", "awning": 0.2, "tier": 0.6, "fence": 0.0, "glass": true},
	"harbour": {"height": [7.0, 12.0], "width": [14.0, 22.0], "depth": [10.0, 14.0], "setback": [3.0, 5.0], "gap": 0.3,
		"walls": ["3d4a52", "4a4f58", "3a4450", "51483f"], "lit": 0.2, "shop": 0.1, "tall_sign": 0.0,
		"billboard": 0.0, "fire_escape": 0.0, "water_tower": 0.0, "roof": "flat", "awning": 0.0, "tier": 0.0, "fence": 0.0, "roller": 0.8},
}

## Shop names for signs, per district.
const SHOP_NAMES := {
	"home": ["KONBINI 24", "DRY CLEAN", "TAKO BAR", "CORNER STORE", "LAUNDRY"],
	"neon": ["NOODLE MOON", "PACHINKO", "KARAOKE 7", "RAMEN", "GAME CENTER", "MANGA", "SUSHI GO", "ARCADE", "PURIKURA", "CAFE NEKO", "VINYL", "TOKYO DOG", "BAR LUNA", "HOT POT", "PHOTO"],
	"avenue": ["DELI", "PHARMACY", "PIZZA", "DINER", "HOTEL", "BAGELS", "TATTOO", "LIQUOR", "GYM", "BANK", "CINEMA", "KEBAB"],
	"market": ["FISH", "FRUIT", "TEA", "DUMPLINGS", "SPICES", "TOFU", "BAKERY", "FLOWERS", "BOOKS"],
	"canal": ["AUTO", "REHEARSAL", "STORAGE", "PRINTS", "BIKES", "SCRAP"],
	"back": ["DIVE BAR", "JAZZ", "BARBER", "LAUNDROMAT", "PAWN", "THE CELLAR", "RECORDS"],
	"uptown": ["SKY LOUNGE", "BOUTIQUE", "GALLERY", "HOTEL", "BISTRO"],
	"harbour": ["DOCK 4", "COLD STORE", "FERRY"],
}

const JP_SIGNS := ["ラーメン", "カラオケ", "居酒屋", "寿司", "喫茶", "酒場", "焼き鳥", "映画", "本屋", "古着", "薬", "ゲーム", "音楽", "夜", "猫", "ホテル", "餃子", "うどん"]

const NEON_COLORS := ["ff4fa0", "3ddbd9", "ffd166", "c77dff", "7f8cff", "ff8a5b", "8affc1", "ff5d5d"]
