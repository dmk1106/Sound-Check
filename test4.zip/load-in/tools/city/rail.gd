extends RefCounted
## The elevated railway: a deck on pairs of pillars, crossing the creek,
## running beside Canal Street and then right over Cat Alley, where its arches
## become the alley's walls (bars and lock-ups tucked under the tracks). Away
## from the alley the arches are filled in with little shops. A lit train runs
## along it now and then (world/train.gd).

const Plan := preload("res://tools/city/plan.gd")
const Layout := preload("res://tools/city/layout.gd")
const Kit := preload("res://tools/city/kit.gd")
const TRAIN := preload("res://world/train.gd")

var kit: Kit
var layout: Layout
var root: Node3D
var solid: StaticBody3D
## Walls the camera may look through (the alley).
var alley_walls: StaticBody3D
var rng := RandomNumberGenerator.new()
var doors: Array[Dictionary] = []
var light_count := 0
## Street furniture builder (benches, planting), set by the city builder.
var streets
var _arch_index := 0

const PIER := 2.85   # pillar line, either side of the track centre
const SPAN := 7.5


func _init(the_kit: Kit, the_layout: Layout, parent: Node3D, body: StaticBody3D, see_through_body: StaticBody3D) -> void:
	kit = the_kit
	layout = the_layout
	root = parent
	solid = body
	alley_walls = see_through_body
	rng.seed = 99


func build(alley_yard: Rect2) -> void:
	var line: PackedVector2Array = layout.rail
	var total := Layout.length_of(line)
	var concrete := kit.toy(Color("5a5868"), 0, 0.85, 0.2)
	var dark := kit.toy(Color("3a3846"), 0, 0.85, 0.2)
	var rail_mat := kit.toy(Color("8c8fa0"), 0, 0.35, 0.2, 0.6)
	var y := Plan.RAIL_HEIGHT
	var half := Plan.RAIL_WIDTH * 0.5
	var viaduct := kit.node(root, "Railway")
	var alley := _alley()
	# Deck, side walls and rails: one piece per segment of the curve.
	for i in range(1, line.size()):
		var a := line[i - 1]
		var b := line[i]
		var mid := (a + b) * 0.5
		var length := a.distance_to(b) + 0.08
		var yaw := Layout.yaw_facing((b - a).normalized())
		var base := Transform3D(Basis(Vector3.UP, yaw), Kit.v3(mid, y))
		kit.mesh(viaduct, "Deck", kit.box(Vector3(Plan.RAIL_WIDTH, 0.9, length), concrete, 0.02, 1), base)
		for side in [-1.0, 1.0]:
			kit.mesh(viaduct, "Parapet", kit.box(Vector3(0.25, 0.9, length), dark, 0.02, 1), base * Transform3D(Basis(), Vector3(side * (half - 0.12), 0.9, 0)))
			kit.mesh(viaduct, "Rail", kit.box(Vector3(0.1, 0.12, length), rail_mat, 0.0, 1), base * Transform3D(Basis(), Vector3(side * 0.75, 0.52, 0)), false, 90.0)
		# Overhead line masts every few segments.
		if i % 3 == 0:
			var mast := base * Transform3D(Basis(), Vector3(half - 0.3, 3.0, 0))
			kit.mesh(viaduct, "Mast", kit.box(Vector3(0.18, 4.4, 0.18), dark, 0.03), mast, true, 150.0)
			kit.mesh(viaduct, "MastArm", kit.box(Vector3(3.2, 0.12, 0.12), dark, 0.02), base * Transform3D(Basis(), Vector3(half - 1.8, 5.1, 0)), true, 150.0)
	# Pillars and what fills the arches between them.
	var along := 2.0
	var previous := {}
	while along < total:
		var here := Layout.at_distance(line, along)
		var n := Layout.left_of(here.dir)
		var pair := {}
		for side in [-1.0, 1.0]:
			var p: Vector2 = here.point + n * PIER * side
			if _clear_of_roads(p, 0.9):
				var pillar := Transform3D(Basis(Vector3.UP, Layout.yaw_facing(here.dir)), Kit.v3(p, (y - 0.45) * 0.5))
				kit.mesh(viaduct, "Pillar", kit.box(Vector3(0.75, y - 0.45, 0.9), concrete, 0.06, 2), pillar)
				var body := alley_walls if alley.distance.call(p) < 4.0 else solid
				kit.shape(body, "Pillar", pillar, Vector3(0.75, y - 0.45, 0.9))
				pair[side] = p
		# Fill the arch between this pair and the last one.
		if not previous.is_empty():
			_arch(previous, pair, here, alley, alley_yard)
		previous = pair
		along += SPAN
	# The train.
	var train := Node3D.new()
	train.name = "Train"
	train.set_script(TRAIN)
	var track := PackedVector3Array()
	for p in line:
		track.append(Kit.v3(p, y + 0.45))
	train.set("track", track)
	root.add_child(train)
	train.owner = kit.owner


## Cat Alley's centre line, for "is this pillar on the alley?".
func _alley() -> Dictionary:
	for road in layout.roads:
		if road.name == "Cat Alley":
			return {"line": road.points, "distance": func(p: Vector2) -> float: return Layout.distance_to_line(p, road.points)}
	return {"line": PackedVector2Array(), "distance": func(_p: Vector2) -> float: return INF}


func _clear_of_roads(p: Vector2, margin: float) -> bool:
	for road in layout.roads:
		if road.kind == Plan.ALLEY:
			if layout.distance_to_road(p, road) < road.width * 0.5 + 0.25:
				return false
			continue
		if layout.distance_to_road(p, road) < road.width * 0.5 + margin:
			return false
	return true


func _arch(from: Dictionary, to: Dictionary, here: Dictionary, alley: Dictionary, yard: Rect2) -> void:
	var y := Plan.RAIL_HEIGHT
	var centre_a: Vector2
	var centre_b: Vector2
	for side in [-1.0, 1.0]:
		if not (from.has(side) and to.has(side)):
			continue
		var a: Vector2 = from[side]
		var b: Vector2 = to[side]
		var mid := (a + b) * 0.5
		var over_alley: bool = alley.distance.call(mid - Layout.left_of(here.dir) * PIER * side) < 1.2
		if over_alley:
			# The alley runs under the deck: each side's arch is walled in with a
			# lock-up or a tiny bar facing the alley. Leave the yard side open.
			if yard.has_point(mid + (mid - (here.point)).normalized() * 0.5):
				continue
			_alley_wall(a, b, side, here)
		else:
			# Normal stretch: a little shop fills the arch from pier line to pier
			# line, facing out on the side away from the track centre.
			if side < 0.0:
				continue
			if not (from.has(-1.0) and to.has(-1.0)):
				continue
			_open_arch(from, to, here)


func _alley_wall(a: Vector2, b: Vector2, side: float, here: Dictionary) -> void:
	var length := a.distance_to(b) - 0.8
	if length < 1.0:
		return
	var mid := (a + b) * 0.5
	var along := (b - a).normalized()
	# Facing into the alley.
	var inward := -Layout.left_of(here.dir) * side
	var yaw := Layout.yaw_facing(inward)
	var xform := Transform3D(Basis(Vector3.UP, yaw), Kit.v3(mid, 0))
	var unit := kit.node(root, "UnderTracks", xform)
	var colour := Color(["4a3a3a", "3d3a4a", "4a4236", "38404a"][rng.randi() % 4])
	var wall := kit.wall(colour, Vector3(length, 6.0, 0.5), float(rng.randi_range(0, 300)), 0.3, Color("ffb870"), Color("ffb870"), Vector2(2.4, 3.0), 3.4)
	wall.set_shader_parameter(&"see_through", true)
	kit.mesh(unit, "Infill", kit.box(Vector3(length, y_of(), 0.5), wall, 0.05), Transform3D(Basis(), Vector3(0, y_of() * 0.5, -0.1)))
	kit.shape(alley_walls, "Infill", xform * Transform3D(Basis(), Vector3(0, y_of() * 0.5, -0.1)), Vector3(length, y_of(), 0.5))
	var roll := rng.randf()
	if roll < 0.45:
		# A tiny bar: noren curtain, a lantern, warm light.
		var light := Color("ffcf8a")
		kit.mesh(unit, "BarWindow", kit.box(Vector3(length * 0.6, 1.6, 0.06), kit.toy(light.darkened(0.25), 1.2, 0.2)), Transform3D(Basis(), Vector3(-length * 0.1, 1.4, 0.17)), false)
		var curtain := Color(["1d3557", "8e2430", "2a2d3a"][rng.randi() % 3])
		for k in 3:
			kit.add_box(unit, "Noren", Vector3(length * 0.32 + (k - 1) * 0.36, 1.9, 0.22), Vector3(0.32, 0.7, 0.03), kit.toy(curtain, 0.1, 0.9), 0, false, 50.0)
		kit.mesh(unit, "Lantern", kit.capsule(0.2, 0.2, 0.55, kit.glow(Color("ff4f5e"), 2.4)), Transform3D(Basis(), Vector3(length * 0.32, 2.65, 0.35)), false)
		var jp: String = Plan.JP_SIGNS[rng.randi() % Plan.JP_SIGNS.size()]
		kit.label(unit, "Sign", jp, Transform3D(Basis(), Vector3(-length * 0.1, 2.75, 0.22)), 0.5, Color(2.2, 1.6, 1.1), true, rng.randf() < 0.2)
		if rng.randf() < 0.6:
			kit.omni(unit, "BarLight", Vector3(0, 2.2, 1.4), light, 0.8, 5.0)
			light_count += 1
	elif roll < 0.8:
		# Lock-up with a shutter and a buzzing lamp.
		kit.add_box(unit, "Shutter", Vector3(0, 1.4, 0.17), Vector3(length * 0.7, 2.8, 0.06), kit.toy(Color("6e7280"), 0, 0.5, 0.2, 0.3))
		kit.mesh(unit, "Lamp", kit.sphere(0.12, kit.glow(Color("dff3ff"), 3.0)), Transform3D(Basis(), Vector3(length * 0.42, 3.1, 0.3)), false)
		if rng.randf() < 0.5:
			kit.label(unit, "Graffiti", ["MEOW", "BASS", "SLIDE", "HUSH", "LOUD"][rng.randi() % 5], Transform3D(Basis(), Vector3(-length * 0.1, 1.5, 0.21)), 0.8, Color(Plan.NEON_COLORS[rng.randi() % Plan.NEON_COLORS.size()]), false)
	# Pipes and an AC unit on the wall above.
	if rng.randf() < 0.5:
		kit.add_box(unit, "AirCon", Vector3(length * 0.25, 3.8, 0.45), Vector3(0.9, 0.6, 0.6), kit.toy(Color("8d93a8"), 0, 0.6), 0, true, 60.0)
	kit.add_box(unit, "Pipe", Vector3(-length * 0.45, 3.5, 0.25), Vector3(0.12, 7.0 - 0.5, 0.12), kit.toy(Color("4f525d"), 0, 0.5, 0.2, 0.4), 0, true, 60.0)


func y_of() -> float:
	return Plan.RAIL_HEIGHT - 0.45


## Away from Cat Alley the arches stay open: a lamp hung under the deck,
## planters and a bench or a bike rack between the piers, so the space under
## the tracks reads as a lit walkway instead of a row of boxes.
func _open_arch(from: Dictionary, to: Dictionary, here: Dictionary) -> void:
	var a: Vector2 = (from[-1.0] + from[1.0]) * 0.5
	var b: Vector2 = (to[-1.0] + to[1.0]) * 0.5
	var mid := (a + b) * 0.5
	var length := a.distance_to(b)
	if length < 3.0:
		return
	var along := (b - a).normalized()
	var n := Layout.left_of(here.dir)
	var xform := Transform3D(Basis(Vector3.UP, Layout.yaw_facing(along)), Kit.v3(mid, 0))
	var arch := kit.node(root, "UnderTracks", xform)
	_arch_index += 1
	var iron := kit.toy(Color("2d2c38"), 0, 0.55, 0.2, 0.2)
	# A pendant lamp from the deck, every arch; a real light every other one.
	var y := Plan.RAIL_HEIGHT - 0.45
	kit.mesh(arch, "LampCord", kit.cyl(0.02, 0.02, 2.4, iron, 4), Transform3D(Basis(), Vector3(0, y - 1.2, 0)), false, 90.0)
	kit.mesh(arch, "LampShade", kit.cyl(0.08, 0.42, 0.32, kit.toy(Color("1f6f6a"), 0.1, 0.5)), Transform3D(Basis(), Vector3(0, y - 2.5, 0)))
	kit.mesh(arch, "LampBulb", kit.sphere(0.16, kit.glow(Color("ffd9a0"), 4.0)), Transform3D(Basis(), Vector3(0, y - 2.68, 0)), false)
	if _arch_index % 2 == 0:
		kit.omni(arch, "Light", Vector3(0, y - 3.0, 0), Color("ffcf8a"), 1.1, 9.0)
		light_count += 1
	# In the park (north of Creek Lane's back gardens) the path runs under here.
	if streets == null or mid.y < -11.0:
		return
	# Between the piers on each side: planters, a bench or a bike rack.
	for side in [-1.0, 1.0]:
		var p: Vector2 = mid + n * PIER * side
		if not _clear_of_roads(p, 1.2):
			continue
		var face := Layout.yaw_facing(n * side)
		var roll := (_arch_index * 3 + (1 if side > 0 else 0)) % 4
		var spot := Transform3D(Basis(Vector3.UP, face), Kit.v3(p))
		match roll:
			0, 2:
				_planter(spot, length - 1.6)
			1:
				streets.bench(spot.translated_local(Vector3(0, 0, 0.3)))
				_planter(spot.translated_local(Vector3((length - 1.6) * 0.5 - 0.45, 0, -0.3)), 0.8)
			3:
				for k in 3:
					streets._bike(Transform3D(Basis(Vector3.UP, face + PI * 0.5), Kit.v3(p) + Kit.v3(along) * (k - 1) * 0.8))


## A long planter box with bushes and flowers in it.
func _planter(xform: Transform3D, length: float) -> void:
	var box := kit.node(root, "Planter", xform)
	var concrete := kit.toy(Color("6a6878"), 0, 0.85, 0.2)
	kit.add_box(box, "Box", Vector3(0, 0.3, 0), Vector3(length, 0.6, 0.8), concrete)
	kit.add_box(box, "Soil", Vector3(0, 0.58, 0), Vector3(length - 0.15, 0.06, 0.65), kit.toy(Color("2b2220"), 0, 0.95))
	kit.shape(solid, "Planter", xform * Transform3D(Basis(), Vector3(0, 0.3, 0)), Vector3(length, 0.6, 0.8))
	var count := maxi(1, int(length / 1.1))
	for k in count:
		var x := -length * 0.5 + (k + 0.5) * length / count
		var at := xform * Vector3(x, 0.6, 0)
		if k % 2 == 0:
			streets.bush(at, 0.75)
		else:
			streets.flower_bed(at, 0.8)


func _under_track_unit(from: Dictionary, to: Dictionary, here: Dictionary) -> void:
	var a: Vector2 = (from[-1.0] + from[1.0]) * 0.5
	var b: Vector2 = (to[-1.0] + to[1.0]) * 0.5
	var mid := (a + b) * 0.5
	var length := a.distance_to(b) - 0.9
	if length < 2.0:
		return
	# Which side faces open ground? Prefer the side with a road nearby.
	var n := Layout.left_of(here.dir)
	var face := 1.0
	var near_a := layout.nearest_road(mid + n * 6.0)
	var near_b := layout.nearest_road(mid - n * 6.0)
	if near_b[1] < near_a[1]:
		face = -1.0
	var yaw := Layout.yaw_facing(n * face)
	var xform := Transform3D(Basis(Vector3.UP, yaw), Kit.v3(mid, 0))
	var unit := kit.node(root, "UnderTracks", xform)
	var depth := PIER * 2.0 - 0.6
	var colour := Color(["4a3a3a", "3d3a4a", "4a4236", "38404a", "5a3b36"][rng.randi() % 5])
	kit.mesh(unit, "Box", kit.box(Vector3(length, 3.6, depth), kit.wall(colour, Vector3(length, 3.6, depth), float(rng.randi_range(0, 300)), 0.0), 0.08), Transform3D(Basis(), Vector3(0, 1.8, 0)))
	kit.shape(solid, "Unit", xform * Transform3D(Basis(), Vector3(0, 1.8, 0)), Vector3(length, 3.6, depth))
	var light := Color(["ffcf8a", "ffd1e8", "c9f0ff"][rng.randi() % 3])
	kit.mesh(unit, "Front", kit.box(Vector3(length - 1.2, 2.0, 0.06), kit.toy(light.darkened(0.25), 1.2, 0.2)), Transform3D(Basis(), Vector3(0.3, 1.35, depth * 0.5 + 0.04)), false)
	var jp: String = Plan.JP_SIGNS[rng.randi() % Plan.JP_SIGNS.size()]
	kit.label(unit, "Sign", jp, Transform3D(Basis(), Vector3(0, 3.0, depth * 0.5 + 0.1)), 0.55, Color(2.2, 1.5, 1.0), true, rng.randf() < 0.15)
	kit.mesh(unit, "Lantern", kit.capsule(0.2, 0.2, 0.55, kit.glow(Color("ff4f5e"), 2.4)), Transform3D(Basis(), Vector3(-length * 0.5 + 0.6, 2.6, depth * 0.5 + 0.35)), false, 90.0)
	doors.append({"at": xform * Vector3(-length * 0.5 + 0.8, 0, depth * 0.5 + 0.9), "style": "neon"})
	if rng.randf() < 0.4:
		kit.omni(unit, "Light", Vector3(0, 2.3, depth * 0.5 + 1.4), light, 0.8, 5.5)
		light_count += 1
