extends RefCounted
## The creek behind the starting house: a hidden strip of green between the
## back gardens and the edge of town. A stream winds through it from a little
## waterfall pool in the west, past the house (the log you write songs on),
## under the railway viaduct, to a culvert in the east.
##
##   house bank    the old log seat, stepping stones over to the shrine
##   shrine        a torii gate and a tiny shrine with stone lanterns
##   pool          the waterfall, a jetty and a second seat: the quietest
##                 spot in the city, lit by fireflies
##   footbridge    east of the tracks, with a path up between the houses to
##                 Creek Lane (and another in from the end of Mill Road)
##
## Everything here is rebuilt on every run of the city builder: the Creek node
## is emptied except for its Seat (the log's song-writing spot), which keeps
## its place.

const Plan := preload("res://tools/city/plan.gd")
const Layout := preload("res://tools/city/layout.gd")
const Kit := preload("res://tools/city/kit.gd")
const Ground := preload("res://tools/city/ground.gd")

const SEAT_SCRIPT := preload("res://world/seat.gd")
const WATER_SOUND := preload("res://audio/ambience/creek.ogg")
const WATER_SHADER := preload("res://world/water.gdshader")
const FALL_SHADER := preload("res://world/waterfall.gdshader")

## Centre line of the stream, west (pool) to east (culvert).
const STREAM := [Vector2(-33, -33.5), Vector2(-24, -30), Vector2(-14, -26.5), Vector2(-4, -24.6), Vector2(6, -24.4),
		Vector2(17, -26.5), Vector2(28, -29.5), Vector2(40, -31), Vector2(54, -36), Vector2(66, -41), Vector2(74, -44)]
const POOL := Vector2(-39, -37)
const POOL_RADIUS := 7.5
const FALL_AT := Vector2(-45.5, -43.5)
## Where you can get across: stepping stones by the house, the footbridge.
const STONES_X := -6.0
const BRIDGE_X := 34.0
## Paths, as control points (smoothed).
const TRAILS := [
	# Back garden gate down to the log.
	[Vector2(4.5, -11.0), Vector2(3.6, -15.5), Vector2(2.4, -18.0)],
	# Along the south bank: pool clearing - house bank - under the tracks - footbridge.
	[Vector2(-33, -28.5), Vector2(-24, -25.6), Vector2(-14, -22.2), Vector2(-6, -21.2), Vector2(2, -20.6),
			Vector2(12, -21.2), Vector2(20, -22.5), Vector2(28, -25.0), Vector2(34, -26.4)],
	# Over the stepping stones to the shrine.
	[Vector2(-6, -21.2), Vector2(-6.3, -25.0), Vector2(-6.2, -29.5), Vector2(-6, -34.5)],
	# Footbridge, then up the gap between the houses to Creek Lane.
	[Vector2(34, -36.0), Vector2(34, -30.5), Vector2(34, -26.4), Vector2(37, -18), Vector2(38, -9), Vector2(38, 2), Vector2(38, 11.5)],
	# In from the turning circle at the end of Mill Road.
	[Vector2(-53, -10.5), Vector2(-50, -17), Vector2(-44, -24), Vector2(-36, -28.4), Vector2(-33, -28.5)],
	# Round the pool to the jetty.
	[Vector2(-33, -28.5), Vector2(-35.5, -30.2)],
]

var kit: Kit
var layout: Layout
var streets
var city: Node3D
var root: Node3D
var solid: StaticBody3D
var rng := RandomNumberGenerator.new()
var light_count := 0
## Smoothed stream line and its half width at each point.
var stream := PackedVector2Array()
var halves := PackedFloat32Array()
var trails: Array[PackedVector2Array] = []


func _init(the_kit: Kit, the_layout: Layout, the_streets, the_city: Node3D) -> void:
	kit = the_kit
	layout = the_layout
	streets = the_streets
	city = the_city
	rng.seed = 2207
	stream = Layout.smooth(PackedVector2Array(STREAM), 2.0)
	for p in stream:
		# Narrow by the house, wider and lazier downstream.
		halves.append(lerpf(1.7, 2.6, clampf((p.x - 0.0) / 60.0, 0.0, 1.0)) + 0.4 * sin(p.x * 0.21))
	for t in TRAILS:
		trails.append(Layout.smooth(PackedVector2Array(t), 1.5))


func build() -> void:
	root = city.get_node("Creek")
	for child in root.get_children():
		if child.name != "Seat":
			root.remove_child(child)
			child.free()
	solid = StaticBody3D.new()
	solid.name = "CreekSolid"
	solid.collision_mask = 0
	root.add_child(solid)
	solid.owner = kit.owner
	_ground()
	_water()
	_waterfall()
	_trails()
	_stepping_stones()
	_footbridge()
	_house_bank()
	_shrine()
	_pool_clearing()
	_culvert()
	_planting()
	_fireflies()
	_sounds()


## Water outlines for the minimap.
func water_polygons() -> Array:
	var outline := PackedVector2Array()
	var back := PackedVector2Array()
	for i in stream.size():
		var n := Layout.left_of(Layout.direction_at(stream, i))
		outline.append(stream[i] + n * halves[i])
		back.append(stream[i] - n * halves[i])
	back.reverse()
	outline.append_array(back)
	return [outline, Ground.disc_polygon(POOL, POOL_RADIUS, 32)]


# --- ground and water ---------------------------------------------------------

func _ground() -> void:
	var grass := kit.ground({"color": Color(0.13, 0.27, 0.2), "patch_color": Color(0.105, 0.225, 0.17), "patch_size": 5.0,
			"dot_density": 0.06, "dot_spacing": 0.6, "dot_radius": 0.035, "dot_color": Color(0.75, 0.8, 0.72), "dot_color_b": Color(0.85, 0.75, 0.45),
			"wetness": 0.35})
	var poly: PackedVector2Array = Layout.rect_polygon(_reserved("creek"))
	kit.mesh(root, "Grass", Ground.polygon_mesh(poly, -0.008, grass), Transform3D.IDENTITY, false)
	# Muddy, pebbly banks.
	var bank := kit.ground({"color": Color(0.24, 0.21, 0.2), "patch_color": Color(0.19, 0.17, 0.17), "patch_size": 1.5,
			"dot_density": 0.5, "dot_spacing": 0.35, "dot_radius": 0.06, "dot_color": Color(0.45, 0.43, 0.48), "dot_color_b": Color(0.34, 0.32, 0.36),
			"wetness": 1.0, "puddle_size": 1.2})
	kit.mesh(root, "Bank", _strip(stream, halves, 1.1, 0.0, bank), Transform3D.IDENTITY, false)
	kit.mesh(root, "PoolBank", Ground.polygon_mesh(Ground.disc_polygon(POOL, POOL_RADIUS + 1.3, 40), 0.001, bank), Transform3D.IDENTITY, false)


func _water() -> void:
	var water := ShaderMaterial.new()
	water.shader = WATER_SHADER
	water.set_shader_parameter(&"flow", Vector2(0.45, 0.08))
	kit.mesh(root, "Stream", _strip(stream, halves, 0.0, 0.03, water), Transform3D.IDENTITY, false)
	var still := ShaderMaterial.new()
	still.shader = WATER_SHADER
	still.set_shader_parameter(&"flow", Vector2(0.06, 0.1))
	still.set_shader_parameter(&"deep", Color(0.03, 0.08, 0.13))
	kit.mesh(root, "Pool", Ground.polygon_mesh(Ground.disc_polygon(POOL, POOL_RADIUS, 40), 0.032, still), Transform3D.IDENTITY, false)
	# You can paddle at the edges, but not wade across: the deep middle is solid,
	# except at the stepping stones and the footbridge.
	for i in range(1, stream.size()):
		var a := stream[i - 1]
		var b := stream[i]
		var mid := (a + b) * 0.5
		if absf(mid.x - STONES_X) < 1.8 or absf(mid.x - BRIDGE_X) < 2.2 or mid.distance_to(POOL) < POOL_RADIUS - 0.5:
			continue
		var width := (halves[i - 1] + halves[i]) - 1.0
		var xform := Kit.yawed(Layout.yaw_facing(b - a), Kit.v3(mid, 0.6))
		kit.shape(solid, "Water", xform, Vector3(width, 1.2, a.distance_to(b) + 0.3))
	# The pool's deep part (the jetty reaches out over the shallow south-east side).
	kit.cyl_shape(solid, "Pool", Kit.v3(POOL + Vector2(-1.2, -1.8), 0.6), POOL_RADIUS - 2.2, 1.2)
	var glow := kit.omni(root, "PoolGlow", Kit.v3(POOL, 1.0), Color(0.43, 0.85, 0.91), 0.9, 10.0)
	glow.light_specular = 0.3
	kit.omni(root, "WaterGlow", Vector3(-2, 1.2, -24.4), Color(0.43, 0.85, 0.91), 0.7, 9.0)
	light_count += 2


func _waterfall() -> void:
	var rock := kit.toy(Color("3d3b4a"), 0, 0.9, 0.35)
	var moss := kit.toy(Color("2c4a35"), 0, 0.95, 0.5)
	var cliff := kit.node(root, "Waterfall", Kit.yawed(Layout.yaw_facing(POOL - FALL_AT), Kit.v3(FALL_AT)))
	# A heap of big rounded boulders, the lip in the middle.
	var boulders := [[Vector3(-4.2, 1.6, -1.2), Vector3(4.5, 3.4, 3.8)], [Vector3(4.0, 1.4, -1.0), Vector3(4.2, 3.0, 3.6)],
			[Vector3(-2.2, 3.4, -2.2), Vector3(3.6, 3.2, 3.4)], [Vector3(2.3, 3.2, -2.0), Vector3(3.4, 3.0, 3.2)],
			[Vector3(0, 1.9, -3.0), Vector3(3.0, 3.8, 3.0)], [Vector3(-6.8, 1.0, 0.5), Vector3(3.2, 2.0, 3.0)],
			[Vector3(6.6, 0.9, 0.6), Vector3(3.0, 1.8, 2.8)], [Vector3(0, 4.6, -3.2), Vector3(5.0, 1.6, 3.0)]]
	for b in boulders:
		var size: Vector3 = b[1]
		kit.mesh(cliff, "Boulder", kit.box(size, rock, 0.9, 3), Transform3D(Basis(Vector3.UP, rng.randf_range(-0.3, 0.3)), b[0]))
		kit.mesh(cliff, "Moss", kit.box(Vector3(size.x * 0.8, 0.25, size.z * 0.7), moss, 0.12, 2), Transform3D(Basis(), b[0] + Vector3(0, size.y * 0.5, 0)), false)
		kit.shape(solid, "Cliff", cliff.transform * Transform3D(Basis(), b[0]), size * 0.92)
	# The sheet of falling water, from the lip down into the pool.
	var fall := ShaderMaterial.new()
	fall.shader = FALL_SHADER
	var sheet := QuadMesh.new()
	sheet.size = Vector2(2.2, 5.0)
	sheet.material = fall
	kit.mesh(cliff, "Fall", sheet, Transform3D(Basis(Vector3.RIGHT, -0.12), Vector3(0, 2.55, -0.55)), false)
	var spray := kit.toy(Color(0.75, 0.9, 1.0), 0.6, 0.3, 0.6)
	for i in 7:
		var x := rng.randf_range(-1.3, 1.3)
		kit.mesh(cliff, "Foam", kit.sphere(rng.randf_range(0.3, 0.55), spray, 0.35), Transform3D(Basis(), Vector3(x, 0.08, rng.randf_range(-0.2, 0.9))), false)
	kit.omni(cliff, "FallLight", Vector3(0, 1.4, 1.6), Color(0.5, 0.85, 1.0), 1.4, 9.0)
	light_count += 1


# --- paths and crossings ------------------------------------------------------

func _trails() -> void:
	var gravel := kit.ground({"color": Color(0.36, 0.32, 0.3), "patch_color": Color(0.31, 0.28, 0.27), "patch_size": 1.2,
			"dot_density": 0.6, "dot_spacing": 0.25, "dot_radius": 0.045, "dot_color": Color(0.5, 0.47, 0.5), "dot_color_b": Color(0.42, 0.38, 0.36),
			"wetness": 0.7, "puddle_size": 1.0})
	for i in trails.size():
		var line := trails[i]
		var half := PackedFloat32Array()
		half.resize(line.size())
		half.fill(0.85)
		kit.mesh(root, "Trail", _strip(line, half, 0.0, 0.006 + i * 0.0005, gravel), Transform3D.IDENTITY, false)


func _stepping_stones() -> void:
	var stone := kit.toy(Color("6b6878"), 0, 0.85, 0.4)
	var at := _stream_at_x(STONES_X)
	var across := Layout.left_of(at.dir)
	for k in range(-3, 4):
		var p: Vector2 = at.point + across * (k * 0.75) + at.dir * (0.25 if k % 2 == 0 else -0.25)
		kit.mesh(root, "SteppingStone", kit.cyl(0.42, 0.48, 0.16, stone, 10, 0.06), Transform3D(Basis(Vector3.UP, rng.randf() * TAU), Kit.v3(p, 0.06)))


func _footbridge() -> void:
	var at := _stream_at_x(BRIDGE_X)
	var wood := kit.toy(Color("7a5236"), 0, 0.85, 0.3)
	var dark := kit.toy(Color("4e3424"), 0, 0.85, 0.3)
	var bridge := kit.node(root, "Footbridge", Kit.yawed(Layout.yaw_facing(Layout.left_of(at.dir)), Kit.v3(at.point)))
	var length := halves[at.index] * 2.0 + 3.0
	for k in int(length / 0.42):
		var z := -length * 0.5 + 0.21 + k * 0.42
		kit.add_box(bridge, "Plank", Vector3(0, 0.08, z), Vector3(1.9, 0.07, 0.36), wood if k % 3 else dark, rng.randf_range(-0.04, 0.04))
	for x in [-1.0, 1.0]:
		kit.add_box(bridge, "Beam", Vector3(x * 0.85, 0.02, 0), Vector3(0.16, 0.1, length), dark)
		for k in 4:
			var z := -length * 0.5 + 0.3 + k * (length - 0.6) / 3.0
			kit.add_box(bridge, "Post", Vector3(x * 1.0, 0.5, z), Vector3(0.1, 0.9, 0.1), dark)
		kit.add_box(bridge, "Rail", Vector3(x * 1.0, 0.95, 0), Vector3(0.08, 0.08, length - 0.4), wood)
		kit.shape(solid, "BridgeRail", bridge.transform * Transform3D(Basis(), Vector3(x * 1.05, 0.6, 0)), Vector3(0.12, 1.2, length - 0.4))
	_lantern_post(Kit.v3(at.point + Layout.left_of(at.dir) * (length * 0.5 + 0.2) + at.dir * 1.3))


# --- places -------------------------------------------------------------------

func _house_bank() -> void:
	# The log the song-writing seat sits on (the Seat node itself is kept).
	var seat := root.get_node_or_null("Seat") as Node3D
	if seat == null:
		seat = Node3D.new()
		seat.name = "Seat"
		seat.set_script(SEAT_SCRIPT)
		root.add_child(seat)
		seat.owner = kit.owner
		seat.set("seat_height", 0.46)
		seat.set("prompt", "sit by the creek")
		seat.set("radius", 1.5)
	seat.transform = Transform3D(Basis(), Vector3(2.2, 0, -19.4))
	var bark := kit.toy(Color("5b3d2b"), 0, 0.9, 0.35)
	var ring := kit.toy(Color("a07a52"), 0, 0.9, 0.35)
	kit.mesh(root, "Log", kit.cyl(0.3, 0.3, 2.0, bark, 10), Transform3D(Basis(Vector3.FORWARD, PI * 0.5), Vector3(2.2, 0.24, -19.4)))
	for side in [-1.0, 1.0]:
		kit.mesh(root, "LogEnd", kit.cyl(0.27, 0.27, 0.02, ring, 10), Transform3D(Basis(Vector3.FORWARD, PI * 0.5), Vector3(2.2 + side * 1.0, 0.24, -19.4)))
	kit.shape(solid, "Log", Transform3D(Basis(), Vector3(2.2, 0.24, -19.4)), Vector3(2.0, 0.48, 0.5))
	_lantern_post(Vector3(3.7, 0, -19.1))
	# The back garden gate.
	var fence := kit.toy(Color("e8dcc8"), 0.05, 0.8, 0.3)
	for x in [3.6, 5.4]:
		kit.add_box(root, "GatePost", Vector3(x, 0.6, -11.2), Vector3(0.14, 1.2, 0.14), fence)
	kit.add_box(root, "Gate", Vector3(4.0, 0.55, -11.55), Vector3(0.9, 0.8, 0.05), fence, 0.7)


func _shrine() -> void:
	var red := kit.toy(Color("c8323c"), 0.1, 0.7, 0.3)
	var black := kit.toy(Color("26222c"), 0, 0.7, 0.3)
	var stone := kit.toy(Color("7a7684"), 0, 0.9, 0.4)
	var wood := kit.toy(Color("8a6446"), 0, 0.85, 0.3)
	# Torii on the north bank, where the stepping stones come out.
	var torii := kit.node(root, "Torii", Kit.yawed(0.0, Vector3(-6.1, 0, -29.8)))
	for x in [-1.5, 1.5]:
		kit.mesh(torii, "Pillar", kit.cyl(0.16, 0.14, 3.4, red, 10), Transform3D(Basis(), Vector3(x, 1.7, 0)))
		kit.mesh(torii, "Foot", kit.cyl(0.21, 0.21, 0.3, black, 10), Transform3D(Basis(), Vector3(x, 0.15, 0)))
		kit.cyl_shape(solid, "Torii", torii.transform * Vector3(x, 1.7, 0), 0.18, 3.4)
	kit.add_box(torii, "Kasagi", Vector3(0, 3.55, 0), Vector3(4.4, 0.24, 0.36), black)
	kit.add_box(torii, "Shimaki", Vector3(0, 3.35, 0), Vector3(4.0, 0.2, 0.3), red)
	kit.add_box(torii, "Nuki", Vector3(0, 2.75, 0), Vector3(3.6, 0.16, 0.18), red)
	# The shrine itself: a tiny house on a stone plinth.
	var shrine := kit.node(root, "Shrine", Kit.yawed(0.0, Vector3(-6, 0, -37.5)))
	kit.add_box(shrine, "Plinth", Vector3(0, 0.25, 0), Vector3(2.8, 0.5, 2.4), stone)
	kit.add_box(shrine, "Hall", Vector3(0, 1.15, -0.1), Vector3(1.8, 1.3, 1.5), wood)
	kit.add_box(shrine, "Doors", Vector3(0, 1.1, 0.66), Vector3(1.2, 1.0, 0.04), kit.toy(Color("e8d9b8"), 0.6, 0.8, 0.3))
	var roof := PrismMesh.new()
	roof.size = Vector3(2.5, 0.9, 2.6)
	roof.material = black
	kit.mesh(shrine, "Roof", roof, Transform3D(Basis(Vector3.UP, PI * 0.5), Vector3(0, 2.25, -0.1)))
	kit.add_box(shrine, "OfferingBox", Vector3(0, 0.7, 1.05), Vector3(0.8, 0.4, 0.4), wood)
	kit.label(shrine, "Ema", "願", Transform3D(Basis(), Vector3(0, 1.2, 0.69)), 0.4, Color(0.6, 0.15, 0.15), true)
	kit.shape(solid, "Shrine", shrine.transform * Transform3D(Basis(), Vector3(0, 1.1, 0)), Vector3(2.8, 2.2, 2.4))
	# A straw rope with paper streamers across the front.
	kit.mesh(shrine, "Rope", kit.cyl(0.06, 0.06, 1.9, kit.toy(Color("d9c48a"), 0.1), 8), Transform3D(Basis(Vector3.FORWARD, PI * 0.5), Vector3(0, 1.85, 0.75)))
	for x in [-0.5, 0.0, 0.5]:
		kit.add_box(shrine, "Shide", Vector3(x, 1.65, 0.76), Vector3(0.1, 0.3, 0.01), kit.toy(Color("f4f1e8"), 0.4))
	for x in [-2.4, 2.4]:
		_stone_lantern(Vector3(-6 + x, 0, -35.0))
	var bench_at := Transform3D(Basis(Vector3.UP, PI), Vector3(-9.5, 0, -33.0))
	streets.bench(bench_at)


func _pool_clearing() -> void:
	# A jetty out over the shallow side of the pool, facing the waterfall.
	var wood := kit.toy(Color("7a5236"), 0, 0.85, 0.3)
	var dark := kit.toy(Color("4e3424"), 0, 0.85, 0.3)
	var from := Vector2(-34.6, -30.6)
	var to := Vector2(-36.6, -33.4)
	var dir := (to - from).normalized()
	var jetty := kit.node(root, "Jetty", Kit.yawed(Layout.yaw_facing(dir), Kit.v3((from + to) * 0.5)))
	var length := from.distance_to(to) + 1.6
	for k in int(length / 0.4):
		kit.add_box(jetty, "Plank", Vector3(0, 0.07, -length * 0.5 + 0.2 + k * 0.4), Vector3(1.8, 0.06, 0.34), wood if k % 4 else dark, rng.randf_range(-0.03, 0.03))
	for corner in [Vector3(-0.85, 0, -length * 0.5), Vector3(0.85, 0, -length * 0.5), Vector3(-0.85, 0, length * 0.5), Vector3(0.85, 0, length * 0.5)]:
		kit.mesh(jetty, "Pile", kit.cyl(0.1, 0.1, 0.7, dark, 8), Transform3D(Basis(), corner + Vector3(0, 0.2, 0)))
	# The seat at the end: a cushion on a crate, looking at the falls.
	var end := to + dir * 0.3
	var face := FALL_AT - end
	var yaw := atan2(-face.x, -face.y)
	var crate := kit.node(root, "PoolCrate", Kit.yawed(yaw, Kit.v3(end)))
	kit.add_box(crate, "Crate", Vector3(0, 0.21, 0.45), Vector3(0.7, 0.32, 0.5), wood)
	kit.add_box(crate, "Cushion", Vector3(0, 0.4, 0.45), Vector3(0.62, 0.08, 0.44), kit.toy(Color("c8506e"), 0.1, 0.9, 0.6))
	var seat := Node3D.new()
	seat.name = "PoolSeat"
	seat.set_script(SEAT_SCRIPT)
	root.add_child(seat)
	seat.owner = kit.owner
	seat.transform = Kit.yawed(yaw, Kit.v3(end + Vector2(sin(yaw), cos(yaw)) * 0.45))
	seat.set("seat_height", 0.44)
	seat.set("prompt", "sit by the waterfall")
	seat.set("radius", 1.4)
	# String lights between two trees over the clearing, and a lantern or two.
	var t1 := Vector3(-30.5, 0, -32.5)
	var t2 := Vector3(-36.0, 0, -26.8)
	streets.tree(t1, 1.3, 0)
	streets.tree(t2, 1.2, 1)
	_bulb_string(t1 + Vector3(0, 3.0, 0), t2 + Vector3(0, 3.0, 0), 9, Color("ffd59a"))
	_lantern_post(Vector3(-31.5, 0, -27.5))
	# A guitar case and an old radio someone left on the bank.
	kit.add_box(root, "GuitarCase", Vector3(-33.2, 0.1, -30.3), Vector3(0.38, 0.18, 1.05), kit.toy(Color("2b2635"), 0, 0.6), 0.4)
	kit.add_box(root, "Radio", Vector3(-32.5, 0.15, -29.4), Vector3(0.5, 0.3, 0.2), kit.toy(Color("b8643c"), 0.05, 0.7), -0.2)
	# Lily pads with a few glowing flowers.
	var pad := kit.toy(Color("2f6b45"), 0, 0.9, 0.5)
	var flower := kit.glow(Color("ff9ec4"), 1.6)
	for i in 14:
		var a := rng.randf() * TAU
		var r := rng.randf_range(2.0, POOL_RADIUS - 0.8)
		var p := POOL + Vector2(cos(a), sin(a)) * r
		if p.distance_to(to) < 2.0 or p.distance_to(FALL_AT) < 4.0:
			continue
		kit.mesh(root, "LilyPad", kit.cyl(0.38, 0.38, 0.02, pad, 10, 0.0), Transform3D(Basis(Vector3.UP, a), Kit.v3(p, 0.045)), false)
		if i % 3 == 0:
			kit.mesh(root, "Lily", kit.sphere(0.09, flower), Transform3D(Basis(), Kit.v3(p, 0.11)), false)


func _culvert() -> void:
	# The stream leaves town through a tunnel in a concrete wall.
	var concrete := kit.toy(Color("4a4856"), 0, 0.9, 0.3)
	var at := stream[stream.size() - 1]
	var dir := Layout.direction_at(stream, stream.size() - 1)
	var wall := kit.node(root, "Culvert", Kit.yawed(Layout.yaw_facing(dir), Kit.v3(at)))
	kit.add_box(wall, "Wall", Vector3(0, 2.0, 1.0), Vector3(22, 4.0, 1.2), concrete)
	kit.shape(solid, "Culvert", wall.transform * Transform3D(Basis(), Vector3(0, 2.0, 1.0)), Vector3(22, 4.0, 1.2))
	kit.add_box(wall, "Mouth", Vector3(0, 1.0, 0.38), Vector3(4.6, 2.0, 0.05), kit.toy(Color("0c0b12")))
	kit.add_box(wall, "Lintel", Vector3(0, 2.15, 0.35), Vector3(5.2, 0.3, 0.12), concrete)
	for x in [-1.8, -0.9, 0.0, 0.9, 1.8]:
		kit.add_box(wall, "Bar", Vector3(x, 1.0, 0.3), Vector3(0.07, 2.0, 0.07), kit.toy(Color("6b5a4a"), 0, 0.6, 0.2, 0.3))
	kit.label(wall, "Tag", "LOAD IN", Transform3D(Basis(), Vector3(-6.5, 1.9, 0.38)), 0.9, Color(1.0, 0.45, 0.75), false)
	kit.label(wall, "Tag", "川", Transform3D(Basis(), Vector3(6.0, 2.3, 0.38)), 1.2, Color(0.5, 0.95, 0.85), true)


func _planting() -> void:
	var clear_spots := [Vector2(2.2, -19.4), Vector2(-6, -36), Vector2(-6, -30), POOL, FALL_AT, Vector2(-33, -29.5), Vector2(-9.5, -33.0)]
	var creek_poly: PackedVector2Array = Layout.rect_polygon(_reserved("creek"))
	var placed := 0
	var tries := 0
	while placed < 70 and tries < 1500:
		tries += 1
		var p := Vector2(rng.randf_range(-78, 72), rng.randf_range(-50, -14))
		if not Geometry2D.is_point_in_polygon(p, creek_poly):
			continue
		if _gap_to_water(p) < 2.6 or _gap_to_trails(p) < 2.2 or absf(p.x - _rail_x(p.y)) < 5.0:
			continue
		var crowded := false
		for c in clear_spots:
			if p.distance_to(c) < 4.5:
				crowded = true
		if crowded:
			continue
		streets.tree(Kit.v3(p), rng.randf_range(0.9, 1.5), rng.randi() % 2)
		clear_spots.append(p)
		placed += 1
	# Reeds and rocks along the water's edge.
	var reed := kit.toy(Color("4f6b3a"), 0, 0.95, 0.5)
	var rush := kit.toy(Color("5b3d2b"), 0, 0.9, 0.4)
	var rock := kit.toy(Color("57546a"), 0, 0.9, 0.4)
	for i in range(2, stream.size() - 1, 2):
		var n := Layout.left_of(Layout.direction_at(stream, i))
		for side in [-1.0, 1.0]:
			var p: Vector2 = stream[i] + n * side * (halves[i] + rng.randf_range(0.0, 0.7))
			if absf(p.x - STONES_X) < 2.0 or absf(p.x - BRIDGE_X) < 2.5 or _gap_to_trails(p) < 1.0:
				continue
			if rng.randf() < 0.55:
				_reeds(p, reed, rush)
			elif rng.randf() < 0.6:
				var s := rng.randf_range(0.25, 0.6)
				kit.mesh(root, "Rock", kit.sphere(s, rock, s * 1.1), Transform3D(Basis(Vector3.UP, rng.randf() * TAU), Kit.v3(p, s * 0.2)))
	for i in 16:
		var a := TAU * i / 16.0 + rng.randf_range(-0.1, 0.1)
		var p := POOL + Vector2(cos(a), sin(a)) * (POOL_RADIUS + rng.randf_range(0.0, 0.8))
		if p.distance_to(Vector2(-34.6, -30.6)) < 2.0:
			continue
		if i % 2 == 0:
			_reeds(p, reed, rush)
		else:
			var s := rng.randf_range(0.35, 0.8)
			kit.mesh(root, "Rock", kit.sphere(s, rock, s * 1.1), Transform3D(Basis(Vector3.UP, rng.randf() * TAU), Kit.v3(p, s * 0.2)))
	# A sign at each way in.
	_way_sign(Vector3(-53.5, 0, -12.0), 0.3, "CREEK PATH")
	_way_sign(Vector3(39.6, 0, 10.5), PI, "CREEK PATH")


func _fireflies() -> void:
	var mat := StandardMaterial3D.new()
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.albedo_color = Color(1.0, 0.95, 0.5)
	mat.emission_enabled = true
	mat.emission = Color(1.0, 0.9, 0.4)
	mat.emission_energy_multiplier = 3.0
	mat.vertex_color_use_as_albedo = true
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	var dot := SphereMesh.new()
	dot.radius = 0.035
	dot.height = 0.07
	dot.radial_segments = 6
	dot.rings = 3
	dot.material = mat
	var fade := Gradient.new()
	fade.offsets = PackedFloat32Array([0.0, 0.2, 0.45, 0.6, 0.8, 1.0])
	fade.colors = PackedColorArray([Color(1, 1, 1, 0), Color(1, 1, 1, 1), Color(1, 1, 1, 0.2), Color(1, 1, 1, 1), Color(1, 1, 1, 0.3), Color(1, 1, 1, 0)])
	for spot in [[Vector3(-37, 1.2, -34), Vector3(9, 1.0, 8), 60], [Vector3(1, 1.0, -23), Vector3(14, 0.8, 5), 40],
			[Vector3(-6, 1.3, -34), Vector3(7, 1.0, 6), 30], [Vector3(30, 1.1, -29), Vector3(12, 0.9, 6), 30]]:
		var p := CPUParticles3D.new()
		p.name = kit.name_for(root, "Fireflies")
		p.position = spot[0]
		p.amount = spot[2]
		p.lifetime = 7.0
		p.preprocess = 7.0
		p.mesh = dot
		p.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
		p.emission_box_extents = spot[1]
		p.direction = Vector3(0, 0.3, 0)
		p.spread = 180.0
		p.gravity = Vector3.ZERO
		p.initial_velocity_min = 0.05
		p.initial_velocity_max = 0.25
		p.damping_min = 0.0
		p.damping_max = 0.05
		p.color_ramp = fade
		p.visibility_aabb = AABB(-Vector3(spot[1]) - Vector3.ONE * 2.0, Vector3(spot[1]) * 2.0 + Vector3.ONE * 4.0)
		root.add_child(p)
		p.owner = kit.owner


func _sounds() -> void:
	var near_house := AudioStreamPlayer3D.new()
	near_house.name = "WaterSound"
	near_house.stream = WATER_SOUND
	near_house.position = Vector3(1, 0.3, -23.6)
	near_house.volume_db = -5.0
	near_house.unit_size = 4.0
	near_house.max_distance = 24.0
	near_house.autoplay = true
	near_house.bus = &"Ambience"
	root.add_child(near_house)
	near_house.owner = kit.owner
	var falls := near_house.duplicate() as AudioStreamPlayer3D
	falls.name = "FallSound"
	falls.position = Kit.v3(FALL_AT + (POOL - FALL_AT) * 0.3, 1.0)
	falls.volume_db = 0.0
	falls.pitch_scale = 0.8
	falls.unit_size = 6.0
	falls.max_distance = 34.0
	root.add_child(falls)
	falls.owner = kit.owner
	var east := near_house.duplicate() as AudioStreamPlayer3D
	east.name = "StreamSound"
	east.position = Vector3(34, 0.3, -29.0)
	east.pitch_scale = 1.1
	root.add_child(east)
	east.owner = kit.owner


# --- bits ---------------------------------------------------------------------

func _lantern_post(at: Vector3) -> void:
	var post := kit.node(root, "LanternPost", Kit.yawed(0.0, at))
	kit.mesh(post, "Post", kit.cyl(0.05, 0.05, 1.7, kit.toy(Color("3a2c22")), 6), Transform3D(Basis(), Vector3(0, 0.85, 0)))
	kit.mesh(post, "Lantern", kit.cyl(0.14, 0.12, 0.3, kit.glow(Color("ffcf8a"), 2.6), 8), Transform3D(Basis(), Vector3(0, 1.85, 0)), false)
	kit.mesh(post, "Cap", kit.cyl(0.2, 0.05, 0.12, kit.toy(Color("2b2a36")), 8), Transform3D(Basis(), Vector3(0, 2.06, 0)))
	kit.omni(post, "Light", Vector3(0, 1.9, 0), Color("ffc27a"), 1.0, 6.5)
	kit.cyl_shape(solid, "Post", at + Vector3(0, 0.85, 0), 0.08, 1.7)
	light_count += 1


func _stone_lantern(at: Vector3) -> void:
	var stone := kit.toy(Color("7a7684"), 0, 0.9, 0.4)
	var l := kit.node(root, "StoneLantern", Kit.yawed(0.0, at))
	kit.add_box(l, "Base", Vector3(0, 0.15, 0), Vector3(0.6, 0.3, 0.6), stone)
	kit.mesh(l, "Shaft", kit.cyl(0.12, 0.12, 0.8, stone, 8), Transform3D(Basis(), Vector3(0, 0.7, 0)))
	kit.add_box(l, "Box", Vector3(0, 1.3, 0), Vector3(0.45, 0.4, 0.45), stone)
	kit.add_box(l, "Glow", Vector3(0, 1.3, 0), Vector3(0.47, 0.22, 0.2), kit.glow(Color("ffcf8a"), 2.4), 0, false)
	var roof := PrismMesh.new()
	roof.size = Vector3(0.8, 0.3, 0.8)
	roof.material = stone
	kit.mesh(l, "Roof", roof, Transform3D(Basis(), Vector3(0, 1.65, 0)))
	kit.omni(l, "Light", Vector3(0, 1.3, 0.4), Color("ffc27a"), 0.8, 5.0)
	kit.cyl_shape(solid, "StoneLantern", at + Vector3(0, 0.8, 0), 0.3, 1.6)
	light_count += 1


func _bulb_string(a: Vector3, b: Vector3, count: int, colour: Color) -> void:
	var bulb := kit.glow(colour, 4.0)
	for i in count:
		var t := (i + 0.5) / count
		var p := a.lerp(b, t) + Vector3.DOWN * sin(PI * t) * 0.6
		kit.mesh(root, "Bulb", kit.sphere(0.08, bulb), Transform3D(Basis(), p), false)
	kit.omni(root, "StringGlow", (a + b) * 0.5 + Vector3.DOWN * 0.8, colour, 0.9, 8.0)
	light_count += 1


func _reeds(p: Vector2, reed: Material, rush: Material) -> void:
	var clump := kit.node(root, "Reeds", Kit.yawed(rng.randf() * TAU, Kit.v3(p)))
	for k in 5:
		var h := rng.randf_range(0.6, 1.2)
		var tilt := Basis(Vector3(rng.randf_range(-1, 1), 0, rng.randf_range(-1, 1)).normalized(), rng.randf_range(0.0, 0.25))
		var at := Vector3(rng.randf_range(-0.25, 0.25), h * 0.5, rng.randf_range(-0.25, 0.25))
		kit.mesh(clump, "Blade", kit.cyl(0.03, 0.01, h, reed, 5, 0.0), Transform3D(tilt, at), false, 60.0)
		if k == 0:
			kit.mesh(clump, "Rush", kit.capsule(0.05, 0.05, 0.22, rush), Transform3D(tilt, at + tilt * Vector3(0, h * 0.5, 0)), false, 60.0)


func _way_sign(at: Vector3, yaw: float, text: String) -> void:
	var s := kit.node(root, "WaySign", Kit.yawed(yaw, at))
	var wood := kit.toy(Color("6b4a32"), 0, 0.85, 0.3)
	kit.add_box(s, "Post", Vector3(0, 0.75, 0), Vector3(0.1, 1.5, 0.1), wood)
	kit.add_box(s, "Board", Vector3(0.35, 1.3, 0), Vector3(1.2, 0.3, 0.05), wood)
	kit.label(s, "Text", text, Transform3D(Basis(), Vector3(0.35, 1.3, 0.03)), 0.16, Color(1.0, 0.92, 0.75))
	var back := kit.label(s, "Text", text, Transform3D(Basis(Vector3.UP, PI), Vector3(0.35, 1.3, -0.03)), 0.16, Color(1.0, 0.92, 0.75))
	back.name = "TextBack"
	kit.cyl_shape(solid, "Sign", at + Vector3(0, 0.75, 0), 0.08, 1.5)


# A strip whose half width varies along the line (`grow` added to every
# half width).
func _strip(line: PackedVector2Array, half: PackedFloat32Array, grow: float, y: float, material: Material) -> ArrayMesh:
	var verts := PackedVector3Array()
	var uvs := PackedVector2Array()
	var normals := PackedVector3Array()
	var indices := PackedInt32Array()
	var along := 0.0
	for i in line.size():
		if i > 0:
			along += line[i - 1].distance_to(line[i])
		var n := Layout.left_of(Layout.direction_at(line, i))
		var w := half[i] + grow
		verts.append(Kit.v3(line[i] + n * w, y))
		verts.append(Kit.v3(line[i] - n * w, y))
		uvs.append(Vector2(along, w))
		uvs.append(Vector2(along, -w))
		normals.append(Vector3.UP)
		normals.append(Vector3.UP)
		if i > 0:
			var k := i * 2
			indices.append_array([k - 2, k, k - 1, k - 1, k, k + 1])
	return Ground._array_mesh(verts, normals, uvs, indices, material)


# The stream point nearest to x, with its direction.
func _stream_at_x(x: float) -> Dictionary:
	var best := 0
	for i in stream.size():
		if absf(stream[i].x - x) < absf(stream[best].x - x):
			best = i
	return {"point": stream[best], "dir": Layout.direction_at(stream, best), "index": best}


func _gap_to_water(p: Vector2) -> float:
	var best := p.distance_to(POOL) - POOL_RADIUS
	for i in range(1, stream.size()):
		var c := Geometry2D.get_closest_point_to_segment(p, stream[i - 1], stream[i])
		best = minf(best, p.distance_to(c) - halves[i])
	return best


func _gap_to_trails(p: Vector2) -> float:
	var best := INF
	for line in trails:
		best = minf(best, Layout.distance_to_line(p, line))
	return best


# X of the railway viaduct at depth z (the track runs roughly north-south here).
func _rail_x(z: float) -> float:
	var rail: Array = Plan.RAILWAY
	for i in range(1, rail.size()):
		var a: Vector2 = rail[i - 1]
		var b: Vector2 = rail[i]
		if z >= a.y and z <= b.y:
			return lerpf(a.x, b.x, (z - a.y) / (b.y - a.y))
	return 14.0


func _reserved(what: String) -> Dictionary:
	for spec in Plan.RESERVED:
		if spec.what == what:
			return spec
	return {}
