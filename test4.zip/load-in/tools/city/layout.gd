extends RefCounted
## Works the city plan (plan.gd) out into exact geometry: smooth road centre
## lines, an occupancy grid of what stands where, and building lots along
## the streets. Shared by the builder and nothing at runtime.

const Plan := preload("res://tools/city/plan.gd")

const CELL := 0.5
const FREE := 0
const ROAD := 1
const RESERVED := 2
const BUILDING := 3
const RAIL := 4
const WALL := 5

## One entry per road: {name, kind, width, style, area, points (PackedVector2Array),
## nodes ({junction name: index into points}), end_circle}.
var roads: Array[Dictionary] = []
## Junction name -> [[road index, point index], ...]
var junctions := {}
var rail := PackedVector2Array()
## Every building lot: {centre: Vector2, size: Vector2 (x across the front, y deep),
## yaw, height, style, front (true = faces a street), road, shop}
var lots: Array[Dictionary] = []

var rng := RandomNumberGenerator.new()
var grid := PackedByteArray()
var grid_w := 0
var grid_h := 0
var origin := Vector2.ZERO


func _init() -> void:
	rng.seed = 20261009
	origin = Plan.BOUNDS.position
	grid_w = int(Plan.BOUNDS.size.x / CELL)
	grid_h = int(Plan.BOUNDS.size.y / CELL)
	grid.resize(grid_w * grid_h)
	_make_roads()
	rail = smooth(PackedVector2Array(Plan.RAILWAY), 4.0)


# --- geometry helpers --------------------------------------------------------

## A smooth curve (centripetal Catmull-Rom) through every point, sampled about
## every `step` metres. The control points are kept exactly.
static func smooth(control: PackedVector2Array, step := 3.0) -> PackedVector2Array:
	var out := PackedVector2Array()
	var n := control.size()
	for i in n - 1:
		var p0 := control[maxi(i - 1, 0)]
		var p1 := control[i]
		var p2 := control[i + 1]
		var p3 := control[mini(i + 2, n - 1)]
		if i == 0:
			p0 = p1 - (p2 - p1)
		if i + 2 > n - 1:
			p3 = p2 + (p2 - p1)
		var count := maxi(int(ceil(p1.distance_to(p2) / step)), 1)
		for k in count:
			out.append(_catmull(p0, p1, p2, p3, float(k) / count))
	out.append(control[n - 1])
	return out


static func _catmull(p0: Vector2, p1: Vector2, p2: Vector2, p3: Vector2, t: float) -> Vector2:
	# Centripetal parameterisation: no loops or overshoot at uneven spacing.
	var t0 := 0.0
	var t1 := t0 + pow(p0.distance_to(p1), 0.5)
	var t2 := t1 + pow(p1.distance_to(p2), 0.5)
	var t3 := t2 + pow(p2.distance_to(p3), 0.5)
	if t1 - t0 < 0.0001 or t2 - t1 < 0.0001 or t3 - t2 < 0.0001:
		return p1.lerp(p2, t)
	var tt := lerpf(t1, t2, t)
	var a1 := p0 * (t1 - tt) / (t1 - t0) + p1 * (tt - t0) / (t1 - t0)
	var a2 := p1 * (t2 - tt) / (t2 - t1) + p2 * (tt - t1) / (t2 - t1)
	var a3 := p2 * (t3 - tt) / (t3 - t2) + p3 * (tt - t2) / (t3 - t2)
	var b1 := a1 * (t2 - tt) / (t2 - t0) + a2 * (tt - t0) / (t2 - t0)
	var b2 := a2 * (t3 - tt) / (t3 - t1) + a3 * (tt - t1) / (t3 - t1)
	return b1 * (t2 - tt) / (t2 - t1) + b2 * (tt - t1) / (t2 - t1)


static func length_of(line: PackedVector2Array) -> float:
	var total := 0.0
	for i in range(1, line.size()):
		total += line[i - 1].distance_to(line[i])
	return total


## Point and direction `along` metres down a polyline.
static func at_distance(line: PackedVector2Array, along: float) -> Dictionary:
	for i in range(1, line.size()):
		var length := line[i - 1].distance_to(line[i])
		if along <= length or i == line.size() - 1:
			var t := clampf(along / maxf(length, 0.0001), 0.0, 1.0)
			return {"point": line[i - 1].lerp(line[i], t), "dir": (line[i] - line[i - 1]).normalized(), "index": i}
		along -= length
	return {"point": line[line.size() - 1], "dir": Vector2.RIGHT, "index": line.size() - 1}


## Smoothed direction at point i of a polyline.
static func direction_at(line: PackedVector2Array, i: int) -> Vector2:
	var a := line[maxi(i - 1, 0)]
	var b := line[mini(i + 1, line.size() - 1)]
	return (b - a).normalized()


## Left of the direction of travel (x east, z south: facing +x, left is -z).
static func left_of(direction: Vector2) -> Vector2:
	return Vector2(direction.y, -direction.x)


static func distance_to_line(p: Vector2, line: PackedVector2Array) -> float:
	var best := INF
	for i in range(1, line.size()):
		best = minf(best, p.distance_to(Geometry2D.get_closest_point_to_segment(p, line[i - 1], line[i])))
	return best


## The yaw (radians) that turns a node's +z to face `direction`.
static func yaw_facing(direction: Vector2) -> float:
	return atan2(direction.x, direction.y)


static func rect_corners(centre: Vector2, size: Vector2, yaw: float) -> PackedVector2Array:
	# Local x = across, local z (Vector2.y) = depth; rotated by yaw like a Node3D.
	var ax := Vector2(cos(yaw), -sin(yaw))
	var az := Vector2(sin(yaw), cos(yaw))
	var hx := ax * size.x * 0.5
	var hz := az * size.y * 0.5
	return PackedVector2Array([centre - hx - hz, centre + hx - hz, centre + hx + hz, centre - hx + hz])


# --- roads -------------------------------------------------------------------

func _make_roads() -> void:
	for spec in Plan.ROADS:
		var control := PackedVector2Array()
		var names := {}
		for p in spec.points:
			if p is String:
				names[p] = control.size()
				control.append(Plan.NODES[p])
			else:
				control.append(p)
		var step := 2.5 if spec.kind == Plan.ALLEY or spec.kind == Plan.PATH else 3.0
		# Sample each span separately so junctions stay exact points.
		var points := PackedVector2Array()
		var nodes := {}
		var full := smooth(control, step)
		# Find the control points again in the sampled line.
		var cursor := 0
		for name in names:
			var target: Vector2 = Plan.NODES[name]
			for j in range(cursor, full.size()):
				if full[j].distance_to(target) < 0.001:
					nodes[name] = j
					cursor = j
					break
		points = full
		var road := {"name": spec.name, "kind": spec.kind, "width": spec.width, "style": spec.style,
				"area": spec.get("area", ""), "points": points, "nodes": nodes, "end_circle": spec.get("end_circle", 0.0)}
		roads.append(road)
		for name in nodes:
			if not junctions.has(name):
				junctions[name] = []
			junctions[name].append([roads.size() - 1, nodes[name]])


## Half the width plus the pavement: how far buildings stay from the centre line.
static func clearance(road: Dictionary) -> float:
	match road.kind:
		Plan.AVENUE: return road.width * 0.5 + 2.6
		Plan.STREET: return road.width * 0.5 + 2.2
		Plan.LANE: return road.width * 0.5 + 1.8
		Plan.ALLEY: return road.width * 0.5 + 0.3
	return road.width * 0.5 + 0.2


func distance_to_road(p: Vector2, road: Dictionary) -> float:
	return distance_to_line(p, road.points)


## Nearest road (index) and the distance to its centre line.
func nearest_road(p: Vector2, drivable_only := false) -> Array:
	var best := -1
	var best_distance := INF
	for i in roads.size():
		if drivable_only and roads[i].kind == Plan.PATH:
			continue
		var d := distance_to_road(p, roads[i])
		if d < best_distance:
			best_distance = d
			best = i
	return [best, best_distance]


# --- occupancy grid ----------------------------------------------------------

func cell_of(p: Vector2) -> Vector2i:
	return Vector2i(int(floor((p.x - origin.x) / CELL)), int(floor((p.y - origin.y) / CELL)))


func cell_centre(c: Vector2i) -> Vector2:
	return origin + (Vector2(c) + Vector2(0.5, 0.5)) * CELL


func get_cell(c: Vector2i) -> int:
	if c.x < 0 or c.y < 0 or c.x >= grid_w or c.y >= grid_h:
		return WALL
	return grid[c.y * grid_w + c.x]


func set_cell(c: Vector2i, value: int) -> void:
	if c.x < 0 or c.y < 0 or c.x >= grid_w or c.y >= grid_h:
		return
	grid[c.y * grid_w + c.x] = value


func value_at(p: Vector2) -> int:
	return get_cell(cell_of(p))


## Mark everything within `radius` of a polyline (only cells that are free or
## of a lower priority than `value`).
func paint_line(line: PackedVector2Array, radius: float, value: int) -> void:
	for i in range(1, line.size()):
		var a := line[i - 1]
		var b := line[i]
		var lo := cell_of(Vector2(minf(a.x, b.x) - radius, minf(a.y, b.y) - radius))
		var hi := cell_of(Vector2(maxf(a.x, b.x) + radius, maxf(a.y, b.y) + radius))
		for cy in range(lo.y, hi.y + 1):
			for cx in range(lo.x, hi.x + 1):
				var c := Vector2i(cx, cy)
				var centre := cell_centre(c)
				if centre.distance_to(Geometry2D.get_closest_point_to_segment(centre, a, b)) <= radius:
					_mark(c, value)


func paint_disc(centre: Vector2, radius: float, value: int) -> void:
	var lo := cell_of(centre - Vector2(radius, radius))
	var hi := cell_of(centre + Vector2(radius, radius))
	for cy in range(lo.y, hi.y + 1):
		for cx in range(lo.x, hi.x + 1):
			var c := Vector2i(cx, cy)
			if cell_centre(c).distance_to(centre) <= radius:
				_mark(c, value)


func paint_polygon(polygon: PackedVector2Array, value: int) -> void:
	var lo := Vector2(INF, INF)
	var hi := Vector2(-INF, -INF)
	for p in polygon:
		lo = lo.min(p)
		hi = hi.max(p)
	var clo := cell_of(lo)
	var chi := cell_of(hi)
	for cy in range(clo.y, chi.y + 1):
		for cx in range(clo.x, chi.x + 1):
			var c := Vector2i(cx, cy)
			if Geometry2D.is_point_in_polygon(cell_centre(c), polygon):
				_mark(c, value)


# Roads win over everything, then walls, reserved ground, rail, buildings.
const _PRIORITY := {FREE: 0, BUILDING: 1, RAIL: 2, RESERVED: 3, WALL: 4, ROAD: 5}

func _mark(c: Vector2i, value: int) -> void:
	var now := get_cell(c)
	if c.x < 0 or c.y < 0 or c.x >= grid_w or c.y >= grid_h:
		return
	if _PRIORITY[value] >= _PRIORITY[now]:
		set_cell(c, value)


## True if every cell under the polygon is free.
func polygon_is_free(polygon: PackedVector2Array, allowed := [FREE]) -> bool:
	var lo := Vector2(INF, INF)
	var hi := Vector2(-INF, -INF)
	for p in polygon:
		lo = lo.min(p)
		hi = hi.max(p)
	var clo := cell_of(lo)
	var chi := cell_of(hi)
	for cy in range(clo.y, chi.y + 1):
		for cx in range(clo.x, chi.x + 1):
			var c := Vector2i(cx, cy)
			if Geometry2D.is_point_in_polygon(cell_centre(c), polygon) and not (get_cell(c) in allowed):
				return false
	return true


static func rect_polygon(spec: Dictionary) -> PackedVector2Array:
	if spec.has("polygon"):
		return PackedVector2Array(spec.polygon)
	var r: Array = spec.rect
	return rect_corners(r[0], r[1], deg_to_rad(r[2]) if r.size() > 2 else 0.0)


func paint_plan() -> void:
	for road in roads:
		paint_line(road.points, clearance(road), ROAD)
		if road.end_circle > 0.0:
			paint_disc(road.points[road.points.size() - 1], road.end_circle + 2.0, ROAD)
	for spec in Plan.RESERVED:
		paint_polygon(rect_polygon(spec), RESERVED)
	for gated in Plan.GATED:
		var polygon := PackedVector2Array(gated.polygon)
		for i in polygon.size():
			paint_line(PackedVector2Array([polygon[i], polygon[(i + 1) % polygon.size()]]), 1.2, WALL)
	paint_line(rail, Plan.RAIL_WIDTH * 0.5 + 0.9, RAIL)


# --- building lots -------------------------------------------------------------

## Lots along both sides of every street, facing it.
func place_frontage() -> void:
	# Busy streets first: they get the corners.
	var order := range(roads.size())
	order.sort_custom(func(a: int, b: int) -> bool: return _rank(roads[a]) < _rank(roads[b]))
	for r in order:
		var road: Dictionary = roads[r]
		for side in 2:
			var style_name: String = road.style[side]
			if style_name == "":
				continue
			_frontage(r, road, side, style_name)


func _rank(road: Dictionary) -> int:
	return {Plan.AVENUE: 1, Plan.STREET: 0, Plan.LANE: 2, Plan.ALLEY: 3, Plan.PATH: 4}[road.kind]


func _frontage(r: int, road: Dictionary, side: int, style_name: String) -> void:
	var style: Dictionary = Plan.STYLES[style_name]
	var line: PackedVector2Array = road.points
	var total := length_of(line)
	var sign := 1.0 if side == 0 else -1.0
	var along := rng.randf_range(0.0, 3.0)
	while along < total - 3.0:
		var width := rng.randf_range(style.width[0], style.width[1])
		var mid := at_distance(line, along + width * 0.5)
		var normal: Vector2 = left_of(mid.dir) * sign
		var setback := rng.randf_range(style.setback[0], style.setback[1])
		var placed := false
		var depth := rng.randf_range(style.depth[0], style.depth[1])
		for attempt in 5:
			var off: float = road.width * 0.5 + setback + depth * 0.5
			var centre: Vector2 = mid.point + normal * off
			var yaw := yaw_facing(-normal)
			var corners := rect_corners(centre, Vector2(width, depth), yaw)
			if polygon_is_free(corners):
				# Room behind? Go deeper, so blocks fill up from the street.
				var deepest: float = style.depth[1] * 1.7
				while depth + 2.0 <= deepest:
					var deeper := depth + 2.0
					var c2: Vector2 = mid.point + normal * (road.width * 0.5 + setback + deeper * 0.5)
					var k2 := rect_corners(c2, Vector2(width, deeper), yaw)
					if not polygon_is_free(rect_corners(c2, Vector2(width, deeper + 1.5), yaw)):
						break
					depth = deeper
					centre = c2
					corners = k2
				_add_lot(centre, Vector2(width, depth), yaw, style_name, true, r)
				paint_polygon(corners, BUILDING)
				placed = true
				break
			# Squeeze it: shallower, then narrower.
			if attempt % 2 == 0:
				depth *= 0.75
			else:
				width *= 0.8
				mid = at_distance(line, along + width * 0.5)
				normal = left_of(mid.dir) * sign
			if depth < 4.0 or width < 3.5:
				break
		if placed:
			along += width + 0.15
			if rng.randf() < style.gap:
				along += rng.randf_range(2.0, 5.0)
		else:
			along += 1.5


## Fill what is left inside the blocks with plainer buildings, lined up with
## the nearest street, leaving yards and passages between them.
func place_backfill(step := 4.5, scale := 1.0) -> void:
	var z := Plan.BOUNDS.position.y + 2.0
	while z < Plan.BOUNDS.end.y - 2.0:
		var x := Plan.BOUNDS.position.x + 2.0
		while x < Plan.BOUNDS.end.x - 2.0:
			var p := Vector2(x + rng.randf_range(-2.0, 2.0), z + rng.randf_range(-2.0, 2.0))
			if value_at(p) == FREE:
				_try_backfill(p, scale)
			x += step
		z += step


func _try_backfill(p: Vector2, scale := 1.0) -> void:
	var near := nearest_road(p, true)
	if near[0] < 0:
		return
	var road: Dictionary = roads[near[0]]
	var style_name: String = road.style[0] if road.style[0] != "" else (road.style[1] if road.style[1] != "" else "back")
	if _in_gated(p) != "" and _in_gated(p) != road.area:
		style_name = "uptown" if _in_gated(p) == "uptown" else ("harbour" if _in_gated(p) == "harbour" else style_name)
	var style: Dictionary = Plan.STYLES[style_name]
	var closest := _closest_dir(p, road.points)
	var yaw := yaw_facing(closest)
	var size := Vector2(rng.randf_range(style.width[0], style.width[1] * 1.3), rng.randf_range(style.depth[0], style.depth[1] * 1.3)) * scale
	for attempt in 4:
		var corners := rect_corners(p, size + Vector2(1.2, 1.2), yaw)
		if polygon_is_free(corners):
			_add_lot(p, size, yaw, style_name, false, near[0])
			paint_polygon(rect_corners(p, size, yaw), BUILDING)
			return
		size *= 0.8
		if size.x < 3.5 or size.y < 3.5:
			return


func _closest_dir(p: Vector2, line: PackedVector2Array) -> Vector2:
	var best := INF
	var dir := Vector2.DOWN
	for i in range(1, line.size()):
		var c := Geometry2D.get_closest_point_to_segment(p, line[i - 1], line[i])
		var d := c.distance_to(p)
		if d < best:
			best = d
			dir = (p - c).normalized() if d > 0.01 else left_of((line[i] - line[i - 1]).normalized())
	# Face the street: the front points from the building back to the road.
	return -dir


func _in_gated(p: Vector2) -> String:
	for gated in Plan.GATED:
		if Geometry2D.is_point_in_polygon(p, PackedVector2Array(gated.polygon)):
			return gated.area
	return ""


func _add_lot(centre: Vector2, size: Vector2, yaw: float, style_name: String, front: bool, road: int) -> void:
	var style: Dictionary = Plan.STYLES[style_name]
	var height := rng.randf_range(style.height[0], style.height[1])
	if not front:
		height *= rng.randf_range(0.9, 1.35)
	lots.append({"centre": centre, "size": size, "yaw": yaw, "height": height, "style": style_name,
			"front": front, "road": road, "shop": front and rng.randf() < style.shop, "seed": rng.randi()})


func area_of(p: Vector2) -> String:
	return _in_gated(p)
