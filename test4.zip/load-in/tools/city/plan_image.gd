extends RefCounted
## Draws the city plan as a picture: the minimap's base layer
## (ui/minimap/city_map.png), and a handy overview while editing the plan.
## Drawn at twice the size and shrunk, for smooth edges.

const Plan := preload("res://tools/city/plan.gd")
const Layout := preload("res://tools/city/layout.gd")

const BACKGROUND := Color("12111c")
const BLOCK := Color("1d1b2c")
const BUILDING := Color("2e2b45")
const GREEN := Color("16352a")
const WATER := Color("173a5c")
const PAVED := Color("252335")
const ROAD := Color("6f6c8f")
const AVENUE := Color("8c88b0")
const ALLEY := Color("4d4a68")
const PATH := Color("3e3b55")
const RAIL := Color("53506e")

var layout: Layout
var scale := 4.0   # pixels per metre while drawing
var image: Image


func _init(the_layout: Layout) -> void:
	layout = the_layout


## `metres_per_pixel` of the finished picture.
## `trails` = footpath centre lines that are not roads (the creek paths).
func draw(metres_per_pixel: float, water: Array, greens: Array, paved: Array, trails := []) -> Image:
	scale = 2.0 / metres_per_pixel
	var size := Vector2i(Plan.BOUNDS.size * scale)
	image = Image.create(size.x, size.y, false, Image.FORMAT_RGBA8)
	image.fill(BACKGROUND)
	_fill_rect(Plan.BOUNDS, BLOCK)
	for polygon in paved:
		_fill_polygon(polygon, PAVED)
	for polygon in greens:
		_fill_polygon(polygon, GREEN)
	for polygon in water:
		_fill_polygon(polygon, WATER)
	for lot in layout.lots:
		_fill_polygon(Layout.rect_corners(lot.centre, lot.size, lot.yaw), BUILDING)
	for line in trails:
		_stroke(line, 0.9, PATH)
	_stroke(layout.rail, 1.6, RAIL)
	for road in layout.roads:
		var colour := ROAD
		match road.kind:
			Plan.AVENUE: colour = AVENUE
			Plan.ALLEY: colour = ALLEY
			Plan.PATH: colour = PATH
		_stroke(road.points, road.width * 0.5, colour)
		if road.end_circle > 0.0:
			_disc(road.points[road.points.size() - 1], road.end_circle, colour)
	image.resize(size.x / 2, size.y / 2, Image.INTERPOLATE_BILINEAR)
	return image


func _px(p: Vector2) -> Vector2:
	return (p - Plan.BOUNDS.position) * scale


func _fill_rect(rect: Rect2, colour: Color) -> void:
	image.fill_rect(Rect2i(_px(rect.position), rect.size * scale), colour)


func _fill_polygon(polygon: PackedVector2Array, colour: Color) -> void:
	var px := PackedVector2Array()
	var lo := Vector2(INF, INF)
	var hi := Vector2(-INF, -INF)
	for p in polygon:
		var q := _px(p)
		px.append(q)
		lo = lo.min(q)
		hi = hi.max(q)
	for y in range(maxi(int(lo.y), 0), mini(int(hi.y) + 1, image.get_height())):
		for x in range(maxi(int(lo.x), 0), mini(int(hi.x) + 1, image.get_width())):
			if Geometry2D.is_point_in_polygon(Vector2(x + 0.5, y + 0.5), px):
				image.set_pixel(x, y, colour)


func _stroke(line: PackedVector2Array, radius_m: float, colour: Color) -> void:
	var radius := radius_m * scale
	for i in range(1, line.size()):
		var a := _px(line[i - 1])
		var b := _px(line[i])
		var lo := a.min(b) - Vector2(radius, radius)
		var hi := a.max(b) + Vector2(radius, radius)
		for y in range(maxi(int(lo.y), 0), mini(int(hi.y) + 1, image.get_height())):
			for x in range(maxi(int(lo.x), 0), mini(int(hi.x) + 1, image.get_width())):
				var p := Vector2(x + 0.5, y + 0.5)
				if p.distance_to(Geometry2D.get_closest_point_to_segment(p, a, b)) <= radius:
					image.set_pixel(x, y, colour)


func _disc(centre_m: Vector2, radius_m: float, colour: Color) -> void:
	var c := _px(centre_m)
	var r := radius_m * scale
	for y in range(maxi(int(c.y - r), 0), mini(int(c.y + r) + 1, image.get_height())):
		for x in range(maxi(int(c.x - r), 0), mini(int(c.x + r) + 1, image.get_width())):
			if Vector2(x + 0.5, y + 0.5).distance_to(c) <= r:
				image.set_pixel(x, y, colour)
