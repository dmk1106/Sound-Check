extends RefCounted
## Paint on the ground: paving everywhere, roads as strips that follow their
## curves (with kerbs, gutters and centre lines), junctions, zebra crossings,
## turning circles, lawns and plazas. All flat, all on one ground collider.

const Plan := preload("res://tools/city/plan.gd")
const Layout := preload("res://tools/city/layout.gd")
const Kit := preload("res://tools/city/kit.gd")

var kit: Kit
var layout: Layout
var root: Node3D

## Junction name -> {"centre": Vector2, "radius": float, "arms": [{road, dir, point, width}]}
var junctions := {}
## Zebra crossings: {"centre": Vector2, "across": Vector2 (unit), "half": float, "junction": name}
var crossings: Array[Dictionary] = []

const ASPHALT := {"color": Color(0.231, 0.243, 0.306), "patch_color": Color(0.2, 0.212, 0.275), "patch_size": 2.0, "wetness": 1.0}


func _init(the_kit: Kit, the_layout: Layout, parent: Node3D) -> void:
	kit = the_kit
	layout = the_layout
	root = parent


func build() -> void:
	_find_junctions()
	_base()
	for r in layout.roads.size():
		_road(r)
	for name in junctions:
		_junction(name)
	_crossings()


func _base() -> void:
	var paving := kit.ground({"color": Color(0.38, 0.365, 0.43), "patch_color": Color(0.335, 0.32, 0.385), "patch_size": 3.0,
			"tile_size": Vector2(2, 2), "tile_gap": 0.04, "gap_darkness": 0.25, "tile_variation": 0.05, "wetness": 0.75, "puddle_size": 2.5})
	var plane := PlaneMesh.new()
	plane.size = Plan.BOUNDS.size + Vector2(80, 80)
	plane.material = paving
	kit.mesh(root, "Paving", plane, Transform3D(Basis(), Kit.v3(Plan.BOUNDS.get_center(), -0.02)), false)


func material_for(road: Dictionary) -> ShaderMaterial:
	var half: float = road.width * 0.5
	match road.kind:
		Plan.AVENUE:
			return kit.ground(ASPHALT.merged({"lane_line": 4, "lane_color": Color(1.0, 0.8, 0.35), "gutter_width": 0.7, "half_width": half}))
		Plan.STREET:
			return kit.ground(ASPHALT.merged({"lane_line": 3, "lane_color": Color(1, 0.914, 0.659), "gutter_width": 0.6, "half_width": half}))
		Plan.LANE:
			return kit.ground(ASPHALT.merged({"color": Color(0.25, 0.25, 0.31), "patch_color": Color(0.21, 0.21, 0.27), "gutter_width": 0.5, "half_width": half}))
		Plan.ALLEY:
			return kit.ground({"color": Color(0.29, 0.275, 0.32), "patch_color": Color(0.247, 0.231, 0.282), "patch_size": 2.0,
					"tile_size": Vector2(0.6, 0.6), "tile_gap": 0.03, "gap_darkness": 0.3, "tile_variation": 0.1, "tile_stagger": 0.5,
					"wetness": 1.0, "puddle_size": 2.2})
	# Footpath: warm stone flags.
	return kit.ground({"color": Color(0.42, 0.36, 0.34), "patch_color": Color(0.37, 0.31, 0.3), "patch_size": 2.0,
			"tile_size": Vector2(0.9, 0.45), "tile_gap": 0.03, "gap_darkness": 0.35, "tile_variation": 0.12, "tile_stagger": 0.5,
			"wetness": 0.9, "puddle_size": 1.6})


## A strip of quads along a centre line. UV.x = metres along, UV.y = metres from the centre.
static func strip_mesh(line: PackedVector2Array, half: float, y: float, material: Material) -> ArrayMesh:
	var verts := PackedVector3Array()
	var uvs := PackedVector2Array()
	var normals := PackedVector3Array()
	var indices := PackedInt32Array()
	var along := 0.0
	for i in line.size():
		if i > 0:
			along += line[i - 1].distance_to(line[i])
		var n := Layout.left_of(Layout.direction_at(line, i))
		# Keep the width true round bends (mitre), within reason.
		var a := Layout.direction_at(line, maxi(i - 1, 0))
		var b := Layout.direction_at(line, mini(i + 1, line.size() - 1))
		var mitre := 1.0 / maxf(cos(a.angle_to(b) * 0.5), 0.7)
		verts.append(Kit.v3(line[i] + n * half * mitre, y))
		verts.append(Kit.v3(line[i] - n * half * mitre, y))
		uvs.append(Vector2(along, half))
		uvs.append(Vector2(along, -half))
		normals.append(Vector3.UP)
		normals.append(Vector3.UP)
		if i > 0:
			var k := i * 2
			indices.append_array([k - 2, k - 1, k, k - 1, k + 1, k])
	return _array_mesh(verts, normals, uvs, indices, material)


static func polygon_mesh(polygon: PackedVector2Array, y: float, material: Material) -> ArrayMesh:
	var verts := PackedVector3Array()
	var uvs := PackedVector2Array()
	var normals := PackedVector3Array()
	for p in polygon:
		verts.append(Kit.v3(p, y))
		uvs.append(p)
		normals.append(Vector3.UP)
	var tris := Geometry2D.triangulate_polygon(polygon)
	# Godot wants clockwise-from-above for an upward face; flip if needed.
	var indices := PackedInt32Array()
	for t in range(0, tris.size(), 3):
		var a := polygon[tris[t]]
		var b := polygon[tris[t + 1]]
		var c := polygon[tris[t + 2]]
		var cross: float = (b - a).cross(c - a)
		if cross > 0.0:
			indices.append_array([tris[t], tris[t + 1], tris[t + 2]])
		else:
			indices.append_array([tris[t], tris[t + 2], tris[t + 1]])
	return _array_mesh(verts, normals, uvs, indices, material)


static func disc_polygon(centre: Vector2, radius: float, segments := 24) -> PackedVector2Array:
	var out := PackedVector2Array()
	for i in segments:
		var a := TAU * i / segments
		out.append(centre + Vector2(cos(a), sin(a)) * radius)
	return out


static func _array_mesh(verts: PackedVector3Array, normals: PackedVector3Array, uvs: PackedVector2Array, indices: PackedInt32Array, material: Material) -> ArrayMesh:
	var arrays := []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = verts
	arrays[Mesh.ARRAY_NORMAL] = normals
	arrays[Mesh.ARRAY_TEX_UV] = uvs
	arrays[Mesh.ARRAY_INDEX] = indices
	var mesh := ArrayMesh.new()
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	mesh.surface_set_material(0, material)
	return mesh


func _road(r: int) -> void:
	var road: Dictionary = layout.roads[r]
	var y := 0.004 if road.kind != Plan.PATH else 0.002
	var mat := material_for(road)
	kit.mesh(root, road.name.replace(" ", ""), strip_mesh(road.points, road.width * 0.5, y, mat), Transform3D.IDENTITY, false)
	if road.end_circle > 0.0:
		var plain := kit.ground(ASPHALT.merged({"color": Color(0.25, 0.25, 0.31), "patch_color": Color(0.21, 0.21, 0.27)}))
		var end: Vector2 = road.points[road.points.size() - 1]
		kit.mesh(root, road.name.replace(" ", "") + "Turn", polygon_mesh(disc_polygon(end, road.end_circle), 0.009, plain), Transform3D.IDENTITY, false)
		# A painted ring round the edge of the turning circle.
		kit.mesh(root, road.name.replace(" ", "") + "TurnKerb",
				strip_mesh(_closed(disc_polygon(end, road.end_circle - 0.25, 32)), 0.12, 0.011, kit.ground({"color": Color(0.55, 0.53, 0.6), "patch_color": Color(0.5, 0.48, 0.55), "wetness": 0.8})),
				Transform3D.IDENTITY, false)


static func _closed(polygon: PackedVector2Array) -> PackedVector2Array:
	var out := polygon.duplicate()
	out.append(polygon[0])
	return out


func _find_junctions() -> void:
	for name in layout.junctions:
		var entries: Array = layout.junctions[name]
		var arms := []
		var centre: Vector2 = Plan.NODES[name]
		for entry in entries:
			var road: Dictionary = layout.roads[entry[0]]
			var i: int = entry[1]
			var line: PackedVector2Array = road.points
			if i > 0:
				arms.append({"road": entry[0], "dir": (line[i - 1] - line[i]).normalized(), "width": road.width, "kind": road.kind})
			if i < line.size() - 1:
				arms.append({"road": entry[0], "dir": (line[i + 1] - line[i]).normalized(), "width": road.width, "kind": road.kind})
		if arms.size() < 3:
			continue
		var radius := 0.0
		for arm in arms:
			radius = maxf(radius, arm.width * 0.5)
		junctions[name] = {"centre": centre, "radius": radius + 1.2, "arms": arms}


# Asphalt over the middle of each junction, so centre lines stop short of it
# and the corners come out rounded.
func _junction(name: String) -> void:
	var j: Dictionary = junctions[name]
	var points := PackedVector2Array()
	var widest := 0.0
	for arm in j.arms:
		widest = maxf(widest, arm.width)
		var road: Dictionary = layout.roads[arm.road]
		var reach: float = j.radius + 0.5
		var p := _along_arm(road.points, j.centre, arm.dir, reach)
		var n := Layout.left_of(arm.dir)
		points.append(p + n * arm.width * 0.5)
		points.append(p - n * arm.width * 0.5)
	var hull := Geometry2D.convex_hull(points)
	hull.remove_at(hull.size() - 1)
	var mat := kit.ground(ASPHALT)
	kit.mesh(root, "Junction" + name.to_pascal_case(), polygon_mesh(hull, 0.012, mat), Transform3D.IDENTITY, false)
	# Zebra crossings just outside the junction, on the streets people walk along.
	for arm in j.arms:
		if arm.kind == Plan.ALLEY or arm.kind == Plan.PATH:
			continue
		var road: Dictionary = layout.roads[arm.road]
		var at := _along_arm(road.points, j.centre, arm.dir, j.radius + 2.2)
		crossings.append({"centre": at, "across": Layout.left_of(arm.dir), "along": arm.dir, "half": arm.width * 0.5, "junction": name, "road": arm.road})


# Follow a road's centre line away from a junction for `distance` metres.
func _along_arm(line: PackedVector2Array, from: Vector2, dir: Vector2, distance: float) -> Vector2:
	# Find the junction's index, then walk in the arm's direction.
	var best := 0
	for i in line.size():
		if line[i].distance_to(from) < line[best].distance_to(from):
			best = i
	var step := 1 if best + 1 < line.size() and (line[best + 1] - line[best]).normalized().dot(dir) > 0.5 else -1
	var at := line[best]
	var left := distance
	var i := best
	while left > 0.0 and i + step >= 0 and i + step < line.size():
		var next := line[i + step]
		var seg := at.distance_to(next)
		if seg >= left:
			return at + (next - at).normalized() * left
		left -= seg
		at = next
		i += step
	return at + dir * left


func _crossings() -> void:
	var white := kit.ground({"color": Color(0.85, 0.84, 0.88), "patch_color": Color(0.75, 0.74, 0.8), "patch_size": 1.0, "wetness": 0.9, "puddle_size": 1.2})
	var verts := PackedVector3Array()
	var normals := PackedVector3Array()
	var uvs := PackedVector2Array()
	var indices := PackedInt32Array()
	for c in crossings:
		var across: Vector2 = c.across
		var along: Vector2 = c.along
		var half: float = c.half - 0.5
		var x := -half + 0.3
		while x <= half - 0.3:
			var centre: Vector2 = c.centre + across * x
			var corners := [centre + across * 0.25 + along * 1.3, centre - across * 0.25 + along * 1.3,
					centre - across * 0.25 - along * 1.3, centre + across * 0.25 - along * 1.3]
			var k := verts.size()
			for p in corners:
				verts.append(Kit.v3(p, 0.016))
				normals.append(Vector3.UP)
				uvs.append(p)
			# Wind upward-facing.
			var cross: float = (corners[1] - corners[0]).cross(corners[2] - corners[0])
			if cross > 0.0:
				indices.append_array([k, k + 1, k + 2, k, k + 2, k + 3])
			else:
				indices.append_array([k, k + 2, k + 1, k, k + 3, k + 2])
			x += 1.0
	if not verts.is_empty():
		kit.mesh(root, "Crossings", _array_mesh(verts, normals, uvs, indices, white), Transform3D.IDENTITY, false)


## Flat ground pieces: lawns, plazas and the like.
func patch(name: String, polygon: PackedVector2Array, material: Material, y := -0.01) -> MeshInstance3D:
	return kit.mesh(root, name, polygon_mesh(polygon, y, material), Transform3D.IDENTITY, false)
