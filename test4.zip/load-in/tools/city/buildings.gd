extends RefCounted
## Turns building lots into buildings: walls with lit windows, roofs and
## rooftop clutter, shopfronts with signs and awnings, fire escapes, water
## towers, billboards. Every lot is different but they share the district's
## palette, so streets read as places. A handful of landmarks get their own
## silhouettes so you can find your way by them.

const Plan := preload("res://tools/city/plan.gd")
const Layout := preload("res://tools/city/layout.gd")
const Kit := preload("res://tools/city/kit.gd")

const CLUB_SOUND := preload("res://audio/ambience/club.ogg")
const HVAC_SOUND := preload("res://audio/ambience/hvac.ogg")
const LOOP_SOUND := preload("res://world/loop_sound.gd")
const KENNEY_SHADER := preload("res://art/kenney_building.gdshader")
const KENNEY_ATLAS := preload("res://art/kenney/Textures/colormap.png")

## Kenney City Builder buildings (art/kenney): one model is one bay of a
## street front, about 6.5 m to a floor-pair. Height in model units, and the
## district styles each fits.
const KENNEY := {
	"a": {"path": "res://art/kenney/building-small-a.glb", "h": 0.95},
	"b": {"path": "res://art/kenney/building-small-b.glb", "h": 1.63},
	"c": {"path": "res://art/kenney/building-small-c.glb", "h": 1.5},
	"d": {"path": "res://art/kenney/building-small-d.glb", "h": 1.0},
	"garage": {"path": "res://art/kenney/building-garage.glb", "h": 0.55},
}
const KENNEY_STYLES := {
	"home": ["a", "d", "a", "c"],
	"market": ["d", "a", "d", "c"],
	"back": ["a", "c", "b", "c"],
	"canal": ["c", "b", "garage", "a"],
	"neon": ["d", "c", "b", "d"],
	"avenue": ["b", "c", "d"],
	"harbour": ["garage", "c"],
}
## Metres per model unit, upward. Across and deep, each bay is stretched to its lot.
const KENNEY_SCALE := 6.6
## Lots up to this tall are built from Kenney bays; taller ones stay towers.
const KENNEY_MAX_HEIGHT := 13.5
## Each district's walls are turned round the colour wheel by one of these.
const KENNEY_HUES := {
	"home": [0.0, 0.04, 0.55, 0.62, 0.9],
	"market": [0.0, 0.05, 0.08, 0.95],
	"back": [0.0, 0.92, 0.96, 0.6],
	"canal": [0.0, 0.03, 0.97],
	"neon": [0.75, 0.82, 0.88, 0.0, 0.5],
	"avenue": [0.0, 0.1, 0.6, 0.7],
	"harbour": [0.5, 0.55],
}

var kit: Kit
var layout: Layout
var root: Node3D
## The collision body every building adds its boxes to.
var solid: StaticBody3D
var rng := RandomNumberGenerator.new()

## Shop doors (world position, facing) for the people to walk into.
var doors: Array[Dictionary] = []
var light_count := 0
var _shop_names := {}
var _kenney_mat: ShaderMaterial
## How many lots became Kenney buildings (for the builder's log).
var kenney_count := 0


func _init(the_kit: Kit, the_layout: Layout, parent: Node3D, body: StaticBody3D) -> void:
	kit = the_kit
	layout = the_layout
	root = parent
	solid = body
	rng.seed = 77


func build_all() -> void:
	var index := 0
	for lot in layout.lots:
		rng.seed = lot.seed
		match lot.get("landmark", ""):
			"screen": _screen_tower(lot)
			"theatre": _theatre(lot)
			"pagoda": _pagoda(lot)
			"club": _club(lot)
			"water_tower": _building(lot, index, {"water_tower": true, "clock": true})
			_: _building(lot, index, {})
		index += 1


func _colour(hex: String) -> Color:
	return Color(hex)


func _pick(list: Array) -> Variant:
	return list[rng.randi() % list.size()]


func _shop_name(style_name: String) -> String:
	var names: Array = Plan.SHOP_NAMES[style_name]
	var used: int = _shop_names.get(style_name, 0)
	_shop_names[style_name] = used + 1
	# Go round the list in a shuffled-but-fixed order so neighbours differ.
	return names[(used * 7 + rng.randi_range(0, 2)) % names.size()]


func _neon() -> Color:
	return Color(_pick(Plan.NEON_COLORS))


## Neon colour as a Label3D modulate (above 1 = it glows).
static func _hdr(c: Color, strength := 2.2) -> Color:
	return Color(c.r * strength, c.g * strength, c.b * strength, 1.0)


# --- an ordinary building ------------------------------------------------------

func _building(lot: Dictionary, index: int, extra: Dictionary) -> Node3D:
	var style_name: String = lot.style
	var style: Dictionary = Plan.STYLES[style_name]
	if extra.is_empty() and KENNEY_STYLES.has(style_name) and lot.height <= KENNEY_MAX_HEIGHT and lot.size.x >= 4.0:
		return _kenney_building(lot, index, style_name, style)
	var w: float = lot.size.x
	var d: float = lot.size.y
	var h: float = lot.height
	var yaw: float = lot.yaw
	var base := kit.node(root, style_name.capitalize() + str(index), Kit.yawed(yaw, Kit.v3(lot.centre)))
	var colour := _colour(_pick(style.walls)).lightened(rng.randf_range(-0.06, 0.08))
	var glass: bool = style.get("glass", false)
	var lit: float = clampf(style.lit + rng.randf_range(-0.15, 0.15), 0.08, 0.85)
	var warm := Color("ffb870") if rng.randf() < 0.7 else Color("ffd59a")
	var cool := Color("8ad8ff") if not glass else Color("b6e3ff")
	var spacing: Vector2 = Vector2(rng.randf_range(2.0, 2.6), rng.randf_range(2.9, 3.3)) if not glass else Vector2(1.6, 3.4)
	var first_row := 3.9 if lot.front else 2.6
	if style.roof == "pitched":
		first_row = 1.0
		spacing = Vector2(rng.randf_range(2.6, 3.2), 2.8)
	var tiered: bool = rng.randf() < style.tier and h > 12.0 and w > 7.0 and d > 7.0
	var lower_h := h
	if tiered:
		lower_h = h * rng.randf_range(0.5, 0.7)
	var size := Vector3(w, lower_h, d)
	var wall_mat := kit.wall(colour, size, float(rng.randi_range(0, 500)), lit, warm, cool, spacing, first_row, glass)
	kit.mesh(base, "Walls", kit.box(size, wall_mat, 0.15, 3), Transform3D(Basis(), Vector3(0, lower_h * 0.5, 0)))
	kit.shape(solid, "B%d" % index, Kit.yawed(yaw, Kit.v3(lot.centre, lower_h * 0.5)), size)
	var top := lower_h
	if tiered:
		var inset := rng.randf_range(1.2, 2.5)
		var upper := Vector3(maxf(w - inset * 2.0, 4.0), h - lower_h, maxf(d - inset * 2.0, 4.0))
		var off := Vector3(rng.randf_range(-0.5, 0.5) * inset, 0, -rng.randf_range(0.0, 1.0) * inset)
		var upper_mat := kit.wall(colour.darkened(0.08), upper, float(rng.randi_range(0, 500)), lit, warm, cool, spacing, first_row, glass)
		kit.mesh(base, "Upper", kit.box(upper, upper_mat, 0.15, 3), Transform3D(Basis(), off + Vector3(0, lower_h + upper.y * 0.5, 0)))
		kit.add_box(base, "Ledge", Vector3(0, lower_h + 0.12, 0), Vector3(w - 0.3, 0.24, d - 0.3), kit.toy(colour.darkened(0.35), 0, 0.85, 0.2))
		_roof(base, upper, off, h, style, lot, extra)
		top = h
	elif style.roof == "pitched":
		var roof_colour := Color(_pick(["5a2f38", "3c3f52", "6b3b2f", "2f3a40"]))
		# A gentle gable: ridge along the width, eaves overhanging a little.
		var rise := clampf(d * 0.3, 1.4, 3.2)
		var prism := PrismMesh.new()
		prism.size = Vector3(d + 0.8, rise, w + 0.6)
		prism.material = kit.toy(roof_colour, 0, 0.8, 0.25)
		kit.mesh(base, "Roof", prism, Transform3D(Basis(Vector3.UP, PI / 2.0), Vector3(0, lower_h + rise * 0.5, 0)))
		kit.add_box(base, "Chimney", Vector3(w * 0.25, lower_h + rise * 0.6, -d * 0.15), Vector3(0.6, 1.4, 0.6), kit.toy(colour.darkened(0.2)), 0, true, 80.0)
		top = lower_h + rise
	else:
		_roof(base, Vector3(w, lower_h, d), Vector3.ZERO, lower_h, style, lot, extra)
	if lot.front:
		if lot.shop:
			_shopfront(base, lot, w, d, style_name, style)
		else:
			_entrance(base, lot, w, d, style_name, style, colour)
		if rng.randf() < style.fire_escape and h > 8.0 and style.roof != "pitched":
			_fire_escape(base, w, d, lower_h, colour)
		if rng.randf() < style.tall_sign and lower_h > 7.0:
			_tall_sign(base, w, d, lower_h)
		if style.get("fence", 0.0) > 0.0 and rng.randf() < style.fence:
			_front_yard(base, w, d, lot)
	if extra.get("clock", false):
		_clock(base, w, d, top)
	return base


# --- a street of Kenney bays ---------------------------------------------------

func _kenney_material() -> ShaderMaterial:
	if _kenney_mat == null:
		_kenney_mat = ShaderMaterial.new()
		_kenney_mat.shader = KENNEY_SHADER
		_kenney_mat.set_shader_parameter(&"atlas", KENNEY_ATLAS)
	return _kenney_mat


## One lot as a row of Kenney buildings, each its own colour, with the
## district's shop signs and lights on the front.
func _kenney_building(lot: Dictionary, index: int, style_name: String, style: Dictionary) -> Node3D:
	var w: float = lot.size.x
	var d: float = lot.size.y
	var base := kit.node(root, style_name.capitalize() + str(index), Kit.yawed(lot.yaw, Kit.v3(lot.centre)))
	var bays := maxi(1, int(round(w / 7.0)))
	var bay_w := w / bays
	var choices: Array = KENNEY_STYLES[style_name]
	var tallest := 0.0
	for i in bays:
		# The model whose height comes closest to the lot's (with a little luck).
		var best := ""
		var best_gap := INF
		for key in choices:
			if key == "garage" and lot.front and lot.shop:
				continue
			var gap: float = absf(KENNEY[key].h * KENNEY_SCALE - lot.height) + rng.randf_range(0.0, 3.0)
			if gap < best_gap:
				best_gap = gap
				best = key
		var spec: Dictionary = KENNEY[best]
		var x := -w * 0.5 + bay_w * (i + 0.5)
		# Deep lots get a second bay back to back, so nothing is stretched
		# much more than half again its size.
		var halves := 2 if d > bay_w * 1.6 else 1
		var hue := float(_pick(KENNEY_HUES[style_name])) + rng.randf_range(-0.02, 0.02)
		var paint := rng.randf_range(0.62, 0.9)
		for k in halves:
			var depth := d / halves
			var z := 0.0 if halves == 1 else (d * 0.25 if k == 0 else -d * 0.25)
			var turn := Basis() if k == 0 else Basis(Vector3.UP, PI)
			var xform := Transform3D(turn * Basis().scaled(Vector3(bay_w * 1.005, KENNEY_SCALE, depth * 1.01)), Vector3(x, 0, z))
			var mi := kit.place(base, "Bay", spec.path if k == 0 else KENNEY[_pick(["a", "c"])].path, xform)
			mi.material_override = _kenney_material()
			mi.set_instance_shader_parameter(&"hue_shift", hue)
			mi.set_instance_shader_parameter(&"paint", paint)
			mi.set_instance_shader_parameter(&"lit_ratio", clampf(style.lit + rng.randf_range(-0.15, 0.2), 0.15, 0.85))
			mi.set_instance_shader_parameter(&"seed", float(rng.randi_range(0, 999)))
		tallest = maxf(tallest, spec.h * KENNEY_SCALE)
	kit.shape(solid, "B%d" % index, Kit.yawed(lot.yaw, Kit.v3(lot.centre, tallest * 0.5)), Vector3(w, tallest, d))
	kenney_count += 1
	if lot.front:
		if lot.shop:
			_kenney_shop(base, w, d, style_name)
		else:
			doors.append({"at": base.transform * Vector3(0, 0, d * 0.5 + 1.0), "style": style_name})
			if rng.randf() < 0.3:
				kit.omni(base, "PorchLight", Vector3(0, 2.3, d * 0.5 + 0.9), Color("ffc98a"), 0.6, 5.0)
				light_count += 1
		if rng.randf() < style.tall_sign and tallest > 9.0:
			_tall_sign(base, w, d, tallest)
	return base


## A shop on the ground floor of a Kenney bay: neon name board above the
## door, the shop's light spilling on the pavement.
func _kenney_shop(base: Node3D, w: float, d: float, style_name: String) -> void:
	var front := d * 0.5
	var colour := _neon()
	var name := _shop_name(style_name)
	var board_w := minf(w - 0.8, 1.1 + name.length() * 0.42)
	# Kenney ground floors are about 3 m; the board sits on the floor line.
	kit.add_box(base, "SignBoard", Vector3(0, 3.2, front + 0.14), Vector3(board_w, 0.8, 0.14), kit.toy(colour.darkened(0.72), 0.3, 0.5))
	kit.label(base, "Sign", name, Transform3D(Basis(), Vector3(0, 3.2, front + 0.23)), 0.56, _hdr(colour), false, rng.randf() < 0.12)
	doors.append({"at": base.transform * Vector3(0, 0, front + 1.0), "style": style_name})
	if rng.randf() < 0.42:
		var interior := Color(_pick(["ffe2b0", "ffd1e8", "c9f0ff", "fff3c4", "d6ffd9"]))
		kit.omni(base, "ShopLight", Vector3(0, 2.4, front + 1.6), interior.lerp(colour, 0.35), 0.9, 6.5)
		light_count += 1


func _roof(base: Node3D, box: Vector3, off: Vector3, top: float, style: Dictionary, lot: Dictionary, extra: Dictionary) -> void:
	var dark := kit.toy(Color("2a2838"), 0, 0.85, 0.2)
	kit.add_box(base, "Cap", off + Vector3(0, top + 0.18, 0), Vector3(box.x - 0.2, 0.36, box.z - 0.2), dark)
	if not lot.front and rng.randf() < 0.5:
		return
	# Air-con boxes and vents.
	for i in rng.randi_range(1, 3):
		var p := off + Vector3(rng.randf_range(-0.35, 0.35) * box.x, top + 0.75, rng.randf_range(-0.35, 0.35) * box.z)
		kit.add_box(base, "AirCon", p, Vector3(1.3, 0.8, 1.0), kit.toy(Color("8d93a8"), 0, 0.6, 0.3), rng.randf_range(0, PI), true, 90.0)
	if top > 18.0 and rng.randf() < 0.6:
		var p := off + Vector3(rng.randf_range(-0.3, 0.3) * box.x, top, rng.randf_range(-0.3, 0.3) * box.z)
		var mast_h := rng.randf_range(3.0, 7.0)
		kit.mesh(base, "Mast", kit.cyl(0.08, 0.05, mast_h, kit.toy(Color("6b6f80"), 0, 0.5)), Transform3D(Basis(), p + Vector3(0, mast_h * 0.5, 0)), true, 160.0)
		kit.mesh(base, "MastLight", kit.sphere(0.18, kit.glow(Color("ff3b3b"), 4.0)), Transform3D(Basis(), p + Vector3(0, mast_h + 0.1, 0)), false)
	if extra.get("water_tower", false) or (rng.randf() < style.water_tower and lot.front):
		_water_tower(base, off + Vector3(rng.randf_range(-0.2, 0.2) * box.x, top, rng.randf_range(-0.2, 0.1) * box.z), extra.get("water_tower", false))
	if lot.front and rng.randf() < style.billboard and box.x > 6.0:
		_billboard(base, Vector3(0, top, box.z * 0.5 - 0.6) + off, box.x)


func _water_tower(base: Node3D, at: Vector3, big := false) -> void:
	var s := 1.6 if big else 1.0
	var wood := kit.toy(Color("7a5236"), 0, 0.9, 0.2)
	var iron := kit.toy(Color("3a3a44"), 0, 0.6, 0.2)
	for k in 4:
		var a := TAU * (k + 0.5) / 4.0
		kit.mesh(base, "TowerLeg", kit.box(Vector3(0.14, 2.2 * s, 0.14), iron, 0.03), Transform3D(Basis(), at + Vector3(cos(a), 0, sin(a)) * 1.0 * s + Vector3(0, 1.1 * s, 0)), true, 140.0)
	kit.mesh(base, "Tank", kit.cyl(1.25 * s, 1.25 * s, 2.6 * s, wood, 16), Transform3D(Basis(), at + Vector3(0, 2.2 * s + 1.3 * s, 0)))
	kit.mesh(base, "TankHoop", kit.cyl(1.29 * s, 1.29 * s, 0.12, iron, 16), Transform3D(Basis(), at + Vector3(0, 2.2 * s + 0.7 * s, 0)), true, 120.0)
	kit.mesh(base, "TankHoop", kit.cyl(1.29 * s, 1.29 * s, 0.12, iron, 16), Transform3D(Basis(), at + Vector3(0, 2.2 * s + 1.9 * s, 0)), true, 120.0)
	kit.mesh(base, "TankRoof", kit.cyl(1.4 * s, 0.1, 1.0 * s, kit.toy(Color("4a3a32"), 0, 0.9), 16), Transform3D(Basis(), at + Vector3(0, 2.2 * s + 2.6 * s + 0.5 * s, 0)))


func _billboard(base: Node3D, at: Vector3, width: float) -> void:
	var bw := minf(width - 1.0, rng.randf_range(5.0, 8.0))
	var frame := kit.toy(Color("2b2a36"), 0, 0.7)
	var colour := _neon()
	kit.add_box(base, "BillboardPost", at + Vector3(-bw * 0.35, 1.2, -0.4), Vector3(0.2, 2.4, 0.2), frame, 0, true, 150.0)
	kit.add_box(base, "BillboardPost", at + Vector3(bw * 0.35, 1.2, -0.4), Vector3(0.2, 2.4, 0.2), frame, 0, true, 150.0)
	kit.add_box(base, "BillboardFrame", at + Vector3(0, 3.6, 0), Vector3(bw + 0.3, 2.9, 0.2), frame)
	kit.mesh(base, "Billboard", kit.box(Vector3(bw, 2.6, 0.08), kit.toy(colour.darkened(0.55), 1.2, 0.5, 0.3)), Transform3D(Basis(), at + Vector3(0, 3.6, 0.12)), false)
	var text: String = _pick(Plan.JP_SIGNS) if rng.randf() < 0.6 else _pick(["LIVE", "SALE", "COLA", "RADIO", "NEON", "JAZZ", "SODA", "TOKYO", "WOW"])
	kit.label(base, "BillboardText", text, Transform3D(Basis(), at + Vector3(0, 3.6, 0.18)), 1.6, _hdr(colour, 2.0), text.unicode_at(0) > 255)


# --- street level -------------------------------------------------------------

func _shopfront(base: Node3D, lot: Dictionary, w: float, d: float, style_name: String, style: Dictionary) -> void:
	var front := d * 0.5
	var colour := _neon()
	var window_w := w - 2.2
	var frame := kit.toy(Color("26242f"), 0, 0.6)
	var interior := Color(_pick(["ffe2b0", "ffd1e8", "c9f0ff", "fff3c4", "d6ffd9"]))
	kit.add_box(base, "ShopFrame", Vector3(0.6, 1.5, front + 0.04), Vector3(window_w + 0.3, 2.4, 0.08), frame)
	kit.mesh(base, "ShopWindow", kit.box(Vector3(window_w, 2.1, 0.08), kit.toy(interior.darkened(0.25), 1.3, 0.2, 0.2)), Transform3D(Basis(), Vector3(0.6, 1.5, front + 0.09)), false)
	# Something on the shelves.
	var goods := int(window_w / 0.9)
	for i in goods:
		var x := 0.6 - window_w * 0.5 + 0.45 + i * 0.9
		var good := Color(_pick(Plan.NEON_COLORS)).lightened(0.2)
		kit.add_box(base, "Good", Vector3(x, 1.0 + (i % 2) * 0.55, front + 0.16), Vector3(0.5, 0.42, 0.06), kit.toy(good, 0.6, 0.5), 0, false, 45.0)
	# Door at the left end.
	var door_x := -w * 0.5 + 0.75
	kit.add_box(base, "Door", Vector3(door_x, 1.1, front + 0.05), Vector3(1.0, 2.2, 0.1), frame)
	kit.mesh(base, "DoorGlass", kit.box(Vector3(0.7, 1.1, 0.04), kit.toy(interior.darkened(0.3), 1.0, 0.2)), Transform3D(Basis(), Vector3(door_x, 1.5, front + 0.11)), false)
	doors.append({"at": base.transform * Vector3(door_x, 0, front + 1.0), "style": style_name})
	# Sign board over the window.
	var name := _shop_name(style_name)
	var board_w := minf(w - 0.6, 1.1 + name.length() * 0.42)
	kit.add_box(base, "SignBoard", Vector3(0, 3.55, front + 0.08), Vector3(board_w, 0.9, 0.16), kit.toy(colour.darkened(0.7), 0.3, 0.5))
	kit.label(base, "Sign", name, Transform3D(Basis(), Vector3(0, 3.55, front + 0.18)), 0.62, _hdr(colour), false, rng.randf() < 0.12)
	if rng.randf() < style.awning:
		var awning := Color(_pick(["e63946", "2a9d8f", "f4a261", "6d597a", "264653", "ffb703", "3d5a80"]))
		var stripe := rng.randf() < 0.5
		var tilt := Basis(Vector3.RIGHT, deg_to_rad(13.0))
		kit.mesh(base, "Awning", kit.box(Vector3(window_w + 0.6, 0.1, 1.4), kit.toy(awning, 0.15, 0.8, 0.4), 0.04), Transform3D(tilt, Vector3(0.6, 2.85, front + 0.7)))
		if stripe:
			kit.mesh(base, "AwningEdge", kit.box(Vector3(window_w + 0.6, 0.25, 0.06), kit.toy(Color.WHITE.lerp(awning, 0.3), 0.15, 0.8)), Transform3D(Basis(), Vector3(0.6, 2.6, front + 1.38)), true, 70.0)
	# Some shops light the pavement in front of them.
	if rng.randf() < 0.42:
		kit.omni(base, "ShopLight", Vector3(0.6, 2.4, front + 1.6), interior.lerp(colour, 0.35), 0.9, 6.5)
		light_count += 1


func _entrance(base: Node3D, lot: Dictionary, w: float, d: float, style_name: String, style: Dictionary, colour: Color) -> void:
	var front := d * 0.5
	var frame := kit.toy(colour.darkened(0.45), 0, 0.7)
	if rng.randf() < style.get("roller", 0.0):
		# Loading bay with a roller shutter, maybe some graffiti.
		var rw := minf(w - 1.5, 4.5)
		kit.add_box(base, "Shutter", Vector3(0, 1.6, front + 0.05), Vector3(rw, 3.2, 0.1), kit.toy(Color("6e7280"), 0, 0.5, 0.2, 0.3))
		for k in 6:
			kit.add_box(base, "ShutterRib", Vector3(0, 0.3 + k * 0.5, front + 0.11), Vector3(rw, 0.05, 0.03), kit.toy(Color("4f525d")), 0, false, 40.0)
		if rng.randf() < 0.6:
			var tag := Color(_pick(Plan.NEON_COLORS))
			kit.label(base, "Graffiti", _pick(["CAT", "LOUD", "ZOOM", "RIFF", "YO!", "HOWL", "DIG"]), Transform3D(Basis(), Vector3(rng.randf_range(-0.6, 0.6), 1.7, front + 0.17)), 0.9, tag.darkened(0.1), false)
		kit.mesh(base, "BayLamp", kit.sphere(0.16, kit.glow(Color("ffd9a0"), 3.0)), Transform3D(Basis(), Vector3(rw * 0.5 + 0.4, 3.4, front + 0.25)), false)
		return
	var door_x := rng.randf_range(-0.25, 0.25) * w
	kit.add_box(base, "Door", Vector3(door_x, 1.1, front + 0.05), Vector3(1.1, 2.2, 0.1), frame)
	kit.add_box(base, "Step", Vector3(door_x, 0.08, front + 0.45), Vector3(1.6, 0.16, 0.8), kit.toy(Color("555366")), 0, true, 60.0)
	kit.mesh(base, "PorchLamp", kit.sphere(0.13, kit.glow(Color("ffd59a"), 3.0)), Transform3D(Basis(), Vector3(door_x + 0.8, 2.4, front + 0.2)), false)
	if style.roof == "pitched":
		# Front windows down at the ground floor for houses.
		for sx in [-1.0, 1.0]:
			var x: float = door_x + sx * 2.0
			if absf(x) < w * 0.5 - 0.8:
				kit.mesh(base, "Window", kit.box(Vector3(1.1, 1.0, 0.06), kit.toy(Color("ffcf8a").darkened(0.2) if rng.randf() < 0.6 else Color("20263a"), 1.0 if rng.randf() < 0.6 else 0.0, 0.3)), Transform3D(Basis(), Vector3(x, 1.5, front + 0.04)), false)
	if rng.randf() < 0.35:
		kit.omni(base, "PorchLight", Vector3(door_x + 0.8, 2.3, front + 0.8), Color("ffc98a"), 0.6, 5.0)
		light_count += 1


func _fire_escape(base: Node3D, w: float, d: float, h: float, colour: Color) -> void:
	var iron := kit.toy(Color("2b2b33"), 0, 0.55, 0.15, 0.2)
	var front := d * 0.5
	var ew := minf(w * 0.45, 3.4)
	var x := (w * 0.5 - ew * 0.5 - 0.6) * (1.0 if rng.randf() < 0.5 else -1.0)
	var floors := int((h - 4.0) / 3.1)
	for f in floors:
		var y := 4.3 + f * 3.1
		kit.add_box(base, "EscapeDeck", Vector3(x, y, front + 0.55), Vector3(ew, 0.06, 1.1), iron, 0, true, 110.0, 0.02)
		kit.add_box(base, "EscapeRail", Vector3(x, y + 0.5, front + 1.08), Vector3(ew, 0.05, 0.05), iron, 0, true, 80.0, 0.02)
		kit.add_box(base, "EscapeRail", Vector3(x, y + 0.95, front + 1.08), Vector3(ew, 0.05, 0.05), iron, 0, true, 80.0, 0.02)
		for k in 5:
			kit.add_box(base, "EscapeBar", Vector3(x - ew * 0.5 + k * ew / 4.0, y + 0.48, front + 1.08), Vector3(0.04, 0.96, 0.04), iron, 0, false, 60.0, 0.01)
		if f < floors - 1:
			# A ladder up to the next deck, on a slant.
			var ladder := Basis(Vector3.FORWARD, deg_to_rad(52.0 if f % 2 == 0 else -52.0))
			kit.mesh(base, "EscapeStair", kit.box(Vector3(0.5, 3.9, 0.05), iron, 0.02), Transform3D(ladder, Vector3(x, y + 1.55, front + 0.75)), true, 100.0)


func _tall_sign(base: Node3D, w: float, d: float, h: float) -> void:
	# A vertical neon sign sticking out from the corner of the front: the
	# Tokyo look, readable from down the street.
	var colour := _neon()
	var text: String = _pick(Plan.JP_SIGNS)
	var length := text.length()
	var sh := minf(1.2 + length * 1.05, h - 4.5)
	var x := (w * 0.5 - 0.5) * (1.0 if rng.randf() < 0.5 else -1.0)
	var y := 4.6 + sh * 0.5
	var z := d * 0.5 + 0.6
	kit.add_box(base, "TallSign", Vector3(x, y, z), Vector3(0.22, sh, 1.1), kit.toy(colour.darkened(0.65), 0.35, 0.5))
	kit.add_box(base, "TallSignEdge", Vector3(x, y, z), Vector3(0.26, sh + 0.12, 1.16), kit.toy(colour, 2.0, 0.4), 0, false, 0.0, 0.03)
	# Characters stacked top to bottom, on both faces.
	var stacked := ""
	for i in length:
		stacked += text[i] + ("\n" if i < length - 1 else "")
	var step := sh / maxf(length, 1)
	for face in [1.0, -1.0]:
		var b := Basis(Vector3.UP, PI * 0.5 * face)
		var l := kit.label(base, "TallSignText", stacked, Transform3D(b, Vector3(x + 0.14 * face, y, z)), step * 0.8, _hdr(colour, 2.3), true, rng.randf() < 0.15)
		l.line_spacing = step * 0.2 / l.pixel_size
	if rng.randf() < 0.5:
		kit.omni(base, "SignGlow", Vector3(x, y - sh * 0.25, z + 0.6), colour, 0.8, 5.5)
		light_count += 1


func _front_yard(base: Node3D, w: float, d: float, lot: Dictionary) -> void:
	# Little front garden: a low fence and a hedge or a tree.
	var front := d * 0.5
	var setback := 1.6
	var fence := kit.toy(Color("d8d2c4"), 0, 0.8)
	kit.add_box(base, "Fence", Vector3(0.6, 0.45, front + setback), Vector3(w - 1.8, 0.9, 0.08), fence, 0, true, 70.0)
	kit.add_box(base, "Hedge", Vector3(-w * 0.25, 0.5, front + 0.6), Vector3(w * 0.35, 1.0, 0.7), kit.toy(Color("2f6b45"), 0, 0.95, 0.6), 0, true, 70.0, 0.3)
	kit.shape(solid, "Fence", base.transform * Transform3D(Basis(), Vector3(0.6, 0.45, front + setback)), Vector3(w - 1.8, 0.9, 0.1))


func _clock(base: Node3D, w: float, d: float, top: float) -> void:
	var face := kit.glow(Color("fff2cf"), 1.6)
	var at := Vector3(0, top - 2.5, d * 0.5 + 0.15)
	kit.mesh(base, "ClockRim", kit.cyl(1.25, 1.25, 0.22, kit.toy(Color("3b3445")), 24), Transform3D(Basis(Vector3.RIGHT, PI / 2), at))
	kit.mesh(base, "ClockFace", kit.cyl(1.05, 1.05, 0.25, face, 24), Transform3D(Basis(Vector3.RIGHT, PI / 2), at + Vector3(0, 0, 0.02)), false)
	kit.add_box(base, "ClockHand", at + Vector3(0, 0.35, 0.16), Vector3(0.08, 0.75, 0.04), kit.toy(Color("1a1822")), 0, false)
	kit.mesh(base, "ClockHand", kit.box(Vector3(0.07, 0.95, 0.04), kit.toy(Color("1a1822"))), Transform3D(Basis(Vector3.FORWARD, deg_to_rad(-70.0)), at + Vector3(0.42, 0.15, 0.17)), false)


# --- landmarks ----------------------------------------------------------------

## The big video screen over Hachi Plaza: the thing you steer by downtown.
func _screen_tower(lot: Dictionary) -> void:
	var w: float = lot.size.x
	var d: float = lot.size.y
	var h: float = lot.height
	var base := kit.node(root, "ScreenTower", Kit.yawed(lot.yaw, Kit.v3(lot.centre)))
	var colour := Color("2b2840")
	kit.mesh(base, "Walls", kit.box(Vector3(w, h, d), kit.wall(colour, Vector3(w, h, d), 11.0, 0.5, Color("ffd2a0"), Color("a8e6ff"), Vector2(1.8, 3.2), 4.2, true), 0.2), Transform3D(Basis(), Vector3(0, h * 0.5, 0)))
	kit.shape(solid, "ScreenTower", Kit.yawed(lot.yaw, Kit.v3(lot.centre, h * 0.5)), Vector3(w, h, d))
	kit.add_box(base, "Cap", Vector3(0, h + 0.25, 0), Vector3(w - 0.3, 0.5, d - 0.3), kit.toy(Color("1d1b28")))
	# The screen: a deep frame with a shader that cycles colourful "ads".
	var sw := w - 3.0
	var sh := h * 0.42
	var sy := h * 0.62
	kit.add_box(base, "ScreenFrame", Vector3(0, sy, d * 0.5 + 0.2), Vector3(sw + 0.6, sh + 0.6, 0.4), kit.toy(Color("15141c"), 0, 0.5))
	var screen := ShaderMaterial.new()
	screen.shader = load("res://world/screen.gdshader")
	var quad := QuadMesh.new()
	quad.size = Vector2(sw, sh)
	quad.material = screen
	kit.mesh(base, "Screen", quad, Transform3D(Basis(), Vector3(0, sy, d * 0.5 + 0.41)), false)
	kit.omni(base, "ScreenGlow", Vector3(0, sy - sh * 0.3, d * 0.5 + 6.0), Color("b8a0ff"), 1.6, 16.0)
	kit.label(base, "Name", "HACHI VISION", Transform3D(Basis(), Vector3(0, sy + sh * 0.5 + 0.9, d * 0.5 + 0.42)), 1.1, _hdr(Color("ffd166"), 2.2))
	# Shops along the bottom.
	for i in 3:
		var x := -w * 0.5 + w * (i + 0.5) / 3.0
		var c := Color(Plan.NEON_COLORS[(i * 3 + 1) % Plan.NEON_COLORS.size()])
		kit.mesh(base, "ShopWindow", kit.box(Vector3(w / 3.0 - 1.2, 2.3, 0.08), kit.toy(c.lightened(0.5).darkened(0.2), 1.2, 0.2)), Transform3D(Basis(), Vector3(x, 1.5, d * 0.5 + 0.06)), false)
		kit.label(base, "Sign", ["CAFE", "GAMES", "RECORDS"][i], Transform3D(Basis(), Vector3(x, 3.4, d * 0.5 + 0.12)), 0.6, _hdr(c))
		doors.append({"at": base.transform * Vector3(x, 0, d * 0.5 + 1.0), "style": "neon"})
	kit.add_box(base, "Canopy", Vector3(0, 3.05, d * 0.5 + 0.9), Vector3(w, 0.16, 1.8), kit.toy(Color("2e2b3d"), 0.1))
	for i in 9:
		kit.mesh(base, "CanopyLight", kit.sphere(0.1, kit.glow(Color("fff0c8"), 3.5)), Transform3D(Basis(), Vector3(-w * 0.45 + i * w * 0.9 / 8.0, 2.92, d * 0.5 + 1.6)), false)


## A theatre with a lit marquee on Grand Street.
func _theatre(lot: Dictionary) -> void:
	var w: float = lot.size.x
	var d: float = lot.size.y
	var h: float = lot.height
	var base := kit.node(root, "GrandTheatre", Kit.yawed(lot.yaw, Kit.v3(lot.centre)))
	var brick := Color("6b3a3a")
	kit.mesh(base, "Walls", kit.box(Vector3(w, h, d), kit.wall(brick, Vector3(w, h, d), 4.0, 0.35, Color("ffcf8a"), Color("ffcf8a"), Vector2(2.6, 3.4), 6.0), 0.2), Transform3D(Basis(), Vector3(0, h * 0.5, 0)))
	kit.shape(solid, "Theatre", Kit.yawed(lot.yaw, Kit.v3(lot.centre, h * 0.5)), Vector3(w, h, d))
	kit.add_box(base, "Cornice", Vector3(0, h + 0.3, 0), Vector3(w + 0.4, 0.6, d + 0.4), kit.toy(Color("d9c7a8"), 0, 0.7))
	kit.add_box(base, "Pediment", Vector3(0, h + 1.4, d * 0.5 - 0.6), Vector3(w * 0.6, 1.8, 0.6), kit.toy(Color("d9c7a8"), 0, 0.7))
	var front := d * 0.5
	# Marquee: a lit box over the doors, bulbs all round.
	kit.add_box(base, "Marquee", Vector3(0, 4.0, front + 1.5), Vector3(w - 2.0, 1.3, 3.0), kit.toy(Color("1d1a26"), 0.1))
	kit.label(base, "MarqueeText", "TONIGHT: LIVE MUSIC", Transform3D(Basis(), Vector3(0, 4.05, front + 3.02)), 0.55, _hdr(Color("fff0b0"), 2.0))
	for i in 18:
		kit.mesh(base, "Bulb", kit.sphere(0.09, kit.glow(Color("ffe08a"), 4.0)), Transform3D(Basis(), Vector3(-(w - 2.0) * 0.5 + i * (w - 2.0) / 17.0, 4.72, front + 3.0)), false)
		kit.mesh(base, "Bulb", kit.sphere(0.09, kit.glow(Color("ffe08a"), 4.0)), Transform3D(Basis(), Vector3(-(w - 2.0) * 0.5 + i * (w - 2.0) / 17.0, 3.38, front + 3.0)), false)
	# The tall blade sign: G R A N D.
	kit.add_box(base, "Blade", Vector3(0, 9.5, front + 0.8), Vector3(0.4, 8.0, 1.6), kit.toy(Color("8a1c2b"), 0.5))
	for face in [1.0, -1.0]:
		var l := kit.label(base, "BladeText", "G\nR\nA\nN\nD", Transform3D(Basis(Vector3.UP, PI * 0.5 * face), Vector3(0.22 * face, 9.5, front + 0.8)), 1.05, _hdr(Color("ffd166"), 2.6))
		l.line_spacing = 0.4 / l.pixel_size
	kit.omni(base, "MarqueeLight", Vector3(0, 3.0, front + 4.5), Color("ffd08a"), 2.0, 11.0)
	kit.add_box(base, "Doors", Vector3(0, 1.3, front + 0.05), Vector3(w - 4.0, 2.6, 0.1), kit.toy(Color("3b1d22"), 0.3))
	doors.append({"at": base.transform * Vector3(0, 0, front + 1.0), "style": "avenue"})
	light_count += 1


## A karaoke house with stacked pagoda roofs on Neon Row.
func _pagoda(lot: Dictionary) -> void:
	var w: float = lot.size.x
	var d: float = lot.size.y
	var base := kit.node(root, "KaraokePagoda", Kit.yawed(lot.yaw, Kit.v3(lot.centre)))
	var red := Color("8e2430")
	var roof := kit.toy(Color("2a2d3a"), 0, 0.7)
	var y := 0.0
	var tiers := 4
	for t in tiers:
		var shrink := t * 0.9
		var tw := w - shrink
		var td := d - shrink
		var th := 3.6
		kit.mesh(base, "Floor%d" % t, kit.box(Vector3(tw, th, td), kit.wall(red.darkened(t * 0.05), Vector3(tw, th, td), 20.0 + t, 0.7, Color("ffcf8a"), Color("ff9ec4"), Vector2(1.8, 3.6), 1.4 if t > 0 else 9.0), 0.1), Transform3D(Basis(), Vector3(0, y + th * 0.5, 0)))
		y += th
		kit.mesh(base, "Eave%d" % t, kit.box(Vector3(tw + 1.6, 0.35, td + 1.6), roof, 0.12), Transform3D(Basis(), Vector3(0, y + 0.1, 0)))
		# Lanterns hanging from the corners of each eave.
		for cx in [-1.0, 1.0]:
			kit.mesh(base, "EaveLantern", kit.capsule(0.22, 0.22, 0.6, kit.glow(Color("ff5d5d"), 2.2)), Transform3D(Basis(), Vector3(cx * (tw * 0.5 + 0.6), y - 0.35, td * 0.5 + 0.6)), false, 90.0)
		y += 0.3
	kit.shape(solid, "Pagoda", Kit.yawed(lot.yaw, Kit.v3(lot.centre, y * 0.5)), Vector3(w, y, d))
	kit.mesh(base, "Spire", kit.cyl(0.25, 0.04, 3.0, kit.toy(Color("d4a73a"), 0.4, 0.4, 0.2, 0.6)), Transform3D(Basis(), Vector3(0, y + 1.5, 0)))
	var front := d * 0.5
	kit.label(base, "Sign", "KARAOKE", Transform3D(Basis(), Vector3(0, 2.9, front + 0.2)), 0.75, _hdr(Color("ffd166"), 2.4), false, true)
	kit.label(base, "SignJp", "カラオケ", Transform3D(Basis(), Vector3(0, 6.4, front - 0.3)), 1.0, _hdr(Color("ff4fa0"), 2.4), true)
	kit.mesh(base, "Entrance", kit.box(Vector3(2.4, 2.3, 0.08), kit.toy(Color("ffd1e8").darkened(0.2), 1.3, 0.2)), Transform3D(Basis(), Vector3(0, 1.25, front + 0.06)), false)
	kit.omni(base, "Glow", Vector3(0, 2.4, front + 2.0), Color("ff7ab0"), 1.3, 8.0)
	doors.append({"at": base.transform * Vector3(0, 0, front + 1.0), "style": "neon"})
	light_count += 1


## The Uptown club: bass leaking out, a rooftop bar strung with bulbs.
func _club(lot: Dictionary) -> void:
	var b := _building(lot, 9000, {})
	b.name = "UptownClub"
	var d: float = lot.size.y
	var w: float = lot.size.x
	var h: float = lot.height
	var front := d * 0.5
	kit.add_box(b, "ClubBand", Vector3(0, 3.9, front + 0.12), Vector3(w - 0.4, 0.5, 0.1), kit.glow(Color("ff4fa0"), 2.6), 0, false)
	kit.label(b, "ClubSign", "CLUB ORBIT", Transform3D(Basis(), Vector3(0, 5.0, front + 0.2)), 1.0, _hdr(Color("c77dff"), 2.6))
	var sound := AudioStreamPlayer3D.new()
	sound.name = "ClubBass"
	sound.stream = CLUB_SOUND
	sound.position = Vector3(0, 1.5, front + 0.5)
	sound.volume_db = -2.0
	sound.unit_size = 6.0
	sound.max_distance = 45.0
	sound.autoplay = true
	sound.bus = &"City"
	sound.set_script(LOOP_SOUND)
	b.add_child(sound)
	sound.owner = kit.owner
	# Roof bar: posts, a string of bulbs, a few tables.
	var top := h
	for i in 4:
		var x := -w * 0.4 + i * w * 0.8 / 3.0
		kit.add_box(b, "RoofPost", Vector3(x, top + 1.3, front - 1.0), Vector3(0.12, 2.6, 0.12), kit.toy(Color("2b2a36")), 0, true, 120.0)
	for i in 12:
		var x := -w * 0.4 + i * w * 0.8 / 11.0
		var sag := sin(PI * float(i % 4) / 3.0) * 0.35
		kit.mesh(b, "RoofBulb", kit.sphere(0.1, kit.glow(Color("ffe6a8"), 4.0)), Transform3D(Basis(), Vector3(x, top + 2.5 - sag, front - 1.0)), false)
	kit.omni(b, "RoofGlow", Vector3(0, top + 2.0, front - 2.0), Color("ffcf8a"), 1.2, 9.0)
	light_count += 1
