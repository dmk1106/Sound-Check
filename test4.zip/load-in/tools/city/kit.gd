extends RefCounted
## Building blocks for the city builder: the toy look's meshes and materials
## (shared wherever they repeat), labels, lights and collision, all owned by
## the scene being built so they get saved with it.

const TOY := preload("res://art/toy.gdshader")
const BUILDING := preload("res://world/building.gdshader")
const GROUND := preload("res://world/ground.gdshader")
const BOX := preload("res://art/meshes/rounded_box_mesh.gd")
const CYL := preload("res://art/meshes/rounded_cylinder_mesh.gd")
const PANEL := preload("res://art/meshes/rounded_panel_mesh.gd")
const CAPSULE := preload("res://art/meshes/tapered_capsule_mesh.gd")
const FONT_JP := preload("res://art/fonts/NotoSansJP-signs.ttf")
const FONT := preload("res://art/fonts/fredoka_semibold.tres")
const FLICKER := preload("res://world/flicker.gd")

## The scene root everything is saved under.
var owner: Node

var _materials := {}
var _meshes := {}
var _names := {}


func _init(scene_owner: Node) -> void:
	owner = scene_owner


func adopt(node: Node) -> void:
	node.owner = owner
	for child in node.get_children():
		if child.owner == null or child.owner == node:
			adopt(child)


## A unique, readable child name under `parent`.
func name_for(parent: Node, base: String) -> String:
	var key := str(parent.get_instance_id()) + base
	var n: int = _names.get(key, 0)
	_names[key] = n + 1
	return base if n == 0 else "%s%d" % [base, n]


func node(parent: Node, base: String, xform := Transform3D.IDENTITY) -> Node3D:
	var n := Node3D.new()
	n.name = name_for(parent, base)
	n.transform = xform
	parent.add_child(n)
	n.owner = owner
	return n


# --- materials ---------------------------------------------------------------

func toy(color: Color, light := 0.0, roughness := 0.75, softness := 0.3, metallic := 0.0) -> ShaderMaterial:
	var key := "%s|%.2f|%.2f|%.2f|%.2f" % [color.to_html(), light, roughness, softness, metallic]
	if _materials.has(key):
		return _materials[key]
	var m := ShaderMaterial.new()
	m.shader = TOY
	m.set_shader_parameter(&"albedo", color)
	m.set_shader_parameter(&"softness", softness)
	m.set_shader_parameter(&"roughness", roughness)
	if metallic > 0.0:
		m.set_shader_parameter(&"metallic", metallic)
	if light > 0.0:
		m.set_shader_parameter(&"light", light)
	_materials[key] = m
	return m


## Neon / lamp glass: bright, ignores most lighting.
func glow(color: Color, strength := 2.0) -> ShaderMaterial:
	return toy(color, strength, 0.4, 0.2)


func wall(color: Color, size: Vector3, seed: float, lit := 0.45, window_a := Color("ffb870"), window_b := Color("8ad8ff"),
		spacing := Vector2(2.3, 3.1), first_row := 4.2, glass := false) -> ShaderMaterial:
	var m := ShaderMaterial.new()
	m.shader = BUILDING
	m.set_shader_parameter(&"albedo", color)
	m.set_shader_parameter(&"window_color", window_a)
	m.set_shader_parameter(&"window_color_b", window_b)
	m.set_shader_parameter(&"lit_ratio", lit)
	m.set_shader_parameter(&"glow", 1.6)
	m.set_shader_parameter(&"window_spacing", spacing)
	m.set_shader_parameter(&"window_size", Vector2(spacing.x * (0.62 if glass else 0.48), spacing.y * (0.62 if glass else 0.5)))
	m.set_shader_parameter(&"first_row", first_row)
	m.set_shader_parameter(&"seed", seed)
	m.set_shader_parameter(&"footprint", Vector2(size.x, size.z))
	return m


func ground(params: Dictionary) -> ShaderMaterial:
	var key := "ground" + str(params)
	if _materials.has(key):
		return _materials[key]
	var m := ShaderMaterial.new()
	m.shader = GROUND
	for k in params:
		m.set_shader_parameter(StringName(k), params[k])
	_materials[key] = m
	return m


# --- meshes ------------------------------------------------------------------

func box(size: Vector3, material: Material, radius := 0.05, segments := 3) -> Mesh:
	var key := "box%s|%d|%.3f|%d" % [str(size.snapped(Vector3.ONE * 0.01)), material.get_instance_id(), radius, segments]
	if _meshes.has(key):
		return _meshes[key]
	var mesh: PrimitiveMesh = BOX.new()
	mesh.size = size
	mesh.radius = minf(radius, minf(size.x, minf(size.y, size.z)) * 0.5)
	mesh.segments = segments
	mesh.material = material
	_meshes[key] = mesh
	return mesh


func cyl(bottom: float, top: float, height: float, material: Material, segments := 12, bevel := 0.03) -> Mesh:
	var key := "cyl%.3f|%.3f|%.3f|%d|%d" % [bottom, top, height, material.get_instance_id(), segments]
	if _meshes.has(key):
		return _meshes[key]
	var mesh: PrimitiveMesh = CYL.new()
	mesh.bottom_radius = bottom
	mesh.top_radius = top
	mesh.height = height
	mesh.bevel = minf(bevel, minf(height * 0.5, minf(bottom, top) * 0.5 if minf(bottom, top) > 0.0 else bevel))
	mesh.radial_segments = segments
	mesh.bevel_segments = 2
	mesh.material = material
	_meshes[key] = mesh
	return mesh


func panel(size: Vector2, material: Material, radius := 0.1) -> Mesh:
	var key := "panel%s|%d|%.3f" % [str(size.snapped(Vector2.ONE * 0.01)), material.get_instance_id(), radius]
	if _meshes.has(key):
		return _meshes[key]
	var mesh: PrimitiveMesh = PANEL.new()
	mesh.size = size
	mesh.radius = minf(radius, minf(size.x, size.y) * 0.5)
	mesh.segments = 4
	mesh.material = material
	_meshes[key] = mesh
	return mesh


func sphere(radius: float, material: Material, height := -1.0) -> Mesh:
	var key := "sphere%.3f|%.3f|%d" % [radius, height, material.get_instance_id()]
	if _meshes.has(key):
		return _meshes[key]
	var mesh := SphereMesh.new()
	mesh.radius = radius
	mesh.height = radius * 2.0 if height < 0.0 else height
	mesh.radial_segments = 12
	mesh.rings = 6
	mesh.material = material
	_meshes[key] = mesh
	return mesh


func capsule(bottom: float, top: float, height: float, material: Material) -> Mesh:
	var key := "cap%.3f|%.3f|%.3f|%d" % [bottom, top, height, material.get_instance_id()]
	if _meshes.has(key):
		return _meshes[key]
	var mesh: PrimitiveMesh = CAPSULE.new()
	mesh.bottom_radius = bottom
	mesh.top_radius = top
	mesh.height = height
	mesh.radial_segments = 10
	mesh.rings = 4
	mesh.material = material
	_meshes[key] = mesh
	return mesh


# --- imported models (art/kenney, art/nature) ----------------------------------

const MODEL_MESHES := "res://art/meshes/imported/"
var _models := {}


## The mesh of an imported model (its first MeshInstance3D, with that node's
## transform baked in). Saved once as a .res next to the other meshes so the
## city scene refers to it instead of carrying a copy.
func model(path: String) -> Mesh:
	if _models.has(path):
		return _models[path]
	var saved := MODEL_MESHES + path.get_file().get_basename() + ".res"
	var mesh: Mesh = null
	if ResourceLoader.exists(saved) and FileAccess.get_modified_time(ProjectSettings.globalize_path(saved)) >= FileAccess.get_modified_time(ProjectSettings.globalize_path(path)):
		mesh = load(saved)
	else:
		var scene: Node = (load(path) as PackedScene).instantiate()
		var found: Array[Node] = scene.find_children("*", "MeshInstance3D", true, false)
		var mi := found[0] as MeshInstance3D
		var xform := Transform3D.IDENTITY
		var n: Node = mi
		while n != scene and n is Node3D:
			xform = (n as Node3D).transform * xform
			n = n.get_parent()
		var source := mi.mesh as ArrayMesh
		var out := ArrayMesh.new()
		for s in source.get_surface_count():
			var arrays := source.surface_get_arrays(s)
			if xform != Transform3D.IDENTITY:
				var verts: PackedVector3Array = arrays[Mesh.ARRAY_VERTEX]
				var normals: PackedVector3Array = arrays[Mesh.ARRAY_NORMAL]
				for i in verts.size():
					verts[i] = xform * verts[i]
				for i in normals.size():
					normals[i] = (xform.basis * normals[i]).normalized()
				arrays[Mesh.ARRAY_VERTEX] = verts
				arrays[Mesh.ARRAY_NORMAL] = normals
			out.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
			var mat := source.surface_get_material(s)
			if mat == null:
				mat = mi.get_surface_override_material(s)
			out.surface_set_material(s, mat)
		DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(MODEL_MESHES))
		ResourceSaver.save(out, saved, ResourceSaver.FLAG_COMPRESS)
		out.take_over_path(saved)
		mesh = out
		scene.free()
	_models[path] = mesh
	return mesh


## Place an imported model. `fade` > 0: only drawn within that many metres.
func place(parent: Node, base: String, path: String, xform: Transform3D, shadow := true, fade := 0.0) -> MeshInstance3D:
	return mesh(parent, base, model(path), xform, shadow, fade)


# --- nodes -------------------------------------------------------------------

## A mesh instance. `fade` > 0: drawn only within that many metres (small details).
func mesh(parent: Node, base: String, the_mesh: Mesh, xform: Transform3D, shadow := true, fade := 0.0) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.name = name_for(parent, base)
	mi.mesh = the_mesh
	mi.transform = xform
	if not shadow:
		mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	if fade > 0.0:
		mi.visibility_range_end = fade
		mi.visibility_range_end_margin = fade * 0.1
		mi.visibility_range_fade_mode = GeometryInstance3D.VISIBILITY_RANGE_FADE_SELF
	parent.add_child(mi)
	mi.owner = owner
	return mi


func add_box(parent: Node, base: String, centre: Vector3, size: Vector3, material: Material, yaw := 0.0, shadow := true, fade := 0.0, radius := 0.05) -> MeshInstance3D:
	return mesh(parent, base, box(size, material, radius), Transform3D(Basis(Vector3.UP, yaw), centre), shadow, fade)


func label(parent: Node, base: String, text: String, xform: Transform3D, height: float, color: Color, jp := false, flicker := false, font_size := 96) -> Label3D:
	var l := Label3D.new()
	l.name = name_for(parent, base)
	l.text = text
	l.transform = xform
	l.font = FONT_JP if jp else FONT
	l.font_size = font_size
	l.outline_size = 0
	l.double_sided = false
	# Height of a line of text in metres.
	l.pixel_size = height / float(font_size)
	l.modulate = color
	if flicker:
		l.set_script(FLICKER)
	parent.add_child(l)
	l.owner = owner
	return l


func omni(parent: Node, base: String, at: Vector3, color: Color, energy := 1.0, light_range := 6.0) -> OmniLight3D:
	var light := OmniLight3D.new()
	light.name = name_for(parent, base)
	light.position = at
	light.light_color = color
	light.light_energy = energy
	light.omni_range = light_range
	light.omni_attenuation = 1.2
	light.shadow_enabled = false
	light.distance_fade_enabled = true
	light.distance_fade_begin = 70.0
	light.distance_fade_length = 25.0
	parent.add_child(light)
	light.owner = owner
	return light


func spot(parent: Node, base: String, xform: Transform3D, color: Color, energy := 2.0, light_range := 9.0, angle := 40.0) -> SpotLight3D:
	var light := SpotLight3D.new()
	light.name = name_for(parent, base)
	light.transform = xform
	light.light_color = color
	light.light_energy = energy
	light.spot_range = light_range
	light.spot_angle = angle
	light.shadow_enabled = false
	light.distance_fade_enabled = true
	light.distance_fade_begin = 70.0
	light.distance_fade_length = 25.0
	parent.add_child(light)
	light.owner = owner
	return light


func shape(body: Node, base: String, xform: Transform3D, size: Vector3) -> CollisionShape3D:
	var s := CollisionShape3D.new()
	s.name = name_for(body, base)
	var b := BoxShape3D.new()
	b.size = size
	s.shape = b
	s.transform = xform
	body.add_child(s)
	s.owner = owner
	return s


func cyl_shape(body: Node, base: String, at: Vector3, radius: float, height: float) -> CollisionShape3D:
	var s := CollisionShape3D.new()
	s.name = name_for(body, base)
	var c := CylinderShape3D.new()
	c.radius = radius
	c.height = height
	s.shape = c
	s.position = at
	body.add_child(s)
	s.owner = owner
	return s


## Basis turning +z toward yaw (radians), as a Node3D's rotation.y.
static func yawed(yaw: float, at: Vector3) -> Transform3D:
	return Transform3D(Basis(Vector3.UP, yaw), at)


static func v3(p: Vector2, y := 0.0) -> Vector3:
	return Vector3(p.x, y, p.y)
