extends RefCounted
## Central Park: the green behind the starting house, between the back
## gardens and the edge of town. Winding paths, lawns, a pond, a woodland
## ramble east of the railway, and the quiet places to sit and write a song.
##
##   back gate      the house's garden gate opens onto the gate path
##   great lawn     open grass behind the house, lamps round its edge
##   fountain       the plaza where the paths meet, a two-tier stone fountain
##   the pond       west of the fountain; the music pavilion on its shore
##                  (`Seat`: the nicest seat in the city)
##   the old maple  a red tree on a knoll north of the lawn, a bench under it
##                  (`PoolSeat`)
##   the ramble     woods, boulders and a stepping-stone trail east of the tracks
##   ways in        Mill Road's turning circle, the gap off Creek Lane, the gate
##
## Rebuilt on every run of the city builder: the CentralPark node is emptied except
## for its Seat, which keeps its settings.

const Plan := preload("res://tools/city/plan.gd")
const Layout := preload("res://tools/city/layout.gd")
const Kit := preload("res://tools/city/kit.gd")
const Ground := preload("res://tools/city/ground.gd")

const SEAT_SCRIPT := preload("res://world/seat.gd")
const LOOP_SOUND := preload("res://world/loop_sound.gd")
const CUTAWAY_SCRIPT := preload("res://world/interior_cutaway.gd")
const WATER_SOUND := preload("res://audio/ambience/creek.ogg")
const WATER_SHADER := preload("res://world/water.gdshader")

const POND := Vector2(-33, -34)
const POND_RADII := Vector2(10.0, 7.0)
const FOUNTAIN := Vector2(1, -28.5)
const PAVILION := Vector2(-22.6, -25.2)
const MAPLE := Vector2(-5, -42.5)
const BACK_GATE := Vector2(4.5, -13.6)

## Paths as control points (smoothed); [points, half width].
const PATHS := [
	# Back gate to the fountain.
	[[Vector2(4.5, -13.0), Vector2(4.2, -17.5), Vector2(3.0, -22.0), Vector2(2.0, -25.0)], 1.1],
	# Round the pond: fountain - pavilion - west shore - north shore - maple - fountain.
	[[Vector2(-3.0, -27.0), Vector2(-9.0, -24.0), Vector2(-16.0, -21.8), Vector2(-24.0, -20.6), Vector2(-33.0, -21.6),
			Vector2(-41.5, -24.2), Vector2(-46.5, -30.0), Vector2(-48.0, -37.0), Vector2(-44.0, -44.5), Vector2(-34.0, -46.5),
			Vector2(-23.0, -45.0), Vector2(-14.0, -42.5), Vector2(-7.5, -40.5), Vector2(-3.5, -36.0), Vector2(-1.0, -32.5)], 1.25],
	# In from the end of Mill Road.
	[[Vector2(-53.0, -10.0), Vector2(-51.0, -16.0), Vector2(-47.5, -21.5), Vector2(-43.0, -24.8)], 1.0],
	# Up to the pavilion.
	[[Vector2(-19.5, -21.4), Vector2(-21.0, -23.2)], 0.9],
	# East: under the railway, along the ramble edge, down the gap to Creek Lane.
	[[Vector2(5.0, -29.0), Vector2(10.0, -28.6), Vector2(14.0, -28.0), Vector2(19.0, -28.6), Vector2(26.0, -29.5),
			Vector2(32.0, -27.0), Vector2(36.5, -21.0), Vector2(38.0, -14.0), Vector2(38.0, -6.0), Vector2(38.0, 2.0), Vector2(38.0, 11.5)], 1.15],
	# Out to the meadow in the east.
	[[Vector2(32.0, -27.0), Vector2(44.0, -30.0), Vector2(56.0, -27.5), Vector2(68.0, -31.0), Vector2(80.0, -28.0), Vector2(92.0, -32.0)], 0.95],
]
## The ramble's stepping-stone trail (rock path pieces, not paving).
const RAMBLE := [Vector2(21.0, -29.5), Vector2(24.0, -36.0), Vector2(31.0, -41.5), Vector2(40.0, -42.0), Vector2(47.0, -37.0), Vector2(46.0, -31.0)]
## Open lawns (no trees): centre, radii.
const LAWNS := [[Vector2(-5.0, -19.5), Vector2(9.0, 4.0)], [Vector2(62.0, -40.0), Vector2(14.0, 6.0)], [Vector2(-60.0, -32.0), Vector2(8.0, 9.0)]]

var kit: Kit
var layout: Layout
var streets
var city: Node3D
var root: Node3D
var solid: StaticBody3D
var rng := RandomNumberGenerator.new()
var light_count := 0
var pond := PackedVector2Array()
## Smoothed path centre lines (also drawn on the minimap).
var trails: Array[PackedVector2Array] = []
var _halves: Array[float] = []
var _ramble := PackedVector2Array()
var _busy: Array[Vector3] = []  # x, z, radius: places to keep clear of planting
var _area := PackedVector2Array()


func _init(the_kit: Kit, the_layout: Layout, the_streets, the_city: Node3D) -> void:
	kit = the_kit
	layout = the_layout
	streets = the_streets
	city = the_city
	rng.seed = 1857
	for i in 48:
		var a := TAU * i / 48.0
		var wobble := 1.0 + 0.12 * sin(a * 3.0 + 0.7) + 0.06 * sin(a * 5.0 + 2.1)
		pond.append(POND + Vector2(cos(a) * POND_RADII.x, sin(a) * POND_RADII.y) * wobble)
	for spec in PATHS:
		trails.append(Layout.smooth(PackedVector2Array(spec[0]), 1.2))
		_halves.append(spec[1])
	_ramble = Layout.smooth(PackedVector2Array(RAMBLE), 1.0)
	_area = Layout.rect_polygon(_reserved("park_central"))


func build() -> void:
	root = city.get_node_or_null("CentralPark")
	if root == null:
		root = city.get_node("Creek")
		root.name = "CentralPark"
	for child in root.get_children():
		if child.name != "Seat":
			root.remove_child(child)
			child.free()
	solid = StaticBody3D.new()
	solid.name = "ParkSolid"
	solid.collision_mask = 0
	root.add_child(solid)
	solid.owner = kit.owner
	_busy.append(Vector3(FOUNTAIN.x, FOUNTAIN.y, 6.5))
	_busy.append(Vector3(PAVILION.x, PAVILION.y, 5.0))
	_busy.append(Vector3(MAPLE.x, MAPLE.y, 6.0))
	_ground()
	_paths()
	_pond()
	_fountain()
	_pavilion()
	_maple()
	_ramble_trail()
	_gateways()
	_lamps_and_benches()
	_planting()
	_fireflies()
	_sounds()


## Water outlines for the minimap.
func water_polygons() -> Array:
	return [pond]


# --- ground --------------------------------------------------------------------

func _ground() -> void:
	var grass := kit.ground({"color": Color(0.15, 0.32, 0.2), "patch_color": Color(0.12, 0.27, 0.17), "patch_size": 4.0,
			"dot_density": 0.07, "dot_spacing": 0.6, "dot_radius": 0.035, "dot_color": Color(0.7, 0.82, 0.6), "dot_color_b": Color(0.9, 0.78, 0.5),
			"wetness": 0.3})
	kit.mesh(root, "Lawn", Ground.polygon_mesh(_area, -0.008, grass), Transform3D.IDENTITY, false)
	# The gap between the houses off Creek Lane.
	var gap: Array = _reserved("park_path").rect
	kit.mesh(root, "LawnGap", Ground.polygon_mesh(Layout.rect_corners(gap[0], gap[1], 0.0), -0.007, grass), Transform3D.IDENTITY, false)


func _paths() -> void:
	var paving := kit.ground({"color": Color(0.52, 0.47, 0.44), "patch_color": Color(0.47, 0.43, 0.41), "patch_size": 1.6,
			"tile_size": Vector2(0.9, 0.6), "tile_gap": 0.04, "gap_darkness": 0.3, "tile_variation": 0.1,
			"wetness": 0.85, "puddle_size": 1.3})
	var kerb := kit.ground({"color": Color(0.36, 0.34, 0.36), "patch_color": Color(0.32, 0.3, 0.33), "patch_size": 1.0, "wetness": 0.6})
	for i in trails.size():
		var line := trails[i]
		var half := PackedFloat32Array()
		half.resize(line.size())
		half.fill(_halves[i])
		kit.mesh(root, "PathEdge", _strip(line, half, 0.18, 0.004 + i * 0.0004, kerb), Transform3D.IDENTITY, false)
		kit.mesh(root, "Path", _strip(line, half, 0.0, 0.006 + i * 0.0004, paving), Transform3D.IDENTITY, false)


# --- the pond -----------------------------------------------------------------

func _pond() -> void:
	var bank := kit.ground({"color": Color(0.24, 0.22, 0.2), "patch_color": Color(0.19, 0.18, 0.17), "patch_size": 1.5,
			"dot_density": 0.5, "dot_spacing": 0.35, "dot_radius": 0.06, "dot_color": Color(0.45, 0.43, 0.48), "dot_color_b": Color(0.34, 0.32, 0.36),
			"wetness": 1.0, "puddle_size": 1.2})
	kit.mesh(root, "PondBank", Ground.polygon_mesh(_grown(pond, 1.3), -0.002, bank), Transform3D.IDENTITY, false)
	var water := ShaderMaterial.new()
	water.shader = WATER_SHADER
	water.set_shader_parameter(&"flow", Vector2(0.05, 0.08))
	water.set_shader_parameter(&"deep", Color(0.03, 0.08, 0.13))
	kit.mesh(root, "Pond", Ground.polygon_mesh(pond, 0.03, water), Transform3D.IDENTITY, false)
	# You can paddle at the edge but not wade in: the middle is solid.
	var inner := _grown(pond, -1.4)
	var points := PackedVector3Array()
	for p in inner:
		points.append(Kit.v3(p, 0.0))
		points.append(Kit.v3(p, 1.2))
	var hull := ConvexPolygonShape3D.new()
	hull.points = points
	var shape := CollisionShape3D.new()
	shape.name = "PondWater"
	shape.shape = hull
	solid.add_child(shape)
	shape.owner = kit.owner
	kit.omni(root, "PondGlow", Kit.v3(POND, 1.2), Color(0.43, 0.8, 0.95), 0.8, 12.0)
	light_count += 1
	# Boulders and reeds round the shore, lily pads with glowing flowers.
	var reed := kit.toy(Color("4f6b3a"), 0, 0.95, 0.5)
	var rush := kit.toy(Color("5b3d2b"), 0, 0.9, 0.4)
	for i in 22:
		var k := int(i * pond.size() / 22.0)
		var n := (pond[k] - POND).normalized()
		var p: Vector2 = pond[k] + n * rng.randf_range(0.2, 1.1)
		if p.distance_to(PAVILION) < 5.5 or _gap_to_paths(p) < 1.6:
			continue
		if i % 3 == 0:
			streets.rock(Kit.v3(p, -0.1), rng.randf_range(0.45, 0.8), solid)
		elif i % 3 == 1:
			_reeds(p, reed, rush)
		else:
			streets.ground_plant(Kit.v3(p))
	var pad := kit.toy(Color("2f6b45"), 0, 0.9, 0.5)
	var flower := kit.glow(Color("ff9ec4"), 1.6)
	for i in 18:
		var a := rng.randf() * TAU
		var r := rng.randf_range(0.35, 0.85)
		var p := POND + Vector2(cos(a) * POND_RADII.x, sin(a) * POND_RADII.y) * r
		if p.distance_to(PAVILION) < 7.0:
			continue
		kit.mesh(root, "LilyPad", kit.cyl(0.38, 0.38, 0.02, pad, 10, 0.0), Transform3D(Basis(Vector3.UP, a), Kit.v3(p, 0.045)), false, 70.0)
		if i % 3 == 0:
			kit.mesh(root, "Lily", kit.sphere(0.09, flower), Transform3D(Basis(), Kit.v3(p, 0.11)), false, 70.0)


# --- the fountain plaza ----------------------------------------------------------

func _fountain() -> void:
	var plaza := kit.node(root, "FountainPlaza", Kit.yawed(0.0, Kit.v3(FOUNTAIN)))
	# A round paved plaza with a two-tier stone fountain in the middle.
	var paving := kit.ground({"color": Color(0.5, 0.46, 0.45), "patch_color": Color(0.45, 0.42, 0.41), "patch_size": 1.6,
			"tile_size": Vector2(0.75, 0.75), "tile_gap": 0.04, "gap_darkness": 0.32, "tile_variation": 0.12,
			"wetness": 0.85, "puddle_size": 1.3})
	var stone := kit.toy(Color("9c958c"), 0.0, 0.8, 0.3)
	var dark_stone := kit.toy(Color("6f6962"), 0.0, 0.85, 0.3)
	kit.mesh(plaza, "Paving", Ground.polygon_mesh(Ground.disc_polygon(Vector2.ZERO, 6.2, 40), 0.006, paving), Transform3D.IDENTITY, false)
	kit.mesh(plaza, "Kerb", kit.cyl(6.35, 6.35, 0.08, dark_stone, 40, 0.02), Transform3D(Basis(), Vector3(0, -0.04, 0)), false)
	kit.mesh(plaza, "Basin", kit.cyl(2.7, 2.6, 0.62, stone, 32, 0.08), Transform3D.IDENTITY, true)
	kit.mesh(plaza, "Rim", kit.cyl(2.75, 2.75, 0.1, dark_stone, 32, 0.04), Transform3D(Basis(), Vector3(0, 0.6, 0)), false)
	kit.mesh(plaza, "Column", kit.cyl(0.45, 0.3, 1.5, stone, 16, 0.05), Transform3D(Basis(), Vector3(0, 0.5, 0)), true)
	kit.mesh(plaza, "UpperBowl", kit.cyl(0.35, 1.05, 0.32, stone, 20, 0.06), Transform3D(Basis(), Vector3(0, 1.85, 0)), true)
	kit.mesh(plaza, "Finial", kit.cyl(0.22, 0.12, 0.5, stone, 12, 0.04), Transform3D(Basis(), Vector3(0, 2.15, 0)), true)
	kit.cyl_shape(solid, "Fountain", Kit.v3(FOUNTAIN, 0.6), 2.75, 1.2)
	# Water in both bowls, a thin jet and a glow from under the water.
	var water := ShaderMaterial.new()
	water.shader = WATER_SHADER
	water.set_shader_parameter(&"flow", Vector2(0.2, 0.3))
	kit.mesh(plaza, "Water", kit.cyl(2.5, 2.5, 0.04, water, 32, 0.0), Transform3D(Basis(), Vector3(0, 0.5, 0)), false)
	kit.mesh(plaza, "UpperWater", kit.cyl(0.95, 0.95, 0.03, water, 20, 0.0), Transform3D(Basis(), Vector3(0, 2.13, 0)), false)
	var jet := kit.glow(Color("7fb8d0"), 0.45)
	kit.mesh(plaza, "Jet", kit.cyl(0.06, 0.02, 0.7, jet, 8, 0.0), Transform3D(Basis(), Vector3(0, 2.62, 0)), false)
	for i in 6:
		var a := TAU * i / 6.0
		var d := Vector3(cos(a), 0, sin(a))
		# Little arcs of water falling from the upper bowl into the basin.
		kit.mesh(plaza, "Spill", kit.cyl(0.02, 0.035, 1.45, jet, 6, 0.0),
				Transform3D(Basis(d.cross(Vector3.UP).normalized(), -0.25), d * 1.08 + Vector3(0, 1.3, 0)), false)
	kit.omni(plaza, "FountainLight", Vector3(0, 0.9, 0), Color("9be7ff"), 1.1, 8.0)
	kit.omni(plaza, "PlazaLight", Vector3(0, 4.5, 0), Color("ffd9b0"), 0.8, 13.0)
	light_count += 2
	# Flower beds round the edge.
	for i in 8:
		var a := TAU * (i + 0.5) / 8.0
		var p := FOUNTAIN + Vector2(cos(a), sin(a)) * 5.8
		if _gap_to_paths(p) < 1.6:
			continue
		streets.flower_bed(Kit.v3(p), 0.9)
		streets.bush(Kit.v3(p + Vector2(cos(a), sin(a)) * 1.2), 0.8)


# --- the music pavilion ----------------------------------------------------------

## A little octagonal bandstand on the pond's shore. Its bench, facing the
## water, is the Seat where songs get written.
func _pavilion() -> void:
	var face := (POND - PAVILION).normalized()
	var yaw := Layout.yaw_facing(face)
	var pav := kit.node(root, "Pavilion", Kit.yawed(yaw, Kit.v3(PAVILION)))
	var white := kit.toy(Color("e9e2d4"), 0.05, 0.75, 0.3)
	var roof := kit.toy(Color("2f5d55"), 0.05, 0.7, 0.3)
	var wood := kit.toy(Color("8a5a3c"), 0, 0.85, 0.3)
	var radius := 3.1
	kit.mesh(pav, "Floor", kit.cyl(radius + 0.3, radius + 0.3, 0.14, kit.toy(Color("8c8496"), 0, 0.85), 8, 0.03), Transform3D(Basis(), Vector3(0, 0.07, 0)))
	kit.mesh(pav, "Boards", kit.cyl(radius, radius, 0.02, wood, 8, 0.0), Transform3D(Basis(), Vector3(0, 0.15, 0)))
	for i in 8:
		var a := TAU * (i + 0.5) / 8.0
		var p := Vector3(cos(a) * radius, 0, sin(a) * radius)
		kit.mesh(pav, "Post", kit.cyl(0.11, 0.09, 2.7, white, 8), Transform3D(Basis(), p + Vector3(0, 1.49, 0)))
		kit.cyl_shape(solid, "PavilionPost", pav.transform * (p + Vector3(0, 1.4, 0)), 0.13, 2.8)
		# Low rail between the posts, open on the path side and the water side.
		var b := Vector3(cos(a + TAU / 8.0) * radius, 0, sin(a + TAU / 8.0) * radius)
		var mid := (p + b) * 0.5
		var toward_water: bool = mid.z > radius * 0.6
		var toward_path: bool = mid.z < -radius * 0.6
		if not toward_water and not toward_path:
			var rail_yaw := atan2(b.x - p.x, b.z - p.z) + PI * 0.5
			kit.add_box(pav, "Rail", mid + Vector3(0, 0.85, 0), Vector3(p.distance_to(b), 0.08, 0.08), white, rail_yaw)
			kit.add_box(pav, "RailLow", mid + Vector3(0, 0.45, 0), Vector3(p.distance_to(b), 0.06, 0.06), white, rail_yaw)
			kit.shape(solid, "PavilionRail", pav.transform * Transform3D(Basis(Vector3.UP, rail_yaw), mid + Vector3(0, 0.5, 0)), Vector3(p.distance_to(b), 1.0, 0.15))
	# Roof: a shallow eight-sided cone with a lantern finial.
	var canopy := kit.node(pav, "Canopy")
	kit.mesh(canopy, "Eave", kit.cyl(radius + 0.55, radius + 0.55, 0.16, white, 8, 0.03), Transform3D(Basis(), Vector3(0, 2.86, 0)))
	kit.mesh(canopy, "Roof", kit.cyl(radius + 0.5, 0.25, 1.5, roof, 8, 0.02), Transform3D(Basis(), Vector3(0, 3.68, 0)))
	kit.mesh(canopy, "Finial", kit.sphere(0.2, kit.glow(Color("ffd59a"), 3.0)), Transform3D(Basis(), Vector3(0, 4.55, 0)), false)
	# Under the roof it's dry, and the roof lifts away so the camera can see in.
	var cutaway := Area3D.new()
	cutaway.name = "Cutaway"
	cutaway.set_script(CUTAWAY_SCRIPT)
	pav.add_child(cutaway)
	cutaway.owner = kit.owner
	cutaway.collision_layer = 0
	cutaway.collision_mask = 0
	cutaway.monitoring = false
	cutaway.monitorable = false
	var box := CollisionShape3D.new()
	box.name = "Inside"
	var bs := BoxShape3D.new()
	bs.size = Vector3(radius * 1.7, 2.8, radius * 1.7)
	box.shape = bs
	box.position = Vector3(0, 1.4, 0)
	cutaway.add_child(box)
	box.owner = kit.owner
	cutaway.set("hide_while_inside", [NodePath("../Canopy")] as Array[NodePath])
	# Bulbs round the eave, a lantern hanging in the middle.
	for i in 16:
		var a := TAU * i / 16.0
		kit.mesh(pav, "Bulb", kit.sphere(0.07, kit.glow(Color("ffe6a8"), 4.0)), Transform3D(Basis(), Vector3(cos(a) * (radius + 0.45), 2.72, sin(a) * (radius + 0.45))), false, 90.0)
	kit.mesh(canopy, "Lantern", kit.capsule(0.2, 0.2, 0.5, kit.glow(Color("ffcf8a"), 2.6)), Transform3D(Basis(), Vector3(0, 2.25, 0)), false)
	kit.omni(pav, "Glow", Vector3(0, 2.1, 0), Color("ffc98a"), 1.3, 9.0)
	light_count += 1
	# The bench, facing the water, and the Seat on it.
	var bench := Transform3D(Basis(Vector3.UP, 0.0), Vector3(0, 0.15, 0.9))
	streets.bench(pav.transform * bench, false)
	var seat := root.get_node_or_null("Seat") as Node3D
	if seat == null:
		seat = Node3D.new()
		seat.name = "Seat"
		seat.set_script(SEAT_SCRIPT)
		root.add_child(seat)
		seat.owner = kit.owner
		seat.set("radius", 1.5)
	seat.set("seat_height", 0.6)
	seat.set("prompt", "sit in the pavilion")
	seat.transform = pav.transform * Transform3D(Basis(Vector3.UP, PI), Vector3(0, 0, 1.0))
	# Someone's left a guitar case and a radio.
	kit.add_box(pav, "GuitarCase", Vector3(1.4, 0.27, 0.5), Vector3(0.38, 0.18, 1.05), kit.toy(Color("2b2635"), 0, 0.6), 0.4)
	kit.add_box(pav, "Radio", Vector3(-1.3, 0.32, 0.9), Vector3(0.5, 0.3, 0.2), kit.toy(Color("b8643c"), 0.05, 0.7), -0.2)
	# A little deck out over the water in front of it.
	var deck := kit.node(root, "Deck", Kit.yawed(yaw, Kit.v3(PAVILION + face * (radius + 1.6))))
	for k in 7:
		kit.add_box(deck, "Plank", Vector3(0, 0.1, -1.2 + k * 0.4), Vector3(2.6, 0.06, 0.34), wood if k % 3 else kit.toy(Color("4e3424"), 0, 0.85, 0.3), rng.randf_range(-0.03, 0.03))
	for corner in [Vector3(-1.25, 0, -1.3), Vector3(1.25, 0, -1.3), Vector3(-1.25, 0, 1.3), Vector3(1.25, 0, 1.3)]:
		kit.mesh(deck, "Pile", kit.cyl(0.09, 0.09, 0.6, kit.toy(Color("4e3424"), 0, 0.85, 0.3), 8), Transform3D(Basis(), corner + Vector3(0, 0.1, 0)))
	# Flowers either side of the steps.
	for side in [-1.0, 1.0]:
		var p: Vector2 = PAVILION + Layout.left_of(face) * side * 2.6 - face * 3.6
		streets.flower_bed(Kit.v3(p), 1.0)
		streets.bush(Kit.v3(p - face * 1.0 + Layout.left_of(face) * side * 0.8), 0.9, 1)
	_bulb_string(Kit.v3(PAVILION - face * 4.2 + Layout.left_of(face) * 3.0, 2.8), Kit.v3(PAVILION - face * 4.2 - Layout.left_of(face) * 3.0, 2.8), 9, Color("ffd59a"), false)


# --- the old maple ------------------------------------------------------------------

func _maple() -> void:
	var t := kit.node(root, "OldMaple", Kit.yawed(0.6, Kit.v3(MAPLE)))
	kit.place(t, "Model", "res://art/nature/TwistedTree_1.gltf", Transform3D(Basis().scaled(Vector3.ONE * 0.62), Vector3.ZERO), true)
	kit.cyl_shape(solid, "Maple", Kit.v3(MAPLE, 2.0), 0.7, 4.0)
	# Warm uplights in the leaves.
	kit.spot(root, "MapleUplight", Transform3D(Basis.looking_at(Vector3(0, 1, 0.25), Vector3.BACK), Kit.v3(MAPLE + Vector2(0.5, 2.5), 0.2)), Color("ffb070"), 2.2, 12.0, 35.0)
	light_count += 1
	# The bench under it, looking south over the lawn to the city lights.
	var bench_at := MAPLE + Vector2(1.2, 3.4)
	var bench := Transform3D(Basis(Vector3.UP, 0.0), Kit.v3(bench_at))
	streets.bench(bench, false)
	var seat := Node3D.new()
	seat.name = "PoolSeat"
	seat.set_script(SEAT_SCRIPT)
	root.add_child(seat)
	seat.owner = kit.owner
	seat.transform = bench * Transform3D(Basis(Vector3.UP, PI), Vector3(0, 0, 0.1))
	seat.set("seat_height", 0.45)
	seat.set("prompt", "sit under the old maple")
	seat.set("radius", 1.4)
	_lantern_post(Kit.v3(bench_at + Vector2(1.6, 0.2)))
	for i in 6:
		var a := TAU * i / 6.0 + 0.3
		streets.ground_plant(Kit.v3(MAPLE + Vector2(cos(a), sin(a)) * rng.randf_range(2.0, 3.2)), 0.9)


# --- the ramble ----------------------------------------------------------------------

func _ramble_trail() -> void:
	var along := 0.0
	var total := Layout.length_of(_ramble)
	while along < total:
		var here := Layout.at_distance(_ramble, along)
		var p: Vector2 = here.point + Layout.left_of(here.dir) * rng.randf_range(-0.25, 0.25)
		var piece: String = ["RockPath_Round_Small_1", "RockPath_Round_Small_2", "RockPath_Round_Small_3"][rng.randi() % 3]
		kit.place(root, "SteppingStone", "res://art/nature/%s.gltf" % piece, Transform3D(Basis(Vector3.UP, rng.randf() * TAU).scaled(Vector3(1.1, 1.0, 1.1)), Kit.v3(p, 0.0)), false, 70.0)
		along += 1.25
	# Boulder outcrops, the way Central Park's bedrock pokes out of the grass.
	for spec in [[Vector2(28, -36), 1.6], [Vector2(36, -45), 2.0], [Vector2(44, -45.5), 1.3], [Vector2(52, -41), 1.7], [Vector2(18, -40), 1.2],
			[Vector2(-52, -42), 1.8], [Vector2(-56, -24), 1.3], [Vector2(-16, -48), 1.4], [Vector2(70, -44), 1.6], [Vector2(84, -38), 1.2]]:
		var c: Vector2 = spec[0]
		streets.rock(Kit.v3(c), spec[1], solid)
		for k in 3:
			streets.pebble(Kit.v3(c + Vector2(rng.randf_range(-3, 3), rng.randf_range(-3, 3))), 1.4)
		_busy.append(Vector3(c.x, c.y, 2.2 * spec[1]))
	for k in 10:
		var p := Vector2(rng.randf_range(20, 55), rng.randf_range(-48, -32))
		if _gap_to_paths(p) > 1.5:
			kit.place(root, "Mushroom", "res://art/nature/Mushroom_Common.gltf", Transform3D(Basis(Vector3.UP, rng.randf() * TAU).scaled(Vector3.ONE * 0.8), Kit.v3(p)), false, 40.0)


# --- ways in ---------------------------------------------------------------------------

func _gateways() -> void:
	_gateway(Vector2(-52.6, -11.5), Vector2(-0.35, -1.0).normalized(), "CENTRAL PARK")
	_gateway(Vector2(38.0, 8.6), Vector2(0, -1), "CENTRAL PARK")
	_gateway(Vector2(36.6, -18.5), Vector2(0.2, -1.0).normalized(), "THE RAMBLE", 0.7)


## Two stone piers either side of a path with a lamp on each and a name board.
func _gateway(at: Vector2, inward: Vector2, text: String, size := 1.0) -> void:
	var g := kit.node(root, "Gateway", Kit.yawed(Layout.yaw_facing(inward), Kit.v3(at)))
	var stone := kit.toy(Color("7d7684"), 0, 0.85, 0.3)
	var cap := kit.toy(Color("5c5664"), 0, 0.8, 0.3)
	var half := 1.9
	for side in [-1.0, 1.0]:
		var p := Vector3(side * half, 0, 0)
		kit.add_box(g, "Pier", p + Vector3(0, 0.9 * size, 0), Vector3(0.7, 1.8 * size, 0.7), stone)
		kit.add_box(g, "PierCap", p + Vector3(0, 1.85 * size, 0), Vector3(0.85, 0.12, 0.85), cap)
		kit.mesh(g, "Globe", kit.sphere(0.2, kit.glow(Color("ffe2b0"), 3.0)), Transform3D(Basis(), p + Vector3(0, 2.15 * size, 0)), false)
		kit.shape(solid, "Pier", g.transform * Transform3D(Basis(), p + Vector3(0, 0.9 * size, 0)), Vector3(0.7, 1.8 * size, 0.7))
	kit.omni(g, "Light", Vector3(0, 2.2 * size, 0.6), Color("ffd9a8"), 0.9, 7.0)
	light_count += 1
	if size >= 1.0:
		kit.add_box(g, "Arch", Vector3(0, 2.75, 0), Vector3(half * 2.0 + 0.7, 0.5, 0.18), kit.toy(Color("26303a"), 0.1, 0.6))
		for face in [1.0, -1.0]:
			kit.label(g, "Name", text, Transform3D(Basis(Vector3.UP, 0.0 if face > 0 else PI), Vector3(0, 2.75, 0.1 * face)), 0.32, Color(1.6, 1.4, 1.0))
	else:
		kit.label(g, "Name", text, Transform3D(Basis(Vector3.UP, PI), Vector3(half, 1.0, -0.36)), 0.18, Color(1.3, 1.2, 1.0))


# --- lamps, benches --------------------------------------------------------------------

func _lamps_and_benches() -> void:
	var lamp_every := 15.0
	var bench_every := 21.0
	for i in trails.size():
		var line := trails[i]
		var total := Layout.length_of(line)
		var along := 5.0
		var side := 1.0
		while along < total - 3.0:
			var here := Layout.at_distance(line, along)
			var n: Vector2 = Layout.left_of(here.dir)
			var p: Vector2 = here.point + n * side * (_halves[i] + 0.7)
			if _clear_for_lamp(p):
				_park_lamp(p)
			along += lamp_every
			side = -side
		along = 11.0
		side = -1.0
		while along < total - 6.0:
			var here := Layout.at_distance(line, along)
			var n: Vector2 = Layout.left_of(here.dir) * side
			var p: Vector2 = here.point + n * (_halves[i] + 0.9)
			if _clear_for_lamp(p) and Geometry2D.is_point_in_polygon(p, _area):
				# Facing the path.
				streets.bench(Transform3D(Basis(Vector3.UP, Layout.yaw_facing(-n)), Kit.v3(p)))
				_busy.append(Vector3(p.x, p.y, 1.6))
				if rng.randf() < 0.5:
					streets.bush(Kit.v3(p + n * 1.2 + here.dir * 1.6), 0.8)
			along += bench_every
			side = -side


func _clear_for_lamp(p: Vector2) -> bool:
	if _gap_to_pond(p) < 1.2 or absf(p.x - _rail_x(p.y)) < 4.2:
		return false
	for b in _busy:
		if p.distance_to(Vector2(b.x, b.y)) < b.z:
			return false
	return true


## Central Park's lamp: a black post with a round lantern.
func _park_lamp(p: Vector2) -> void:
	var lamp := kit.node(root, "ParkLamp", Kit.yawed(0.0, Kit.v3(p)))
	var iron := kit.toy(Color("22212b"), 0, 0.5, 0.2, 0.3)
	kit.mesh(lamp, "Base", kit.cyl(0.16, 0.12, 0.5, iron, 8), Transform3D(Basis(), Vector3(0, 0.25, 0)))
	kit.mesh(lamp, "Post", kit.cyl(0.06, 0.05, 3.2, iron, 8), Transform3D(Basis(), Vector3(0, 1.85, 0)))
	kit.mesh(lamp, "Collar", kit.cyl(0.12, 0.12, 0.12, iron, 8), Transform3D(Basis(), Vector3(0, 3.45, 0)))
	kit.mesh(lamp, "Globe", kit.sphere(0.27, kit.glow(Color("ffe2b8"), 3.2)), Transform3D(Basis(), Vector3(0, 3.78, 0)), false)
	kit.mesh(lamp, "Cap", kit.cyl(0.2, 0.06, 0.14, iron, 8), Transform3D(Basis(), Vector3(0, 4.09, 0)))
	kit.omni(lamp, "Light", Vector3(0, 3.6, 0), Color("ffd9a8"), 1.0, 10.0)
	kit.cyl_shape(solid, "Lamp", Kit.v3(p, 2.0), 0.13, 4.0)
	_busy.append(Vector3(p.x, p.y, 1.2))
	light_count += 1


# --- planting ----------------------------------------------------------------------------

func _planting() -> void:
	# Trees in loose groves, never on paths, the pond, the lawns or under the tracks.
	var placed: Array[Vector2] = []
	var tries := 0
	while placed.size() < 150 and tries < 6000:
		tries += 1
		var p := Vector2(rng.randf_range(-78, 136), rng.randf_range(-50, -13))
		if not _plantable(p, 3.2):
			continue
		if _gap_to_rail(p) < 6.0:
			continue
		var too_close := false
		for q in placed:
			if p.distance_to(q) < 4.6:
				too_close = true
				break
		if too_close:
			continue
		# Groves: further from a neighbour = less likely, so trees bunch up.
		var near := INF
		for q in placed:
			near = minf(near, p.distance_to(q))
		if placed.size() > 10 and near > 11.0 and rng.randf() < 0.75:
			continue
		var pine := p.x > 18.0 and p.x < 58.0 and rng.randf() < 0.35
		streets.tree(Kit.v3(p), rng.randf_range(1.1, 1.6), 2 if pine else 0, solid)
		placed.append(p)
	# Shrubs along path edges and round the trees.
	var shrubs := 0
	tries = 0
	while shrubs < 140 and tries < 4000:
		tries += 1
		var line := trails[rng.randi() % trails.size()]
		var here := Layout.at_distance(line, rng.randf() * Layout.length_of(line))
		var p: Vector2 = here.point + Layout.left_of(here.dir) * (1.0 if rng.randf() < 0.5 else -1.0) * rng.randf_range(2.2, 4.0)
		if not _plantable(p, 1.6):
			continue
		match rng.randi() % 5:
			0, 1: streets.bush(Kit.v3(p), rng.randf_range(0.8, 1.2))
			2: streets.flower_bed(Kit.v3(p), 0.9)
			_: streets.ground_plant(Kit.v3(p), 1.0)
		shrubs += 1
	_grass()


## Grass tufts as MultiMeshes, one per patch of park, each faded out with distance.
func _grass() -> void:
	var chunk := 24.0
	var meshes := []
	for name in ["Grass_Common_Short", "Grass_Wispy_Short", "Grass_Common_Tall", "Clover_1"]:
		meshes.append(kit.model("res://art/nature/%s.gltf" % name))
	var x := -80.0
	while x < 140.0:
		var z := -52.0
		while z < -10.0:
			for m in meshes.size():
				var xforms: Array[Transform3D] = []
				var count := 70 if m < 2 else 26
				for k in count:
					var p := Vector2(x + rng.randf() * chunk, z + rng.randf() * chunk)
					if not _plantable(p, 1.2, false):
						continue
					var s := rng.randf_range(0.35, 0.6) if m < 3 else rng.randf_range(0.45, 0.7)
					xforms.append(Transform3D(Basis(Vector3.UP, rng.randf() * TAU).scaled(Vector3.ONE * s), Kit.v3(p, 0.0)))
				if xforms.is_empty():
					continue
				var mm := MultiMesh.new()
				mm.transform_format = MultiMesh.TRANSFORM_3D
				mm.mesh = meshes[m]
				mm.instance_count = xforms.size()
				for k in xforms.size():
					mm.set_instance_transform(k, xforms[k])
				var mmi := MultiMeshInstance3D.new()
				mmi.name = kit.name_for(root, "Grass")
				mmi.multimesh = mm
				mmi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
				mmi.visibility_range_end = 55.0
				mmi.visibility_range_end_margin = 8.0
				mmi.visibility_range_fade_mode = GeometryInstance3D.VISIBILITY_RANGE_FADE_SELF
				root.add_child(mmi)
				mmi.owner = kit.owner
			z += chunk
		x += chunk


func _plantable(p: Vector2, clearance: float, avoid_lawns := true) -> bool:
	if not Geometry2D.is_point_in_polygon(p, _area):
		return false
	if _gap_to_paths(p) < clearance or _gap_to_pond(p) < clearance or _ramble_gap(p) < clearance * 0.7:
		return false
	if absf(p.x - _rail_x(p.y)) < 3.6:
		return false
	for b in _busy:
		if p.distance_to(Vector2(b.x, b.y)) < b.z + clearance * 0.3:
			return false
	if avoid_lawns:
		for lawn in LAWNS:
			var d: Vector2 = (p - lawn[0]) / lawn[1]
			if d.length() < 1.0:
				return false
	# Keep the back fence of the house and the edge of the park clear.
	if p.y > -16.5 and p.x > -18.0 and p.x < 14.0:
		return false
	return true


func _fireflies() -> void:
	var mat := StandardMaterial3D.new()
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.albedo_color = Color(1.0, 0.95, 0.5)
	mat.emission_enabled = true
	mat.emission = Color(1.0, 0.9, 0.4)
	mat.emission_energy_multiplier = 3.0
	mat.vertex_color_use_as_albedo = true
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	var dot := SphereMesh.new()
	dot.radius = 0.035
	dot.height = 0.07
	dot.radial_segments = 6
	dot.rings = 3
	dot.material = mat
	var fade := Gradient.new()
	fade.offsets = PackedFloat32Array([0.0, 0.2, 0.45, 0.6, 0.8, 1.0])
	fade.colors = PackedColorArray([Color(1, 1, 1, 0), Color(1, 1, 1, 1), Color(1, 1, 1, 0.2), Color(1, 1, 1, 1), Color(1, 1, 1, 0.3), Color(1, 1, 1, 0)])
	for spot in [[Kit.v3(POND, 1.2), Vector3(11, 1.0, 8), 60], [Vector3(-5, 1.0, -21), Vector3(10, 0.8, 5), 35],
			[Kit.v3(MAPLE, 1.3), Vector3(6, 1.0, 5), 30], [Vector3(36, 1.1, -38), Vector3(14, 0.9, 8), 40]]:
		var p := CPUParticles3D.new()
		p.name = kit.name_for(root, "Fireflies")
		p.position = spot[0]
		p.amount = spot[2]
		p.lifetime = 7.0
		p.preprocess = 7.0
		p.mesh = dot
		p.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
		p.emission_box_extents = spot[1]
		p.direction = Vector3(0, 0.3, 0)
		p.spread = 180.0
		p.gravity = Vector3.ZERO
		p.initial_velocity_min = 0.05
		p.initial_velocity_max = 0.25
		p.damping_min = 0.0
		p.damping_max = 0.05
		p.color_ramp = fade
		p.visibility_aabb = AABB(-Vector3(spot[1]) - Vector3.ONE * 2.0, Vector3(spot[1]) * 2.0 + Vector3.ONE * 4.0)
		root.add_child(p)
		p.owner = kit.owner


func _sounds() -> void:
	for spec in [["FountainSound", Kit.v3(FOUNTAIN, 0.8), -9.0, 1.25, 16.0], ["PondSound", Kit.v3(POND + Vector2(6, 4), 0.3), -14.0, 0.85, 20.0]]:
		var s := AudioStreamPlayer3D.new()
		s.name = spec[0]
		s.stream = WATER_SOUND
		s.position = spec[1]
		s.volume_db = spec[2]
		s.pitch_scale = spec[3]
		s.unit_size = 4.0
		s.max_distance = spec[4]
		s.autoplay = true
		s.bus = &"Nature"
		s.set_script(LOOP_SOUND)
		root.add_child(s)
		s.owner = kit.owner


# --- bits ---------------------------------------------------------------------

func _lantern_post(at: Vector3) -> void:
	var post := kit.node(root, "LanternPost", Kit.yawed(0.0, at))
	kit.mesh(post, "Post", kit.cyl(0.05, 0.05, 1.7, kit.toy(Color("3a2c22")), 6), Transform3D(Basis(), Vector3(0, 0.85, 0)))
	kit.mesh(post, "Lantern", kit.cyl(0.14, 0.12, 0.3, kit.glow(Color("ffcf8a"), 2.6), 8), Transform3D(Basis(), Vector3(0, 1.85, 0)), false)
	kit.mesh(post, "Cap", kit.cyl(0.2, 0.05, 0.12, kit.toy(Color("2b2a36")), 8), Transform3D(Basis(), Vector3(0, 2.06, 0)))
	kit.omni(post, "Light", Vector3(0, 1.9, 0), Color("ffc27a"), 1.0, 6.5)
	kit.cyl_shape(solid, "Post", at + Vector3(0, 0.85, 0), 0.08, 1.7)
	light_count += 1


func _bulb_string(a: Vector3, b: Vector3, count: int, colour: Color, with_light := true) -> void:
	var bulb := kit.glow(colour, 4.0)
	for i in count:
		var t := (i + 0.5) / count
		var p := a.lerp(b, t) + Vector3.DOWN * sin(PI * t) * 0.6
		kit.mesh(root, "Bulb", kit.sphere(0.08, bulb), Transform3D(Basis(), p), false, 90.0)
	for end in [a, b]:
		kit.mesh(root, "BulbPole", kit.cyl(0.05, 0.05, end.y, kit.toy(Color("2b2a36")), 6), Transform3D(Basis(), Vector3(end.x, end.y * 0.5, end.z)))
		kit.cyl_shape(solid, "BulbPole", Vector3(end.x, end.y * 0.5, end.z), 0.07, end.y)
	if with_light:
		kit.omni(root, "StringGlow", (a + b) * 0.5 + Vector3.DOWN * 0.8, colour, 0.9, 8.0)
		light_count += 1


func _reeds(p: Vector2, reed: Material, rush: Material) -> void:
	var clump := kit.node(root, "Reeds", Kit.yawed(rng.randf() * TAU, Kit.v3(p)))
	for k in 5:
		var h := rng.randf_range(0.6, 1.2)
		var tilt := Basis(Vector3(rng.randf_range(-1, 1), 0, rng.randf_range(-1, 1)).normalized(), rng.randf_range(0.0, 0.25))
		var at := Vector3(rng.randf_range(-0.25, 0.25), h * 0.5, rng.randf_range(-0.25, 0.25))
		kit.mesh(clump, "Blade", kit.cyl(0.03, 0.01, h, reed, 5, 0.0), Transform3D(tilt, at), false, 60.0)
		if k == 0:
			kit.mesh(clump, "Rush", kit.capsule(0.05, 0.05, 0.22, rush), Transform3D(tilt, at + tilt * Vector3(0, h * 0.5, 0)), false, 60.0)


# A strip whose half width varies along the line (`grow` added to every half width).
func _strip(line: PackedVector2Array, half: PackedFloat32Array, grow: float, y: float, material: Material) -> ArrayMesh:
	var verts := PackedVector3Array()
	var uvs := PackedVector2Array()
	var normals := PackedVector3Array()
	var indices := PackedInt32Array()
	for i in line.size():
		var n := Layout.left_of(Layout.direction_at(line, i))
		var w := half[i] + grow
		verts.append(Kit.v3(line[i] + n * w, y))
		verts.append(Kit.v3(line[i] - n * w, y))
		# World-space UVs, so paving tiles line up wherever paths meet.
		uvs.append(line[i] + n * w)
		uvs.append(line[i] - n * w)
		normals.append(Vector3.UP)
		normals.append(Vector3.UP)
		if i > 0:
			var k := i * 2
			indices.append_array([k - 2, k, k - 1, k - 1, k, k + 1])
	return Ground._array_mesh(verts, normals, uvs, indices, material)


## The polygon pushed out (or in, for negative `by`) from its centre.
func _grown(polygon: PackedVector2Array, by: float) -> PackedVector2Array:
	var out := PackedVector2Array()
	var c := Vector2.ZERO
	for p in polygon:
		c += p
	c /= polygon.size()
	for p in polygon:
		out.append(p + (p - c).normalized() * by)
	return out


func _gap_to_pond(p: Vector2) -> float:
	if Geometry2D.is_point_in_polygon(p, pond):
		return -1.0
	return Layout.distance_to_line(p, pond + PackedVector2Array([pond[0]]))


func _gap_to_paths(p: Vector2) -> float:
	var best := INF
	for i in trails.size():
		best = minf(best, Layout.distance_to_line(p, trails[i]) - _halves[i])
	return best


func _ramble_gap(p: Vector2) -> float:
	return Layout.distance_to_line(p, _ramble) - 0.8


func _gap_to_rail(p: Vector2) -> float:
	return absf(p.x - _rail_x(p.y))


# X of the railway viaduct at depth z (the track runs roughly north-south here).
func _rail_x(z: float) -> float:
	var rail: Array = Plan.RAILWAY
	for i in range(1, rail.size()):
		var a: Vector2 = rail[i - 1]
		var b: Vector2 = rail[i]
		if z >= a.y and z <= b.y:
			return lerpf(a.x, b.x, (z - a.y) / (b.y - a.y))
	return 14.0


func _reserved(what: String) -> Dictionary:
	for spec in Plan.RESERVED:
		if spec.what == what:
			return spec
	return {}
