extends RefCounted
## Life on the streets: the pavement network pedestrians route over (with
## zebra crossings, shop doors and hang-out spots), the traffic loops (kept
## to the right, stopping at real junctions only), and where the people and
## cats of the city start out.

const Plan := preload("res://tools/city/plan.gd")
const Layout := preload("res://tools/city/layout.gd")
const Kit := preload("res://tools/city/kit.gd")
const Ground := preload("res://tools/city/ground.gd")

const PAVEMENT := 0
const CROSSING := 1
const DOOR := 2
const SPOT := 3

var layout: Layout
var ground: Ground
var rng := RandomNumberGenerator.new()

var points := PackedVector3Array()
var kinds := PackedByteArray()
var links := PackedInt32Array()
var _pavement_ids: Array[int] = []


func _init(the_layout: Layout, the_ground: Ground) -> void:
	layout = the_layout
	ground = the_ground
	rng.seed = 31337


func _add(p: Vector2, kind: int) -> int:
	points.append(Kit.v3(p))
	kinds.append(kind)
	if kind == PAVEMENT:
		_pavement_ids.append(points.size() - 1)
	return points.size() - 1


func _link(a: int, b: int) -> void:
	if a < 0 or b < 0 or a == b:
		return
	links.append(a)
	links.append(b)


func _walkable(p: Vector2) -> bool:
	var v := layout.value_at(p)
	if v == Layout.BUILDING or v == Layout.RAIL or v == Layout.WALL:
		return false
	return layout.area_of(p) == ""


func _in_junction(p: Vector2) -> String:
	for name in ground.junctions:
		var j: Dictionary = ground.junctions[name]
		if p.distance_to(j.centre) < j.radius + 1.6:
			return name
	return ""


## The pavements: a line of points down each side of every street, joined up
## round the corners and across the zebra crossings.
func build_network(doors: Array, spots: Array) -> void:
	# junction -> list of {id, dir_from_centre}
	var ends := {}
	for r in layout.roads.size():
		var road: Dictionary = layout.roads[r]
		if road.kind == Plan.ALLEY or road.area != "":
			continue
		var sides := [1.0, -1.0] if road.kind != Plan.PATH else [0.0]
		for side in sides:
			var offset: float = road.width * 0.5 + 1.1
			var line: PackedVector2Array = road.points
			var total := Layout.length_of(line)
			var along := 0.0
			var last := -1
			var last_junction := ""
			while along <= total:
				var here := Layout.at_distance(line, along)
				var p: Vector2 = here.point + Layout.left_of(here.dir) * offset * side
				var jn := _in_junction(p) if side != 0.0 else _in_junction(here.point)
				if jn != "":
					if last >= 0:
						_note_end(ends, jn, last)
					last = -1
					last_junction = jn
				elif _walkable(p):
					var id := _add(p, PAVEMENT)
					if last >= 0:
						_link(last, id)
					elif last_junction != "":
						_note_end(ends, last_junction, id)
					last = id
					last_junction = ""
				else:
					last = -1
				along += 5.5 if road.kind != Plan.PATH else 4.0
			# Round a turning circle at the end.
			if road.end_circle > 0.0 and last >= 0 and side > 0.0:
				pass
		if road.end_circle > 0.0:
			_round_the_end(road)
	# Corners and crossings at every junction.
	for name in ends:
		var list: Array = ends[name]
		var centre: Vector2 = ground.junctions[name].centre
		list.sort_custom(func(a: int, b: int) -> bool:
			var pa := points[a] - Kit.v3(centre)
			var pb := points[b] - Kit.v3(centre)
			return atan2(pa.z, pa.x) < atan2(pb.z, pb.x))
		# Neighbours round the junction: if they're close, they're a corner.
		for i in list.size():
			var a: int = list[i]
			var b: int = list[(i + 1) % list.size()]
			var gap := points[a].distance_to(points[b])
			if gap < 13.0:
				_link(a, b)
	for c in ground.crossings:
		var road: Dictionary = layout.roads[c.road]
		if road.area != "":
			continue
		var mid := _add(c.centre, CROSSING)
		for side in [1.0, -1.0]:
			var p: Vector2 = c.centre + c.across * (c.half + 1.1) * side
			var near := _nearest_pavement(p, 4.5)
			_link(mid, near)
	for door in doors:
		var p := Vector2(door.at.x, door.at.z)
		if layout.area_of(p) != "":
			continue
		var near := _nearest_pavement(p, 7.0)
		if near >= 0:
			_link(_add(p, DOOR), near)
	for spot in spots:
		var p := Vector2(spot.x, spot.z)
		if layout.area_of(p) != "":
			continue
		var near := _nearest_pavement(p, 7.0)
		if near >= 0:
			_link(_add(p, SPOT), near)
	_drop_islands()


func _note_end(ends: Dictionary, junction: String, id: int) -> void:
	if not ends.has(junction):
		ends[junction] = []
	ends[junction].append(id)


func _round_the_end(road: Dictionary) -> void:
	var end: Vector2 = road.points[road.points.size() - 1]
	var r: float = road.end_circle + 1.1
	var ring: Array[int] = []
	for k in 10:
		var a := TAU * k / 10.0
		var p := end + Vector2(cos(a), sin(a)) * r
		ring.append(_add(p, PAVEMENT) if _walkable(p) else -1)
	for k in 10:
		if ring[k] >= 0 and ring[(k + 1) % 10] >= 0:
			_link(ring[k], ring[(k + 1) % 10])
	# Tie the ring to the two pavements that arrive at it.
	for k in 10:
		if ring[k] >= 0:
			var near := _nearest_pavement(Vector2(points[ring[k]].x, points[ring[k]].z), 6.0, ring)
			if near >= 0:
				_link(ring[k], near)


func _nearest_pavement(p: Vector2, within: float, exclude: Array = []) -> int:
	var best := -1
	var best_d := within
	for id in _pavement_ids:
		if id in exclude:
			continue
		var d := Vector2(points[id].x, points[id].z).distance_to(p)
		if d < best_d:
			best_d = d
			best = id
	return best


# Points nobody can reach from the main network are dropped.
func _drop_islands() -> void:
	var adjacency := {}
	for i in range(0, links.size(), 2):
		adjacency.get_or_add(links[i], []).append(links[i + 1])
		adjacency.get_or_add(links[i + 1], []).append(links[i])
	var seen := {}
	var best: Array = []
	for start in points.size():
		if seen.has(start):
			continue
		var group := [start]
		seen[start] = true
		var k := 0
		while k < group.size():
			for nb in adjacency.get(group[k], []):
				if not seen.has(nb):
					seen[nb] = true
					group.append(nb)
			k += 1
		if group.size() > best.size():
			best = group
	var keep := {}
	for id in best:
		keep[id] = true
	var remap := {}
	var new_points := PackedVector3Array()
	var new_kinds := PackedByteArray()
	for i in points.size():
		if keep.has(i):
			remap[i] = new_points.size()
			new_points.append(points[i])
			new_kinds.append(kinds[i])
	var new_links := PackedInt32Array()
	var have := {}
	for i in range(0, links.size(), 2):
		if remap.has(links[i]) and remap.has(links[i + 1]):
			var key := Vector2i(mini(remap[links[i]], remap[links[i + 1]]), maxi(remap[links[i]], remap[links[i + 1]]))
			if have.has(key):
				continue
			have[key] = true
			new_links.append(remap[links[i]])
			new_links.append(remap[links[i + 1]])
	print("  pavement network: %d points (%d dropped), %d links" % [new_points.size(), points.size() - new_points.size(), new_links.size() / 2])
	points = new_points
	kinds = new_kinds
	links = new_links
	_pavement_ids.clear()
	for i in points.size():
		if kinds[i] == PAVEMENT:
			_pavement_ids.append(i)


func random_pavement() -> Vector3:
	return points[_pavement_ids[rng.randi() % _pavement_ids.size()]]


# --- traffic -------------------------------------------------------------------

## Each loop: {points: PackedVector3Array (lane centre, driving order), stops: PackedByteArray}
func traffic_routes() -> Array:
	var out := []
	for loop in Plan.TRAFFIC:
		var centre := PackedVector2Array()
		var widths := PackedFloat32Array()
		var junction_at := {}
		for k in range(loop.size() - 1):
			var a: String = loop[k]
			var b: String = loop[k + 1]
			var piece := _road_between(a, b)
			if piece.is_empty():
				push_error("No road from %s to %s" % [a, b])
				continue
			var pts: PackedVector2Array = piece.points
			for i in pts.size():
				if centre.size() > 0 and i == 0:
					continue
				centre.append(pts[i])
				widths.append(piece.width)
			junction_at[centre.size() - 1] = b
		# Drop the closing duplicate.
		if centre[0].distance_to(centre[centre.size() - 1]) < 0.01:
			centre.remove_at(centre.size() - 1)
			widths.remove_at(widths.size() - 1)
		var lane := PackedVector3Array()
		var stops := PackedByteArray()
		var n := centre.size()
		for i in n:
			var dir := (centre[(i + 1) % n] - centre[(i - 1 + n) % n]).normalized()
			var right := -Layout.left_of(dir)
			lane.append(Kit.v3(centre[i] + right * widths[i] * 0.25))
			var jn: String = junction_at.get(i, junction_at.get(i + n, ""))
			if i == 0:
				jn = loop[0]
			stops.append(1 if jn != "" and ground.junctions.has(jn) else 0)
		out.append({"points": lane, "stops": stops})
	return out


func _road_between(a: String, b: String) -> Dictionary:
	for road in layout.roads:
		if road.nodes.has(a) and road.nodes.has(b):
			var ia: int = road.nodes[a]
			var ib: int = road.nodes[b]
			var pts: PackedVector2Array = road.points
			var piece := PackedVector2Array()
			if ia <= ib:
				piece = pts.slice(ia, ib + 1)
			else:
				piece = pts.slice(ib, ia + 1)
				piece.reverse()
			return {"points": piece, "width": road.width}
	return {}
