extends Node3D
## Prints every location's parking spot and how far it is from a drivable road,
## plus a route from the house to each (headless check after a city rebuild).

func _ready() -> void:
	var city: Node = load("res://levels/city.tscn").instantiate()
	add_child(city)
	await get_tree().process_frame
	var net: RoadNetwork = get_tree().get_first_node_in_group(&"road_network")
	var home := Vector3(1, 0, 4.6)
	for n in ["Studio", "MusicStore", "Diner", "Alley", "Venue", "Tower", "Plaza"]:
		var place := city.get_node_or_null(n) as Node3D
		if place == null:
			print(n, " missing")
			continue
		var park := place.get_node_or_null("Parking") as Node3D
		var p := park.global_position if park else place.global_position
		var r := net.route(home, p)
		print("%-10s parking %s road gap %.1f on '%s' route %d pts %.0f m" % [n, p.snapped(Vector3.ONE * 0.1), net.distance_to_roads(p), net.street_name_at(p), r.size(), RoadNetwork.length_of(r)])
	# Anything solid standing in a carriageway (where the truck must fit)?
	var space := get_world_3d().direct_space_state
	var probe := SphereShape3D.new()
	probe.radius = 0.45
	var q := PhysicsShapeQueryParameters3D.new()
	q.shape = probe
	q.collision_mask = 1
	var found := {}
	for road in net.road_count():
		if not net.is_drivable(road):
			continue
		var line := net.road_points(road)
		var w := net.road_width[road]
		var sides := [0.0] if w < 6.0 else [-(w * 0.5 - 1.3), 0.0, w * 0.5 - 1.3]
		for i in range(1, line.size()):
			var dir := (line[i] - line[i - 1]).normalized()
			var across := Vector3(-dir.z, 0, dir.x)
			for side: float in sides:
				q.transform = Transform3D(Basis(), line[i] + across * side + Vector3(0, 0.8, 0))
				for hit in space.intersect_shape(q, 4):
					var body := hit.collider as CollisionObject3D
					if body is PhysicsBody3D and not (body is StaticBody3D):
						continue
					var path := String(body.get_path())
					if path.contains("Gate"):
						continue
					var what := "%s/%s" % [body.name, body.shape_owner_get_owner(body.shape_find_owner(hit.shape)).name]
					found[what] = "%s on %s" % [(line[i] + across * side).snappedf(0.1), net.road_name[road]]
	print("things in the carriageway: %d" % found.size())
	for k in found:
		print("  ", k, " at ", found[k])
	get_tree().quit()
