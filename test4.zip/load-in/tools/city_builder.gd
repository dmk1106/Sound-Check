extends Node
## Builds levels/city.tscn from the plan in tools/city/plan.gd: streets,
## buildings, the railway, street furniture, the pavement network, traffic,
## the fan gates and the minimap picture. The places the game needs (house,
## studio, shop, venues, creek) are kept and moved to where the plan puts them.
##
##   godot --headless --path . res://tools/city_builder.tscn
##
## Run it again after changing the plan; then `godot --headless --import` so
## the minimap picture is re-imported.

const Plan := preload("res://tools/city/plan.gd")
const Layout := preload("res://tools/city/layout.gd")
const Kit := preload("res://tools/city/kit.gd")
const GroundPaint := preload("res://tools/city/ground.gd")
const Buildings := preload("res://tools/city/buildings.gd")
const Streets := preload("res://tools/city/streets.gd")
const Rail := preload("res://tools/city/rail.gd")
const People := preload("res://tools/city/people.gd")
const PlanImage := preload("res://tools/city/plan_image.gd")
const Park := preload("res://tools/city/park.gd")
const GATE_SCRIPT := preload("res://world/garden_gate.gd")
const ROAD_NETWORK := preload("res://world/road_network.gd")
const BUSK_SPOT := preload("res://levels/busk_spot.tscn")

const CITY := "res://levels/city.tscn"
const MAP_IMAGE := "res://ui/minimap/city_map.png"

var city: Node3D
var kit: Kit
var layout: Layout
var ground: GroundPaint
var streets: Streets
var buildings: Buildings
var rail: Rail
var park: Park
var lights := 0


func _ready() -> void:
	var started := Time.get_ticks_msec()
	city = load(CITY).instantiate()
	kit = Kit.new(city)
	_clear_old()
	_step("plan", started)
	layout = Layout.new()
	layout.paint_plan()
	_landmark_lots()
	layout.place_frontage()
	_tag_landmarks()
	layout.place_backfill()
	layout.place_backfill(3.0, 0.6)
	print("  %d buildings" % layout.lots.size())
	_step("ground", started)
	ground = GroundPaint.new(kit, layout, city.get_node("Ground"))
	ground.build()
	_resize_ground_collider()
	_step("buildings", started)
	var scenery: StaticBody3D = city.get_node("Scenery")
	buildings = Buildings.new(kit, layout, city.get_node("Buildings"), scenery)
	buildings.build_all()
	_step("railway", started)
	var street_root := kit.node(city, "Street")
	var street_solid := StaticBody3D.new()
	street_solid.name = "StreetSolid"
	street_solid.collision_mask = 0
	city.add_child(street_solid)
	street_solid.owner = city
	streets = Streets.new(kit, layout, ground, street_root, street_solid)
	rail = Rail.new(kit, layout, city.get_node("Buildings"), scenery, city.get_node("AlleyWalls"))
	rail.streets = streets
	var yard_spec: Array = _reserved("Alley").rect
	rail.build(Rect2(yard_spec[0] - yard_spec[1] * 0.5, yard_spec[1]))
	_step("streets", started)
	streets.build()
	_places()
	_set_pieces()
	_yard_walls()
	_gates_and_walls()
	_skyline()
	_home_yard()
	_step("park", started)
	park = Park.new(kit, layout, streets, city)
	park.build()
	_step("people", started)
	_people()
	_road_network()
	_minimap_image()
	lights = buildings.light_count + streets.light_count + rail.light_count + park.light_count + lights
	print("  lights added: %d (buildings %d, streets %d, railway %d, park %d)" % [lights, buildings.light_count, streets.light_count, rail.light_count, park.light_count])
	print("  %d of %d lots built from Kenney bays" % [buildings.kenney_count, layout.lots.size()])
	_step("save", started)
	var packed := PackedScene.new()
	var err := packed.pack(city)
	if err != OK:
		push_error("pack failed %d" % err)
	err = ResourceSaver.save(packed, CITY)
	print("saved %s (%d) in %.1f s" % [CITY, err, (Time.get_ticks_msec() - started) / 1000.0])
	get_tree().quit(0 if err == OK else 1)


func _step(what: String, started: int) -> void:
	print("[%5.1f s] %s" % [(Time.get_ticks_msec() - started) / 1000.0, what])


func _reserved(what: String) -> Dictionary:
	for spec in Plan.RESERVED:
		if spec.what == what:
			return spec
	return {}


# --- clearing out the old square city ------------------------------------------------

## Top-level nodes of the city that are not generated here.
const KEEP := ["Sun", "Fill", "WorldEnvironment", "Ground", "House", "Scenery", "AlleyWalls", "Buildings", "ParkSideGate",
		"UptownGate", "HarbourGate", "Skyline", "SkylineSolid", "Studio", "MusicStore", "Venue", "Alley", "Diner", "Tower",
		"Sidewalks", "People", "Cats", "Creek", "CentralPark", "Debug", "Traffic", "Rain", "WorldEdge"]


func _clear_old() -> void:
	for path in ["Buildings", "Scenery", "AlleyWalls", "Skyline", "SkylineSolid", "WorldEdge"]:
		for child in city.get_node(path).get_children():
			city.get_node(path).remove_child(child)
			child.free()
	for child in city.get_node("Ground").get_children():
		if child.name != "GroundShape":
			city.get_node("Ground").remove_child(child)
			child.free()
	# Everything else at the top level was made by this script last time.
	for child in city.get_children():
		if not (child.name in KEEP):
			city.remove_child(child)
			child.free()
	var alley_walls: StaticBody3D = city.get_node("AlleyWalls")
	alley_walls.collision_layer = 1


func _resize_ground_collider() -> void:
	var shape: CollisionShape3D = city.get_node("Ground/GroundShape")
	var box := BoxShape3D.new()
	box.size = Vector3(Plan.BOUNDS.size.x + 120.0, 2.0, Plan.BOUNDS.size.y + 120.0)
	shape.shape = box
	shape.position = Kit.v3(Plan.BOUNDS.get_center(), -1.0)


# --- landmarks ----------------------------------------------------------------

const LANDMARK_LOTS := [
	{"landmark": "screen", "centre": Vector2(1, 34), "size": Vector2(22, 11), "facing": Vector2(0, 1), "height": 26.0, "style": "neon"},
	{"landmark": "theatre", "centre": Vector2(80, 99), "size": Vector2(15, 13), "facing": Vector2(-1, 0), "height": 14.0, "style": "avenue"},
	# A thin shop between Canal Street and the alley yard, so the yard is shut in.
	{"landmark": "", "centre": Vector2(35.2, 87.6), "size": Vector2(13.0, 4.0), "facing": Vector2(-1, 0), "height": 10.0, "style": "canal"},
]

const LANDMARK_TAGS := [
	{"landmark": "pagoda", "near": Vector2(-16, 69), "road": "Neon Row"},
	{"landmark": "club", "near": Vector2(100, 70), "road": "Uptown Boulevard"},
	{"landmark": "water_tower", "near": Vector2(40, 109), "road": "Back Street"},
]


func _landmark_lots() -> void:
	for spec in LANDMARK_LOTS:
		var yaw := Layout.yaw_facing(spec.facing)
		var corners := Layout.rect_corners(spec.centre, spec.size, yaw)
		layout.paint_polygon(corners, Layout.BUILDING)
		var lot := {"centre": spec.centre, "size": spec.size, "yaw": yaw, "height": spec.height, "style": spec.style,
				"front": true, "road": -1, "shop": spec.landmark == "", "seed": 5}
		if spec.landmark != "":
			lot.landmark = spec.landmark
		layout.lots.append(lot)


func _tag_landmarks() -> void:
	for spec in LANDMARK_TAGS:
		var best := -1
		var best_d := INF
		for i in layout.lots.size():
			var lot: Dictionary = layout.lots[i]
			if not lot.front or lot.road < 0 or lot.has("landmark") or layout.roads[lot.road].name != spec.road:
				continue
			var d: float = lot.centre.distance_to(spec.near)
			if d < best_d:
				best_d = d
				best = i
		if best >= 0:
			layout.lots[best]["landmark"] = spec.landmark
			if spec.landmark == "club":
				layout.lots[best]["height"] = 16.0
			elif spec.landmark == "water_tower":
				layout.lots[best]["height"] = maxf(layout.lots[best].height, 13.0)


# --- the game's places ----------------------------------------------------------

func _places() -> void:
	for name in Plan.PLACES:
		var spec: Dictionary = Plan.PLACES[name]
		var node: Node3D = city.get_node_or_null(name)
		if name == "Plaza":
			node = BUSK_SPOT.instantiate()
			node.name = "Plaza"
			city.add_child(node)
			node.owner = city
		if node == null:
			continue
		node.transform = Kit.yawed(deg_to_rad(spec.yaw), Kit.v3(spec.at))


## Hachi Plaza, the building site, the park, the courtyards, Uptown's front
## steps and the harbour.
## Brick walls round the back of the Cat Alley yard: the only way in is from
## the alley, so the gig there feels tucked away.
func _yard_walls() -> void:
	var walls: StaticBody3D = city.get_node("AlleyWalls")
	var root := kit.node(city, "YardWalls")
	var runs := [[Vector2(37.6, 80.9), Vector2(37.6, 94.4)], [Vector2(37.6, 94.4), Vector2(53.8, 94.4)], [Vector2(53.8, 94.4), Vector2(53.8, 82.6)]]
	for run in runs:
		var a: Vector2 = run[0]
		var b: Vector2 = run[1]
		var length := a.distance_to(b)
		var xform := Kit.yawed(Layout.yaw_facing((b - a).normalized()) + PI * 0.5, Kit.v3((a + b) * 0.5, 1.7))
		var brick := kit.wall(Color("4a3a3a"), Vector3(length, 3.4, 0.4), float(length), 0.0, Color("ffb870"), Color("ffb870"), Vector2(2.4, 3.0), 9.0)
		brick.set_shader_parameter(&"see_through", true)
		kit.mesh(root, "YardWall", kit.box(Vector3(length, 3.4, 0.4), brick, 0.05), xform)
		kit.add_box(root, "Coping", xform.origin + Vector3(0, 1.75, 0), Vector3(length + 0.2, 0.12, 0.5), kit.toy(Color("5a5868"), 0, 0.85), xform.basis.get_euler().y)
		kit.shape(walls, "YardWall", xform, Vector3(length, 3.4, 0.4))
	# Bits leaning on the walls: crates, a bike, a drainpipe, a lamp over the gig.
	streets._bin(Kit.yawed(PI * 0.5, Vector3(38.4, 0, 92.5)))
	kit.add_box(root, "Crate", Vector3(52.9, 0.3, 93.4), Vector3(0.7, 0.6, 0.7), kit.toy(Color("8a5a3c"), 0, 0.85), 0.3)
	kit.add_box(root, "Crate", Vector3(52.7, 0.85, 93.3), Vector3(0.6, 0.5, 0.6), kit.toy(Color("7a4a2c"), 0, 0.85), -0.2)
	kit.label(root, "Mural", "CAT ALLEY", Transform3D(Basis(Vector3.UP, PI), Vector3(45.7, 2.3, 94.18)), 0.9, Color(1.0, 0.55, 0.8))


func _set_pieces() -> void:
	var solid: StaticBody3D = city.get_node("StreetSolid")
	# Hachi Plaza: fountain, the faithful dog statue, benches and trees.
	var plaza_poly := Layout.rect_polygon(_reserved("plaza"))
	ground.patch("PlazaFloor", plaza_poly, kit.ground({"color": Color(0.46, 0.4, 0.42), "patch_color": Color(0.41, 0.36, 0.38), "patch_size": 2.0,
			"tile_size": Vector2(1.2, 1.2), "tile_gap": 0.05, "gap_darkness": 0.35, "tile_variation": 0.12, "wetness": 0.85, "puddle_size": 2.0}), -0.005)
	var plaza := kit.node(city, "PlazaDecor")
	var stone := kit.toy(Color("8a8494"), 0, 0.8, 0.2)
	var fountain := Vector3(-6.0, 0, 47.0)
	kit.mesh(plaza, "Basin", kit.cyl(3.2, 3.3, 0.6, stone, 28), Transform3D(Basis(), fountain + Vector3(0, 0.3, 0)))
	var water := ShaderMaterial.new()
	water.shader = load("res://world/water.gdshader")
	kit.mesh(plaza, "Water", kit.cyl(2.9, 2.9, 0.1, water, 28), Transform3D(Basis(), fountain + Vector3(0, 0.56, 0)), false)
	kit.mesh(plaza, "Spout", kit.cyl(0.4, 0.25, 1.6, stone, 14), Transform3D(Basis(), fountain + Vector3(0, 1.1, 0)))
	kit.mesh(plaza, "SpoutGlow", kit.sphere(0.32, kit.glow(Color("9be7ff"), 2.0)), Transform3D(Basis(), fountain + Vector3(0, 2.0, 0)), false)
	kit.cyl_shape(solid, "Fountain", fountain + Vector3(0, 0.4, 0), 3.3, 0.8)
	kit.omni(plaza, "FountainLight", fountain + Vector3(0, 1.4, 0), Color("9be7ff"), 1.2, 9.0)
	# The dog on its plinth.
	var dog_at := Vector3(8.5, 0, 45.0)
	kit.add_box(plaza, "Plinth", dog_at + Vector3(0, 0.6, 0), Vector3(1.4, 1.2, 2.0), stone)
	var bronze := kit.toy(Color("6b5a3a"), 0, 0.4, 0.2, 0.7)
	kit.mesh(plaza, "DogBody", kit.capsule(0.32, 0.3, 1.25, bronze), Transform3D(Basis(Vector3.RIGHT, PI * 0.5), dog_at + Vector3(0, 1.75, 0.0)))
	kit.mesh(plaza, "DogHead", kit.sphere(0.28, bronze), Transform3D(Basis(), dog_at + Vector3(0, 2.25, 0.62)))
	kit.mesh(plaza, "DogSnout", kit.capsule(0.12, 0.1, 0.35, bronze), Transform3D(Basis(Vector3.RIGHT, PI * 0.5), dog_at + Vector3(0, 2.18, 0.86)))
	for x in [-0.15, 0.15]:
		kit.mesh(plaza, "DogEar", kit.capsule(0.07, 0.02, 0.28, bronze), Transform3D(Basis(Vector3.FORWARD, x * 2.0), dog_at + Vector3(x, 2.5, 0.55)))
		for z in [-0.4, 0.4]:
			kit.mesh(plaza, "DogLeg", kit.capsule(0.08, 0.07, 0.6, bronze), Transform3D(Basis(), dog_at + Vector3(x * 1.4, 1.42, z)))
	kit.shape(solid, "Plinth", Transform3D(Basis(), dog_at + Vector3(0, 0.6, 0)), Vector3(1.4, 1.2, 2.0))
	kit.label(plaza, "PlinthText", "HACHI", Transform3D(Basis(), dog_at + Vector3(0, 0.75, 1.01)), 0.32, Color(1.3, 1.2, 1.0))
	for spec in [[Vector3(-11, 0, 44), 0.5], [Vector3(-10.5, 0, 53.5), PI * 0.6], [Vector3(-1.5, 0, 54.0), PI], [Vector3(4.5, 0, 53.5), PI]]:
		streets.bench(Transform3D(Basis(Vector3.UP, spec[1]), spec[0]))
	for at in [Vector3(-10, 0, 49.5), Vector3(12.5, 0, 43.5), Vector3(13, 0, 52.5), Vector3(0.5, 0, 43)]:
		streets.tree(at, 0.9, 0)
	for at in [Vector3(-6, 0, 53), Vector3(3, 0, 47.5), Vector3(-1, 0, 50)]:
		streets.spots.append(at)
	kit.omni(plaza, "PlazaLight", Vector3(3, 4.5, 50), Color("ffd9b0"), 1.0, 12.0)

	# The building site behind Market Lane: hoardings, a crane, a half-built frame.
	var works_poly := Layout.rect_polygon(_reserved("works"))
	ground.patch("WorksFloor", works_poly, kit.ground({"color": Color(0.36, 0.3, 0.26), "patch_color": Color(0.3, 0.25, 0.22), "patch_size": 2.5,
			"dot_density": 0.25, "dot_spacing": 0.4, "dot_radius": 0.05, "dot_color": Color(0.5, 0.46, 0.42), "dot_color_b": Color(0.4, 0.38, 0.36), "wetness": 0.9}), -0.006)
	var works := kit.node(city, "Works")
	var centre := Vector2(-41.5, 27)
	var steel := kit.toy(Color("e0a020"), 0.05, 0.5, 0.2, 0.3)
	var grey := kit.toy(Color("6e7280"), 0, 0.6, 0.2, 0.3)
	for x in [-3.0, 0.0, 3.0]:
		for z in [-4.0, 0.0, 4.0]:
			kit.add_box(works, "Column", Kit.v3(centre, 4.5) + Vector3(x, 0, z), Vector3(0.3, 9.0, 0.3), grey, 0, true, 150.0)
	for y in [3.0, 6.0, 9.0]:
		for z in [-4.0, 0.0, 4.0]:
			kit.add_box(works, "Beam", Kit.v3(centre, y) + Vector3(0, 0, z), Vector3(6.3, 0.3, 0.3), grey, 0, true, 150.0)
		kit.add_box(works, "Floor", Kit.v3(centre, y - 0.2), Vector3(6.3, 0.15, 8.3), kit.toy(Color("8a8494")), 0, true, 150.0)
	kit.shape(solid, "Frame", Transform3D(Basis(), Kit.v3(centre, 4.5)), Vector3(6.6, 9.0, 8.6))
	# Tower crane.
	var crane_at := Kit.v3(centre + Vector2(-3.5, 5.0))
	kit.add_box(works, "CraneMast", crane_at + Vector3(0, 11, 0), Vector3(1.0, 22, 1.0), steel)
	kit.add_box(works, "CraneJib", crane_at + Vector3(6, 22.5, 0), Vector3(22, 0.8, 0.8), steel)
	kit.add_box(works, "CraneCab", crane_at + Vector3(0.9, 21.3, 0), Vector3(1.4, 1.4, 1.2), kit.toy(Color("f4f1de"), 0.3))
	kit.add_box(works, "Counterweight", crane_at + Vector3(-4, 21.8, 0), Vector3(2.0, 1.4, 1.2), grey)
	kit.mesh(works, "CraneLight", kit.sphere(0.25, kit.glow(Color("ff3b3b"), 4.0)), Transform3D(Basis(), crane_at + Vector3(16.5, 23.1, 0)), false)
	kit.mesh(works, "CraneLight", kit.sphere(0.25, kit.glow(Color("ff3b3b"), 4.0)), Transform3D(Basis(), crane_at + Vector3(0, 23.4, 0)), false)
	kit.add_box(works, "Hook", crane_at + Vector3(12, 17, 0), Vector3(0.05, 11, 0.05), kit.toy(Color("26252e")), 0, false, 120.0)
	kit.add_box(works, "Load", crane_at + Vector3(12, 11.2, 0), Vector3(1.6, 0.6, 1.0), kit.toy(Color("5b4636")), 0, true, 120.0)
	kit.shape(solid, "CraneMast", Transform3D(Basis(), crane_at + Vector3(0, 11, 0)), Vector3(1.0, 22, 1.0))
	# Hoarding round it, gap at the front for the gate.
	var poly := PackedVector2Array(works_poly)
	for i in poly.size():
		var a := poly[i]
		var b := poly[(i + 1) % poly.size()]
		var length := a.distance_to(b)
		var steps := int(length / 2.0)
		for k in steps:
			var p := a.lerp(b, (k + 0.5) / steps)
			if i == 1 and k == steps / 2:
				continue
			var yaw := Layout.yaw_facing(Layout.left_of((b - a).normalized()))
			var colour := Color("f4f1de") if (k + i) % 2 == 0 else Color("2a6f97")
			kit.add_box(works, "Hoarding", Kit.v3(p, 1.1), Vector3(2.0, 2.2, 0.08), kit.toy(colour, 0.08), yaw)
			kit.shape(solid, "Hoarding", Kit.yawed(yaw, Kit.v3(p, 1.1)), Vector3(2.0, 2.2, 0.15))
	for p in [Vector2(-36.5, 24.0), Vector2(-36.3, 27.5), Vector2(-36.6, 31.0)]:
		streets.cone(Kit.v3(p))
	streets.barrier(Transform3D(Basis(Vector3.UP, PI * 0.5), Vector3(-36.8, 0, 29.3)), 2.4)
	kit.label(works, "Notice", "WORKS", Transform3D(Basis(Vector3.UP, PI * 0.5), Vector3(-37.4, 1.6, 23.0)), 0.4, Color(1.6, 1.3, 0.4))

	# Courtyards: basketball hoop, string lights, a mural.
	for spec in Plan.RESERVED:
		if spec.what != "court":
			continue
		var c: Vector2 = spec.rect[0]
		var s: Vector2 = spec.rect[1]
		ground.patch("CourtFloor", Layout.rect_polygon(spec), kit.ground({"color": Color(0.28, 0.33, 0.42), "patch_color": Color(0.25, 0.3, 0.38), "patch_size": 3.0, "wetness": 0.9}), -0.006)
		var court := kit.node(city, "Court", Kit.yawed(0.0, Kit.v3(c)))
		kit.add_box(court, "HoopPole", Vector3(0, 1.7, -s.y * 0.5 + 0.4), Vector3(0.14, 3.4, 0.14), kit.toy(Color("26252e")))
		kit.add_box(court, "Backboard", Vector3(0, 3.3, -s.y * 0.5 + 0.7), Vector3(1.6, 1.0, 0.06), kit.toy(Color("f4f1de"), 0.2))
		kit.mesh(court, "Hoop", kit.cyl(0.25, 0.25, 0.04, kit.toy(Color("ff7a1a"), 0.3), 12), Transform3D(Basis(), Vector3(0, 3.0, -s.y * 0.5 + 1.0)))
		kit.shape(solid, "HoopPole", Transform3D(Basis(), Kit.v3(c, 1.7) + Vector3(0, 0, -s.y * 0.5 + 0.4)), Vector3(0.2, 3.4, 0.2))
		for i in 10:
			var x := -s.x * 0.45 + i * s.x * 0.9 / 9.0
			kit.mesh(court, "Bulb", kit.sphere(0.08, kit.glow(Color("ffe6a8"), 4.0)), Transform3D(Basis(), Vector3(x, 3.6 - sin(PI * i / 9.0) * 0.5, 0)), false, 80.0)
		kit.omni(court, "Glow", Vector3(0, 3.0, 0), Color("ffd59a"), 0.8, 8.0)
		streets.spots.append(Kit.v3(c))
		lights += 1

	# The car park off Kanda Avenue.
	var lot_spec := _reserved("lot")
	ground.patch("CarPark", Layout.rect_polygon(lot_spec), kit.ground(GroundPaint.ASPHALT.merged({"color": Color(0.25, 0.25, 0.31), "patch_color": Color(0.21, 0.21, 0.27)})), 0.003)
	var lot_c: Vector2 = lot_spec.rect[0]
	var colours := [Color("e63946"), Color("ffd166"), Color("3ddbd9"), Color("f4f1de"), Color("7f8cff"), Color("2b2d42")]
	for i in 4:
		streets.parked_car(Kit.yawed(PI * 0.5, Kit.v3(lot_c + Vector2(-4.5 + i * 0.0, -4.0 + i * 2.7))), colours[i], i == 2)

	# Park Side: lawn, paths, trees, lamps round the bandshell.
	var park_poly := Layout.rect_polygon(_reserved("park"))
	ground.patch("ParkLawn", park_poly, kit.ground({"color": Color(0.212, 0.431, 0.282), "patch_color": Color(0.18, 0.376, 0.251), "patch_size": 4.5,
			"dot_density": 0.08, "dot_spacing": 0.55, "dot_radius": 0.04, "dot_color": Color(0.81, 0.85, 0.78), "dot_color_b": Color(0.85, 0.77, 0.42), "wetness": 0.25}), -0.01)
	var park := kit.node(city, "Park")
	var rng := RandomNumberGenerator.new()
	rng.seed = 5
	for i in 26:
		var p := Vector2(rng.randf_range(-27, 33), rng.randf_range(150, 193))
		if p.distance_to(Vector2(2, 162)) < 16.0 or absf(p.x - 2.0) < 4.0:
			continue
		streets.tree(Kit.v3(p), rng.randf_range(0.9, 1.4), rng.randi() % 2)
	for spec in [[Vector3(-12, 0, 160), PI * 0.5], [Vector3(16, 0, 160), -PI * 0.5], [Vector3(-12, 0, 168), PI * 0.5], [Vector3(16, 0, 168), -PI * 0.5]]:
		streets.bench(Transform3D(Basis(Vector3.UP, spec[1]), spec[0]))
	for x in [-8.0, 12.0]:
		kit.omni(park, "ParkLamp", Vector3(x, 3.5, 152), Color("ffe0b0"), 1.0, 10.0)
		kit.mesh(park, "ParkLampGlobe", kit.sphere(0.25, kit.glow(Color("ffe0b0"), 3.0)), Transform3D(Basis(), Vector3(x, 3.5, 152)), false)
		kit.mesh(park, "ParkLampPost", kit.cyl(0.07, 0.07, 3.4, kit.toy(Color("2d2c38")), 8), Transform3D(Basis(), Vector3(x, 1.7, 152)))

	# Uptown: front steps for Skyline Tower, planters, a little plaza.
	var tower: Node3D = city.get_node("Tower")
	ground.patch("UptownSquare", Ground_rect(tower.position + Vector3(-4, 0, 0), Vector2(26, 22)), kit.ground({"color": Color(0.42, 0.42, 0.5), "patch_color": Color(0.38, 0.38, 0.46), "patch_size": 2.0,
			"tile_size": Vector2(1.5, 1.5), "tile_gap": 0.04, "gap_darkness": 0.3, "tile_variation": 0.06, "wetness": 0.8}), -0.004)
	for at in [Vector3(110, 0, 56), Vector3(110, 0, 75)]:
		streets.tree(at, 1.1, 0)

	# Harbour: the water, a quay edge, cranes against the sky, containers.
	var harbour := kit.node(city, "Harbour")
	var water_mat := ShaderMaterial.new()
	water_mat.shader = load("res://world/water.gdshader")
	var bay := PlaneMesh.new()
	bay.size = Vector2(120, 140)
	bay.material = water_mat
	kit.mesh(harbour, "Bay", bay, Transform3D(Basis(), Vector3(-185, -0.6, -10)), false)
	kit.add_box(harbour, "Quay", Vector3(-126.5, -0.3, -10), Vector3(1.0, 0.7, 86), kit.toy(Color("4a4856"), 0, 0.85))
	for i in 3:
		var at := Vector3(-120.0 + i * 2.0, 0, -30.0 + i * 18.0)
		kit.add_box(harbour, "CraneLeg", at + Vector3(-2, 9, -2), Vector3(0.6, 18, 0.6), kit.toy(Color("c0392b"), 0.05))
		kit.add_box(harbour, "CraneLeg", at + Vector3(-2, 9, 2), Vector3(0.6, 18, 0.6), kit.toy(Color("c0392b"), 0.05))
		kit.add_box(harbour, "CraneLeg", at + Vector3(3, 9, -2), Vector3(0.6, 18, 0.6), kit.toy(Color("c0392b"), 0.05))
		kit.add_box(harbour, "CraneLeg", at + Vector3(3, 9, 2), Vector3(0.6, 18, 0.6), kit.toy(Color("c0392b"), 0.05))
		kit.add_box(harbour, "CraneBoom", at + Vector3(-10, 18.5, 0), Vector3(30, 1.2, 1.4), kit.toy(Color("c0392b"), 0.05))
		kit.mesh(harbour, "CraneLight", kit.sphere(0.3, kit.glow(Color("ff3b3b"), 4.0)), Transform3D(Basis(), at + Vector3(-24.5, 19.4, 0)), false)
	for i in 14:
		var at := Vector3(-112.0 + (i % 4) * 3.0, 1.3 + (i / 7) * 2.6, -4.0 + (i % 7) * 4.6 - (i / 7) * 2.0)
		kit.add_box(harbour, "Container", at, Vector3(2.5, 2.6, 4.2), kit.toy(Color(["c0392b", "2a6f97", "e0a020", "2a9d8f", "6d597a"][i % 5]), 0.04, 0.6))
	kit.omni(harbour, "QuayLight", Vector3(-118, 6, 10), Color("ffd59a"), 1.6, 18.0)
	# Lights across the bay: the rest of the city.
	for i in 18:
		var at := Vector3(-235.0 + rng.randf_range(-10, 10), 0, -70.0 + i * 9.0)
		var h := rng.randf_range(8.0, 40.0)
		var m := kit.wall(Color("1d1b2c"), Vector3(8, h, 8), float(i), 0.5)
		kit.mesh(harbour, "FarShore", kit.box(Vector3(8, h, 8), m, 0.1), Transform3D(Basis(), at + Vector3(0, h * 0.5, 0)), false)

	# Trees along Creek Lane and down Kanda Avenue.
	for road_name in ["Creek Lane", "Kanda Avenue", "Mill Road"]:
		var road: Dictionary = layout.roads[streets._road_index(road_name)]
		var line: PackedVector2Array = road.points
		var total := Layout.length_of(line)
		var along := 9.0
		var side := 1.0
		while along < total - 6.0:
			var here := Layout.at_distance(line, along)
			var p: Vector2 = here.point + Layout.left_of(here.dir) * side * (road.width * 0.5 + 1.5)
			if streets._on_pavement(p, road) and _clear_of_things(p):
				streets.tree(Kit.v3(p), 0.8, 0)
			along += 13.0 if road_name != "Kanda Avenue" else 21.0
			side = -side
	# Parked cars in front of the houses on Creek Lane.
	var cars := 0
	for lot in layout.lots:
		if lot.style != "home" or not lot.front or cars >= 6 or lot.size.x < 8.0:
			continue
		if rng.randf() < 0.5:
			continue
		var base := Transform3D(Basis(Vector3.UP, lot.yaw), Kit.v3(lot.centre))
		var spot := base * Vector3(lot.size.x * 0.5 - 1.3, 0, lot.size.y * 0.5 + 2.1)
		if layout.value_at(Vector2(spot.x, spot.z)) == Layout.ROAD and _clear_of_roads(Vector2(spot.x, spot.z), 1.0):
			streets.parked_car(Transform3D(base.basis * Basis(Vector3.UP, PI * 0.5), spot), colours[cars % colours.size()])
			cars += 1


func Ground_rect(centre: Vector3, size: Vector2) -> PackedVector2Array:
	return Layout.rect_corners(Vector2(centre.x, centre.z), size, 0.0)


func _clear_of_things(p: Vector2) -> bool:
	var space_ok := true
	for child in city.get_node("Street").get_children():
		if child is Node3D and Vector2((child as Node3D).position.x, (child as Node3D).position.z).distance_to(p) < 2.0:
			space_ok = false
			break
	return space_ok


func _clear_of_drivable(p: Vector2, margin: float) -> bool:
	for road in layout.roads:
		if road.kind != Plan.PATH and layout.distance_to_road(p, road) < road.width * 0.5 + margin:
			return false
	return true


func _clear_of_roads(p: Vector2, margin: float) -> bool:
	for road in layout.roads:
		if layout.distance_to_road(p, road) < road.width * 0.5 + margin:
			return false
	return true


# --- fan gates and the walls round the gated parts of town ----------------------------

func _gates_and_walls() -> void:
	var gate_nodes := {"uptown": "UptownGate", "park_side": "ParkSideGate", "harbour": "HarbourGate"}
	var walls := StaticBody3D.new()
	walls.name = "DistrictWalls"
	walls.collision_mask = 0
	city.get_node("Street").add_child(walls)
	walls.owner = city
	for gated in Plan.GATED:
		var gate: StaticBody3D = city.get_node(gate_nodes[gated.area])
		for child in gate.get_children():
			gate.remove_child(child)
			child.free()
		# The road through the gate: which way it runs there and how wide it is.
		var road := _road_for_area(gated.area)
		var p: Vector2 = gated.gate
		var closest := _closest_on(road.points, p)
		var dir: Vector2 = closest.dir
		var span: float = road.width + 2.0 * 2.4
		gate.transform = Kit.yawed(Layout.yaw_facing(dir), Kit.v3(closest.point))
		_build_gate(gate, span)
		# Walls along the polygon, leaving the road open (the gate shuts it).
		var polygon := PackedVector2Array(gated.polygon)
		var park: bool = gated.area == "park_side"
		for i in polygon.size():
			var a := polygon[i]
			var b := polygon[(i + 1) % polygon.size()]
			if _on_world_edge(a, b):
				continue
			var length := a.distance_to(b)
			var piece := 3.0
			var steps := maxi(int(length / piece), 1)
			for k in steps:
				var q := a.lerp(b, (k + 0.5) / steps)
				if q.distance_to(closest.point) < span * 0.5 + 0.2:
					continue
				var skip := false
				for other in layout.roads:
					if layout.distance_to_road(q, other) < other.width * 0.5 + 0.5:
						skip = true
				if skip:
					continue
				var yaw := Layout.yaw_facing(Layout.left_of((b - a).normalized()))
				var len := length / steps + 0.05
				if park:
					kit.add_box(walls, "Railing", Kit.v3(q, 0.9), Vector3(len, 0.08, 0.08), kit.toy(Color("26252e"), 0, 0.5, 0.2, 0.4), yaw, true, 90.0)
					kit.add_box(walls, "Hedge", Kit.v3(q, 0.75), Vector3(len, 1.5, 1.1), kit.toy(Color("2b5e3e"), 0, 0.95, 0.6), yaw, true, 0.0, 0.35)
					kit.shape(walls, "Hedge", Kit.yawed(yaw, Kit.v3(q, 1.5)), Vector3(len, 3.0, 1.1))
				else:
					kit.add_box(walls, "Wall", Kit.v3(q, 1.6), Vector3(len, 3.2, 0.5), kit.toy(Color("4a3a3a") if gated.area == "uptown" else Color("4a4856"), 0, 0.9), yaw)
					kit.add_box(walls, "WallCap", Kit.v3(q, 3.25), Vector3(len, 0.15, 0.65), kit.toy(Color("2a2838")), yaw, true, 90.0)
					kit.shape(walls, "Wall", Kit.yawed(yaw, Kit.v3(q, 1.6)), Vector3(len, 3.2, 0.5))


func _on_world_edge(a: Vector2, b: Vector2) -> bool:
	var r := Plan.BOUNDS
	for p in [a, b]:
		pass
	if (absf(a.x - r.position.x) < 0.5 and absf(b.x - r.position.x) < 0.5) or (absf(a.x - r.end.x) < 0.5 and absf(b.x - r.end.x) < 0.5):
		return true
	if (absf(a.y - r.position.y) < 0.5 and absf(b.y - r.position.y) < 0.5) or (absf(a.y - r.end.y) < 0.5 and absf(b.y - r.end.y) < 0.5):
		return true
	return false


func _road_for_area(area: String) -> Dictionary:
	for road in layout.roads:
		if road.area == area:
			return road
	return {}


func _closest_on(line: PackedVector2Array, p: Vector2) -> Dictionary:
	var best := {}
	var best_d := INF
	for i in range(1, line.size()):
		var c := Geometry2D.get_closest_point_to_segment(p, line[i - 1], line[i])
		var d := c.distance_to(p)
		if d < best_d:
			best_d = d
			best = {"point": c, "dir": (line[i] - line[i - 1]).normalized()}
	return best


func _build_gate(gate: StaticBody3D, span: float) -> void:
	var boards := int(span)
	var stripes := [kit.toy(Color("f4f1de"), 0.15), kit.toy(Color("e63946"), 0.2)]
	for i in boards:
		var x := -span * 0.5 + 0.5 + i
		kit.add_box(gate, "Board", Vector3(x, 1.0, 0), Vector3(0.98, 0.3, 0.08), stripes[i % 2])
		kit.add_box(gate, "BoardLow", Vector3(x, 0.5, 0), Vector3(0.98, 0.3, 0.08), stripes[(i + 1) % 2])
	for x in [-span * 0.5 - 0.2, 0.0, span * 0.5 + 0.2]:
		kit.add_box(gate, "Post", Vector3(x, 0.75, 0), Vector3(0.2, 1.5, 0.2), kit.toy(Color("26252e")))
		kit.mesh(gate, "Beacon", kit.sphere(0.12, kit.glow(Color("ffb020"), 4.0)), Transform3D(Basis(), Vector3(x, 1.6, 0)), false)
	kit.add_box(gate, "Board", Vector3(0, 2.6, 0), Vector3(4.6, 1.2, 0.12), kit.toy(Color("1d1b28"), 0.1))
	var sign := kit.label(gate, "Sign", "CLOSED", Transform3D(Basis(Vector3.UP, PI), Vector3(0, 2.6, -0.08)), 0.36, Color(2.0, 1.6, 0.6))
	sign.name = "Sign"
	var back := kit.label(gate, "SignBack", "", Transform3D(Basis(), Vector3(0, 2.6, 0.08)), 0.36, Color(2.0, 1.6, 0.6))
	back.visible = false
	kit.shape(gate, "Shape", Transform3D(Basis(), Vector3(0, 1.5, 0)), Vector3(span + 0.6, 3.0, 0.4)).name = "Shape"


# --- the starting house's yard ------------------------------------------------------

## The yard: x from YARD.position.x to YARD.end.x, z the same (metres).
const YARD := Rect2(-16.6, -13.6, 29.2, 23.0)
## The back gate's opening (centre x on the back fence) and the drive's gap in the front.
const BACK_GATE_X := 4.5
const GATE_WIDTH := 1.9
const DRIVE := Vector2(-3.4, 5.4)


## A picket fence all round the house and its yard, the old wonky gate in the
## back fence (now on a hinge), a lawn, a drive for the truck, flower beds.
func _home_yard() -> void:
	var yard := kit.node(city, "HomeYard")
	var body := StaticBody3D.new()
	body.name = "FenceSolid"
	body.collision_mask = 0
	yard.add_child(body)
	body.owner = city
	var r := YARD
	var back_l := Vector2(r.position.x, r.position.y)
	var back_r := Vector2(r.end.x, r.position.y)
	var front_l := Vector2(r.position.x, r.end.y)
	var front_r := Vector2(r.end.x, r.end.y)
	var gate_a := Vector2(BACK_GATE_X - GATE_WIDTH * 0.5, r.position.y)
	var gate_b := Vector2(BACK_GATE_X + GATE_WIDTH * 0.5, r.position.y)
	var runs := [[back_l, gate_a], [gate_b, back_r], [back_r, front_r], [front_r, Vector2(DRIVE.y, r.end.y)],
			[Vector2(DRIVE.x, r.end.y), front_l], [front_l, back_l]]
	for run in runs:
		_fence_run(yard, body, run[0], run[1])
	# Gate pillars either side of the drive, with a lamp and the house number.
	var white := kit.toy(Color("e8dcc8"), 0.05, 0.8, 0.3)
	for x in [DRIVE.x, DRIVE.y]:
		var at := Vector3(x, 0, r.end.y)
		kit.add_box(yard, "DrivePier", at + Vector3(0, 0.65, 0), Vector3(0.45, 1.3, 0.45), kit.toy(Color("8a6b5c"), 0, 0.85, 0.3))
		kit.add_box(yard, "DrivePierCap", at + Vector3(0, 1.36, 0), Vector3(0.55, 0.1, 0.55), white)
		kit.mesh(yard, "DriveLamp", kit.sphere(0.16, kit.glow(Color("ffe0b0"), 3.0)), Transform3D(Basis(), at + Vector3(0, 1.58, 0)), false)
		kit.shape(body, "DrivePier", Transform3D(Basis(), at + Vector3(0, 0.65, 0)), Vector3(0.45, 1.3, 0.45))
	kit.omni(yard, "DriveLight", Vector3((DRIVE.x + DRIVE.y) * 0.5, 2.0, r.end.y - 0.5), Color("ffd9a8"), 0.8, 7.0)
	lights += 1
	kit.label(yard, "HouseNumber", "No. 1", Transform3D(Basis(), Vector3(DRIVE.y, 0.95, r.end.y + 0.24)), 0.22, Color(0.25, 0.2, 0.18))
	# Mailbox by the drive.
	kit.add_box(yard, "MailPost", Vector3(DRIVE.y + 1.0, 0.5, r.end.y - 0.4), Vector3(0.08, 1.0, 0.08), kit.toy(Color("3a2c22")))
	kit.add_box(yard, "Mailbox", Vector3(DRIVE.y + 1.0, 1.05, r.end.y - 0.4), Vector3(0.3, 0.28, 0.5), kit.toy(Color("c8323c"), 0.1, 0.5))
	# The gate itself: the old cream boards, wonky as ever, on a hinge.
	var gate := Node3D.new()
	gate.name = "BackGate"
	gate.set_script(GATE_SCRIPT)
	gate.transform = Transform3D(Basis(), Vector3(BACK_GATE_X, 0, r.position.y))
	yard.add_child(gate)
	gate.owner = city
	_build_gate_leaf(gate, white)
	# Lawn, drive and a stepping path round to the back gate.
	var lawn := kit.ground({"color": Color(0.17, 0.33, 0.21), "patch_color": Color(0.14, 0.28, 0.18), "patch_size": 3.0,
			"dot_density": 0.06, "dot_spacing": 0.55, "dot_radius": 0.035, "dot_color": Color(0.85, 0.85, 0.75), "dot_color_b": Color(0.95, 0.7, 0.75), "wetness": 0.35})
	ground.patch("YardLawn", Layout.rect_corners(r.get_center(), r.size, 0.0), lawn, -0.006)
	var drive := kit.ground(GroundPaint.ASPHALT.merged({"color": Color(0.27, 0.26, 0.3), "patch_color": Color(0.23, 0.22, 0.26)}))
	ground.patch("Drive", Layout.rect_corners(Vector2((DRIVE.x + DRIVE.y) * 0.5, (-3.6 + r.end.y + 2.2) * 0.5), Vector2(DRIVE.y - DRIVE.x, r.end.y + 2.2 + 3.6), 0.0), drive, -0.004)
	for k in 9:
		var t := k / 8.0
		var p := Vector2(3.6, -2.0).lerp(Vector2(BACK_GATE_X, r.position.y + 0.9), t) + Vector2(4.2 * sin(t * PI), 0)
		kit.place(yard, "Step", "res://art/nature/RockPath_Round_Small_%d.gltf" % (k % 3 + 1), Transform3D(Basis(Vector3.UP, k * 1.3), Kit.v3(p, 0.0)), false, 60.0)
	# Flower beds along the inside of the front fence, bushes and a tree in the corners.
	for x in [-14.5, -12.0, -9.5, -6.5, 7.5, 10.0]:
		streets.flower_bed(Vector3(x, 0, r.end.y - 0.9), 0.85)
	for at in [Vector3(-15.3, 0, r.end.y - 1.2), Vector3(11.4, 0, r.end.y - 1.3), Vector3(-15.0, 0, -6.0), Vector3(11.3, 0, -2.0), Vector3(-6.0, 0, -12.4), Vector3(9.0, 0, -12.5)]:
		streets.bush(at, 1.0)
	streets.tree(Vector3(-12.5, 0, -9.0), 1.2, 0, body)
	streets.tree(Vector3(9.5, 0, -8.0), 1.05, 0, body)
	streets.bench(Transform3D(Basis(Vector3.UP, PI * 0.5), Vector3(-9.5, 0, -1.0)), false)
	kit.omni(yard, "BackLight", Vector3(BACK_GATE_X, 2.2, r.position.y + 1.2), Color("ffc98a"), 0.7, 6.0)
	lights += 1


## A straight run of picket fence: one merged mesh, one collider.
func _fence_run(parent: Node3D, body: StaticBody3D, a: Vector2, b: Vector2) -> void:
	var length := a.distance_to(b)
	if length < 0.2:
		return
	var yaw := Layout.yaw_facing(Layout.left_of((b - a).normalized()))
	var xform := Kit.yawed(yaw, Kit.v3((a + b) * 0.5))
	kit.mesh(parent, "Fence", _fence_mesh(length), xform, true, 140.0)
	kit.shape(body, "Fence", xform * Transform3D(Basis(), Vector3(0, 0.6, 0)), Vector3(length, 1.2, 0.14))


var _fence_meshes := {}


## Pickets with rounded-off tops, two rails, a post every couple of metres.
## Local x along the run (centred), z out of the yard.
func _fence_mesh(length: float) -> Mesh:
	var key := snappedf(length, 0.05)
	if _fence_meshes.has(key):
		return _fence_meshes[key]
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	var posts := maxi(1, int(ceil(length / 2.4)))
	for k in posts + 1:
		var x := -length * 0.5 + length * k / posts
		_box_into(st, Vector3(x, 0.62, 0), Vector3(0.12, 1.24, 0.12))
		_box_into(st, Vector3(x, 1.27, 0), Vector3(0.16, 0.06, 0.16))
	for y in [0.32, 0.86]:
		_box_into(st, Vector3(0, y, -0.06), Vector3(length, 0.07, 0.04))
	var count := int(length / 0.26)
	for k in count:
		var x := -length * 0.5 + (k + 0.5) * length / count
		var h := 1.02 + 0.05 * sin(k * 2.1)
		_box_into(st, Vector3(x, h * 0.5, 0.0), Vector3(0.09, h, 0.025))
		_box_into(st, Vector3(x, h + 0.03, 0.0), Vector3(0.05, 0.06, 0.025))
	st.generate_normals()
	var mesh := st.commit()
	mesh.surface_set_material(0, kit.toy(Color("e8dcc8"), 0.05, 0.8, 0.3))
	_fence_meshes[key] = mesh
	return mesh


func _box_into(st: SurfaceTool, c: Vector3, size: Vector3) -> void:
	var h := size * 0.5
	var corners := [Vector3(-h.x, -h.y, -h.z), Vector3(h.x, -h.y, -h.z), Vector3(h.x, h.y, -h.z), Vector3(-h.x, h.y, -h.z),
			Vector3(-h.x, -h.y, h.z), Vector3(h.x, -h.y, h.z), Vector3(h.x, h.y, h.z), Vector3(-h.x, h.y, h.z)]
	# Faces as quads (outward, counter-clockwise seen from outside -> Godot wants clockwise, so reversed).
	var faces := [[0, 3, 2, 1], [4, 5, 6, 7], [0, 4, 7, 3], [1, 2, 6, 5], [3, 7, 6, 2], [0, 1, 5, 4]]
	for f in faces:
		var q := [c + corners[f[0]], c + corners[f[1]], c + corners[f[2]], c + corners[f[3]]]
		st.add_vertex(q[0])
		st.add_vertex(q[1])
		st.add_vertex(q[2])
		st.add_vertex(q[0])
		st.add_vertex(q[2])
		st.add_vertex(q[3])


## The gate's leaf: uneven cream boards with a crooked brace and a heart cut
## into the top board, hinged at the gate's -x end. Posts either side.
func _build_gate_leaf(gate: Node3D, white: Material) -> void:
	var half := GATE_WIDTH * 0.5
	for x in [-half, half]:
		kit.add_box(gate, "GatePost", Vector3(x, 0.7, 0), Vector3(0.16, 1.4, 0.16), white)
		kit.mesh(gate, "PostKnob", kit.sphere(0.1, white), Transform3D(Basis(), Vector3(x, 1.46, 0)))
	var hinge := Node3D.new()
	hinge.name = "Hinge"
	hinge.position = Vector3(-half + 0.1, 0, 0)
	gate.add_child(hinge)
	hinge.owner = city
	var leaf := AnimatableBody3D.new()
	leaf.name = "Leaf"
	leaf.sync_to_physics = true
	leaf.collision_mask = 0
	hinge.add_child(leaf)
	leaf.owner = city
	var width := GATE_WIDTH - 0.24
	var boards := 6
	for k in boards:
		var x := (k + 0.5) * width / boards
		var h: float = 0.95 + [0.0, 0.12, 0.05, 0.16, 0.02, 0.1][k]
		kit.add_box(leaf, "Board", Vector3(x, 0.12 + h * 0.5, 0), Vector3(width / boards - 0.04, h, 0.05), white, [0.0, 0.03, -0.02, 0.04, -0.03, 0.02][k])
	kit.add_box(leaf, "RailLow", Vector3(width * 0.5, 0.35, -0.05), Vector3(width, 0.09, 0.04), white)
	kit.add_box(leaf, "RailHigh", Vector3(width * 0.5, 0.88, -0.05), Vector3(width, 0.09, 0.04), white)
	kit.mesh(leaf, "Brace", kit.box(Vector3(width * 1.08, 0.08, 0.04), white), Transform3D(Basis(Vector3.BACK, 0.42), Vector3(width * 0.5, 0.62, -0.06)))
	kit.mesh(leaf, "Heart", kit.sphere(0.07, kit.toy(Color("e05a7a"), 0.3)), Transform3D(Basis(), Vector3(width * 0.5, 0.95, 0.04)), false)
	kit.mesh(leaf, "Latch", kit.box(Vector3(0.1, 0.05, 0.06), kit.toy(Color("2b2a36"), 0, 0.5, 0.2, 0.5)), Transform3D(Basis(), Vector3(width - 0.05, 0.7, 0.05)))
	kit.shape(leaf, "Shape", Transform3D(Basis(), Vector3(width * 0.5, 0.65, 0)), Vector3(width, 1.1, 0.12))


# --- skyline and the edge of the world --------------------------------------------------

func _skyline() -> void:
	var sky: Node3D = city.get_node("Skyline")
	var edge: StaticBody3D = city.get_node("WorldEdge")
	var r := Plan.BOUNDS
	var rng := RandomNumberGenerator.new()
	rng.seed = 909
	# Invisible walls at the edge.
	var thick := 4.0
	kit.shape(edge, "North", Transform3D(Basis(), Vector3(r.get_center().x, 6, r.position.y - thick * 0.5)), Vector3(r.size.x + 20, 12, thick))
	kit.shape(edge, "South", Transform3D(Basis(), Vector3(r.get_center().x, 6, r.end.y + thick * 0.5)), Vector3(r.size.x + 20, 12, thick))
	kit.shape(edge, "West", Transform3D(Basis(), Vector3(r.position.x - thick * 0.5, 6, r.get_center().y)), Vector3(thick, 12, r.size.y + 20))
	kit.shape(edge, "East", Transform3D(Basis(), Vector3(r.end.x + thick * 0.5, 6, r.get_center().y)), Vector3(thick, 12, r.size.y + 20))
	# Dark towers all round, lights in their windows (not across the harbour).
	var sides := [[Vector2(r.position.x, r.position.y), Vector2(r.end.x, r.position.y), Vector2(0, -1)],
			[Vector2(r.end.x, r.position.y), Vector2(r.end.x, r.end.y), Vector2(1, 0)],
			[Vector2(r.end.x, r.end.y), Vector2(r.position.x, r.end.y), Vector2(0, 1)],
			[Vector2(r.position.x, r.end.y), Vector2(r.position.x + 0.01, 33), Vector2(-1, 0)]]
	var index := 0
	for side in sides:
		var a: Vector2 = side[0]
		var b: Vector2 = side[1]
		var out: Vector2 = side[2]
		var length := a.distance_to(b)
		var along := 0.0
		while along < length:
			var w := rng.randf_range(9.0, 18.0)
			var p := a.lerp(b, (along + w * 0.5) / length)
			# Gap where the railway leaves town.
			if Layout.distance_to_line(p, layout.rail) < 9.0:
				along += w
				continue
			# Behind the creek: a wooded bank, with the towers well beyond it.
			var wooded := out.y < 0.0 and p.x > -82.0 and p.x < 78.0
			if wooded:
				# A low earth berm under a wall of big trees (the park's far edge).
				var hill := rng.randf_range(1.6, 3.0)
				var bank_c := p + out * 9.0
				kit.mesh(sky, "Bank", kit.box(Vector3(w + 4.0, hill * 2.0, 14.0), kit.toy(Color("14271d"), 0, 0.95, 0.6), 1.2, 2),
						Kit.yawed(rng.randf_range(-0.1, 0.1), Kit.v3(bank_c, 0.0)), false)
				var trees := int(w / 3.2) + 2
				for k in trees:
					var tp := bank_c + Vector2(lerpf(-w * 0.5, w * 0.5, (k + rng.randf_range(0.2, 0.8)) / trees), rng.randf_range(-4.5, 3.5))
					streets.tree(Kit.v3(tp, hill * 0.85), rng.randf_range(1.5, 2.3), rng.randi() % 3)
			for row in 2:
				if wooded and row == 0:
					continue
				var depth := rng.randf_range(8.0, 14.0)
				var h := rng.randf_range(14.0, 34.0) + row * rng.randf_range(6.0, 24.0)
				var c := p + out * (4.0 + depth * 0.5 + row * (34.0 if wooded else 16.0))
				var yaw := Layout.yaw_facing(-out)
				var size := Vector3(w - 1.0, h, depth)
				var m := kit.wall(Color("1e1c2c").lightened(rng.randf_range(0.0, 0.08)), size, float(index), rng.randf_range(0.25, 0.5), Color("ffb870"), Color("8ad8ff"), Vector2(2.3, 3.1), 3.0)
				kit.mesh(sky, "Sky", kit.box(size, m, 0.1, 1), Kit.yawed(yaw, Kit.v3(c, h * 0.5)), row == 0)
				if h > 30.0 and rng.randf() < 0.4:
					kit.mesh(sky, "SkyLight", kit.sphere(0.4, kit.glow(Color("ff3b3b"), 4.0)), Transform3D(Basis(), Kit.v3(c, h + 0.5)), false)
				index += 1
			along += w


# --- people, traffic, routes ----------------------------------------------------------

func _people() -> void:
	var people := People.new(layout, ground)
	var doors: Array = buildings.doors + rail.doors
	people.build_network(doors, streets.spots)
	var walks: Node3D = city.get_node("Sidewalks")
	walks.set("points", people.points)
	walks.set("kinds", people.kinds)
	walks.set("links", people.links)
	# Put everyone somewhere sensible.
	var rng := RandomNumberGenerator.new()
	rng.seed = 2468
	var seats := streets.seats.duplicate()
	var spot_list: Array = streets.spots.duplicate()
	spot_list.shuffle()
	var spot_i := 0
	for person in city.get_node("People").get_children():
		if not (person is Node3D):
			continue
		var mode: int = person.get("mode") if person.get("mode") != null else -1
		# Two neighbours always chatting at the kerb along from the house.
		if person.name == "Stander13" or person.name == "Stander14":
			var left := person.name == "Stander13"
			person.transform = Kit.yawed(PI * 0.5 if left else -PI * 0.5, Vector3(-12.2 if left else -11.2, 0, 11.3))
			continue
		if mode == 0:
			person.transform = Kit.yawed(rng.randf() * TAU, people.random_pavement())
		elif mode == 2 and not seats.is_empty():
			var seat: Dictionary = seats.pop_back()
			person.transform = Kit.yawed(seat.yaw, seat.at)
		else:
			var at: Vector3 = people.random_pavement()
			# A spot to hang about at, but never out in a road or an alley.
			for k in spot_list.size():
				var candidate: Vector3 = spot_list[spot_i % spot_list.size()]
				spot_i += 1
				if _clear_of_drivable(Vector2(candidate.x, candidate.z), 1.6):
					at = candidate
					break
			var offset := Vector3(rng.randf_range(-1.0, 1.0), 0, rng.randf_range(-1.0, 1.0))
			person.transform = Kit.yawed(rng.randf() * TAU, at + offset)
	# Cats: the Cat Alley yard, by the studio, the shop, the park, the creek, the diner, the plaza.
	var cat_spots := [Vector3(44, 0, 88), Vector3(50, 0, 91), Vector3(-8.5, 0, 87.5), Vector3(-44, 0, 47), Vector3(8, 0, 160),
			Vector3(-6, 0, -20.5), Vector3(-80, 0, 46), Vector3(-7, 0, 53)]
	var i := 0
	for cat in city.get_node("Cats").get_children():
		if cat is Node3D:
			cat.transform = Kit.yawed(rng.randf() * TAU, cat_spots[i % cat_spots.size()])
			i += 1
	# Traffic.
	var traffic: Node3D = city.get_node("Traffic")
	var routes: Array[PackedVector3Array] = []
	var stops: Array[PackedByteArray] = []
	for loop in people.traffic_routes():
		routes.append(loop.points)
		stops.append(loop.stops)
	traffic.set("routes", routes)
	traffic.set("route_stops", stops)
	traffic.set("route_cars", PackedInt32Array([3, 3, 2, 2]))


func _road_network() -> void:
	var net := Node3D.new()
	net.name = "RoadNetwork"
	net.set_script(ROAD_NETWORK)
	var points := PackedVector3Array()
	var starts := PackedInt32Array()
	var widths := PackedFloat32Array()
	var kinds := PackedByteArray()
	var names := PackedStringArray()
	var areas := PackedStringArray()
	var index_of := {}  # [road, i] -> global index
	for r in layout.roads.size():
		var road: Dictionary = layout.roads[r]
		starts.append(points.size())
		for i in road.points.size():
			index_of[Vector2i(r, i)] = points.size()
			points.append(Kit.v3(road.points[i]))
		widths.append(road.width)
		kinds.append(road.kind)
		names.append(road.name)
		areas.append(road.area)
	starts.append(points.size())
	var joins := PackedInt32Array()
	for name in layout.junctions:
		var entries: Array = layout.junctions[name]
		for a in entries.size():
			for b in range(a + 1, entries.size()):
				joins.append(index_of[Vector2i(entries[a][0], entries[a][1])])
				joins.append(index_of[Vector2i(entries[b][0], entries[b][1])])
	net.set("points", points)
	net.set("road_start", starts)
	net.set("road_width", widths)
	net.set("road_kind", kinds)
	net.set("road_name", names)
	net.set("road_area", areas)
	net.set("joins", joins)
	net.set("map_rect", Plan.BOUNDS)
	net.set("railway", _v3_line(layout.rail))
	city.add_child(net)
	net.owner = city


func _v3_line(line: PackedVector2Array) -> PackedVector3Array:
	var out := PackedVector3Array()
	for p in line:
		out.append(Kit.v3(p))
	return out


func _minimap_image() -> void:
	var greens := []
	var paved := []
	var water := []
	for spec in Plan.RESERVED:
		match spec.what:
			"park", "home", "park_central", "park_path":
				greens.append(Layout.rect_polygon(spec))
			_:
				paved.append(Layout.rect_polygon(spec))
	water.append(PackedVector2Array([Vector2(-140, -60), Vector2(-127, -60), Vector2(-127, 40), Vector2(-140, 40)]))
	for poly in park.water_polygons():
		water.append(poly)
	var img := PlanImage.new(layout).draw(0.5, water, greens, paved, park.trails)
	DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path("res://ui/minimap"))
	img.save_png(ProjectSettings.globalize_path(MAP_IMAGE))
	print("  minimap picture %dx%d" % [img.get_width(), img.get_height()])
