extends Node3D
## Lays the imported asset packs out on a floor and saves pictures (needs a display).
##   xvfb-run godot --path . res://tools/asset_preview.tscn -- out_dir [night]
func _ready() -> void:
	var args := OS.get_cmdline_user_args()
	var out := args[0]
	var night := args.size() > 1 and args[1] == "night"
	var env := WorldEnvironment.new()
	env.environment = load("res://art/toy_environment.tres") if night else Environment.new()
	if not night:
		env.environment.background_mode = Environment.BG_COLOR
		env.environment.background_color = Color(0.6, 0.65, 0.75)
		env.environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
		env.environment.ambient_light_color = Color(0.6, 0.6, 0.65)
	add_child(env)
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-50, 30, 0)
	sun.light_energy = 0.3 if night else 1.2
	sun.shadow_enabled = true
	add_child(sun)
	var floor := MeshInstance3D.new()
	var pm := PlaneMesh.new()
	pm.size = Vector2(200, 200)
	floor.mesh = pm
	add_child(floor)
	var x := 0.0
	var row := 0
	var files := []
	for dir in ["res://art/kenney/", "res://art/nature/"]:
		for f in DirAccess.get_files_at(dir):
			if f.ends_with(".glb") or f.ends_with(".gltf"):
				files.append(dir + f)
	var i := 0
	for path in files:
		var n: Node3D = load(path).instantiate()
		var kenney: bool = path.contains("kenney")
		if kenney:
			n.scale = Vector3.ONE * 6.0
		add_child(n)
		n.position = Vector3((i % 10) * 8.0, 0, (i / 10) * 9.0)
		if night:
			var l := OmniLight3D.new()
			l.position = n.position + Vector3(2, 3, 3)
			l.omni_range = 9
			l.light_color = Color("ffcf8a")
			add_child(l)
		var lab := Label3D.new()
		lab.text = path.get_file().get_basename()
		lab.position = n.position + Vector3(0, 0.2, 3.5)
		lab.rotation_degrees.x = -60
		lab.pixel_size = 0.01
		add_child(lab)
		i += 1
	var cam := Camera3D.new()
	add_child(cam)
	cam.current = true
	get_window().size = Vector2i(1600, 900)
	var views := [["all", Vector3(36, 45, 70), Vector3(36, 0, 18)], ["kenney", Vector3(28, 12, -14), Vector3(28, 3, 4)], ["trees", Vector3(30, 8, 34), Vector3(30, 3, 20)]]
	for v in views:
		cam.global_transform = Transform3D().looking_at(v[2] - v[1], Vector3.UP).translated(v[1])
		for k in 8:
			await get_tree().process_frame
		get_viewport().get_texture().get_image().save_png(out + "/" + v[0] + ("_night" if night else "") + ".png")
	get_tree().quit()
