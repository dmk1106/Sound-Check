extends "res://tests/test_driver.gd"
## Automated playtest: a scripted player plays the whole loop with fake input
## and every step is checked - load up at the old house, lose the guitar out of
## the open back and fetch it, drive to the studio, pick a gig from the board
## without unloading, squeeze the truck down the back alley, set up, pick a
## difficulty, play the show, get paid, drive home, do up the studio, change
## the music volume, unlock a part of town, go shopping.
##
##   godot --headless --fixed-fps 60 --path . res://tests/playtest.tscn
##
## Exit code 0 = everything passed. To also save a screenshot at each step, drop
## --headless and add "--disable-render-loop -- shots=<folder>".

## Spots are given in each place's own frame (see at()), so the drives and
## walks follow the place wherever the city plan puts it. Drives go along the
## streets (RoadNetwork.route), the way the minimap shows.

var guitar: Equipment
var amp: Equipment
var flow: GameFlow
var alley: Venue
var bandshell: Venue
var diner: Venue
var tower: Venue
var studio: Node3D
var store: Node3D
var ambience: Ambience
## Times the driver was fined for knocking someone over.
var fines := 0
## Everyone who has been knocked over, and whether each was a real tumbling body while down.
var ever_down := {}
var rag_dolls_seen := true

var _truck_peak := 0.0
var _accuracy := 0.0
var _cars: Array[Node3D] = []
var _car_metres: Array[float] = []
var _car_last: Array[Vector3] = []
var _walkers: Array[Npc] = []
var _walker_start: Array[Vector3] = []
var _walker_far: Array[float] = []


## Finds everything the tests talk about. Call first in run().
func setup() -> void:
	guitar = find_item(&"guitar")
	amp = find_item(&"amp")
	flow = get_tree().get_first_node_in_group(&"game_flow")
	ambience = get_tree().get_first_node_in_group(&"ambience")
	studio = get_tree().current_scene.find_child("Studio", true, false)
	store = get_tree().current_scene.find_child("MusicStore", true, false)
	for node in get_tree().get_nodes_in_group(&"venue"):
		match (node as Venue).venue_id:
			&"alley":
				alley = node
			&"bandshell":
				bandshell = node
			&"diner":
				diner = node
			&"tower":
				tower = node
	Career.fined.connect(func(_amount: int) -> void:
		fines += 1
		print("  (fined: truck at %s doing %.1f m/s)" % [truck.global_position.snappedf(0.1), truck.speed]))
	for node in get_tree().get_nodes_in_group(&"cat"):
		_cats.append(node)
		_cat_states.append({})
	for node in get_tree().get_nodes_in_group(&"traffic_car"):
		if (node as TrafficCar).route.size() < 2:
			continue  # parked at the kerb
		_cars.append(node)
		_car_metres.append(0.0)
		_car_last.append((node as Node3D).global_position)
	for node in find_children("*", "AnimatableBody3D", true, false):
		if node is Npc and (node as Npc).mode == Npc.Mode.WALK:
			_walkers.append(node)
			_walker_start.append((node as Npc).global_position)
			_walker_far.append(0.0)


func run() -> void:
	setup()
	await wait(1.5)
	await shot("start")
	section("Start")
	check("guitar rests in the room", guitar.global_position.y > 0.02 and guitar.global_position.y < 0.6)
	check("amp rests on the floor", absf(amp.global_position.y - 0.25) < 0.03)
	check("player stands at ride height", absf(player.global_position.y - 0.9) < 0.05)
	check("truck is empty, parked, back open", truck.get_loaded().is_empty() and truck.freeze and truck.door_open)
	check("first objective is to load up", flow.step == GameFlow.Step.LOAD_HOME)
	check("there are four venues: the back alley, the diner, the bandshell and the tower", alley != null and bandshell != null and diner != null and tower != null)

	section("Walking")
	var from := player.global_position
	player_peak = 0.0
	await walk_to(Vector3(-1.5, 0, -5.2))
	var free_speed := player_peak
	print("  top speed empty-handed: %.2f m/s" % free_speed)
	check("walks at a sensible speed", free_speed > 3.2 and free_speed < 5.5)
	check("actually moved", from.distance_to(player.global_position) > 1.5)
	tap(&"jump")
	var peak := 0.0
	for i in 70:
		await get_tree().physics_frame
		peak = maxf(peak, player.global_position.y - 0.9)
	print("  jump height: %.2f m" % peak)
	check("can jump", peak > 0.5 and peak < 1.5)

	section("Arms follow the character, not the camera")
	await approach(guitar)
	check("guitar is highlighted as grabbable", hands.focus == guitar)
	var floor_y := guitar.global_position.y
	press_grab(true)
	await wait(1.2)
	check("guitar is held", hands.held == guitar)
	check("guitar left the floor", guitar.global_position.y > floor_y + 0.25)
	check("guitar is held in front of the character", _in_front_of_player(hands.get_grip_position()) > 0.3)
	var facing := player.facing_yaw
	player.camera_rig.yaw += 2.0
	await wait(1.0)
	check("turning the camera doesn't turn the character", absf(angle_difference(facing, player.facing_yaw)) < 0.05)
	check("...or swing what it holds", _in_front_of_player(hands.get_grip_position()) > 0.3)
	await shot("guitar_held")

	section("Load the truck")
	# Put the guitar down for a moment: the amp goes in first, deep and to one side.
	await walk_path([Vector3(0.2, 0, -5.4)])
	press_grab(false)
	await wait(1.5)
	var haul_start := Engine.get_physics_frames()
	await haul(amp, [Vector3(1.0, 0, -5.0), Vector3(1.0, 0, -2.6), Vector3(1.0, 0, -0.9), Vector3(0.5, 0, 4.6)])
	var haul_seconds := (Engine.get_physics_frames() - haul_start) / 60.0
	check("truck has the amp", truck.is_loaded(amp))
	check("player walked up the ramp", absf(player.global_position.y - 1.6) < 0.1)
	check("amp is too heavy to carry: it was dragged", amp.global_position.y < 1.4)
	print("  top speed hauling amp: %.2f m/s (%.1f s from the room into the truck)" % [player_peak, haul_seconds])
	check("hauling the amp is still clearly slower than walking", player_peak < free_speed * 0.85)
	check("...but no longer a crawl", player_peak > free_speed * 0.6)
	await walk_path([Vector3(1.5, 0, 4.2), Vector3(1.5, 0, -2.0), Vector3(1.0, 0, -5.0)])
	player_peak = 0.0
	# The guitar goes in last, on the other side: nothing between it and the open back.
	await carry(guitar, Vector3.INF, [Vector3(1.0, 0, -5.0), Vector3(1.0, 0, -2.6), Vector3(1.5, 0, -0.9), Vector3(1.5, 0, 3.7)])
	print("  top speed carrying guitar: %.2f m/s" % player_peak)
	check("truck has the guitar too", truck.is_loaded(guitar))
	await shot("loaded")
	await wait(0.5)
	check("objective moved on to driving", flow.step == GameFlow.Step.DRIVE_TO_STUDIO)

	section("Drive off with the back open: the guitar falls out")
	await walk_path([Vector3(1.5, 0, -2.0), Vector3(3.3, 0, -0.6), Vector3(3.3, 0, 6.2)])
	check("driver's door prompt is offered", _focus_prompt() == "drive")
	await press_interact()
	await wait(0.3)
	check("player is driving", truck.driver == player and not truck.freeze)
	await drive_path([Vector3(1, 0, 12.0)], 20.0)
	await wait(1.5)
	check("guitar slid out of the open back", not truck.is_loaded(guitar))
	check("it is lying on the ground behind the truck, a real object",
			guitar.global_position.y < 0.5 and flat_distance(guitar.global_position, truck.global_position) > 4.0 and not guitar.freeze)
	print("  guitar ended up at %s, amp at %s, truck at %s" % [guitar.global_position.snappedf(0.1), amp.global_position.snappedf(0.1), truck.global_position.snappedf(0.1)])
	await shot("fell_out")
	await press_interact()
	await wait(0.5)
	check("stopped and got out", truck.driver == null and truck.freeze)
	await walk_path([T(-2.0, 1.5), T(-2.0, 6.5)])
	await carry(guitar, Vector3.INF, [T(-2.0, 6.5), _behind_truck(3.6), _behind_truck(-2.7)])
	await wait(0.5)
	check("picked it up off the road and put it back by hand", truck.is_loaded(guitar))
	if not truck.is_loaded(amp):
		# The amp went the same way: drag it back up the ramp.
		await walk_path([_behind_truck(3.6), T(-2.0, 6.5)])
		await haul(amp, [T(-2.0, 6.7), _behind_truck(3.8), _behind_truck(-1.7, -0.4)])
		await wait(0.5)
	await close_back()
	aim_at(_behind_truck(-1.0))
	Input.action_press(&"move_forward")
	await wait(2.0)
	Input.action_release(&"move_forward")
	check("closed door keeps the player out", player.global_position.y < 1.2)
	check("gear is still physically inside", truck.is_loaded(guitar) and truck.is_loaded(amp))

	section("Drive to the studio through the city")
	await get_in(-2.0)
	await shot("driving")
	# Back up the drive, then pull out properly this time.
	await reverse_straight(PI, Vector3(1, 0, 6), func() -> bool: return truck.global_position.z < 5.0)
	_truck_peak = 0.0
	await drive_path([Vector3(1, 0, 10.0), Vector3(-7, 0, 14.2)], 30.0)
	await drive_to(studio_parking())
	print("  fastest the truck went: %.1f m/s" % _truck_peak)
	check("truck got up to speed", _truck_peak > 9.0)
	check("with the back shut, the gear rode along inside (guitar %s, amp %s in its frame)" % [truck.to_local(guitar.global_position).snappedf(0.01), truck.to_local(amp.global_position).snappedf(0.01)],
			truck.is_loaded(guitar) and truck.is_loaded(amp))
	await shot("arrived_studio")
	await press_interact()
	await wait(0.5)
	check("player is back on foot", truck.driver == null and player.visible and player.controls_enabled)
	check("truck is parked at the studio", truck.freeze and flat_distance(truck.global_position, studio_parking()) < 3.0)
	await wait(0.5)
	check("objective: pick a gig (no unloading asked for)", flow.step == GameFlow.Step.GET_GIG and not flow.objective.to_lower().contains("unload"))

	section("Pick a gig from the board, gear stays in the truck")
	await walk_path([T(-2.8, -1.6), T(-2.8, -4.4), studio_door(), at(studio, 0, 1.6), at(studio, -1.6, -1.5)])
	check("job board is offered", _focus_prompt().contains("gig"))
	await press_interact()
	await wait(0.3)
	check("the board opens a list of gigs", GameMenu.is_any_open())
	await shot("gig_menu")
	await menu_pick(0)
	check("back alley gig is booked", Career.has_job() and Career.job.id == &"alley")
	check("the gig says what to bring", Career.describe_kinds(Career.job.needs) == "guitar")
	await wait(0.6)
	check("objective: straight on to the venue, nothing to reload", flow.step == GameFlow.Step.DRIVE_TO_VENUE)
	check("gear never left the truck", truck.is_loaded(guitar) and truck.is_loaded(amp))
	check("two gigs need no fans; bigger ones are locked until you have some", Career.is_offered(gig(&"diner")) and not Career.is_offered(gig(&"rock")) and not Career.is_offered(gig(&"balcony")))

	section("Drive to Cat Alley")
	await walk_path([at(studio, 0, 1.6), studio_door(), T(-2.8, -4.4)])
	await get_in()
	await drive_into_cat_alley()
	await press_interact()
	await wait(0.8)
	check("got out by the yard", truck.driver == null and flat_distance(player.global_position, truck.global_position) < 4.0)
	check("objective: set up", flow.step == GameFlow.Step.SET_UP)

	section("Set up in the yard")
	var listeners := _people(alley)
	var sitting := 0
	for person in listeners:
		if person.mode == Npc.Mode.SIT and person.visible:
			sitting += 1
	print("  %d people in the yard, %d of them sitting" % [listeners.size(), sitting])
	check("people are sitting around waiting for the music", sitting >= 6)
	check("show can't start without the guitar", not alley.is_set_up() and alley.missing_kinds() == [&"guitar"])
	# Out of the driver's door on the alley side: round the back to open it.
	await walk_path([T(-2.4, 0.5), T(-2.4, 4.6)])
	await open_back()
	await unload([_behind_truck(3.6)] + yard_aisle() + [at(alley, -0.6, -1.0)],
			[_behind_truck(3.8)] + yard_aisle() + [at(alley, -1.2, -0.3)],
			[yard_aisle()[1], yard_aisle()[0], _behind_truck(3.6)])
	await wait(1.0)
	check("guitar is at the mic", alley.stage.has(guitar))
	check("amp came too (optional extra)", alley.stage.has(amp))
	check("objective: play", flow.step == GameFlow.Step.PLAY)
	await shot("set_up")

	section("Pick a difficulty and play")
	await walk_path([at(alley, -0.9, -0.7)])
	check("mic offers to start the show", _focus_prompt() == "start the show")
	await press_interact()
	await wait(0.3)
	check("asked for a difficulty first", GameMenu.is_any_open() and not alley.playing)
	await shot("difficulty_menu")
	await menu_pick(1)
	check("show is on", alley.playing and alley.game != null and not player.controls_enabled)
	check("five lanes on D F J K L", RhythmGame.LANES == 5 and RhythmGame.LANE_KEYS == ["D", "F", "J", "K", "L"])
	var medium := Songs.chart(&"alley_cat_shuffle", "medium")
	check("playing this song's medium chart", alley.game.notes.size() == medium.size())
	check("easy / medium / hard are different charts",
			Songs.chart(&"alley_cat_shuffle", "easy").size() < medium.size() and medium.size() < Songs.chart(&"alley_cat_shuffle", "hard").size())
	check("another song has its own chart", Songs.chart(&"neon_rush", "medium") != medium and Songs.bpm(&"neon_rush") != Songs.bpm(&"alley_cat_shuffle"))
	await play_song(alley)
	await shot("results")
	check("got paid", Career.money > 20)
	check("gained fans", Career.fans > 0)
	check("gig is done", not Career.has_job())
	print("  accuracy %d%%, money $%d, fans %d" % [roundi(_accuracy * 100.0), Career.money, Career.fans])
	check("the bot played most of it right", _accuracy > 0.6)
	check("the crowd got into it", _crowd_peak > 0.62)
	await press_interact()
	await wait(0.5)
	check("controls are back", not alley.playing and player.controls_enabled)
	check("objective: pack up", flow.step == GameFlow.Step.PACK_UP)

	section("Pack up, out the far end of the alley, drive home")
	var into_truck := [yard_aisle()[1], yard_aisle()[0], _behind_truck(3.6)]
	await carry(guitar, Vector3.INF, into_truck + [_behind_truck(-2.7)])
	await walk_path([_behind_truck(3.6), yard_aisle()[0], yard_aisle()[1]])
	await haul(amp, into_truck + [_behind_truck(-1.7, -0.4)])
	await wait(0.5)
	check("truck has the gear", truck.is_loaded(guitar) and truck.is_loaded(amp))
	await close_back()
	await get_in()
	await leave_cat_alley()
	await drive_to(studio_parking(), 180.0)
	await press_interact()
	await wait(0.8)
	check("back home (step %d)" % flow.step, flow.step == GameFlow.Step.FREE)
	check("gear is still in the truck (guitar %s, amp %s in its frame)" % [truck.to_local(guitar.global_position).snappedf(0.01), truck.to_local(amp.global_position).snappedf(0.01)],
			truck.is_loaded(guitar) and truck.is_loaded(amp))
	await shot("home")

	section("Do up the studio, from the studio")
	var extras := get_tree().current_scene.find_child("Extras", true, false) as Node3D
	var posters := extras.get_node("Posters") as Node3D
	check("the studio starts bare", not posters.visible and get_tree().get_nodes_in_group(&"decor").is_empty())
	await walk_path([T(-2.8, -1.6), T(-2.8, -4.4), studio_door(), at(studio, 0, 1.6), at(studio, 1.4, -1.6)])
	check("catalogue is offered inside the studio", _focus_prompt().contains("decorate"))
	var money := Career.money
	await press_interact()
	await wait(0.3)
	await shot("catalogue")
	await menu_pick(0)
	var lamps := get_tree().get_nodes_in_group(&"decor")
	check("bought a floor lamp: money went down", Career.money == money - 25)
	check("the lamp is a real object standing in the studio",
			lamps.size() == 1 and lamps[0] is Grabbable and flat_distance((lamps[0] as Node3D).global_position, at(studio, 0, 0)) < 4.0)
	await press_interact()
	await wait(0.3)
	await menu_pick(2)   # Floor lamp is owned now, so two steps down is the poster set.
	check("posters went up on the wall", posters.visible and Career.money == money - 45)
	await wait(1.0)
	if lamps.size() == 1:
		var floor_lamp := lamps[0] as Grabbable
		await approach(floor_lamp)
		press_grab(true)
		await wait(1.0)
		check("the lamp can be picked up and put where you like", hands.held == floor_lamp)
		await walk_path([at(studio, -2.4, 1.4)])
		press_grab(false)
		await wait(1.5)
	await shot("studio_decorated")

	section("Settings: music volume")
	var bus := AudioServer.get_bus_index(Settings.MUSIC_BUS)
	var before := Settings.music_volume
	await press_action(&"ui_cancel")
	check("Esc pauses and opens the settings", get_tree().paused and GameMenu.is_any_open())
	await press_action(&"ui_left")
	await press_action(&"ui_left")
	check("slider moved", is_equal_approx(Settings.music_volume, before - 0.2))
	check("...and the music bus followed at once", absf(AudioServer.get_bus_volume_db(bus) - linear_to_db(before - 0.2)) < 0.01)
	for i in 10:
		await press_action(&"ui_left")
	check("0% is silence", Settings.music_volume == 0.0 and AudioServer.is_bus_mute(bus))
	for i in 10:
		await press_action(&"ui_right")
	check("100% is full volume", Settings.music_volume == 1.0 and not AudioServer.is_bus_mute(bus) and absf(AudioServer.get_bus_volume_db(bus)) < 0.01)
	for i in roundi((1.0 - before) * 10.0):
		await press_action(&"ui_left")
	await shot("settings")
	await press_action(&"ui_cancel")
	await wait(0.2)
	check("closing it resumes the game", not get_tree().paused and not GameMenu.is_any_open())

	section("Fans open up the town and bigger gigs")
	var gate := get_tree().current_scene.find_child("ParkSideGate", true, false) as FanGate
	var uptown := get_tree().current_scene.find_child("UptownGate", true, false) as FanGate
	check("Park Side is shut at %d fans" % Career.fans, not gate.is_open and gate.visible)
	check("the crowd only turns up at the bandshell for a gig", not _people(bandshell)[0].visible)
	Career.add_fans(40 - Career.fans)
	await wait(0.3)
	check("at 40 fans the Park Side roadblock is gone", gate.is_open and not gate.visible and (gate.get_node("Shape") as CollisionShape3D).disabled)
	check("Uptown is still shut", not uptown.is_open and uptown.visible)
	check("rock night is now on offer", Career.is_offered(gig(&"rock")) and not Career.is_offered(gig(&"drums")))
	Career.accept(gig(&"rock"))
	await wait(0.6)
	check("rock night wants a guitar and an amp at the bandshell", bandshell.has_gig() and not alley.has_gig()
			and bandshell.missing_kinds() == [&"guitar", &"amp"])
	check("both are in the truck already: objective is to drive there", flow.step == GameFlow.Step.DRIVE_TO_VENUE)
	check("the bandshell crowd has turned up", _people(bandshell)[0].visible)
	Career.accept(gig(&"keys"))
	await wait(0.6)
	check("the keyboard gig needs a keyboard you don't have yet", flow.step == GameFlow.Step.LOAD_GIG and flow.objective.contains("keyboard"))

	section("Go shopping")
	var stock := {}
	var mic: Equipment = null
	for node in get_tree().get_nodes_in_group(&"equipment"):
		var item := node as Equipment
		if item.for_sale:
			stock[item.kind] = true
			check("%s is a physical object bolted to its stand" % item.display_name, item.freeze and not item.can_grab and item.price > 0)
			if item.kind == &"mic":
				mic = item
	check("the shop has basses, mics, keyboards, drums, guitars and amps", stock.size() == 6)
	await walk_path([at(studio, 0, 1.6), studio_door(), T(-2.8, -4.4)])
	await get_in()
	await pull_out(at(store, 0, 10.9))
	await drive_to(at(store, 0, 10.9), 120.0)
	await press_interact()
	await wait(0.5)
	check("parked at Wobble Music", truck.driver == null and flat_distance(truck.global_position, at(store, 0, 10.9)) < 3.0)
	await walk_path([T(-2.8, -1.6), T(-2.8, -4.0), at(store, 0, 6.8)])
	check("price tag offers the microphone", _focus_prompt().contains("Microphone"))
	Career.money = 10
	await press_interact()
	await wait(0.4)
	check("can't buy what you can't afford", mic.for_sale and Career.money == 10)
	Career.money = 100
	await press_interact()
	await wait(0.5)
	check("bought it: money went down by the price", Career.money == 100 - mic.price)
	check("it is ordinary gear now", mic.can_grab and not mic.freeze and mic.is_owned())
	await approach(mic)
	press_grab(true)
	await wait(1.0)
	check("and can be picked up", hands.held == mic)
	press_grab(false)
	await wait(1.5)
	await shot("shopping")

	section("Life in the city")
	var moving := 0
	for i in _cars.size():
		if _car_metres[i] > 150.0:
			moving += 1
	print("  %d cars, each drove %s m" % [_cars.size(), _car_metres.map(func(m: float) -> int: return roundi(m))])
	check("there is traffic on the roads", _cars.size() >= 6)
	check("every car kept driving round its loop", moving == _cars.size())
	check("cars have headlights", _cars[0].find_children("*", "SpotLight3D").size() > 0)
	var wandered := 0
	for far in _walker_far:
		if far > 8.0:
			wandered += 1
	print("  %d people walking, %d of them got somewhere" % [_walkers.size(), wandered])
	check("people are out walking the streets", _walkers.size() >= 12 and wandered >= _walkers.size() - 2)
	check("they kept to the pavements and crossings (furthest anyone strayed: %.1f m)" % _walker_stray, _walker_stray < 2.0)
	check("a careful driver went all that way without knocking anyone over (%d fines)" % fines, fines == 0)
	_check_cats()


func _check_cats() -> void:
	var walked := 0
	var sat := 0
	var watched := 0
	for i in _cats.size():
		if _cats[i].travelled > 1.0:
			walked += 1
		if _cat_states[i].has(Cat.State.SIT):
			sat += 1
		if _cat_states[i].has(Cat.State.WATCH):
			watched += 1
	print("  %d cats: %d wandered, %d sat down, %d stopped to watch the player" % [_cats.size(), walked, sat, watched])
	check("cats live in the city, and are not just small people", _cats.size() >= 6 and not ((_cats[0] as Node) is AnimatableBody3D))
	check("they wander about and sit down", walked >= _cats.size() - 2 and sat >= _cats.size() - 2)
	check("a cat noticed the player", watched >= 1)


var _crowd_peak := 0.0
var _cats: Array[Cat] = []
var _cat_states: Array[Dictionary] = []
var _walker_stray := 0.0
var _sidewalks: Sidewalks


func _physics_process(delta: float) -> void:
	super(delta)
	if truck:
		_truck_peak = maxf(_truck_peak, absf(truck.speed))
	for i in _cars.size():
		var at := _cars[i].global_position
		_car_metres[i] += at.distance_to(_car_last[i])
		_car_last[i] = at
	for i in _walkers.size():
		_walker_far[i] = maxf(_walker_far[i], flat_distance(_walkers[i].global_position, _walker_start[i]))
	for i in _cats.size():
		_cat_states[i][_cats[i].state] = true
	var tumbling := 0
	for node in get_tree().get_nodes_in_group(&"npc"):
		if (node as Npc).state == Npc.State.DOWN:
			ever_down[node] = true
			tumbling += 1
	if tumbling > 0:
		var bodies := 0
		for node in get_tree().current_scene.find_child("People", true, false).get_children():
			if node is RigidBody3D and not (node as RigidBody3D).freeze:
				bodies += 1
		rag_dolls_seen = rag_dolls_seen and bodies >= 1
	# Every so often, see how far the walkers are from the pavement network.
	if Engine.get_physics_frames() % 30 == 0 and not _walkers.is_empty():
		if _sidewalks == null:
			_sidewalks = get_tree().get_first_node_in_group(&"sidewalks")
		for person in _walkers:
			if person.visible and not person.is_down() and person.state != Npc.State.RETURN:
				_walker_stray = maxf(_walker_stray, _sidewalks.distance_to_network(person.global_position))
	for venue: Venue in [alley, diner, bandshell, tower]:
		if venue and venue.playing:
			for person in _people(venue):
				_crowd_peak = maxf(_crowd_peak, person.excitement)


# --- places -----------------------------------------------------------------

func studio_door() -> Vector3:
	return at(studio, 0, 4.4)


## Where the truck stands on the studio's pad, nose to the door.
func studio_parking() -> Vector3:
	return at(studio, 0, 8.2)


## From the truck's tail in Cat Alley into the yard, past the crates.
func yard_aisle() -> Array:
	return [at(alley, -6.1, -6.7), at(alley, -6.1, -2.1)]


## Drives round to Canal Street, then the careful bit: one slow arc into Cat
## Alley (barely wider than the truck) and along it to the yard.
func drive_into_cat_alley() -> void:
	var net: RoadNetwork = get_tree().get_first_node_in_group(&"road_network")
	var cat_alley := -1
	for road in net.road_count():
		if net.road_name[road] == "Cat Alley":
			cat_alley = road
	var line := net.road_points(cat_alley)
	var mouth := line[0]
	var heading := (line[3] - line[0]).normalized()
	var alley_yaw := atan2(-heading.x, -heading.z)
	# Come up Canal Street from the south, keeping left of the lane line for a wider swing.
	var approach := mouth + Vector3(-1.2, 0, 9.0)
	await pull_out(approach)
	await drive_to(approach + Vector3(0, 0, 4.0))
	await shot("canal_street")
	await drive_line(0.0, approach, func() -> bool: return truck.global_position.z < mouth.z + 6.6, 2.0)
	await turn_onto_line(alley_yaw, mouth + heading * 6.0)
	print("  lined up at the alley mouth: %.2f m off the centre line" % absf((truck.global_position - mouth).cross(heading).y))
	var spot := at(alley, 0.5, -8.7)
	await drive_path([spot], 30.0, 3.0)
	check("threaded the truck into Cat Alley, alongside the yard", flat_distance(truck.global_position, spot) < 2.5)
	await shot("in_alley")


## Cat Alley is too narrow to turn round in: carry on out of the far end.
func leave_cat_alley() -> void:
	var net: RoadNetwork = get_tree().get_first_node_in_group(&"road_network")
	for road in net.road_count():
		if net.road_name[road] == "Cat Alley":
			var line := net.road_points(road)
			var far: Vector3 = line[line.size() - 1]
			var before: Vector3 = line[line.size() - 3]
			await drive_path([before, far + (far - before).normalized() * 3.0], 40.0, 4.0)
	check("drove out of the far end of the alley without getting wedged", flat_distance(truck.global_position, at(alley, 0.5, -8.7)) > 15.0)


# --- bot skills -------------------------------------------------------------

func _people(venue: Venue) -> Array[Npc]:
	var people: Array[Npc] = []
	for node in venue.get_node("Crowd").get_children():
		if node is Npc:
			people.append(node)
	return people


## A ground point behind the parked truck (positive = further out the back),
## optionally shifted sideways.
func _behind_truck(metres: float, sideways := 0.0) -> Vector3:
	var point := truck.to_global(Vector3(sideways, 0.0, 3.0 + metres))
	point.y = 0.0
	return point


## A ground point given in the truck's own frame (-x = the driver's side;
## z = back from the middle).
func T(x: float, z: float) -> Vector3:
	var point := truck.to_global(Vector3(x, 0.0, z))
	point.y = 0.0
	return point


func _focus_prompt() -> String:
	var interactor: Interactor = player.get_node("Interactor")
	return interactor.focus.prompt if interactor.focus else ""


# How far in front of the character (along its facing) a point is.
func _in_front_of_player(point: Vector3) -> float:
	return (point - player.global_position).dot(player.get_facing_forward())


func open_back() -> void:
	await walk_path([_behind_truck(1.0, 2.4), _behind_truck(1.6)])
	await press_interact()
	await wait(1.2)
	check("back is open, ramp is down", truck.door_open)


func close_back() -> void:
	await walk_path([_behind_truck(1.5, 0.9), _behind_truck(2.7, 0.3)])
	await press_interact()
	await wait(1.2)
	check("back is closed", not truck.door_open)


## Walks round to a cab door (negative side = the driver's) and gets in.
func get_in(side := -2.4) -> void:
	await walk_path([_behind_truck(2.4, side * 1.1), truck.to_global(Vector3(side, 0, -1.6)) * Vector3(1, 0, 1)])
	await press_interact()
	await wait(0.3)
	check("driving", truck.driver == player)


## Empties the truck, whatever is nearest the door first (after a drive the
## gear is in a heap). Light things take one path, heavy things the other.
func unload(light_path: Array, heavy_path: Array, back_path: Array) -> void:
	var items: Array[Equipment] = [guitar, amp]
	items.sort_custom(func(a: Equipment, b: Equipment) -> bool:
		return truck.to_local(a.global_position).z > truck.to_local(b.global_position).z)
	for i in items.size():
		if items[i].mass >= hands.two_hand_mass:
			await haul(items[i], heavy_path, _behind_truck(1.6))
		else:
			await carry(items[i], _behind_truck(1.6), light_path)
		if i == 0:
			await walk_path(back_path)


## Picks up a light item (walking to `via` first if given) and carries it along
## a path. If it snags on something and is pulled out of the hands, goes back
## for it, like anyone would.
func carry(item: Grabbable, via: Vector3, path: Array) -> void:
	if via.is_finite():
		await walk_to(via, 0.4, 20.0)
	var index := 0
	for attempt in 4:
		await approach(item)
		press_grab(true)
		await wait(1.0)
		if attempt == 0:
			check("picked up %s" % item.display_name, hands.held == item)
			if hands.held != item:
				print("    player at %s facing %.2f, %s at %s; hands would take %s" % [player.global_position.snappedf(0.01), player.facing_yaw, item.display_name,
						item.global_position.snappedf(0.01), String(hands.focus.name) if hands.focus else "nothing"])

		# In the back of the truck there is no room to swing a guitar round
		# next to a wall: step across to the other side of the bay first.
		var spot := truck.to_local(player.global_position)
		if hands.held == item and absf(spot.x) < 1.0 and spot.z > -0.6 and spot.z < 3.0:
			await walk_to(T(-0.45 * signf(spot.x), clampf(spot.z, 0.4, 2.3)), 0.25, 4.0)
		while index < path.size() and hands.held == item:
			await walk_to(path[index], 0.4, 20.0)
			if hands.held == item:
				index += 1
		if index >= path.size():
			break
		print("  %s snagged and was pulled out of the hands at %s: going back for it" % [item.display_name, item.global_position.snappedf(0.1)])
		press_grab(false)
		await wait(0.6)
	check("still holding %s" % item.display_name, hands.held == item)
	press_grab(false)
	await wait(2.0)


## Grabs a heavy item and drags it along a path.
func haul(item: Grabbable, path: Array, via := Vector3.INF) -> void:
	if via.is_finite():
		await walk_to(via, 0.4, 20.0)
	await approach(item)
	press_grab(true)
	await wait(0.8)
	check("took hold of %s" % item.display_name, hands.held == item)
	player_peak = 0.0
	for point: Vector3 in path:
		await walk_to(point, 0.4, 20.0)
		if hands.held != item:
			print("  lost grip heading for %s: player %s, %s at %s" % [point, player.global_position.snappedf(0.01), item.display_name, item.global_position.snappedf(0.01)])
			break
	check("still hauling %s" % item.display_name, hands.held == item)
	press_grab(false)
	await wait(2.5)


## Plays the rhythm game through real key presses, fluffing every sixth note.
func play_song(venue: Venue) -> void:
	var game := venue.game
	game.sync_to_audio = false
	var done := [false]
	game.finished.connect(func(accuracy: float) -> void:
		_accuracy = accuracy
		done[0] = true)
	var index := 0
	var lanes := {}
	for i in 120 * Engine.physics_ticks_per_second:
		if done[0]:
			break
		for note in game.notes:
			if note.state == 0 and not note.has("tried") and game.song_time >= (note.time as float):
				note["tried"] = true
				lanes[note.lane] = true
				index += 1
				if index == 22:
					await shot("mid_song")
				if index % 6 != 0:
					var event := InputEventAction.new()
					event.action = RhythmGame.LANE_ACTIONS[note.lane as int]
					event.pressed = true
					Input.parse_input_event(event)
					Input.flush_buffered_events()
					event = InputEventAction.new()
					event.action = RhythmGame.LANE_ACTIONS[note.lane as int]
					event.pressed = false
					Input.parse_input_event(event)
		await get_tree().process_frame
	check("song finished", done[0])
	check("the chart used all five lanes", lanes.size() == 5)
