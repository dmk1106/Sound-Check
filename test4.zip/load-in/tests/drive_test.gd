extends "res://tests/playtest.gd"
## Drives the truck to every place in town along the streets, the way the
## minimap routes it, and parks at each: the studio, Cat Alley, Wobble Music,
## the Moon Diner, Skyline Tower, the bandshell and Hachi Plaza. Checks the
## city plan still joins up after a rebuild (all gates open).
##
##   godot --headless --fixed-fps 60 --path . res://tests/drive_test.tscn


func run() -> void:
	setup()
	Career.add_fans(1000)
	await wait(1.0)
	player.global_position = T(-2.6, 0.5) + Vector3(0, 0.9, 0)
	await wait(0.5)
	await get_in(-2.0)
	await reverse_straight(PI, Vector3(1, 0, 6), func() -> bool: return truck.global_position.z < 5.0)
	await drive_path([Vector3(1, 0, 10.0), Vector3(-7, 0, 14.2)], 30.0)

	section("The studio")
	await _park("the studio's pad", studio_parking(), 3.0)

	section("Cat Alley")
	await drive_into_cat_alley()
	await leave_cat_alley()

	# Out of the alley facing east: carry straight on to the tower, then round town.
	section("the foot of Skyline Tower")
	await _park("the foot of Skyline Tower", at(tower, 9.5, -5.6), 3.0)
	var stops := [["Wobble Music", at(store, 0, 10.9), 3.0], ["the Moon Diner's forecourt", at(diner, 7.7, -1.0), 2.5],
			["the bandshell", bandshell.get_node("Parking").global_position, 4.0],
			["Hachi Plaza", _plaza().get_node("Parking").global_position, 4.0], ["the studio again", studio_parking(), 3.0]]
	for stop: Array in stops:
		section(stop[0])
		await pull_out(stop[1])
		await _park(stop[0], stop[1], stop[2])
	check("a careful driver went all that way without knocking anyone over (%d fines)" % fines, fines == 0)


func _park(what: String, spot: Vector3, within: float) -> void:
	var started := Engine.get_physics_frames()
	var net: RoadNetwork = get_tree().get_first_node_in_group(&"road_network")
	var metres := RoadNetwork.length_of(net.route(truck.global_position, spot))
	await drive_to(spot, 200.0)
	print("  %.0f m of road in %.0f s" % [metres, (Engine.get_physics_frames() - started) / 60.0])
	check("parked at %s" % what, flat_distance(truck.global_position, spot) < within)


func _plaza() -> Venue:
	for node in get_tree().get_nodes_in_group(&"venue"):
		if (node as Venue).venue_id == &"plaza":
			return node
	return null
