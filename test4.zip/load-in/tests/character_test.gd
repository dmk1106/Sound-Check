extends "res://tests/test_driver.gd"
## The player character model: stands on its feet, walks and runs with the
## clips, reaches the hands onto what it holds, throws its arms up in the air,
## blinks, and keeps its pose when stepping out of the truck.
##
##   godot --headless --fixed-fps 60 --path . res://tests/character_test.tscn
##
## Add "--disable-render-loop -- shots=<folder>" (without --headless) for screenshots.

var visual: Node3D
var skeleton: Skeleton3D


func run() -> void:
	visual = player.get_node(^"Visual")
	skeleton = visual.get_node(^"Model/target_character/Skeleton3D")
	await wait(1.0)

	section("Standing")
	await shot("standing")
	var ground := player.get_feet_position().y
	var toes := maxf(_bone_y("mixamorig_LeftToeBase"), _bone_y("mixamorig_RightToeBase")) - ground
	print("  toes %.3f m above the ground, head top %.2f m" % [toes, _bone_y("mixamorig_HeadTop_End") - ground])
	check("feet are on the ground", absf(toes) < 0.12)
	check("stands about 1.7 m tall", absf(_bone_y("mixamorig_HeadTop_End") - ground - 1.69) < 0.12)
	check("arms hang down (not the T-pose)", _hand("Left").y < _bone_pos("mixamorig_LeftArm").y - 0.25 and _hand("Right").y < _bone_pos("mixamorig_RightArm").y - 0.25)
	check("faces where the player faces", _in_front(skeleton.global_transform * skeleton.get_bone_global_pose(skeleton.find_bone("headfront")).origin) > 0.15)

	section("Walking and running")
	var start_phase: float = visual._phase
	player_peak = 0.0
	Input.action_press(&"move_forward")
	var moved := 0.0
	var ran := 0.0
	var lowest := INF
	var highest := -INF
	for i in 90:
		await get_tree().physics_frame
		await get_tree().process_frame
		moved = maxf(moved, visual._move)
		ran = maxf(ran, visual._run)
		var foot := _bone_y("mixamorig_LeftToeBase") - player.get_feet_position().y
		lowest = minf(lowest, foot)
		highest = maxf(highest, foot)
		if i == 45:
			await shot("running")
	Input.action_release(&"move_forward")
	print("  top speed %.1f m/s, run blend %.2f, cycles %.2f, left toe between %.2f and %.2f m" % [player_peak, ran, visual._phase - start_phase, lowest, highest])
	check("the walk / run clips take over when moving", moved > 0.9)
	check("full speed is a run", ran > 0.8)
	check("the legs cycle with distance", visual._phase - start_phase > 1.5)
	check("feet lift and come back down", highest - lowest > 0.15 and lowest > -0.1)
	await wait(1.0)
	check("back to standing when stopped", visual._move < 0.1)

	section("Jumping")
	tap(&"jump")
	var arms_up := false
	for i in 30:
		await get_tree().physics_frame
		await get_tree().process_frame
		if _hand("Left").y > _bone_pos("mixamorig_LeftArm").y and _hand("Right").y > _bone_pos("mixamorig_RightArm").y:
			arms_up = true
			if i < 20:
				await shot("jump")
	check("arms fly up in the air", arms_up)
	await wait(1.0)

	section("Holding")
	var guitar := find_item(&"guitar")
	await approach(guitar)
	press_grab(true)
	await wait(1.2)
	await shot("holding")
	check("guitar is held", hands.held == guitar)
	var grip: Vector3 = hands.get_grip_position()
	var left := _hand("Left").distance_to(grip)
	var right := _hand("Right").distance_to(grip)
	print("  hands %.2f and %.2f m from the grip" % [left, right])
	check("both hands are on the guitar", left < 0.2 and right < 0.2)
	press_grab(false)
	await wait(1.0)

	section("Blinking")
	var blinked := false
	for i in 6 * 60:
		await get_tree().physics_frame
		await get_tree().process_frame
		var lid: Node3D = visual._lids[0]
		if lid.visible and lid.scale.y > 0.8:
			blinked = true
			await shot("blink")
			break
	check("blinks every few seconds", blinked)
	check("eyes open again", await _eyes_open_soon())

	section("Truck")
	player.enter_vehicle(truck)
	await wait(0.5)
	check("hidden while driving", not player.visible)
	player.exit_vehicle(player.global_position + Vector3(0, 0, 0), 0.0)
	await wait(0.5)
	check("back after stepping out, feet down", player.visible and absf(_bone_y("mixamorig_LeftToeBase") - player.get_feet_position().y) < 0.15)


func _bone_pos(bone: String) -> Vector3:
	return skeleton.global_transform * skeleton.get_bone_global_pose(skeleton.find_bone(bone)).origin


func _bone_y(bone: String) -> float:
	return _bone_pos(bone).y


## Middle of a hand (halfway from the wrist to the fingertips).
func _hand(side: String) -> Vector3:
	var wrist := _bone_pos("mixamorig_%sHand" % side)
	var tip := _bone_pos("Bone_022" if side == "Left" else "Bone_023")
	return (wrist + tip) * 0.5


## How far in front of the character a point is (m).
func _in_front(point: Vector3) -> float:
	return (point - player.global_position).dot(player.get_facing_forward())


func _eyes_open_soon() -> bool:
	for i in 30:
		await get_tree().physics_frame
		await get_tree().process_frame
		if not (visual._lids[0] as Node3D).visible:
			return true
	return false
