extends "res://tests/playtest.gd"
## Second automated playthrough: the life of the city. Looks up at the
## skyline, presses the debug button, writes a song in the park pavilion, drags the
## volume sliders with the mouse, plays the truck radio, runs two people over
## (and pays for it), plays the diner, then takes the gear up the lift and
## plays the balcony of Skyline Tower.
##
##   godot --headless --path . res://tests/playtest_city.tscn



func run() -> void:
	setup()
	var radio_was := Settings.truck_radio
	var music_was := Settings.music_volume
	var sound_was := Settings.sound_volume
	Settings.truck_radio = true
	await wait(1.5)

	section("At home: quiet, indoors")
	var indoors := ambience.levels()
	check("the room counts as indoors", ambience.zone == "indoors")
	check("rain and traffic are a muffled patter, the room hums (cutoff %d Hz, rain %.0f dB, room %.0f dB)" % [indoors.cutoff, indoors.rain, indoors.room],
			indoors.cutoff < 2500.0 and indoors.rain < -14.0 and indoors.room > -20.0)

	section("Looking up")
	var rig := player.camera_rig
	var camera := get_viewport().get_camera_3d()
	Input.action_press(&"look_up")
	await wait(1.5)
	Input.action_release(&"look_up")
	await wait(0.2)
	var elevation := rad_to_deg(asin(clampf((-camera.global_basis.z).y, -1.0, 1.0)))
	print("  looking up: %.0f degrees above level, camera %.2f m off the ground" % [elevation, camera.global_position.y])
	check("can look well up at the rooftops", elevation > 60.0)
	check("without flipping over or going under the floor", camera.global_basis.y.y > 0.2 and camera.global_position.y > 0.3)
	await shot("look_up")
	Input.action_press(&"look_down")
	await wait(2.0)
	Input.action_release(&"look_down")
	await wait(0.2)
	elevation = rad_to_deg(asin(clampf((-camera.global_basis.z).y, -1.0, 1.0)))
	check("and still look down as before", elevation < -60.0 and camera.global_basis.y.y > 0.2)
	rig.pitch = deg_to_rad(-28.0)

	section("Behind the house: the DEBUG button")
	await walk_path([Vector3(1.0, 0, -5.0), Vector3(1.0, 0, -2.6), Vector3(5.8, 0, -2.6), Vector3(5.8, 0, -10.6), Vector3(-0.9, 0, -11.0)])
	await wait(1.0)
	var outdoors := ambience.levels()
	check("stepping outside opens the sound up (cutoff %d Hz, rain %.0f dB)" % [outdoors.cutoff, outdoors.rain],
			ambience.zone == "street" and outdoors.cutoff > 10000.0 and outdoors.rain > indoors.rain + 4.0 and outdoors.room < indoors.room - 10.0)
	check("you can hear your own footsteps (%d so far)" % ambience.footsteps, ambience.footsteps > 8)
	aim_at(Vector3(-2.2, 0, -10.6))
	await wait(0.3)
	check("the button says what it is", _focus_prompt().contains("DEBUG"))
	check("starting out with nothing", Career.money < 100 and Career.fans == 0)
	await press_interact()
	await wait(0.4)
	check("money and fans are maxed", Career.money >= 999999 and Career.fans >= 99999)
	var gates_open := 0
	for node in get_tree().current_scene.find_children("*Gate", "", true, false):
		if node is FanGate and (node as FanGate).is_open:
			gates_open += 1
	check("every part of town is open", gates_open == 3)
	var offered := 0
	for entry in Career.GIGS:
		if Career.is_offered(entry):
			offered += 1
	check("every gig is on offer", offered == Career.GIGS.size())
	await shot("debug_button")

	section("Through the garden gate into the park")
	var gate := get_tree().current_scene.find_child("BackGate", true, false) as Interactable
	await walk_path([Vector3(1.6, 0, -12.0), Vector3(4.5, 0, -12.3)])
	aim_at(gate.global_position)
	await wait(0.3)
	check("the back gate offers to open", _focus_prompt() == "open the gate")
	await press_interact()
	await wait(1.0)
	check("E swings it open", gate.get("is_open") == true and _focus_prompt() == "close the gate")
	await walk_path([Vector3(4.4, 0, -16.0), Vector3(3.2, 0, -21.5), Vector3(2.0, 0, -24.3), Vector3(-3.0, 0, -26.3),
			Vector3(-9.0, 0, -24.0), Vector3(-16.0, 0, -21.8), Vector3(-19.5, 0, -21.4)])
	check("the park path leads from the gate to the pavilion", flat_distance(player.global_position, Vector3(-19.5, 0, -21.4)) < 1.0)

	section("The pavilion by the pond")
	var seat := get_tree().current_scene.find_child("Seat", true, false) as Interactable
	var water := get_tree().current_scene.find_child("PondSound", true, false) as AudioStreamPlayer3D
	await walk_path([Vector3(-21.0, 0, -23.2), Vector3(-22.4, 0, -25.0)])
	await wait(1.2)
	var park := ambience.levels()
	check("the pond can be heard from the pavilion (playing %s, %.1f m)" % [water.playing, water.global_position.distance_to(player.global_position)], water.playing and water.global_position.distance_to(player.global_position) < water.max_distance * 0.5)
	check("the city is a long way off (city bed %.0f dB against %.0f in the street)" % [park.city, -11.0], park.city < -22.0 and ambience.busy < 0.1)
	check("the park counts as the park (and it's dry under the roof)", ambience.zone == "park" or ambience.zone == "indoors")
	aim_at(seat.global_position)
	await wait(0.3)
	check("the bench offers a seat", _focus_prompt() == "sit in the pavilion")
	await press_interact()
	await wait(0.5)
	check("sitting in the pavilion, looking at the water", player.seated and not player.controls_enabled
			and flat_distance(player.global_position, seat.global_position) < 0.1 and player.global_position.y < 1.4)
	await shot("pavilion_sitting")

	section("Write a song")
	var songs_before := SongBook.load_all().size()
	await press_interact()
	await wait(0.3)
	check("E opens the song sketchpad", SongMaker.is_open)
	var maker: SongMaker = null
	for node in seat.get_children():
		if node is SongMaker:
			maker = node
	await get_tree().process_frame
	await get_tree().process_frame
	var cells := [Vector2i(0, 0), Vector2i(2, 2), Vector2i(4, 4), Vector2i(8, 1), Vector2i(12, 3)]
	for cell: Vector2i in cells:
		await click(maker.cell_rect(cell.x, cell.y).get_center())
	var placed := 0
	for cell: Vector2i in cells:
		if maker.has_note(cell.x, cell.y):
			placed += 1
	check("clicking squares puts notes down", placed == cells.size())
	await click(maker.cell_rect(0, 0).get_center())
	check("clicking again takes one off", not maker.has_note(0, 0))
	await press_action(&"ui_right")
	await press_action(&"interact")
	check("arrows and E work too", maker.has_note(1, 0))
	await click(maker.button_rect("Tempo").get_center())
	check("tempo button changes the tempo", int(maker.song.bpm) == 120)
	await click(maker.button_rect("Play").get_center())
	check("play loops the tune", maker.playing)
	await wait(1.5)
	await shot("song_maker")
	await click(maker.button_rect("Play").get_center())
	check("and stops it", not maker.playing)
	var title: String = maker.song.title
	await click(maker.button_rect("Save").get_center())
	var saved := {}
	for song: Dictionary in SongBook.load_all():
		if song.title == title:
			saved = song
	check("the song is saved in the song book", SongBook.load_all().size() == songs_before + 1 and not saved.is_empty())
	check("with the notes and tempo it was given", not saved.is_empty() and int(saved.bpm) == 120 and SongBook.to_chart(saved).size() == 5)
	check("writing songs leaves the gig system alone", not Career.has_job() and flow.step == GameFlow.Step.LOAD_HOME)
	await press_action(&"ui_cancel")
	await wait(0.2)
	check("Esc closes the sketchpad (and nothing else)", not SongMaker.is_open and player.seated and not get_tree().paused)
	await press_action(&"jump")
	await wait(0.6)
	check("Space gets back up", not player.seated and player.controls_enabled)
	SongBook.delete_song(title)

	section("Settings: drag the sliders with the mouse")
	var music_bus := AudioServer.get_bus_index(Settings.MUSIC_BUS)
	var sound_bus := AudioServer.get_bus_index(Settings.SOUND_BUS)
	await press_action(&"ui_cancel")
	check("Esc pauses and opens the settings", get_tree().paused and GameMenu.is_any_open())
	var menu: GameMenu = null
	for node in Settings.get_children():
		if node is GameMenu:
			menu = node
	await get_tree().process_frame
	await get_tree().process_frame
	var bar := menu.get_slider_rect(0)
	var bar_y := bar.get_center().y
	await mouse_button(Vector2(bar.position.x + bar.size.x * 0.5, bar_y), true)
	check("clicking the bar jumps the volume there", absf(Settings.music_volume - 0.5) < 0.01)
	check("...and the music bus follows at once", absf(AudioServer.get_bus_volume_db(music_bus) - linear_to_db(Settings.music_volume)) < 0.01)
	var values := {}
	var smooth := true
	var last := Settings.music_volume
	for i in 30:
		await mouse_move(Vector2(lerpf(bar.position.x + bar.size.x * 0.5, bar.position.x - 30.0, (i + 1) / 30.0), bar_y + 40.0))
		smooth = smooth and Settings.music_volume <= last and last - Settings.music_volume < 0.06
		last = Settings.music_volume
		values[snappedf(last, 0.001)] = true
	check("dragging left turns it down smoothly (%d different values on the way)" % values.size(), smooth and values.size() >= 20)
	check("0% is silence", Settings.music_volume == 0.0 and AudioServer.is_bus_mute(music_bus))
	for i in 30:
		await mouse_move(Vector2(lerpf(bar.position.x - 30.0, bar.end.x + 30.0, (i + 1) / 30.0), bar_y - 30.0))
	check("100% is full volume", Settings.music_volume == 1.0 and not AudioServer.is_bus_mute(music_bus) and absf(AudioServer.get_bus_volume_db(music_bus)) < 0.01)
	await mouse_move(Vector2(bar.position.x + bar.size.x * 0.37, bar_y))
	check("it stops exactly where you leave it, not on a notch (%.3f)" % Settings.music_volume, absf(Settings.music_volume - 0.37) < 0.005)
	await shot("settings_mouse")
	await mouse_button(Vector2(bar.position.x + bar.size.x * 0.37, bar_y), false)
	await mouse_move(Vector2(bar.position.x + bar.size.x * 0.9, bar_y))
	check("letting go lets go", absf(Settings.music_volume - 0.37) < 0.005)
	var sound_bar := menu.get_slider_rect(1)
	await mouse_button(Vector2(sound_bar.position.x + sound_bar.size.x * 0.25, sound_bar.get_center().y), true)
	await mouse_button(Vector2(sound_bar.position.x + sound_bar.size.x * 0.25, sound_bar.get_center().y), false)
	check("the sound slider works the same way", absf(Settings.sound_volume - 0.25) < 0.01
			and absf(AudioServer.get_bus_volume_db(sound_bus) - linear_to_db(Settings.sound_volume)) < 0.01)
	# One slider per kind of sound: 0 mutes just that one.
	var nature_row := 2 + Settings.CATEGORIES.map(func(c: Array) -> StringName: return c[0]).find(Settings.NATURE_BUS)
	var nature_bar := menu.get_slider_rect(nature_row)
	await mouse_button(Vector2(nature_bar.position.x + 4.0, nature_bar.get_center().y), true)
	await mouse_move(Vector2(nature_bar.position.x - 30.0, nature_bar.get_center().y))
	await mouse_button(Vector2(nature_bar.position.x - 30.0, nature_bar.get_center().y), false)
	var nature_bus := AudioServer.get_bus_index(Settings.NATURE_BUS)
	check("the park slider at 0 mutes the park, and only the park", nature_bus >= 0 and AudioServer.is_bus_mute(nature_bus)
			and not AudioServer.is_bus_mute(AudioServer.get_bus_index(Settings.RAIN_BUS)) and not AudioServer.is_bus_mute(sound_bus))
	check("every kind of sound has its slider (%d)" % Settings.CATEGORIES.size(), Settings.CATEGORIES.size() == 6)
	Settings.set_volume(Settings.NATURE_BUS, 1.0)
	var radio_row := 2 + Settings.CATEGORIES.size()
	await click(menu.get_row_rect(radio_row).get_center())
	check("clicking the radio row switches it off", not Settings.truck_radio)
	await click(menu.get_row_rect(radio_row).get_center())
	check("and on again", Settings.truck_radio)
	Settings.music_volume = music_was
	Settings.sound_volume = sound_was
	await click(menu.get_row_rect(radio_row + 1).get_center())
	await wait(0.2)
	check("clicking Resume carries on with the game", not get_tree().paused and not GameMenu.is_any_open() and player.controls_enabled)

	section("Load up")
	await walk_path([Vector3(-21.0, 0, -23.2), Vector3(-19.5, 0, -21.4), Vector3(-16.0, 0, -21.8), Vector3(-9.0, 0, -24.0), Vector3(-3.0, 0, -26.3),
			Vector3(2.0, 0, -24.3), Vector3(3.2, 0, -21.5), Vector3(4.4, 0, -16.0), Vector3(4.5, 0, -12.3), Vector3(5.8, 0, -2.6), Vector3(1.0, 0, -2.6), Vector3(1.0, 0, -5.0), Vector3(-1.5, 0, -5.2)])
	await carry(guitar, Vector3.INF, [Vector3(0.2, 0, -5.4)])
	await haul(amp, [Vector3(1.0, 0, -5.0), Vector3(1.0, 0, -2.6), Vector3(1.0, 0, -0.9), Vector3(0.5, 0, 4.6)])
	await walk_path([Vector3(1.5, 0, 4.2), Vector3(1.5, 0, -2.0), Vector3(1.0, 0, -5.0)])
	await carry(guitar, Vector3.INF, [Vector3(1.0, 0, -5.0), Vector3(1.0, 0, -2.6), Vector3(1.5, 0, -0.9), Vector3(1.5, 0, 3.7)])
	check("guitar and amp are in the truck", truck.is_loaded(guitar) and truck.is_loaded(amp))
	await close_back()

	section("The truck radio")
	await get_in(-2.0)
	await wait(0.6)
	var radio := truck.get_node("Radio") as AudioStreamPlayer3D
	check("the jingle starts when you get behind the wheel", truck.is_radio_playing())
	check("it comes from the truck itself", radio.get_parent() == truck and radio.max_distance > 5.0 and radio.max_distance < 80.0)
	check("from the cab the city sounds duller", ambience.zone == "driving")
	await press_action(&"radio")
	check("R switches it off at once", not truck.is_radio_playing() and not Settings.truck_radio)
	await press_action(&"radio")
	check("R switches it back on", truck.is_radio_playing() and Settings.truck_radio)
	await press_interact()
	await wait(0.5)
	check("it does not play while you are on foot", truck.driver == null and not truck.is_radio_playing())
	check("the cab door is right there", _focus_prompt() == "drive")
	await press_interact()
	await wait(0.4)
	check("back in: the radio is back", truck.driver == player and truck.is_radio_playing())

	section("Mind the pedestrians")
	var victims: Array[Npc] = []
	for node in get_tree().get_nodes_in_group(&"npc"):
		var person := node as Npc
		if person.mode == Npc.Mode.STAND and flat_distance(person.global_position, Vector3(-11.7, 0, 11.3)) < 1.0:
			victims.append(person)
	check("two people are chatting at the kerb", victims.size() == 2)
	await drive_path([Vector3(1, 0, 7.0)], 30.0)
	check("pulling out carefully costs nothing", fines == 0)
	var money := Career.money
	# ...and now not carefully at all: up the kerb, straight through them.
	await drive_line(PI * 0.5, Vector3(-10, 0, 11.7), func() -> bool: return truck.global_position.x < -17.0, 3.2, 30.0, false, 0.6)
	var down := _downed.size()
	var rag_dolls := 0
	for node in victims[0].get_parent().get_children():
		if node is RigidBody3D and not (node as RigidBody3D).freeze:
			rag_dolls += 1
	print("  %d people sent flying, %d fines, money went from $%d to $%d" % [down, fines, money, Career.money])
	check("both went flying", _downed.has(victims[0]) and _downed.has(victims[1]))
	check("as floppy rag dolls: real bodies that tumble", rag_dolls_seen and down > 0)
	check("$5 each, once each", fines == down and Career.money == money - 5 * down)
	await shot("knocked_over")
	await wait(1.0)
	check("no second charge for someone already on the floor", fines == down)
	var back_up := false
	for i in 20 * 60:
		back_up = not victims[0].is_down() and not victims[1].is_down()
		if back_up:
			break
		await get_tree().physics_frame
	check("they pick themselves up", back_up)
	var home := false
	for i in 25 * 60:
		home = victims[0].state == Npc.State.NORMAL and victims[1].state == Npc.State.NORMAL
		if home:
			break
		await get_tree().physics_frame
	check("...and go back to where they were", home and flat_distance(victims[0].global_position, Vector3(-12.2, 0, 11.3)) < 0.3
			and flat_distance(victims[1].global_position, Vector3(-11.2, 0, 11.3)) < 0.3)
	var fines_so_far := fines

	section("To the studio, and the board")
	await drive_to(studio_parking())
	await press_interact()
	await wait(1.0)
	check("parked at the studio", truck.driver == null and flow.step == GameFlow.Step.GET_GIG)
	await walk_path([T(-2.8, -1.6), T(-2.8, -4.4), studio_door(), at(studio, 0, 1.6), at(studio, -1.6, -1.5)])
	await press_interact()
	await wait(0.3)
	await shot("gig_menu_all")
	await menu_pick(1)
	check("booked the dinner set at the diner", Career.has_job() and Career.job.id == &"diner" and diner.has_gig())
	await wait(0.6)
	check("objective: drive to the diner", flow.step == GameFlow.Step.DRIVE_TO_VENUE and flow.objective.contains("Moon Diner"))

	section("Drive to the Moon Diner")
	await walk_path([at(studio, 0, 1.6), studio_door(), T(-2.8, -4.4)])
	await get_in()
	await pull_out(at(diner, 7.7, -1.0))
	await drive_to(at(diner, 7.7, -1.0), 150.0)
	await press_interact()
	await wait(0.8)
	check("parked on the forecourt, clear of the door", truck.driver == null and flat_distance(truck.global_position, at(diner, 7.7, -1.0)) < 2.5)
	check("objective: set up", flow.step == GameFlow.Step.SET_UP)
	await shot("diner_forecourt")

	section("A dinner set, indoors")
	var diners := _people(diner)
	var seated := 0
	for person in diners:
		if person.mode == Npc.Mode.SIT:
			seated += 1
	check("people are eating at the counter and the tables (%d, %d sitting)" % [diners.size(), seated], diners.size() >= 6 and seated >= 5)
	await open_back_from_cab()
	var into_diner := [_behind_truck(3.6), at(diner, 12.1, -5.0), at(diner, 7.5, -5.2), at(diner, 4.5, -4.5), at(diner, 1.9, -4.5), at(diner, 0.6, -1.6), at(diner, 0.5, -0.5)]
	await carry(guitar, _behind_truck(1.6), into_diner)
	await wait(1.0)
	check("carried the guitar in through the door", diner.stage.has(guitar) and InteriorCutaway.indoors > 0)
	check("the amp stayed in the truck", truck.is_loaded(amp))
	var inside := ambience.levels()
	check("inside, the street is shut out (cutoff %d Hz)" % inside.cutoff, ambience.zone == "indoors" and inside.cutoff < 2500.0)
	check("objective: play", flow.step == GameFlow.Step.PLAY)
	await walk_path([at(diner, -0.1, -0.8)])
	aim_at(diner.get_node("Mic").global_position)
	await wait(0.3)
	check("the mic offers to start the show", _focus_prompt() == "start the show")
	await press_interact()
	await wait(0.3)
	await menu_pick(0)
	check("the show is on", diner.playing and diner.game != null)
	check("with the diner's own song", Career.job.song == &"late_night_diner" and diner.game.notes.size() == Songs.chart(&"late_night_diner", "easy").size())
	var watching := 0
	for person in diners:
		if person.is_watching():
			watching += 1
	check("the diners turn round to watch", watching == diners.size())
	money = Career.money
	var fans := Career.fans
	_crowd_peak = 0.0
	await play_song(diner)
	await shot("diner_results")
	print("  accuracy %d%%, paid $%d, %d new fans" % [roundi(_accuracy * 100.0), Career.money - money, Career.fans - fans])
	check("got paid and won fans", Career.money > money and Career.fans > fans and not Career.has_job())
	check("the room enjoyed it", _crowd_peak > 0.62)
	await press_interact()
	await wait(0.5)
	check("objective: pack up", flow.step == GameFlow.Step.PACK_UP)
	var out_of_diner := into_diner.duplicate()
	out_of_diner.reverse()
	out_of_diner.remove_at(0)
	await carry(guitar, Vector3.INF, out_of_diner + [_behind_truck(-2.7)])
	await wait(0.5)
	check("guitar is back in the truck", truck.is_loaded(guitar) and truck.is_loaded(amp))
	await close_back()

	section("Back to the board for the big one")
	await get_in()
	await pull_out(studio_parking())
	await drive_to(studio_parking(), 150.0)
	await press_interact()
	await wait(1.0)
	check("back at the studio", truck.driver == null and flow.step == GameFlow.Step.FREE)
	await walk_path([T(-2.8, -1.6), T(-2.8, -4.4), studio_door(), at(studio, 0, 1.6), at(studio, -1.6, -1.5)])
	await press_interact()
	await wait(0.3)
	await menu_pick(6)
	check("booked the balcony show", Career.has_job() and Career.job.id == &"balcony" and tower.has_gig())
	check("it wants a guitar and an amp", Career.describe_kinds(Career.job.needs) == "guitar and amp")
	await wait(0.6)

	section("Drive to Skyline Tower")
	await walk_path([at(studio, 0, 1.6), studio_door(), T(-2.8, -4.4)])
	await get_in()
	# Through the open gate onto Uptown Boulevard, to the foot of the tower.
	await pull_out(at(tower, 9.5, -5.6))
	await drive_to(at(tower, 9.5, -5.6), 180.0)
	await press_interact()
	await wait(0.8)
	check("through the Uptown gate and parked at the foot of the tower", truck.driver == null and flat_distance(truck.global_position, at(tower, 9.5, -5.6)) < 3.0)
	check("objective: set up", flow.step == GameFlow.Step.SET_UP)
	var tower_top := 0.0
	for node in tower.find_children("Tower", "MeshInstance3D", true, false):
		tower_top = ((node as MeshInstance3D).get_aabb().size.y)
	check("the tower is the tallest thing around (%d m)" % roundi(tower_top), tower_top > 40.0)
	await shot("tower_street")

	section("Up in the goods lift")
	var lift := tower.get_node("Lift") as Lift
	var crowd := _people(tower)
	check("a crowd has gathered in the street, and on the roof bar opposite", crowd.size() >= 15 and crowd[0].visible)
	await open_back_from_cab()
	var to_lift := [_behind_truck(3.6), at(tower, 13.4, -3.4), at(tower, 5.7, -3.4), at(tower, 5.6, -5.3), at(tower, 3.8, -5.3)]
	var back_to_truck := [at(tower, 3.8, -5.3), at(tower, 5.6, -5.3), at(tower, 5.7, -3.4), at(tower, 13.4, -3.4), _behind_truck(3.6)]
	# Whatever is nearest the door comes out first. The amp is dragged straight
	# onto the lift; the guitar is put down beside it, then carried up in the hands.
	var order: Array[Equipment] = [guitar, amp]
	order.sort_custom(func(a: Equipment, b: Equipment) -> bool:
		return truck.to_local(a.global_position).z > truck.to_local(b.global_position).z)
	for i in 2:
		if order[i] == amp:
			await haul(amp, to_lift + [at(tower, 4.0, -3.5), at(tower, 4.2, -2.0)], _behind_truck(1.6))
			await walk_path([at(tower, 3.6, -3.7), at(tower, 3.8, -5.3)])
		else:
			await carry(guitar, _behind_truck(1.6), to_lift + [at(tower, 2.8, -5.5)])
		if i == 0:
			await walk_path(back_to_truck)
	await carry(guitar, Vector3.INF, [at(tower, 3.2, -5.4), at(tower, 3.1, -3.25)])
	await wait(0.5)
	var on_lift := func(item: Node3D) -> bool:
		var local := lift.to_local(item.global_position)
		return absf(local.x) < 1.2 and absf(local.z) < 1.4 and local.y > -0.1
	check("guitar and amp are on the lift, with you", on_lift.call(guitar) and on_lift.call(amp) and on_lift.call(player))
	await shot("lift_loaded")
	aim_at(lift.get_node("Panel").global_position)
	await wait(0.3)
	check("the panel offers the ride", _focus_prompt() == "ride the lift up")
	await press_interact()
	var ride_peak := 0.0
	for i in 15 * 60:
		if lift.at_top and not lift.moving:
			break
		ride_peak = maxf(ride_peak, guitar.linear_velocity.length())
		await get_tree().physics_frame
	await wait(1.0)
	print("  at the top: player %.1f m up, guitar %.1f, amp %.1f" % [player.global_position.y - 0.9, guitar.global_position.y, amp.global_position.y])
	check("the lift arrived at the balcony", lift.at_top and absf(lift.global_position.y - 11.88) < 0.05)
	check("it carried you up", absf(player.global_position.y - 12.9) < 0.15)
	check("and the gear rode up with it: nothing teleported", guitar.global_position.y > 11.9 and amp.global_position.y > 11.9 and ride_peak < 4.0
			and on_lift.call(guitar) and on_lift.call(amp))

	section("Set up on the balcony")
	# Step off the lift first, then turn round for the guitar.
	await walk_path([at(tower, 2.8, -2.9), at(tower, 1.0, -2.5)])
	await carry(guitar, Vector3.INF, [at(tower, 1.6, -2.3), at(tower, 0.0, -2.7)])
	await walk_path([at(tower, 2.4, -2.4)])
	await haul(amp, [at(tower, 1.6, -1.9), at(tower, -0.4, -0.4)])
	await wait(1.0)
	check("guitar and amp are set up twelve metres over the street", tower.stage.has(guitar) and tower.stage.has(amp) and tower.is_set_up())
	check("objective: play", flow.step == GameFlow.Step.PLAY)
	await walk_path([at(tower, -0.5, -1.9)])
	aim_at(tower.get_node("Mic").global_position)
	await wait(0.3)
	check("the mic offers to start the show", _focus_prompt() == "start the show")
	await shot("balcony_set_up")
	await press_interact()
	await wait(0.3)
	await menu_pick(0)
	check("the show is on", tower.playing and tower.game != null)
	await wait(1.0)
	camera = get_viewport().get_camera_3d()
	var out_over := (-camera.global_basis.z).dot(Vector3.BACK)
	check("the camera looks out over the street from behind you", out_over > 0.7 and camera.global_position.y > 12.5)
	var looking_up := 0
	for person in crowd:
		if person.is_watching():
			looking_up += 1
	var below := 0
	for person in crowd:
		if person.global_position.y < 1.0:
			below += 1
	check("everyone is watching: %d down in the street, %d across on the roof bar" % [below, crowd.size() - below], looking_up == crowd.size() and below >= 10 and crowd.size() - below >= 4)
	money = Career.money
	fans = Career.fans
	_crowd_peak = 0.0
	await play_song(tower)
	await shot("balcony_results")
	print("  accuracy %d%%, paid $%d, %d new fans" % [roundi(_accuracy * 100.0), Career.money - money, Career.fans - fans])
	check("the biggest pay day yet", Career.money - money > 150 and Career.fans > fans)
	check("the street loved it", _crowd_peak > 0.62)
	await press_interact()
	await wait(0.5)
	check("controls are back", not tower.playing and player.controls_enabled)

	section("Back down")
	await haul(amp, [at(tower, 1.6, -1.9), at(tower, 3.8, -1.7), at(tower, 4.4, -1.7)])
	await walk_path([at(tower, 3.4, -2.9), at(tower, 1.6, -2.7)])
	await carry(guitar, Vector3.INF, [at(tower, 1.8, -2.9), at(tower, 3.0, -3.0)])
	check("gear is back on the lift", on_lift.call(guitar) and on_lift.call(amp) and on_lift.call(player))
	aim_at(lift.get_node("Panel").global_position)
	await wait(0.3)
	check("the panel offers the ride down", _focus_prompt() == "send the lift down")
	await press_interact()
	for i in 15 * 60:
		if not lift.at_top and not lift.moving:
			break
		await get_tree().physics_frame
	await wait(1.0)
	check("down at street level again, gear and all", absf(player.global_position.y - 1.02) < 0.15 and guitar.global_position.y < 1.0 and amp.global_position.y < 1.0
			and on_lift.call(guitar) and on_lift.call(amp))
	check("nothing left on the balcony: objective is the drive back", flow.step == GameFlow.Step.DRIVE_BACK)

	section("Life in the city")
	check("nobody else was run over along the way (%d fines since the two at the kerb)" % (fines - fines_so_far), fines == fines_so_far)
	_check_cats()
	Settings.truck_radio = radio_was
	Settings.save()


var _downed := {}


func _physics_process(delta: float) -> void:
	super(delta)
	for node in get_tree().get_nodes_in_group(&"npc"):
		if (node as Npc).is_down():
			_downed[node] = true


## Round the driver's side of the truck to the back, and open it.
func open_back_from_cab() -> void:
	await walk_path([T(-2.4, 0.5), T(-2.4, 4.6), _behind_truck(1.6)])
	await press_interact()
	await wait(1.2)
	check("back is open, ramp is down", truck.door_open)


# --- the mouse ---------------------------------------------------------------

func mouse_button(at: Vector2, pressed: bool) -> void:
	var event := InputEventMouseButton.new()
	event.button_index = MOUSE_BUTTON_LEFT
	event.pressed = pressed
	event.position = at
	event.global_position = at
	get_viewport().push_input(event, true)
	await get_tree().process_frame


func mouse_move(at: Vector2) -> void:
	var event := InputEventMouseMotion.new()
	event.position = at
	event.global_position = at
	get_viewport().push_input(event, true)
	await get_tree().process_frame


func click(at: Vector2) -> void:
	await mouse_button(at, true)
	await mouse_button(at, false)
