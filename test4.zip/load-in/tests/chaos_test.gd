extends "res://tests/test_driver.gd"
## Soak test: a monkey mashes the controls (run at things, grab, spin the
## camera, jump, let go, use whatever is near - doors, the truck...) for a while. It passes if nothing explodes, leaves
## the world or tunnels through the floor, and everything settles afterwards.
##
##   godot --headless --fixed-fps 60 --path . res://tests/chaos_test.tscn
##
## Options after "--":  seconds=<n> (default 90)   seed=<n> (default 1)

const MOVES: Array[StringName] = [&"move_forward", &"move_back", &"move_left", &"move_right"]

var _grabs := 0
var _drives := 0


func run() -> void:
	var seconds := 90.0
	var rng := RandomNumberGenerator.new()
	rng.seed = 1
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("seconds="):
			seconds = float(arg.trim_prefix("seconds="))
		elif arg.begins_with("seed="):
			rng.seed = int(arg.trim_prefix("seed="))

	var items: Array[Node] = []
	for node in get_tree().get_nodes_in_group(&"grabbable"):
		if (node as Grabbable).can_grab:
			items.append(node)
	truck.driver_changed.connect(func(driver: Player) -> void:
		if driver:
			_drives += 1)
	hands.grab_started.connect(func(_item: Grabbable) -> void: _grabs += 1)

	section("Chaos for %d s (seed %d)" % [seconds, rng.seed])
	await wait(1.0)
	var spin := 0.0
	var target: Node3D = null
	var next_change := 0
	for tick in int(seconds * Engine.physics_ticks_per_second):
		if tick >= next_change:
			next_change = tick + rng.randi_range(15, 100)
			for action in MOVES:
				Input.action_release(action)
			# Half the time: go for a random item. Otherwise: wander.
			target = items[rng.randi() % items.size()] if rng.randf() < 0.55 else null
			if target:
				Input.action_press(&"move_forward")
			else:
				for action in MOVES:
					if rng.randf() < 0.35:
						Input.action_press(action)
			spin = 0.0
			if rng.randf() < 0.4:
				spin = rng.randf_range(-9.0, 9.0)
			if rng.randf() < 0.1:
				player.camera_rig.yaw += rng.randf_range(-PI, PI)
			press_grab(rng.randf() < 0.65)
			if rng.randf() < 0.25:
				tap(&"jump")
			if rng.randf() < 0.2:
				press_interact()
			Input.action_release(&"hold_raise")
			Input.action_release(&"hold_lower")
			if rng.randf() < 0.3:
				Input.action_press(&"hold_raise" if rng.randf() < 0.5 else &"hold_lower")
		if target and hands.held == null:
			aim_at(target.global_position)
		else:
			player.camera_rig.yaw += spin / Engine.physics_ticks_per_second
		await get_tree().physics_frame

	for action in MOVES:
		Input.action_release(action)
	Input.action_release(&"hold_raise")
	Input.action_release(&"hold_lower")
	press_grab(false)
	if truck.driver:
		await press_interact()
	print("  grabbed things %d times, drove the truck %d times" % [_grabs, _drives])

	section("Joyride for %d s" % seconds)
	truck.set_door_open(rng.randf() < 0.5)
	truck.enter(player)
	var drive_actions: Array[StringName] = [&"move_forward", &"move_back", &"move_left", &"move_right", &"jump"]
	next_change = 0
	var top := 0.0
	for tick in int(seconds * Engine.physics_ticks_per_second):
		if tick >= next_change:
			next_change = tick + rng.randi_range(20, 150)
			for action in drive_actions:
				Input.action_release(action)
			if rng.randf() < 0.8:
				Input.action_press(&"move_forward" if rng.randf() < 0.75 else &"move_back")
			if rng.randf() < 0.6:
				Input.action_press(&"move_left" if rng.randf() < 0.5 else &"move_right")
			if rng.randf() < 0.1:
				Input.action_press(&"jump")
		top = maxf(top, absf(truck.speed))
		await get_tree().physics_frame
	for action in drive_actions:
		Input.action_release(action)
	await wait(0.5)
	await press_interact()
	await wait(1.0)
	var parked := truck.global_position
	print("  truck top speed %.1f m/s, ended at %s" % [top, parked.snappedf(0.1)])
	check("truck stayed level and on the ground", absf(parked.y) < 0.01 and absf(truck.global_rotation.x) < 0.001 and absf(truck.global_rotation.z) < 0.001)
	check("truck is still in the city", absf(parked.x) < 80.0 and parked.z > -39.0 and parked.z < 129.0)
	check("driver got out next to the truck", truck.driver == null and player.visible and player.global_position.distance_to(parked) < 6.0)
	check("driver is not stuck inside something", not _inside_world(player.global_position))

	section("Settle")
	await wait(6.0)
	for item: Grabbable in items:
		var p := item.global_position
		print("  %s ended at %s" % [item.display_name, p.snappedf(0.01)])
		check("%s came to rest" % item.display_name, item.linear_velocity.length() < 0.1)
		check("%s is above the ground" % item.display_name, p.y > 0.0)
		check("%s is not stuck inside a wall" % item.display_name, not _inside_world(p))
	check("player is standing somewhere sane", player.global_position.y > 0.5 and player.global_position.y < 3.5)


## True if the point is inside solid static geometry (i.e. something tunnelled).
func _inside_world(point: Vector3) -> bool:
	var query := PhysicsPointQueryParameters3D.new()
	query.position = point
	query.collision_mask = 1
	return not player.get_world_3d().direct_space_state.intersect_point(query, 1).is_empty()
