extends Node
## Shared machinery for the automated tests: loads the game, plays it through
## fake input, checks results and watches for physics blow-ups.
##
## A test is a scene whose root script extends this one and overrides run().

const MAIN_SCENE := "res://scenes/main.tscn"

var player: Player
var hands: GrabController
var truck: Truck

## Fastest the player moved horizontally since it was last reset.
var player_peak := 0.0
## Fastest anything moved, ever.
var world_peak := 0.0

var _bodies: Array[RigidBody3D] = []
var _free_positions: Array[Vector3] = []   # last spot where each body's centre was in open space
var _checks := 0
var _failures := PackedStringArray()
var _bad_state := ""
var _shot_dir := ""
var _shot_index := 0
var _was_driving := false
var _held_up_by := "nothing"


func _ready() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("shots="):
			_shot_dir = arg.trim_prefix("shots=")
			DirAccess.make_dir_recursive_absolute(_shot_dir)

	add_child(load(MAIN_SCENE).instantiate())
	player = get_tree().get_first_node_in_group(&"player")
	hands = player.get_node("Hands")
	truck = get_tree().get_first_node_in_group(&"truck")
	_bodies.append(player)
	for node in get_tree().get_nodes_in_group(&"grabbable"):
		_bodies.append(node)
	for body in _bodies:
		_free_positions.append(body.global_position)

	await run()

	section("Stability")
	print("  fastest anything moved: %.1f m/s" % world_peak)
	check("nothing exploded, left the world or went through a wall (%s)" % _bad_state, _bad_state == "")
	print("\n%d checks, %d failed" % [_checks, _failures.size()])
	for failure in _failures:
		print("  FAILED: ", failure)
	get_tree().quit(1 if _failures.size() > 0 else 0)


## Override with the actual test.
func run() -> void:
	await get_tree().process_frame


## The town's edges (tools/city/plan.gd BOUNDS, plus a little).
const WORLD := Rect2(-130, -54, 274, 252)


func _physics_process(_delta: float) -> void:
	# Watchdog: nothing may explode, leave the world, go NaN or pass through a wall, ever.
	# While the truck is being driven the cargo rides inside a moving box, so
	# "passed through a wall" can't be judged from world positions: skip, and
	# start afresh once it is parked again.
	var driving := truck != null and truck.driver != null
	if driving or _was_driving:
		for i in _bodies.size():
			_free_positions[i] = _bodies[i].global_position
			world_peak = maxf(world_peak, 0.0)
		_was_driving = driving
		return
	var space := player.get_world_3d().direct_space_state
	var point := PhysicsPointQueryParameters3D.new()
	point.collision_mask = 1
	for i in _bodies.size():
		var body := _bodies[i]
		var p := body.global_position
		var speed := body.linear_velocity.length()
		world_peak = maxf(world_peak, speed)
		var problem := ""
		if not p.is_finite() or p.y < -1.0 or p.y > 20.0 or not WORLD.has_point(Vector2(p.x, p.z)):
			problem = "left the world"
		elif speed > 25.0:
			problem = "exploded"
		else:
			# A centre pressed a little way into a wall is fine; coming out the far side is not.
			point.position = p
			if space.intersect_point(point, 1).is_empty():
				var ray := PhysicsRayQueryParameters3D.create(_free_positions[i], p, 1)
				if not space.intersect_ray(ray).is_empty():
					problem = "went through something solid"
				_free_positions[i] = p
		if problem != "" and _bad_state == "":
			_bad_state = "%s %s at %s, %.1f m/s, t=%.1f s" % [body.name, problem, p.snappedf(0.01), speed,
					Engine.get_physics_frames() / float(Engine.physics_ticks_per_second)]
	player_peak = maxf(player_peak, player.get_horizontal_velocity().length())


# --- reporting -------------------------------------------------------------

func section(title: String) -> void:
	print("\n== ", title)


func check(what: String, ok: bool) -> void:
	_checks += 1
	print("  [%s] %s" % ["ok" if ok else "FAIL", what])
	if not ok:
		_failures.append(what)


## Saves a screenshot when the test was started with "-- shots=<folder>".
func shot(label: String) -> void:
	if _shot_dir == "":
		return
	await get_tree().process_frame
	RenderingServer.force_draw()
	_shot_index += 1
	var image := get_viewport().get_texture().get_image()
	image.save_png("%s/%02d_%s.png" % [_shot_dir, _shot_index, label])


# --- world -----------------------------------------------------------------

func find_item(kind: StringName) -> Equipment:
	for node in get_tree().get_nodes_in_group(&"grabbable"):
		if node is Equipment and node.kind == kind and node.is_owned():
			return node
	return null


func flat_distance(a: Vector3, b: Vector3) -> float:
	return Vector2(a.x - b.x, a.z - b.z).length()


# --- fake input ------------------------------------------------------------

func wait(seconds: float) -> void:
	for i in int(seconds * Engine.physics_ticks_per_second):
		await get_tree().physics_frame


## How fast the fake player turns the camera, in radians/s (a quick but human mouse sweep).
const TURN_SPEED := 6.0


## Snaps the camera (and so the player's aim) to face a world position.
func aim_at(target: Vector3) -> void:
	var to := target - player.global_position
	player.camera_rig.yaw = atan2(-to.x, -to.z)


## Turns the camera toward a world position at a human speed. Returns how far off it still is (radians).
func turn_toward(target: Vector3, backwards := false) -> float:
	var to := target - player.global_position
	if backwards:
		to = -to
	var wanted := atan2(-to.x, -to.z)
	var step := TURN_SPEED / Engine.physics_ticks_per_second
	player.camera_rig.yaw = rotate_toward(player.camera_rig.yaw, wanted, step)
	return absf(angle_difference(player.camera_rig.yaw, wanted))


## Walks (or backs up, dragging) until within `tolerance` of the target.
func walk_to(target: Vector3, tolerance := 0.3, timeout := 12.0, backwards := false) -> bool:
	var action := &"move_back" if backwards else &"move_forward"
	var arrived := false
	for i in int(timeout * Engine.physics_ticks_per_second):
		if flat_distance(target, player.global_position) < tolerance:
			arrived = true
			break
		# Turn first, then go: only walk once roughly facing the right way.
		if facing_enough(turn_toward(target, backwards)):
			Input.action_press(action)
		else:
			Input.action_release(action)
		await get_tree().physics_frame
	Input.action_release(action)
	if not arrived:
		check("reached %s (stuck at %s)" % [target, player.global_position], false)
	await wait(0.3)
	return arrived


func facing_enough(off_by: float) -> bool:
	return off_by < 0.6


## Runs up to an item, slows to a creep for the last stretch, then faces it.
func approach(item: Grabbable) -> void:
	# The character faces the way it walks, so when it is standing right next to
	# the thing it first takes a few steps away, then comes back facing it.
	var gap := player.global_position - item.global_position
	gap.y = 0.0
	if gap.length() < 1.3:
		# Straight back if there is room; otherwise off to one side or the other.
		var out := gap.normalized() if gap.length() > 0.05 else Vector3.BACK
		for swing: float in [0.0, 1.1, -1.1, 2.2, -2.2]:
			var away := item.global_position + out.rotated(Vector3.UP, swing) * 2.0
			for i in 80:
				if flat_distance(away, player.global_position) < 0.3:
					break
				if facing_enough(turn_toward(away)):
					Input.action_press(&"move_forward")
				await get_tree().physics_frame
			Input.action_release(&"move_forward")
			if flat_distance(item.global_position, player.global_position) > 1.45:
				break
	for attempt in 4:
		await _close_in(item)
		if hands.focus == item or hands.held == item:
			break
		# Something else is nearer the hands (an amp right beside the guitar,
		# say): walk a quarter of the way round and come at it from there.
		var from := player.global_position - item.global_position
		from.y = 0.0
		var around := item.global_position + from.normalized().rotated(Vector3.UP, 1.5 if attempt % 2 == 0 else -3.0) * 1.8
		for i in 150:
			if flat_distance(around, player.global_position) < 0.35:
				break
			if facing_enough(turn_toward(around)):
				Input.action_press(&"move_forward")
			else:
				Input.action_release(&"move_forward")
			await get_tree().physics_frame
		Input.action_release(&"move_forward")


# The last couple of metres: walk up to the item, slow down, end up facing it.
func _close_in(item: Grabbable) -> void:
	for i in 12 * Engine.physics_ticks_per_second:
		var off_by := turn_toward(item.global_position)
		var distance := flat_distance(item.global_position, player.global_position)
		if distance < 1.0:
			break
		if facing_enough(off_by):
			Input.action_press(&"move_forward", 1.0 if distance > 2.0 else 0.35)
		else:
			Input.action_release(&"move_forward")
		await get_tree().physics_frame
	Input.action_release(&"move_forward")
	for i in 40:
		turn_toward(item.global_position)
		await get_tree().physics_frame
	# Still side-on to it (no room to step back)? Shuffle round to face it.
	for i in 45:
		var to := item.global_position - player.global_position
		if absf(angle_difference(player.facing_yaw, atan2(-to.x, -to.z))) < 0.5:
			break
		turn_toward(item.global_position)
		Input.action_press(&"move_forward", 0.3)
		await get_tree().physics_frame
	Input.action_release(&"move_forward")


func press_grab(pressed: bool) -> void:
	var event := InputEventAction.new()
	event.action = &"grab"
	event.pressed = pressed
	Input.parse_input_event(event)
	Input.flush_buffered_events()


func press_interact() -> void:
	for pressed: bool in [true, false]:
		var event := InputEventAction.new()
		event.action = &"interact"
		event.pressed = pressed
		Input.parse_input_event(event)
		Input.flush_buffered_events()
		await get_tree().physics_frame


## Walks to each point in turn.
func walk_path(points: Array, tolerance := 0.4) -> void:
	for point: Vector3 in points:
		await walk_to(point, tolerance, 20.0)


## Drives the truck through the points (ground positions) and stops at the last.
## `max_speed` caps the speed; `reach` is how close counts as "at" a waypoint.
## `careful` = wait for traffic and people (turn it off to test running someone over).
func drive_path(points: Array, timeout := 60.0, max_speed := INF, reach := 4.0, careful := true) -> bool:
	var index := 0
	var ok := false
	var snagged := 0.0
	var recoveries := 0
	for i in int(timeout * Engine.physics_ticks_per_second):
		var target: Vector3 = points[index]
		if OS.has_environment("TRACE") and i % 30 == 0:
			print("    t%d at %s yaw %.2f -> #%d %s speed %.1f" % [i / 60, truck.global_position.snappedf(0.1), truck.global_rotation.y, index, target.snappedf(0.1), truck.speed])
		var to := target - truck.global_position
		to.y = 0.0
		var distance := to.length()
		var last := index == points.size() - 1
		var off_by := angle_difference(truck.global_rotation.y, atan2(-to.x, -to.z))
		# Close enough - or, for the last point, level with it and about to overshoot.
		var passed := last and distance < 5.0 and to.dot(-truck.global_basis.z) < 0.3
		# A waypoint inside the truck's turning circle (or behind it) can't be
		# driven through: look further along instead of circling round it.
		var lock := deg_to_rad(lerpf(truck.steer_angle_slow, truck.steer_angle_fast, clampf(absf(truck.speed) / truck.top_speed, 0.0, 1.0)))
		# (Only nearby ones: one far behind means turning round, not skipping on.)
		var out_of_reach := not last and distance < 10.0 and (distance < 2.0 * truck.wheelbase / tan(lock) * absf(sin(off_by)) or absf(off_by) > PI * 0.5)
		if distance < (1.2 if last else reach) or passed or out_of_reach:
			if last:
				ok = true
				break
			index += 1
			continue
		Input.action_release(&"move_left")
		Input.action_release(&"move_right")
		if off_by > 0.02:
			Input.action_press(&"move_left", clampf(off_by * 2.5, 0.0, 1.0))
		elif off_by < -0.02:
			Input.action_press(&"move_right", clampf(-off_by * 2.5, 0.0, 1.0))
		# Ease off for corners and for the final stop.
		var limit := truck.top_speed
		if absf(off_by) > 0.35:
			limit = 4.0
		elif last and distance < 14.0:
			limit = clampf(distance * 0.7, 2.0, 8.0)
		elif _corner_ahead(points, index, 8.0 + truck.speed * 1.2):
			limit = 4.5
		limit = minf(limit, max_speed)
		# Turning hard, the truck goes where it's steering, not straight on; and
		# nobody beyond the stopping point is in the way of the last stretch.
		if careful and _traffic_ahead(to / maxf(distance, 0.01), distance + 3.0 if last else INF, absf(off_by) > 0.5):
			limit = 0.0
		Input.action_release(&"move_forward")
		Input.action_release(&"jump")
		if truck.speed < limit:
			Input.action_press(&"move_forward")
		elif truck.speed > limit + 1.5:
			Input.action_press(&"jump")
		# Nose against a corner? Back off a couple of metres, wheel the other way, try again.
		snagged = snagged + 1.0 / Engine.physics_ticks_per_second if limit > 0.5 and absf(truck.speed) < 0.3 else 0.0
		if snagged > 1.5 and recoveries < 6:
			recoveries += 1
			snagged = 0.0
			print("  (backing off a snag at %s)" % truck.global_position.snappedf(0.1))
			Input.action_release(&"move_forward")
			Input.action_release(&"move_left")
			Input.action_release(&"move_right")
			Input.action_press(&"move_right" if off_by > 0.0 else &"move_left")
			for k in int(1.4 * Engine.physics_ticks_per_second):
				if _people_behind():
					Input.action_release(&"move_back")
				else:
					Input.action_press(&"move_back")
				await get_tree().physics_frame
			Input.action_release(&"move_back")
		await get_tree().physics_frame
	for action: StringName in [&"move_forward", &"move_back", &"move_left", &"move_right"]:
		Input.action_release(action)
	Input.action_press(&"jump")
	await wait(1.0)
	Input.action_release(&"jump")
	if not ok:
		check("drove to %s (ended at %s)" % [points[-1], truck.global_position.snappedf(0.1)], false)
		# What was in the way?
		print("    truck heading %.2f, making for %s, last held up by %s" % [truck.global_rotation.y, points[index], _held_up_by])
		for node in get_tree().get_nodes_in_group(&"npc"):
			var person := node as Npc
			if person.visible and flat_distance(person.global_position, truck.global_position) < 10.0:
				print("    %s at %s (in the truck's frame %s), state %d" % [person.name, person.global_position.snappedf(0.1), truck.to_local(person.global_position).snappedf(0.1), person.state])
		for car in get_tree().get_nodes_in_group(&"traffic_car"):
			if flat_distance((car as Node3D).global_position, truck.global_position) < 30.0:
				var waiting_for: Object = (car as TrafficCar).blocked_by
				print("    car at %s heading %.2f, waiting for %s" % [(car as Node3D).global_position.snappedf(0.1), (car as Node3D).global_rotation.y,
						String((waiting_for as Node).name) if waiting_for else "nothing"])
	return ok


# A sharp bend (a junction) in the next `within` metres of the path?
func _corner_ahead(points: Array, index: int, within: float) -> bool:
	var from := truck.global_position
	var travelled := 0.0
	var last_dir := -truck.global_basis.z
	for k in range(index, points.size()):
		var seg: Vector3 = points[k] - from
		seg.y = 0.0
		if seg.length() < 0.5:
			continue
		travelled += seg.length()
		if travelled > within:
			return false
		var dir := seg.normalized()
		if k > index and absf(last_dir.signed_angle_to(dir, Vector3.UP)) > 0.6:
			return true
		last_dir = dir
		from = points[k]
	return false


# Anything on wheels we should wait for: a moving car anywhere close in front
# (crossing, oncoming, turning), or any car in the lane ahead or on the way to
# where we are steering. Like a careful driver.
func _traffic_ahead(heading_for: Vector3, max_along := INF, turning := false) -> bool:
	var reach := 7.5 + absf(truck.speed) * 0.9
	var forward := -truck.global_basis.z
	for node in get_tree().get_nodes_in_group(&"traffic_car"):
		var car := node as TrafficCar
		# A car that has stopped to let us through is not in the way.
		if _is_waiting_for_us(car):
			continue
		var offset := car.global_position - truck.global_position
		offset.y = 0.0
		if car.speed > 0.5 and offset.length() < 9.0 and offset.dot(forward) > 0.0:
			_held_up_by = "a moving car at %s" % car.global_position.snappedf(0.1)
			return true
		for direction: Vector3 in [forward, heading_for]:
			var along := offset.dot(direction)
			if along > 1.0 and along < reach and (offset - direction * along).length() < 2.0:
				_held_up_by = "a car in the lane at %s" % car.global_position.snappedf(0.1)
				return true
	# People: anyone on foot in front of the bonnet, or about to step in front of it.
	var stopping := minf(4.0 + absf(truck.speed) * 0.75, max_along - 2.6)
	for node in get_tree().get_nodes_in_group(&"npc"):
		var person := node as Npc
		if not person.visible or person.is_down():
			continue
		var offset := person.global_position - truck.global_position
		offset.y = 0.0
		if offset.length() > stopping + 3.0:
			continue
		for direction: Vector3 in [forward, heading_for]:
			var along := offset.dot(direction)
			# While turning, straight on only matters right in front of the bumper.
			var range_ahead := 3.5 if turning and direction == forward else stopping + 2.6
			if along > 0.5 and along < range_ahead and (offset - direction * along).length() < 2.0:
				_held_up_by = "%s at %s" % [person.name, person.global_position.snappedf(0.1)]
				return true
	_held_up_by = "nothing"
	return false


# Anyone on foot close behind the truck (where it is about to reverse)?
func _people_behind() -> bool:
	for node in get_tree().get_nodes_in_group(&"npc"):
		var person := node as Npc
		if not person.visible or person.is_down():
			continue
		var local := truck.to_local(person.global_position)
		if absf(local.x) < 2.4 and local.z > -1.0 and local.z < 7.5 and absf(local.y) < 2.0:
			return true
	return false


# True if the car is held up by the truck, by something riding in it, or by a
# queue of cars that is.
func _is_waiting_for_us(car: TrafficCar) -> bool:
	var blocker: Object = car.blocked_by
	for i in 6:
		if blocker == truck or (blocker is Grabbable and truck.is_loaded(blocker)):
			return true
		if not (blocker is TrafficCar):
			return false
		blocker = (blocker as TrafficCar).blocked_by
	return false


## Drives forwards along a straight line (heading `yaw`, through `on_line`),
## correcting sideways drift, until `done` says stop. For tight spots.
func drive_line(yaw: float, on_line: Vector3, done: Callable, max_speed := 3.0, timeout := 40.0, careful := true, max_correction := 0.2) -> void:
	var left := Vector3(-cos(yaw), 0.0, sin(yaw))
	for i in int(timeout * Engine.physics_ticks_per_second):
		if done.call():
			break
		var off_line := (truck.global_position - on_line).dot(left)
		var wanted := yaw - clampf(off_line * 0.3, -max_correction, max_correction)
		_steer_and_go(angle_difference(truck.global_rotation.y, wanted) * 5.0, max_speed, careful)
		await get_tree().physics_frame
	await _stop_truck()


## One careful arc (left or right, whichever way `exit_yaw` lies) that brings
## the truck out heading along `exit_yaw` exactly on the line through
## `exit_point` - how you get a truck into an alley barely wider than it is.
## Start beside the line, not past it.
func turn_onto_line(exit_yaw: float, exit_point: Vector3, max_speed := 1.5, timeout := 30.0) -> void:
	var left := Vector3(-cos(exit_yaw), 0.0, sin(exit_yaw))
	var side := signf(angle_difference(truck.global_rotation.y, exit_yaw))     # +1 = a left turn
	for i in int(timeout * Engine.physics_ticks_per_second):
		var still_to_turn := angle_difference(truck.global_rotation.y, exit_yaw) * side
		if still_to_turn < 0.03:
			break
		# The circle that lands on the line, and how much wheel that takes at this speed.
		var to_line := (truck.global_position - exit_point).dot(left) * side
		var radius := maxf(to_line / maxf(1.0 - cos(still_to_turn), 0.01), 0.5)
		var lock := deg_to_rad(lerpf(truck.steer_angle_slow, truck.steer_angle_fast, clampf(absf(truck.speed) / truck.top_speed, 0.0, 1.0)))
		_steer_and_go(side * atan(truck.wheelbase / radius) / lock, max_speed)
		await get_tree().physics_frame
	for action: StringName in [&"move_left", &"move_right"]:
		Input.action_release(action)


# steer: +1 = full left, -1 = full right. Holds the speed at `max_speed`, waits for traffic.
func _steer_and_go(steer: float, max_speed: float, careful := true) -> void:
	Input.action_release(&"move_left")
	Input.action_release(&"move_right")
	if steer > 0.01:
		Input.action_press(&"move_left", clampf(steer, 0.0, 1.0))
	elif steer < -0.01:
		Input.action_press(&"move_right", clampf(-steer, 0.0, 1.0))
	var limit := 0.0 if careful and _traffic_ahead(-truck.global_basis.z) else max_speed
	Input.action_release(&"move_forward")
	Input.action_release(&"jump")
	if truck.speed < limit:
		Input.action_press(&"move_forward")
	elif truck.speed > limit + 0.3:
		Input.action_press(&"jump")


func _stop_truck() -> void:
	for action: StringName in [&"move_forward", &"move_back", &"move_left", &"move_right"]:
		Input.action_release(action)
	Input.action_press(&"jump")
	await wait(1.0)
	Input.action_release(&"jump")


## Backs the truck up in a straight line (nose along `yaw`, on the line through
## `on_line`) until `done` says stop.
func reverse_straight(yaw: float, on_line: Vector3, done: Callable, timeout := 30.0) -> void:
	var left := Vector3(-cos(yaw), 0.0, sin(yaw))
	for i in int(timeout * Engine.physics_ticks_per_second):
		if done.call():
			break
		# Check the mirrors: never back into someone.
		if _people_behind():
			Input.action_release(&"move_back")
			Input.action_press(&"jump")
			await get_tree().physics_frame
			continue
		Input.action_release(&"jump")
		Input.action_press(&"move_back")
		# Going backwards, pointing the nose a little to the left moves the truck right.
		var off_line := (truck.global_position - on_line).dot(left)
		var wanted := yaw + clampf(off_line * 0.25, -0.15, 0.15)
		var off_by := angle_difference(truck.global_rotation.y, wanted)
		Input.action_release(&"move_left")
		Input.action_release(&"move_right")
		if off_by > 0.01:
			Input.action_press(&"move_right", clampf(off_by * 6.0, 0.0, 1.0))
		elif off_by < -0.01:
			Input.action_press(&"move_left", clampf(-off_by * 6.0, 0.0, 1.0))
		await get_tree().physics_frame
	for action: StringName in [&"move_back", &"move_left", &"move_right"]:
		Input.action_release(action)
	Input.action_press(&"jump")
	await wait(1.0)
	Input.action_release(&"jump")


## Backs the truck out and swings it round until its nose points along `yaw`.
func reverse_to_heading(yaw: float, straight := 2.0, max_speed := INF) -> void:
	var from := truck.global_position
	for i in 30 * Engine.physics_ticks_per_second:
		var off_by := angle_difference(truck.global_rotation.y, yaw)
		if absf(off_by) < 0.12:
			break
		Input.action_release(&"jump")
		if _people_behind():
			Input.action_release(&"move_back")
			Input.action_press(&"jump")
		elif truck.speed > -max_speed:
			Input.action_press(&"move_back")
		else:
			Input.action_release(&"move_back")
		Input.action_release(&"move_left")
		Input.action_release(&"move_right")
		if from.distance_to(truck.global_position) >= straight:
			# Going backwards, the wheel works the other way round.
			Input.action_press(&"move_right" if off_by > 0.0 else &"move_left")
		await get_tree().physics_frame
	for action: StringName in [&"move_back", &"move_left", &"move_right"]:
		Input.action_release(action)
	Input.action_press(&"jump")
	await wait(1.0)
	Input.action_release(&"jump")


## A ground point in `node`'s own frame (x = its right, z = its back): spots at
## a venue stay put however the city around it is laid out.
func at(node: Node3D, x: float, z: float) -> Vector3:
	var point := node.to_global(Vector3(x, 0.0, z))
	point.y = 0.0
	return point


## The way along the streets from the truck to the road nearest `to`
## (RoadNetwork.route), keeping to the right-hand lane.
func street_route(to: Vector3) -> Array:
	var net: RoadNetwork = get_tree().get_first_node_in_group(&"road_network")
	var path := net.route(truck.global_position, to)
	var out := []
	for i in path.size():
		var dir := path[mini(i + 1, path.size() - 1)] - path[maxi(i - 1, 0)]
		dir.y = 0.0
		if dir.length() < 0.01:
			out.append(path[i])
			continue
		dir = dir.normalized()
		var road := net.road_at(path[i], 0.5)
		var lane := 0.0
		if road >= 0 and net.road_width[road] >= 7.0:
			lane = net.road_width[road] * 0.22
		elif road >= 0 and net.road_width[road] >= 6.0:
			lane = 0.7
		out.append(path[i] + Vector3(-dir.z, 0.0, dir.x) * lane)
	return out


## Backs out of a parking spot and swings round to face the way the streets
## lead to `to` (after looking both ways).
func pull_out(to: Vector3) -> void:
	var points := street_route(to)
	if points.size() < 2:
		return
	var kerb: Vector3 = points[0]
	var ahead: Vector3 = points[mini(3, points.size() - 1)] - kerb
	await wait_for_gap(kerb, 20.0)
	# Back out far enough that the swing ends in our own lane, not the oncoming one.
	var across := Vector3(-ahead.z, 0.0, ahead.x).normalized()
	var gap := absf((kerb - truck.global_position).dot(across))
	var squareness := maxf(absf(truck.global_basis.z.dot(across)), 0.5)
	var straight := clampf((gap - 2.5) / squareness, 2.0, 7.0)
	var net: RoadNetwork = get_tree().get_first_node_in_group(&"road_network")
	var on_road := net.road_at(truck.global_position)
	if on_road >= 0 and net.is_drivable(on_road):
		straight = 2.0  # already out in the street: just turn round
	await reverse_to_heading(atan2(-ahead.x, -ahead.z), straight, 2.5)


## Drives along the streets to the kerb nearest `spot` and pulls in onto it
## (a parking pad, a forecourt), stopping there.
func drive_to(spot: Vector3, timeout := 150.0) -> bool:
	var points := street_route(spot)
	if points.is_empty():
		check("there is a way along the streets to %s" % spot.snappedf(0.1), false)
		return false
	# Aim a little way up the road rather than at the spot right beside us.
	while points.size() > 2 and flat_distance(points[0], truck.global_position) < 10.0:
		points.pop_front()
	var kerb: Vector3 = points[points.size() - 1]
	var into := spot - kerb
	into.y = 0.0
	if into.length() > 2.5:
		# Swing in off the lane: stop following the street a little early.
		var along: Vector3 = kerb - points[maxi(points.size() - 4, 0)]
		along.y = 0.0
		along = along.normalized()
		while points.size() > 1 and flat_distance(points[points.size() - 1], kerb) < 9.0:
			points.pop_back()
		points.append(kerb - along * 6.0)
		points.append(kerb + into.normalized() * minf(3.0, into.length() * 0.45))
	points.append(spot)
	return await drive_path(points, timeout)


## Looks both ways: waits until no car is within `radius` of a spot on the road.
func wait_for_gap(at: Vector3, radius: float, timeout := 45.0) -> void:
	for i in int(timeout * Engine.physics_ticks_per_second):
		var clear := true
		for node in get_tree().get_nodes_in_group(&"traffic_car"):
			if flat_distance((node as Node3D).global_position, at) < radius:
				clear = false
				break
		if clear:
			return
		await get_tree().physics_frame


func gig(id: StringName) -> Dictionary:
	for entry in Career.GIGS:
		if entry.id == id:
			return entry
	return {}


## One press and release of an action, a frame apart (works while paused).
func press_action(action: StringName) -> void:
	for pressed: bool in [true, false]:
		var event := InputEventAction.new()
		event.action = action
		event.pressed = pressed
		Input.parse_input_event(event)
		Input.flush_buffered_events()
		await get_tree().process_frame
	await get_tree().process_frame


## Picks a row of the open menu: `down` presses of "down", then "interact".
func menu_pick(down: int) -> void:
	for i in down:
		await press_action(&"ui_down")
	await press_action(&"interact")
	await wait(0.2)


func tap(action: StringName) -> void:
	Input.action_press(action)
	await wait(0.05)
	Input.action_release(action)
