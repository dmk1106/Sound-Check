extends "res://tests/playtest.gd"
## Drives the truck into street lamps: slowly (it should bend) and fast (it
## should fall over), and checks the truck never gets stuck on one.
##
##   godot --headless --fixed-fps 60 --path . res://tests/lamp_test.tscn


func run() -> void:
	setup()
	await wait(1.0)
	player.global_position = T(-2.6, 0.5) + Vector3(0, 0.9, 0)
	await wait(0.5)
	await get_in(-2.0)
	var lamps: Array[Node3D] = []
	for node in get_tree().get_root().find_children("Lamp*", "Node3D", true, false):
		if node.has_method(&"_knock"):
			lamps.append(node)
	check("street lamps can be knocked over (%d of them)" % lamps.size(), lamps.size() > 20)
	lamps.sort_custom(func(a: Node3D, b: Node3D) -> bool: return a.global_position.length() < b.global_position.length())
	# Lamps with a clear 16 m run-up from the road.
	var space := player.get_world_3d().direct_space_state
	var clear: Array[Node3D] = []
	for lamp in lamps:
		var away := Vector3(lamp.global_basis.z.x, 0, lamp.global_basis.z.z).normalized()
		var side := away.cross(Vector3.UP)
		var ok := true
		for offset in [-1.3, 0.0, 1.3]:
			var from: Vector3 = lamp.global_position + away * 1.0 + side * offset + Vector3.UP * 1.2
			var query := PhysicsRayQueryParameters3D.create(from, from + away * 16.0, 0b101, [truck.get_rid()])
			if not space.intersect_ray(query).is_empty():
				ok = false
		if ok:
			clear.append(lamp)
	check("found lamps with a clear run-up (%d)" % clear.size(), clear.size() >= 2)
	for run_up in [[clear[0], 4.0, "bends"], [clear[1], 12.0, "falls over"]]:
		var lamp: Node3D = run_up[0]
		var top_speed: float = run_up[1]
		section("Truck into a lamp at %.0f m/s" % top_speed)
		# Line up 14 m away, aimed at the post, then go.
		var away := Vector3(lamp.global_basis.z.x, 0, lamp.global_basis.z.z).normalized()
		var start := lamp.global_position + away * 14.0
		truck.global_transform = Transform3D(Basis.looking_at(-away), Vector3(start.x, truck.global_position.y, start.z))
		truck.linear_velocity = Vector3.ZERO
		await wait(0.3)
		var t := 0.0
		while t < 4.0 and flat_distance(truck.global_position, start) < 20.0:
			_steer_and_go(0.0, top_speed, false)
			await get_tree().physics_frame
			t += 1.0 / 60.0
		var tilt: float = (lamp.get_node("Pivot") as Node3D).basis.get_euler().length()
		await wait(0.8)
		tilt = (lamp.get_node("Pivot") as Node3D).basis.get_euler().length()
		check("the lamp %s (knocked=%s, tilt %.0f°)" % [run_up[2], lamp.get("knocked"), rad_to_deg(tilt)], lamp.get("knocked") and (tilt > 1.2 if top_speed > 8.0 else tilt > 0.2 and tilt < 1.0))
		check("the truck carried on past it (%.1f m from the start)" % flat_distance(truck.global_position, start), flat_distance(truck.global_position, start) > 15.0)
		await _stop_truck()
