class_name Cat
extends Node3D
## A cat about town. It potters round its own patch, sits down for a bit,
## washes, watches the player go by, and clears off sharpish when the truck
## comes near. Not a physics object: nothing can bump into it.

enum State { WALK, SIT, WATCH, RUN }

## How far from where it was put it will wander.
@export var roam := 5.0
@export var coat := Color("ff9f5a")
@export var walk_speed := 0.9

var state := State.SIT
## Total distance walked (for tests).
var travelled := 0.0

const MEOWS: Array[AudioStream] = [preload("res://audio/sfx/meow1.ogg"), preload("res://audio/sfx/meow2.ogg")]

var _home := Vector3.ZERO
var _goal := Vector3.ZERO
var _timer := 0.0
var _phase := 0.0
var _speed := 0.0
var _meow_wait := 0.0
var _time := 0.0

@onready var _body: Node3D = $Body
@onready var _head: Node3D = $Body/Head
@onready var _tail: Node3D = $Body/Tail
@onready var _legs: Array[Node3D] = [$Body/LegFL, $Body/LegFR, $Body/LegBL, $Body/LegBR]
@onready var _player: Node3D = get_tree().get_first_node_in_group(&"player")
@onready var _truck: Truck = get_tree().get_first_node_in_group(&"truck")


func _ready() -> void:
	add_to_group(&"cat")
	_home = global_position
	_timer = randf_range(0.5, 4.0)
	_meow_wait = randf_range(4.0, 20.0)
	for node in find_children("Fur*", "MeshInstance3D"):
		var mesh := node as MeshInstance3D
		var material: ShaderMaterial = mesh.mesh.surface_get_material(0).duplicate()
		material.set_shader_parameter(&"albedo", coat)
		mesh.material_override = material


func _physics_process(delta: float) -> void:
	_time += delta
	_timer -= delta
	_meow_wait -= delta
	var to_player := (_player.global_position - global_position) if _player and _player.visible else Vector3(99, 0, 99)
	to_player.y = 0.0

	# A truck rolling this way trumps everything.
	if _truck and _truck.driver and absf(_truck.speed) > 1.0 and state != State.RUN:
		var gap := global_position - _truck.global_position
		gap.y = 0.0
		if gap.length() < 9.0:
			var away := gap.normalized() if gap.length() > 0.1 else Vector3.RIGHT
			_goal = _free_spot(global_position + away * 6.0)
			state = State.RUN
			_timer = 4.0

	var wanted := 0.0
	match state:
		State.SIT:
			if to_player.length() < 4.5:
				state = State.WATCH
				_timer = randf_range(3.0, 6.0)
				if _meow_wait <= 0.0:
					_meow_wait = randf_range(10.0, 30.0)
					Sfx.play_at(self, MEOWS[randi() % MEOWS.size()], global_position, -4.0, randf_range(0.9, 1.2), 18.0)
			elif _timer <= 0.0:
				_wander()
		State.WATCH:
			# Sitting up, following the player with its eyes.
			var local := global_basis.inverse() * to_player
			_head.rotation.y = lerp_angle(_head.rotation.y, clampf(atan2(-local.x, -local.z), -1.3, 1.3), 1.0 - exp(-6.0 * delta))
			if _timer <= 0.0 or to_player.length() > 7.0:
				state = State.SIT
				_timer = randf_range(1.0, 5.0)
		State.WALK, State.RUN:
			var to := _goal - global_position
			to.y = 0.0
			if to.length() < 0.2 or _timer <= 0.0:
				state = State.SIT
				_timer = randf_range(2.0, 9.0)
			else:
				wanted = walk_speed * (3.2 if state == State.RUN else 1.0)
				global_rotation.y = lerp_angle(global_rotation.y, atan2(-to.x, -to.z), 1.0 - exp(-8.0 * delta))
	if state != State.WATCH:
		_head.rotation.y = lerp_angle(_head.rotation.y, sin(_time * 0.6) * 0.3, 1.0 - exp(-3.0 * delta))

	_speed = move_toward(_speed, wanted, delta * 6.0)
	if _speed > 0.01:
		var step := -global_basis.z * _speed * delta
		global_position += step
		travelled += step.length()
	_pose(delta)


func _wander() -> void:
	var angle := randf() * TAU
	_goal = _free_spot(_home + Vector3(cos(angle), 0, sin(angle)) * randf_range(1.0, roam))
	state = State.WALK
	_timer = 12.0


# The point itself if nothing solid is between here and there, otherwise as far as the cat can get.
func _free_spot(point: Vector3) -> Vector3:
	var from := global_position + Vector3.UP * 0.15
	var ray := PhysicsRayQueryParameters3D.create(from, Vector3(point.x, from.y, point.z), 1)
	var hit := get_world_3d().direct_space_state.intersect_ray(ray)
	if hit:
		var short: Vector3 = hit.position + hit.normal * 0.4
		return Vector3(short.x, global_position.y, short.z)
	return Vector3(point.x, global_position.y, point.z)


func _pose(delta: float) -> void:
	var moving := clampf(_speed / walk_speed, 0.0, 1.0)
	var sitting := 1.0 - moving if state == State.SIT or state == State.WATCH else 0.0
	_phase += _speed * 9.0 * delta
	var swing := sin(_phase) * 0.7 * moving
	_legs[0].rotation.x = swing
	_legs[1].rotation.x = -swing
	_legs[2].rotation.x = -swing
	_legs[3].rotation.x = swing
	# Sitting: bottom down, chest up.
	var blend := 1.0 - exp(-7.0 * delta)
	_body.rotation.x = lerpf(_body.rotation.x, 0.5 * sitting, blend)
	_body.position.y = lerpf(_body.position.y, -0.045 * sitting + absf(sin(_phase)) * 0.012 * moving, blend)
	_head.rotation.x = lerpf(_head.rotation.x, -0.45 * sitting, blend)
	_tail.rotation = Vector3(-0.5 - 0.5 * sitting, sin(_time * (5.0 if state == State.RUN else 1.7)) * (0.5 + 0.3 * moving), 0)
