class_name Npc
extends AnimatableBody3D
## One of the people of the city. Kinematic and cheap: all the motion is a few
## rotating joints.
##
##  WALK   finds a way along the pavements (Sidewalks, A*) to a shop door or a
##         spot to hang about, keeps to the right, steps round other people,
##         waits at crossings for traffic, pops into shops, then goes
##         somewhere else.
##  STAND  hangs about, chats, watches a show.
##  SIT    the same, sitting down.
##
## Anyone hit by the player's truck goes flying as a floppy rag doll (a real
## rigid body), costs the driver $5, lies there for a moment, gets up, shakes
## it off and carries on.
##
## Everyone gets their own clothes, hair, size and timing from `look_seed`, so
## a crowd never moves in step.

enum Mode { WALK, STAND, SIT }
enum State { NORMAL, PAUSE, INSIDE, WAIT, DOWN, GET_UP, DIZZY, RETURN }

@export var mode := Mode.STAND
@export var walk_speed := 1.25
## Different number = different-looking, differently-timed person. 0 = pick from the position.
@export var look_seed := 0
@export var has_umbrella := false
## What the driver pays for knocking this person over.
@export var fine := 5

## 0..1: how much this person is enjoying the show (set by the venue).
var excitement := 0.5
var state := State.NORMAL

const SHIRTS: Array[Color] = [Color("ff5d8f"), Color("ffd166"), Color("3ddbd9"), Color("7f8cff"), Color("c77dff"), Color("ff8a5b"),
		Color("f4f1de"), Color("81b29a"), Color("e07a5f"), Color("3d5a80"), Color("9bf6ff"), Color("ffadad")]
const PANTS: Array[Color] = [Color("2b2d42"), Color("3d405b"), Color("1d3557"), Color("4a4e69"), Color("6d597a"), Color("264653"), Color("5c4742")]
const SKINS: Array[Color] = [Color("ffd6b8"), Color("f1c27d"), Color("e0ac69"), Color("c68642"), Color("8d5524"), Color("ffe0cc")]
const HAIRS: Array[Color] = [Color("2b2118"), Color("5b3a29"), Color("1a1a24"), Color("d9a441"), Color("b23a48"), Color("e0e0e8"), Color("3ddbd9"), Color("ff5d8f")]
const UMBRELLAS: Array[Color] = [Color("ff8fab"), Color("f4f1de"), Color("9bf6ff"), Color("ffd166"), Color("c77dff"), Color("2b2d42")]
const BONK := preload("res://audio/sfx/bonk.ogg")
const SQUEAK := preload("res://audio/sfx/squeak.ogg")
const PENALTY := preload("res://audio/sfx/penalty.ogg")
const FONT := preload("res://art/fonts/fredoka_semibold.tres")

# Everyone who is out and about (for stepping round each other).
static var _everyone: Array[Npc] = []

var _random := RandomNumberGenerator.new()
var _time := 0.0
var _phase := 0.0
var _watching: Node3D = null
var _cheer := 0.0
var _cheer_level := 0.0
var _gesture := 0.0
var _next_gesture := 3.0
var _clap_tempo := 1.0
var _shy := false
var _home_yaw := 0.0
var _home_position := Vector3.ZERO
var _base_y := 0.0
var _head_yaw := 0.0
var _walk_blend := 0.0
var _present := true

# Walking.
var _net: Sidewalks
var _route := PackedInt64Array()
var _route_at := 0
var _velocity := Vector3.ZERO
var _lane := 0.3
var _timer := 0.0
var _stuck_timer := 0.0
var _best_distance := INF
var _clear_time := 0.0
var _scared := false

# Being knocked over.
var _tumbler: RigidBody3D
var _still_time := 0.0
var _down_time := 0.0
var _rise_from := Transform3D.IDENTITY
var _grace := 0.0

@onready var _body: Node3D = $Body
@onready var _head: Node3D = $Body/Head
@onready var _arms: Array[Node3D] = [$Body/ArmL, $Body/ArmR]
@onready var _legs: Array[Node3D] = [$Body/LegL, $Body/LegR]
@onready var _umbrella: Node3D = $Body/Umbrella
@onready var _player: Node3D = get_tree().get_first_node_in_group(&"player")
@onready var _truck: Truck = get_tree().get_first_node_in_group(&"truck")


func _ready() -> void:
	add_to_group(&"npc")
	_everyone.append(self)
	_random.seed = look_seed if look_seed != 0 else hash(global_position.snappedf(0.01))
	_dress()
	_phase = _random.randf() * TAU
	_clap_tempo = _random.randf_range(0.85, 1.2)
	_shy = _random.randf() < 0.2
	_next_gesture = _random.randf_range(1.0, 6.0)
	_lane = _random.randf_range(0.2, 0.42)
	_home_yaw = global_rotation.y
	_home_position = global_position
	_base_y = _body.position.y
	# People are solid to someone on foot, and cars wait for them, but a truck
	# does not stop for a pedestrian: it sends them flying.
	collision_layer = 16
	_umbrella.visible = has_umbrella and mode != Mode.SIT
	if mode == Mode.WALK:
		_net = get_tree().get_first_node_in_group(&"sidewalks")
		_timer = _random.randf_range(0.0, 2.0)
		state = State.PAUSE


func _exit_tree() -> void:
	_everyone.erase(self)


# Own colours, hair and build.
func _dress() -> void:
	var colors := {
		"Shirt": SHIRTS[_random.randi() % SHIRTS.size()],
		"Pants": PANTS[_random.randi() % PANTS.size()],
		"Skin": SKINS[_random.randi() % SKINS.size()],
		"Hair": HAIRS[_random.randi() % HAIRS.size()],
		"Brolly": UMBRELLAS[_random.randi() % UMBRELLAS.size()],
	}
	var materials := {}
	for node in find_children("*", "MeshInstance3D"):
		var mesh := node as MeshInstance3D
		for part: String in colors:
			if mesh.name.begins_with(part):
				if not materials.has(part):
					var material: ShaderMaterial = mesh.mesh.surface_get_material(0).duplicate()
					material.set_shader_parameter(&"albedo", colors[part])
					materials[part] = material
				mesh.material_override = materials[part]
	var style := _random.randi() % 4
	for i in 4:
		var hair := get_node_or_null("Body/Head/Hair%d" % i) as Node3D
		if hair:
			hair.visible = i == style
	var height := _random.randf_range(0.9, 1.08)
	_body.scale = Vector3(_random.randf_range(0.92, 1.1), height, _random.randf_range(0.92, 1.1))


## Here or not: a crowd that only turns up for a gig takes its bodies with it.
func set_present(here: bool) -> void:
	_present = here
	visible = here
	collision_layer = 16 if here and state != State.DOWN and state != State.INSIDE else 0


## Turn to face someone and react to how they play.
func watch(who: Node3D) -> void:
	_watching = who


## End of the show: a few seconds of applause, as hearty as the show was good.
func cheer(how_good: float) -> void:
	_cheer = _random.randf_range(3.5, 5.0)
	_cheer_level = how_good


func relax() -> void:
	_watching = null
	excitement = 0.5


func is_watching() -> bool:
	return _watching != null


## True from the moment of being knocked over until back on both feet.
func is_down() -> bool:
	return state == State.DOWN or state == State.GET_UP or state == State.DIZZY


func _physics_process(delta: float) -> void:
	_time += delta
	_cheer = maxf(_cheer - delta, 0.0)
	_grace = maxf(_grace - delta, 0.0)
	match state:
		State.DOWN:
			_lie_there(delta)
			return
		State.GET_UP:
			_get_up(delta)
			return
		State.DIZZY:
			_shake_it_off(delta)
			return
		State.INSIDE:
			_timer -= delta
			if _timer <= 0.0:
				visible = _present
				collision_layer = 16
				state = State.NORMAL
				_pick_goal()
			return
	if _present and _hit_by_truck():
		return
	if state == State.RETURN:
		_walk_home(delta)
	elif mode == Mode.WALK:
		_walk(delta)
	else:
		_idle(delta)


# ---------------------------------------------------------------- walking

func _walk(delta: float) -> void:
	if _net == null:
		_idle(delta)
		return
	var wanted := Vector3.ZERO
	_scared = false
	match state:
		State.PAUSE:
			_timer -= delta
			if _timer <= 0.0:
				state = State.NORMAL
				_pick_goal()
		State.WAIT:
			# At the kerb: look both ways, go when it has been clear for a moment.
			_clear_time = _clear_time + delta if _road_clear(_net.position_of(_route[_route_at])) else 0.0
			_head_yaw = lerpf(_head_yaw, sin(_time * 2.2) * 0.9, 1.0 - exp(-6.0 * delta))
			if _clear_time > 0.5:
				state = State.NORMAL
		State.NORMAL:
			wanted = _steer()
	wanted += _step_aside(wanted)
	wanted += _flee_truck()
	var limit := walk_speed * (2.6 if _scared else 1.15)
	if wanted.length() > limit:
		wanted = wanted.normalized() * limit
	_move(wanted, delta, 9.0 if _scared else 5.0)
	if state == State.NORMAL:
		_look_around(delta)
	else:
		_head.rotation.y = _head_yaw


# Where the route says to go next, as a velocity.
func _steer() -> Vector3:
	if _route_at >= _route.size():
		_arrive()
		return Vector3.ZERO
	var id := _route[_route_at]
	var target := _net.position_of(id)
	var from := _net.position_of(_route[_route_at - 1]) if _route_at > 0 else global_position
	var along := target - from
	along.y = 0.0
	# Keep to the right of the line, like everyone else, so people pass each other.
	if along.length() > 0.5 and _net.kind_of(id) != Sidewalks.Kind.DOOR:
		along = along.normalized()
		target += Vector3(-along.z, 0.0, along.x) * _lane
	var to := target - global_position
	to.y = 0.0
	var distance := to.length()
	if distance < 0.45:
		_route_at += 1
		_best_distance = INF
		_stuck_timer = 0.0
		# About to step into the road? Check for traffic first.
		if _route_at < _route.size() and _net.kind_of(_route[_route_at]) == Sidewalks.Kind.ROAD \
				and _net.kind_of(id) != Sidewalks.Kind.ROAD and not _road_clear(_net.position_of(_route[_route_at])):
			state = State.WAIT
			_clear_time = 0.0
		return Vector3.ZERO
	# Getting nowhere (something in the way that won't move)? Go somewhere else.
	if distance < _best_distance - 0.25:
		_best_distance = distance
		_stuck_timer = 0.0
	else:
		_stuck_timer += get_physics_process_delta_time()
		if _stuck_timer > 4.0:
			_pick_goal()
			return Vector3.ZERO
	# Ease off for the last step so the stop isn't a jolt.
	var last := _route_at == _route.size() - 1
	return to / distance * walk_speed * (clampf(distance / 1.2, 0.35, 1.0) if last else 1.0)


func _arrive() -> void:
	var kind := _net.kind_of(_route[_route.size() - 1]) if not _route.is_empty() else Sidewalks.Kind.PAVEMENT
	if kind == Sidewalks.Kind.DOOR:
		# Into the shop for a while.
		state = State.INSIDE
		_timer = _random.randf_range(4.0, 12.0)
		_velocity = Vector3.ZERO
		visible = false
		collision_layer = 0
	else:
		state = State.PAUSE
		_timer = _random.randf_range(2.5, 9.0) if kind == Sidewalks.Kind.SPOT else _random.randf_range(0.3, 1.5)


func _pick_goal() -> void:
	var goal := _net.random_goal(_random, global_position)
	_route = _net.route(global_position, goal)
	_route_at = 0
	_best_distance = INF
	_stuck_timer = 0.0
	if _route.size() < 2:
		state = State.PAUSE
		_timer = 1.5


# No car bearing down on this bit of road?
func _road_clear(road_point: Vector3) -> bool:
	for node in get_tree().get_nodes_in_group(&"traffic_car"):
		var car := node as TrafficCar
		if car.speed > 1.0 and _coming_at(car.global_position, -car.global_basis.z, road_point, 14.0):
			return false
	if _truck and _truck.driver and absf(_truck.speed) > 1.0 \
			and _coming_at(_truck.global_position, -_truck.global_basis.z * signf(_truck.speed), road_point, 16.0):
		return false
	return true


func _coming_at(from: Vector3, heading: Vector3, point: Vector3, within: float) -> bool:
	var to := point - from
	to.y = 0.0
	var distance := to.length()
	return distance < within and distance > 0.01 and (to / distance).dot(heading) > 0.6


# A nudge away from anyone too close, biased to the right so two people
# walking at each other don't dance.
func _step_aside(wanted: Vector3) -> Vector3:
	var push := Vector3.ZERO
	var heading := wanted.normalized() if wanted.length() > 0.1 else Vector3.ZERO
	for other in _everyone:
		if other != self and other.visible and other.state != State.DOWN:
			push += _avoid(other.global_position, heading, 1.0)
	if _player and _player.visible:
		push += _avoid(_player.global_position, heading, 1.25)
	# Walk round the parked truck (and its ramp), not through it. A truck
	# with someone at the wheel is the driver's problem (see _flee_truck).
	if _truck and _truck.driver == null:
		var local := _truck.to_local(global_position)
		var tail := 5.8 if _truck.door_open else 3.4       # the ramp counts when it is down
		if absf(local.x) < 2.4 and local.z > -3.6 and local.z < tail and absf(local.y) < 2.0:
			# Out by the nearest way: a side, or round the back.
			var to_side := 2.4 - absf(local.x)
			var to_tail := tail - local.z
			if to_tail < to_side:
				push += _truck.global_basis.z * (to_tail + 0.3) * 2.5
			else:
				push += _truck.global_basis.x * (1.0 if local.x >= 0.0 else -1.0) * (to_side + 0.3) * 2.5
	return push


func _avoid(other: Vector3, heading: Vector3, reach: float) -> Vector3:
	var gap := global_position - other
	gap.y = 0.0
	var distance := gap.length()
	if distance >= reach or distance < 0.01:
		return Vector3.ZERO
	var weight := (reach - distance) / reach
	var push := gap / distance * weight * 1.8
	if heading != Vector3.ZERO and gap.dot(heading) < 0.0:
		push += Vector3(-heading.z, 0.0, heading.x) * weight * 1.2
	return push


# A truck coming slowly enough to be heard gets a wide berth. A fast one doesn't.
func _flee_truck() -> Vector3:
	if _truck == null or _truck.driver == null:
		return Vector3.ZERO
	var speed := absf(_truck.speed)
	if speed < 1.5 or speed > 8.0:
		return Vector3.ZERO
	var gap := global_position - _truck.global_position
	gap.y = 0.0
	var heading := -_truck.global_basis.z * signf(_truck.speed)
	var ahead := gap.dot(heading)
	var side := _truck.global_basis.x
	var across := gap.dot(side)
	if ahead < -3.5 or ahead > 4.0 + speed * 0.9 or absf(across) > 2.6:
		return Vector3.ZERO
	_scared = true
	var away := side * (1.0 if across >= 0.0 else -1.0)
	# Out of the way, but not through a shop front: stay on (or right beside) the pavement.
	if _net and _net.distance_to_network(global_position + away * 0.6) > 1.5:
		return Vector3.ZERO
	return away * walk_speed * 2.6


func _move(wanted: Vector3, delta: float, response: float) -> void:
	_velocity = _velocity.lerp(wanted, 1.0 - exp(-response * delta))
	var speed := _velocity.length()
	if speed > 0.02:
		global_position += _velocity * delta
	if speed > 0.25:
		global_rotation.y = lerp_angle(global_rotation.y, atan2(-_velocity.x, -_velocity.z), 1.0 - exp(-7.0 * delta))
	# Legs and arms swing with the distance covered, the body bobs.
	_walk_blend = move_toward(_walk_blend, clampf(speed / walk_speed, 0.0, 1.3), delta * 5.0)
	_phase += speed * 3.4 * delta
	var swing := sin(_phase) * 0.6 * minf(_walk_blend, 1.0)
	_legs[0].rotation.x = swing
	_legs[1].rotation.x = -swing
	_arms[0].rotation = Vector3(-swing * 0.7, 0, -1.2 if _scared else 0.0)
	_arms[1].rotation = Vector3(-2.6 if has_umbrella else swing * 0.7, 0, 1.2 if _scared and not has_umbrella else 0.0)
	_body.position.y = _base_y + absf(sin(_phase)) * 0.04 * minf(_walk_blend, 1.0)
	_body.rotation = Vector3(0.0, 0.0, 0.0)


# After being knocked over: someone who was standing or sitting goes back to their spot.
func _walk_home(delta: float) -> void:
	var to := _home_position - global_position
	to.y = 0.0
	var distance := to.length()
	if distance < 0.15:
		global_position = _home_position
		state = State.NORMAL
		_velocity = Vector3.ZERO
		return
	_move(to / distance * walk_speed * clampf(distance / 0.8, 0.4, 1.0), delta, 5.0)
	global_position.y = move_toward(global_position.y, _home_position.y, delta * 2.0)
	_look_around(delta)


# ---------------------------------------------------------------- standing and sitting

func _idle(delta: float) -> void:
	var sitting := mode == Mode.SIT
	var leg := -1.45 if sitting else 0.0
	_legs[0].rotation.x = leg + (sin(_time * 1.3 + _phase) * 0.12 if sitting else 0.0)
	_legs[1].rotation.x = leg
	var bob := 0.0
	var arms := [Vector3(-0.5 if sitting else 0.0, 0, 0), Vector3(-0.5 if sitting else 0.0, 0, 0)]
	var lean := sin(_time * 0.7 + _phase) * 0.03
	_head.rotation.x = 0.0

	if _watching:
		# Face the music.
		var to := _watching.global_position - global_position
		global_rotation.y = lerp_angle(global_rotation.y, atan2(-to.x, -to.z), 1.0 - exp(-3.0 * delta))
	if _cheer > 0.0:
		# Applause: a standing ovation for a great show, polite clapping for a poor one.
		var clap := sin(_time * 14.0 * _clap_tempo + _phase)
		if _cheer_level > 0.6 and not _shy:
			arms = [Vector3(-2.7, 0, 0.35 + clap * 0.25), Vector3(-2.7, 0, -0.35 - clap * 0.25)]
			bob = absf(sin(_time * 6.0 + _phase)) * (0.05 if sitting else 0.22)
		else:
			arms = [Vector3(-1.2, 0, 0.5 + clap * 0.18), Vector3(-1.2, 0, -0.5 - clap * 0.18)]
	elif _watching:
		if excitement > 0.62 and not _shy:
			# Into it: clapping along and bouncing.
			var clap := sin(_time * 9.0 * _clap_tempo + _phase)
			arms = [Vector3(-1.3, 0, 0.5 + clap * 0.2), Vector3(-1.3, 0, -0.5 - clap * 0.2)]
			bob = absf(sin(_time * 4.4 * _clap_tempo + _phase)) * (0.03 if sitting else 0.1)
			lean = sin(_time * 2.2 + _phase) * 0.08
		elif excitement > 0.35:
			# Nodding along.
			_head.rotation.x = sin(_time * 4.4 * _clap_tempo + _phase) * 0.14
			lean = sin(_time * 2.2 + _phase) * 0.05
		else:
			# Not feeling it: arms folded, looking elsewhere.
			arms = [Vector3(-0.9, 0, 0.75), Vector3(-0.9, 0, -0.75)]
			_head_yaw = lerpf(_head_yaw, 0.7 * (1.0 if _phase > PI else -1.0), 1.0 - exp(-2.0 * delta))
	else:
		# Hanging out: now and then wave a hand about while talking.
		_next_gesture -= delta
		if _next_gesture <= 0.0:
			_next_gesture = _random.randf_range(2.5, 8.0)
			_gesture = _random.randf_range(0.8, 1.6)
		if _gesture > 0.0:
			_gesture -= delta
			arms[1] = Vector3(-1.5 + sin(_time * 7.0) * 0.3, 0, -0.2)
			_head.rotation.x = sin(_time * 5.0) * 0.08
		global_rotation.y = lerp_angle(global_rotation.y, _home_yaw, 1.0 - exp(-2.0 * delta))

	var blend := 1.0 - exp(-10.0 * delta)
	for i in 2:
		_arms[i].rotation = _arms[i].rotation.lerp(arms[i], blend)
	_body.position.y = _base_y + bob - (0.36 if sitting else 0.0)
	_body.rotation = Vector3(0.0, 0.0, lean)
	if excitement <= 0.35 and _watching and _cheer <= 0.0:
		_head.rotation.y = _head_yaw
	else:
		_look_around(delta)


# Glance at the player when they come close; look up at a show on a balcony.
func _look_around(delta: float) -> void:
	var wanted := 0.0
	var up := 0.0
	var subject: Node3D = _watching if _watching else _player
	if subject and subject.visible:
		var to := global_basis.inverse() * (subject.global_position - _head.global_position)
		if to.length() < 5.0 or _watching:
			wanted = clampf(atan2(-to.x, -to.z), -1.1, 1.1)
			if _watching:
				up = clampf(atan2(to.y, Vector2(to.x, to.z).length()), -0.3, 0.9)
	_head_yaw = lerpf(_head_yaw, wanted, 1.0 - exp(-4.0 * delta))
	_head.rotation.y = _head_yaw
	_head.rotation.x += up


# ---------------------------------------------------------------- knocked over

# Is the driven truck's body on top of us right now?
func _hit_by_truck() -> bool:
	if _truck == null or _truck.driver == null or _grace > 0.0 or absf(_truck.speed) < 2.0:
		return false
	var local := _truck.to_local(global_position + Vector3.UP * 0.6)
	if absf(local.x) > 1.4 or local.z < -2.8 or local.z > 3.25 or local.y < -0.5 or local.y > 3.0:
		return false
	# Only the end that is moving into them counts: walking into the side of a
	# truck that is pulling away is not being run over.
	if local.z * signf(_truck.speed) > -1.0:
		return false
	var heading := -_truck.global_basis.z * signf(_truck.speed)
	var speed := absf(_truck.speed)
	var fling := heading * speed * 1.05 + _truck.global_basis.x * signf(local.x + 0.001) * (2.0 + speed * 0.15) + Vector3.UP * (3.0 + speed * 0.3)
	knock_down(fling)
	Career.fine(fine, "Mind the pedestrians!")
	Sfx.play(self, PENALTY, -4.0)
	_float_text("-$%d" % fine)
	return true


## Sends this person flying as a rag doll. Free of charge: the fine is the truck's business.
func knock_down(fling: Vector3) -> void:
	if is_down():
		return
	state = State.DOWN
	_down_time = 0.0
	_still_time = 0.0
	_velocity = Vector3.ZERO
	collision_layer = 0
	visible = true
	_umbrella.visible = false
	# A real rigid body takes over: it tumbles, bounces off walls, gets shunted by the truck.
	_tumbler = RigidBody3D.new()
	_tumbler.mass = 45.0
	_tumbler.collision_layer = 4
	_tumbler.collision_mask = 0b101
	var bounce := PhysicsMaterial.new()
	bounce.bounce = 0.45
	bounce.friction = 0.7
	_tumbler.physics_material_override = bounce
	_tumbler.angular_damp = 1.2
	var shape := CollisionShape3D.new()
	var capsule := CapsuleShape3D.new()
	capsule.radius = 0.27
	capsule.height = 1.25
	shape.shape = capsule
	_tumbler.add_child(shape)
	get_parent().add_child(_tumbler)
	_tumbler.global_transform = Transform3D(global_basis.orthonormalized(), global_position + Vector3.UP * 0.75)
	_body.reparent(_tumbler)
	_tumbler.linear_velocity = fling
	var spin_axis := Vector3.UP.cross(fling).normalized() if fling.length() > 0.1 else Vector3.RIGHT
	_tumbler.angular_velocity = spin_axis * _random.randf_range(6.0, 11.0) + Vector3.UP * _random.randf_range(-4.0, 4.0)
	_tumbler.reset_physics_interpolation()
	Sfx.play_at(self, BONK, global_position, 2.0, _random.randf_range(0.9, 1.15))
	Sfx.play_at(self, SQUEAK, global_position, -2.0, _random.randf_range(0.85, 1.3))


func _lie_there(delta: float) -> void:
	_down_time += delta
	global_position = Vector3(_tumbler.global_position.x, global_position.y, _tumbler.global_position.z)
	# Arms and legs flop about while airborne, then go limp.
	var flail := clampf(_tumbler.linear_velocity.length() / 4.0, 0.0, 1.0)
	for i in 2:
		var side := 1.0 if i == 0 else -1.0
		_arms[i].rotation = Vector3(-1.6 + sin(_time * 17.0 + i * 2.0) * 1.2 * flail, 0, side * (0.9 + sin(_time * 13.0 + i) * 0.5 * flail))
		_legs[i].rotation.x = sin(_time * 15.0 + i * PI) * 0.9 * flail
	_head.rotation = Vector3(sin(_time * 11.0) * 0.4 * flail, 0, sin(_time * 9.0) * 0.3 * flail)
	_still_time = _still_time + delta if _tumbler.linear_velocity.length() < 0.35 else 0.0
	if (_still_time > 1.6 and _down_time > 2.2) or _down_time > 9.0:
		# Back onto the feet, wherever they ended up.
		var ground := _tumbler.global_position
		var ray := PhysicsRayQueryParameters3D.create(ground + Vector3.UP * 0.4, ground + Vector3.DOWN * 3.0, 1)
		var hit := get_world_3d().direct_space_state.intersect_ray(ray)
		global_position = hit.position if hit else Vector3(ground.x, 0.0, ground.z)
		_body.reparent(self)
		_rise_from = _body.transform
		_tumbler.queue_free()
		_tumbler = null
		_timer = 0.0
		state = State.GET_UP
		reset_physics_interpolation()


func _get_up(delta: float) -> void:
	_timer += delta
	var t := clampf(_timer / 0.9, 0.0, 1.0)
	var eased := t * t * (3.0 - 2.0 * t)
	var standing := Transform3D(Basis.from_scale(_rise_from.basis.get_scale()), Vector3(0, _base_y, 0))
	_body.transform = _rise_from.interpolate_with(standing, eased)
	for i in 2:
		_arms[i].rotation = _arms[i].rotation.lerp(Vector3(-0.6, 0, 0), 1.0 - exp(-6.0 * delta))
		_legs[i].rotation.x = lerpf(_legs[i].rotation.x, 0.0, 1.0 - exp(-6.0 * delta))
	if t >= 1.0:
		_body.transform = standing
		_timer = 0.0
		state = State.DIZZY


func _shake_it_off(delta: float) -> void:
	_timer += delta
	# Seeing stars: the head goes round, one hand comes up to it.
	_head.rotation = Vector3(sin(_time * 7.0) * 0.25, 0, cos(_time * 7.0) * 0.25)
	_body.rotation.z = sin(_time * 5.0) * 0.08
	_arms[0].rotation = _arms[0].rotation.lerp(Vector3(-2.4, 0, 0.5), 1.0 - exp(-8.0 * delta))
	_arms[1].rotation = _arms[1].rotation.lerp(Vector3.ZERO, 1.0 - exp(-8.0 * delta))
	if _timer > 1.4:
		_head.rotation = Vector3.ZERO
		_body.rotation = Vector3.ZERO
		collision_layer = 16 if _present else 0
		_umbrella.visible = has_umbrella and mode != Mode.SIT
		# No second fine while they are still finding their feet.
		_grace = 2.0
		if mode == Mode.WALK:
			state = State.PAUSE
			_timer = 0.5
		else:
			state = State.RETURN


# The price of it, floating up from where it happened.
func _float_text(text: String) -> void:
	var label := Label3D.new()
	label.text = text
	label.font = FONT
	label.font_size = 96
	label.pixel_size = 0.006
	label.outline_size = 24
	label.modulate = Color("ff5566")
	label.outline_modulate = Color("2b0d14")
	label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	label.no_depth_test = true
	get_parent().add_child(label)
	label.global_position = global_position + Vector3.UP * 2.0
	var tween := label.create_tween()
	tween.tween_property(label, "global_position", label.global_position + Vector3.UP * 1.6, 1.4).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_CUBIC)
	tween.parallel().tween_property(label, "modulate:a", 0.0, 0.5).set_delay(0.9)
	tween.parallel().tween_property(label, "outline_modulate:a", 0.0, 0.5).set_delay(0.9)
	tween.tween_callback(label.queue_free)
